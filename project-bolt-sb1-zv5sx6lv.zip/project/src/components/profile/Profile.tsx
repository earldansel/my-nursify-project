import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/components/ui/Toast';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Modal from '@/components/ui/Modal';
import {
  Crown, Mail, Calendar, MessageCircle, Lock, Pencil, Check,
  TrendingUp, Target, Award, Flame, Save, User as UserIcon,
} from 'lucide-react';
import { PREMIUM_FACEBOOK_URL } from '@/config';
import { getLearningProgress, getLevel, getStreak, type Achievement } from '@/lib/learning';

interface ProfileProps {
  onNavigate: (view: 'dashboard' | 'pricing' | 'landing') => void;
}

interface UserStats {
  total_questions_answered: number;
  total_correct: number;
  total_tests_completed: number;
  current_streak: number;
  best_streak: number;
  avg_accuracy: number;
}

export default function Profile({ onNavigate }: ProfileProps) {
  const { user, profile, signOut, isPremium, refreshProfile, updatePassword } = useAuth();
  const { toast } = useToast();
  const [stats, setStats] = useState<UserStats | null>(null);
  const [statsLoading, setStatsLoading] = useState(true);
  const [learning, setLearning] = useState<{ xp: number; activity: { activity_date: string }[]; achievements: Achievement[] } | null>(null);

  const [editOpen, setEditOpen] = useState(false);
  const [editName, setEditName] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  const [pwOpen, setPwOpen] = useState(false);
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [pwLoading, setPwLoading] = useState(false);

  const fetchStats = useCallback(async () => {
    if (!user) return;
    setStatsLoading(true);
    const { data, error } = await supabase.rpc('get_user_stats');
    if (error) {
      console.error('Error fetching stats:', error);
    } else if (data) {
      setStats(data as unknown as UserStats);
    }
    setStatsLoading(false);
  }, [user]);

  useEffect(() => {
    fetchStats();
    getLearningProgress().then(setLearning);
  }, [fetchStats]);

  if (!user || !profile) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center px-5">
        <Card className="p-8 text-center max-w-md">
          <p className="text-secondary">Please sign in to view your profile.</p>
          <Button className="mt-6" onClick={() => onNavigate('landing')}>Go Home</Button>
        </Card>
      </div>
    );
  }

  const openEdit = () => {
    setEditName(profile.full_name);
    setEditAvatar(profile.avatar_url ?? '');
    setEditOpen(true);
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    setSavingProfile(true);
    const { error } = await supabase
      .from('profiles')
      .update({
        full_name: editName,
        avatar_url: editAvatar,
        updated_at: new Date().toISOString(),
      })
      .eq('id', user.id);

    if (error) {
      toast({ title: 'Update failed', description: error.message, variant: 'error' });
    } else {
      toast({ title: 'Profile updated', variant: 'success' });
      await refreshProfile();
      setEditOpen(false);
    }
    setSavingProfile(false);
  };

  const handleChangePassword = async () => {
    if (newPw !== confirmPw) {
      toast({ title: 'Passwords do not match', variant: 'warning' });
      return;
    }
    if (newPw.length < 6) {
      toast({ title: 'Password must be at least 6 characters', variant: 'warning' });
      return;
    }

    setPwLoading(true);

    // Verify current password by re-authenticating
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: user.email!,
      password: currentPw,
    });

    if (signInError) {
      toast({ title: 'Current password is incorrect', variant: 'error' });
      setPwLoading(false);
      return;
    }

    // Update password
    const { error: updateError } = await updatePassword(newPw);
    if (updateError) {
      toast({ title: 'Password change failed', description: updateError, variant: 'error' });
    } else {
      toast({ title: 'Password changed successfully', variant: 'success' });
      setPwOpen(false);
      setCurrentPw('');
      setNewPw('');
      setConfirmPw('');
    }
    setPwLoading(false);
  };

  const avatar = profile.avatar_url;
  const initials = (profile.full_name || user.email || '?').charAt(0).toUpperCase();

  return (
    <div className="min-h-screen bg-surface">
      <header className="sticky top-0 z-50 glass border-b border-subtle">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
          <button onClick={() => onNavigate('dashboard')} className="flex items-center gap-2.5">
            <span className="w-8 h-8 gradient-brand rounded-full flex items-center justify-center">
              <span className="w-2.5 h-2.5 bg-white rounded-full animate-pulse" />
            </span>
            <span className="font-bold text-lg text-primary">Nursify</span>
          </button>
          <Button size="sm" variant="ghost" onClick={() => onNavigate('dashboard')}>
            Dashboard
          </Button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-5 sm:px-8 py-8 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-extrabold text-primary">My Profile</h1>
          <Button size="sm" variant="outline" onClick={openEdit}>
            <Pencil className="w-4 h-4" />
            Edit Profile
          </Button>
        </div>

        {/* Profile Card */}
        <Card className="p-6">
          <div className="flex items-center gap-4">
            {avatar ? (
              <img
                src={avatar}
                alt={profile.full_name}
                className="w-16 h-16 rounded-full object-cover shrink-0 border-2 border-subtle"
              />
            ) : (
              <div className="w-16 h-16 rounded-full gradient-brand flex items-center justify-center text-white font-bold text-xl shrink-0">
                {initials}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-lg font-bold text-primary">{profile.full_name || 'User'}</p>
              <p className="text-sm text-secondary truncate">{user.email}</p>
              <div className="mt-2 flex items-center gap-2">
                {isPremium ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-violet-100 dark:bg-violet-950/50 text-violet-700 dark:text-violet-300 text-xs font-bold">
                    <Crown className="w-3.5 h-3.5" />
                    Premium
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-ink-100 dark:bg-ink-800 text-secondary text-xs font-bold">
                    Free Plan
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-ink-50 dark:bg-ink-900/50">
              <Mail className="w-4 h-4 text-secondary" />
              <div className="min-w-0">
                <p className="text-xs text-secondary">Email</p>
                <p className="text-sm font-medium text-primary truncate">{user.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-xl bg-ink-50 dark:bg-ink-900/50">
              <Calendar className="w-4 h-4 text-secondary" />
              <div>
                <p className="text-xs text-secondary">Member since</p>
                <p className="text-sm font-medium text-primary">
                  {new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </p>
              </div>
            </div>
            <div className={`flex items-center gap-3 p-3 rounded-xl ${isPremium ? 'bg-violet-50 dark:bg-violet-950/30' : 'bg-ink-50 dark:bg-ink-900/50'}`}>
              {isPremium ? (
                <Crown className="w-4 h-4 text-violet-600 dark:text-violet-400" />
              ) : (
                <UserIcon className="w-4 h-4 text-secondary" />
              )}
              <div>
                <p className="text-xs text-secondary">Plan</p>
                <p className={`text-sm font-medium ${isPremium ? 'text-violet-700 dark:text-violet-300' : 'text-primary'}`}>
                  {isPremium ? 'Premium' : 'Free Plan'}
                </p>
              </div>
            </div>
            {isPremium && profile.premium_expires_at && (
              <div className="flex items-center gap-3 p-3 rounded-xl bg-violet-50 dark:bg-violet-950/30">
                <Calendar className="w-4 h-4 text-violet-600 dark:text-violet-400" />
                <div>
                  <p className="text-xs text-secondary">Premium expires</p>
                  <p className="text-sm font-medium text-primary">
                    {new Date(profile.premium_expires_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                  </p>
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Study Statistics */}
        <Card className="p-6">
          <h2 className="text-lg font-bold text-primary mb-4">Study Statistics</h2>
          {statsLoading ? (
            <p className="text-sm text-secondary">Loading stats...</p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <StatBox
                icon={Target}
                label="Questions"
                value={stats?.total_questions_answered?.toLocaleString() ?? '0'}
                color="text-blue-600 dark:text-blue-400"
              />
              <StatBox
                icon={TrendingUp}
                label="Accuracy"
                value={`${stats?.avg_accuracy ?? 0}%`}
                color="text-mint-600 dark:text-mint-400"
              />
              <StatBox
                icon={Award}
                label="Tests Done"
                value={stats?.total_tests_completed?.toLocaleString() ?? '0'}
                color="text-violet-600 dark:text-violet-400"
              />
              <StatBox
                icon={Flame}
                label="Streak"
                value={`${stats?.current_streak ?? 0}d`}
                color="text-amber-600 dark:text-amber-400"
              />
            </div>
          )}
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div><p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wide">Progress</p><h2 className="text-lg font-bold text-primary">Level {getLevel(learning?.xp ?? 0).level} · {getLevel(learning?.xp ?? 0).title}</h2></div>
            <span className="text-sm font-bold text-violet-600 dark:text-violet-400">{learning?.xp ?? 0} XP</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-3 rounded-xl bg-ink-50 dark:bg-ink-900/50"><p className="text-lg font-bold text-primary">{getStreak(learning?.activity ?? []).current}</p><p className="text-xs text-secondary">Current streak</p></div>
            <div className="p-3 rounded-xl bg-ink-50 dark:bg-ink-900/50"><p className="text-lg font-bold text-primary">{getStreak(learning?.activity ?? []).longest}</p><p className="text-xs text-secondary">Longest streak</p></div>
            <div className="p-3 rounded-xl bg-ink-50 dark:bg-ink-900/50"><p className="text-lg font-bold text-primary">{getStreak(learning?.activity ?? []).activeDays}</p><p className="text-xs text-secondary">Active days</p></div>
            <div className="p-3 rounded-xl bg-ink-50 dark:bg-ink-900/50"><p className="text-lg font-bold text-primary">{getLevel(learning?.xp ?? 0).current}/100</p><p className="text-xs text-secondary">Next level</p></div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4"><div><p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wide">Milestones</p><h2 className="text-lg font-bold text-primary">Achievements</h2></div><Award className="w-5 h-5 text-amber-500" /></div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {(learning?.achievements ?? []).map((achievement) => <div key={achievement.key} className={`flex items-center gap-3 p-3 rounded-xl border ${achievement.unlockedAt ? 'border-amber-200 bg-amber-50/60 dark:border-amber-900 dark:bg-amber-950/20' : 'border-subtle opacity-55'}`}><span className="text-lg">{achievement.unlockedAt ? '★' : '○'}</span><div><p className="text-sm font-semibold text-primary">{achievement.title}</p><p className="text-xs text-secondary">{achievement.description}</p></div></div>)}
          </div>
        </Card>

        {/* Change Password */}
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-ink-50 dark:bg-ink-900/50 flex items-center justify-center shrink-0">
              <Lock className="w-5 h-5 text-secondary" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-primary">Password</h3>
              <p className="mt-0.5 text-sm text-secondary">Change your account password</p>
            </div>
            <Button size="sm" variant="outline" onClick={() => setPwOpen(true)}>
              Change
            </Button>
          </div>
        </Card>

        {/* Upgrade Card */}
        {!isPremium && (
          <Card className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl gradient-brand flex items-center justify-center shrink-0">
                <Crown className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-primary">Upgrade to Premium</h3>
                <p className="mt-1 text-sm text-secondary">
                  Get full access to 12,000+ questions, CAT simulations, NGN case studies, and advanced analytics.
                </p>
                <div className="mt-3 flex items-center gap-2">
                  <a href={PREMIUM_FACEBOOK_URL} target="_blank" rel="noopener noreferrer">
                    <Button size="sm" withArrow>
                      <MessageCircle className="w-4 h-4" />
                      Get Premium
                    </Button>
                  </a>
                </div>
              </div>
            </div>
          </Card>
        )}

        <div className="pt-2">
          <Button
            variant="outline"
            onClick={async () => {
              await signOut();
              onNavigate('landing');
            }}
            className="border-rose-200 text-rose-600 hover:bg-rose-50 dark:border-rose-800 dark:text-rose-400 dark:hover:bg-rose-950/40"
          >
            Sign Out
          </Button>
        </div>
      </main>

      {/* Edit Profile Modal */}
      <Modal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        title="Edit Profile"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-4 mb-2">
            {editAvatar ? (
              <img
                src={editAvatar}
                alt="Preview"
                className="w-16 h-16 rounded-full object-cover border-2 border-subtle"
              />
            ) : (
              <div className="w-16 h-16 rounded-full gradient-brand flex items-center justify-center text-white font-bold text-xl">
                {(editName || user.email || '?').charAt(0).toUpperCase()}
              </div>
            )}
            <p className="text-xs text-secondary">Enter an image URL for your profile picture</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-primary mb-1.5">Full Name</label>
            <div className="relative">
              <UserIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
                placeholder="Your name"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-primary mb-1.5">Profile Picture URL</label>
            <input
              type="url"
              value={editAvatar}
              onChange={(e) => setEditAvatar(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
              placeholder="https://example.com/photo.jpg"
            />
          </div>

          <div className="flex gap-2 justify-end pt-2">
            <Button variant="ghost" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveProfile} disabled={savingProfile}>
              <Save className="w-4 h-4" />
              {savingProfile ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Change Password Modal */}
      <Modal
        open={pwOpen}
        onClose={() => setPwOpen(false)}
        title="Change Password"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-primary mb-1.5">Current Password</label>
            <input
              type="password"
              required
              value={currentPw}
              onChange={(e) => setCurrentPw(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
              placeholder="Enter current password"
              autoComplete="current-password"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-primary mb-1.5">New Password</label>
            <input
              type="password"
              required
              value={newPw}
              onChange={(e) => setNewPw(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
              placeholder="At least 6 characters"
              autoComplete="new-password"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-primary mb-1.5">Confirm New Password</label>
            <input
              type="password"
              required
              value={confirmPw}
              onChange={(e) => setConfirmPw(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
              placeholder="Re-enter new password"
              autoComplete="new-password"
            />
          </div>

          <div className="flex gap-2 justify-end pt-2">
            <Button variant="ghost" onClick={() => setPwOpen(false)}>Cancel</Button>
            <Button onClick={handleChangePassword} disabled={pwLoading}>
              <Check className="w-4 h-4" />
              {pwLoading ? 'Updating...' : 'Change Password'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function StatBox({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: typeof Target;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <div className="p-4 rounded-xl bg-ink-50 dark:bg-ink-900/50">
      <div className="flex items-center gap-2 mb-1">
        <Icon className={`w-4 h-4 ${color}`} />
        <span className="text-xs text-secondary font-medium">{label}</span>
      </div>
      <p className="text-xl font-extrabold text-primary">{value}</p>
    </div>
  );
}
