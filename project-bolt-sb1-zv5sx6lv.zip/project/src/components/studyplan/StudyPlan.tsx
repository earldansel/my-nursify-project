import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Moon,
  Sun,
  CalendarCheck,
  Flame,
  Target,
  Plus,
  Pencil,
  Pause,
  Play,
  RefreshCw,
  Trash2,
  CheckCircle2,
  Circle,
  Clock,
  TrendingUp,
  BookOpen,
  Stethoscope,
  ClipboardCheck,
  RotateCcw,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Loader2,
} from 'lucide-react';
import type { View, SubjectId } from '@/types';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { subjects } from '@/data';
import Sidebar from '@/components/dashboard/Sidebar';
import MobileNav from '@/components/dashboard/MobileNav';
import Button from '@/components/ui/Button';
import Modal from '@/components/ui/Modal';
import ProgressRing from '@/components/ui/ProgressRing';
import Skeleton from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';

type Intensity = 'light' | 'balanced' | 'intensive';

interface StudyPlanData {
  id: string;
  exam_date: string;
  study_days_per_week: number;
  questions_per_day: number;
  focus_subjects: SubjectId[];
  intensity: Intensity;
  status: 'active' | 'paused';
  created_at: string;
}

interface StudyTask {
  id: string;
  plan_id: string;
  scheduled_date: string;
  title: string;
  task_type: 'questions' | 'review' | 'practice' | 'assessment' | 'review-incorrect';
  subject_id: SubjectId | null;
  question_count: number | null;
  completed: boolean;
  completed_at: string | null;
  sort_order: number;
}

interface StudyPlanProps {
  onNavigate: (view: View) => void;
  dark: boolean;
  onToggleDark: () => void;
}

function getGreeting(hour: number): string {
  if (hour >= 5 && hour < 12) return 'Good morning';
  if (hour >= 12 && hour < 18) return 'Good afternoon';
  return 'Good evening';
}

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function formatDayLabel(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { weekday: 'short' });
}

function formatDayNum(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.getDate().toString();
}

function daysBetween(a: string, b: string): number {
  const da = new Date(a + 'T00:00:00');
  const db = new Date(b + 'T00:00:00');
  return Math.round((db.getTime() - da.getTime()) / (1000 * 60 * 60 * 24));
}

const intensityConfig: Record<Intensity, { label: string; multiplier: number; color: string }> = {
  light: { label: 'Light', multiplier: 0.6, color: 'text-mint-500' },
  balanced: { label: 'Balanced', multiplier: 1, color: 'text-violet-500' },
  intensive: { label: 'Intensive', multiplier: 1.5, color: 'text-amber-500' },
};

const taskTypeConfig: Record<
  StudyTask['task_type'],
  { icon: typeof BookOpen; label: string; color: string; bg: string }
> = {
  questions: { icon: BookOpen, label: 'Questions', color: 'text-violet-600 dark:text-violet-400', bg: 'bg-violet-50 dark:bg-violet-950/40' },
  review: { icon: RotateCcw, label: 'Review', color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-950/40' },
  practice: { icon: Stethoscope, label: 'Practice', color: 'text-mint-600 dark:text-mint-400', bg: 'bg-mint-50 dark:bg-mint-950/40' },
  assessment: { icon: ClipboardCheck, label: 'Assessment', color: 'text-rose-600 dark:text-rose-400', bg: 'bg-rose-50 dark:bg-rose-950/40' },
  'review-incorrect': { icon: RotateCcw, label: 'Review Incorrect', color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-950/40' },
};

const subjectMap: Record<string, { name: string; shortName: string; accent: string }> = {};
subjects.forEach((s) => {
  subjectMap[s.id] = { name: s.name, shortName: s.shortName, accent: s.accent };
});

// Generate tasks for a single study day
function generateDayTasks(
  dateStr: string,
  dayIndex: number,
  plan: Pick<StudyPlanData, 'questions_per_day' | 'focus_subjects' | 'intensity' | 'exam_date'>,
  totalStudyDays: number
): Omit<StudyTask, 'id' | 'plan_id' | 'completed' | 'completed_at' | 'sort_order'>[] {
  const tasks: Omit<StudyTask, 'id' | 'plan_id' | 'completed' | 'completed_at' | 'sort_order'>[] = [];
  const qPerDay = Math.round(plan.questions_per_day * intensityConfig[plan.intensity].multiplier);
  const focus = plan.focus_subjects;

  // Every study day gets a question task
  if (qPerDay > 0) {
    tasks.push({
      scheduled_date: dateStr,
      title: `Answer ${qPerDay} questions`,
      task_type: 'questions',
      subject_id: null,
      question_count: qPerDay,
    });
  }

  // Subject-specific practice/review rotation
  if (focus.length > 0) {
    const subjId = focus[dayIndex % focus.length];
    const subj = subjectMap[subjId];
    const subjName = subj?.shortName ?? subjId;

    // Alternate between practice and review
    if (dayIndex % 2 === 0) {
      tasks.push({
        scheduled_date: dateStr,
        title: `Practice ${subjName}`,
        task_type: 'practice',
        subject_id: subjId,
        question_count: Math.round(qPerDay * 0.4),
      });
    } else {
      tasks.push({
        scheduled_date: dateStr,
        title: `Review ${subjName}`,
        task_type: 'review',
        subject_id: subjId,
        question_count: null,
      });
    }
  }

  // Review incorrect answers every 3rd day
  if (dayIndex % 3 === 2) {
    tasks.push({
      scheduled_date: dateStr,
      title: 'Review incorrect answers',
      task_type: 'review-incorrect',
      subject_id: null,
      question_count: null,
    });
  }

  // Readiness assessment weekly
  if (dayIndex % 7 === 6) {
    tasks.push({
      scheduled_date: dateStr,
      title: 'Complete a readiness assessment',
      task_type: 'assessment',
      subject_id: null,
      question_count: 75,
    });
  }

  return tasks;
}

// Generate the full schedule
function generateSchedule(plan: Pick<StudyPlanData, 'exam_date' | 'study_days_per_week' | 'questions_per_day' | 'focus_subjects' | 'intensity'>): Omit<StudyTask, 'id' | 'plan_id' | 'completed' | 'completed_at' | 'sort_order'>[] {
  const today = todayStr();
  const examDate = plan.exam_date;
  const daysUntilExam = daysBetween(today, examDate);

  if (daysUntilExam <= 0) return [];

  // Generate dates from today to exam date
  const allDates: string[] = [];
  const start = new Date(today + 'T00:00:00');
  for (let i = 0; i <= daysUntilExam; i++) {
    const d = new Date(start);
    d.setDate(d.getDate() + i);
    allDates.push(d.toISOString().slice(0, 10));
  }

  // Filter to study days per week (take first N days of each ISO week)
  const studyDates: string[] = [];
  let weekStartIdx = 0;
  let daysThisWeek = 0;

  for (let i = 0; i < allDates.length; i++) {
    if (daysThisWeek < plan.study_days_per_week) {
      studyDates.push(allDates[i]);
      daysThisWeek++;
    }
    // Reset counter at start of new ISO week (Monday)
    const d = new Date(allDates[i] + 'T00:00:00');
    if (d.getDay() === 1) {
      daysThisWeek = 0;
    }
  }

  // Generate tasks for each study date
  const allTasks: Omit<StudyTask, 'id' | 'plan_id' | 'completed' | 'completed_at' | 'sort_order'>[] = [];
  studyDates.forEach((date, idx) => {
    const dayTasks = generateDayTasks(date, idx, plan, studyDates.length);
    allTasks.push(...dayTasks);
  });

  return allTasks;
}

export default function StudyPlan({ onNavigate, dark, onToggleDark }: StudyPlanProps) {
  const { profile, user } = useAuth();
  const { toast } = useToast();

  const [plan, setPlan] = useState<StudyPlanData | null>(null);
  const [tasks, setTasks] = useState<StudyTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const [saving, setSaving] = useState(false);
  const [calendarOffset, setCalendarOffset] = useState(0);

  const [greeting, setGreeting] = useState(() => getGreeting(new Date().getHours()));
  useEffect(() => {
    const update = () => setGreeting(getGreeting(new Date().getHours()));
    update();
    const interval = setInterval(update, 60_000);
    return () => clearInterval(interval);
  }, []);

  const firstName = (profile?.full_name || '').split(' ')[0] || 'there';

  // Load plan and tasks
  const loadData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data: planData, error: planError } = await supabase
        .from('study_plans')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .maybeSingle();

      if (planError) throw planError;

      if (planData) {
        setPlan(planData as StudyPlanData);
        const { data: taskData, error: taskError } = await supabase
          .from('study_tasks')
          .select('*')
          .eq('plan_id', planData.id)
          .order('scheduled_date', { ascending: true })
          .order('sort_order', { ascending: true });
        if (taskError) throw taskError;
        setTasks((taskData as StudyTask[]) ?? []);
      } else {
        setPlan(null);
        setTasks([]);
      }
    } catch (err) {
      console.error('Error loading study plan:', err);
      toast({ title: 'Failed to load study plan', variant: 'error' });
    } finally {
      setLoading(false);
    }
  }, [user, toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Derived stats
  const today = todayStr();
  const todayTasks = useMemo(() => tasks.filter((t) => t.scheduled_date === today), [tasks, today]);
  const todayCompleted = todayTasks.filter((t) => t.completed).length;
  const todayPct = todayTasks.length > 0 ? Math.round((todayCompleted / todayTasks.length) * 100) : 0;

  const allCompleted = tasks.filter((t) => t.completed).length;
  const overallPct = tasks.length > 0 ? Math.round((allCompleted / tasks.length) * 100) : 0;

  const daysRemaining = plan ? Math.max(0, daysBetween(today, plan.exam_date)) : 0;

  // Streak: count consecutive days (going back from today) where all tasks were completed
  const streak = useMemo(() => {
    if (tasks.length === 0) return 0;
    let count = 0;
    const d = new Date(today + 'T00:00:00');
    for (let i = 0; i < 365; i++) {
      const dateStr = d.toISOString().slice(0, 10);
      const dayTasks = tasks.filter((t) => t.scheduled_date === dateStr);
      if (dayTasks.length === 0) {
        // Skip days with no tasks (rest days) — don't break streak
        d.setDate(d.getDate() - 1);
        continue;
      }
      const allDone = dayTasks.every((t) => t.completed);
      if (allDone) {
        count++;
        d.setDate(d.getDate() - 1);
      } else {
        break;
      }
    }
    return count;
  }, [tasks, today]);

  // Calendar week view
  const calendarWeeks = useMemo(() => {
    if (!plan) return [];
    const weeks: { label: string; days: { date: string; tasks: StudyTask[]; isToday: boolean; isPast: boolean; isFuture: boolean }[] }[] = [];
    const start = new Date(today + 'T00:00:00');
    // Offset by weeks
    start.setDate(start.getDate() + calendarOffset * 7);
    // Align to Monday
    const dayOfWeek = start.getDay();
    const monday = new Date(start);
    monday.setDate(start.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1));

    for (let w = 0; w < 4; w++) {
      const weekDays: typeof weeks[number]['days'] = [];
      const weekStart = new Date(monday);
      weekStart.setDate(monday.getDate() + w * 7);
      const weekLabel = weekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      for (let d = 0; d < 7; d++) {
        const dayDate = new Date(weekStart);
        dayDate.setDate(weekStart.getDate() + d);
        const dateStr = dayDate.toISOString().slice(0, 10);
        const dayTasks = tasks.filter((t) => t.scheduled_date === dateStr);
        weekDays.push({
          date: dateStr,
          tasks: dayTasks,
          isToday: dateStr === today,
          isPast: dateStr < today,
          isFuture: dateStr > today,
        });
      }
      weeks.push({ label: weekLabel, days: weekDays });
    }
    return weeks;
  }, [plan, tasks, today, calendarOffset]);

  // Toggle task completion
  const toggleTask = useCallback(
    async (taskId: string) => {
      const task = tasks.find((t) => t.id === taskId);
      if (!task) return;
      const newCompleted = !task.completed;
      // Optimistic update
      setTasks((prev) =>
        prev.map((t) =>
          t.id === taskId
            ? { ...t, completed: newCompleted, completed_at: newCompleted ? new Date().toISOString() : null }
            : t
        )
      );
      try {
        const { error } = await supabase
          .from('study_tasks')
          .update({ completed: newCompleted, completed_at: newCompleted ? new Date().toISOString() : null })
          .eq('id', taskId);
        if (error) throw error;
        if (newCompleted) {
          toast({ title: 'Task complete!', variant: 'success' });
        }
      } catch (err) {
        console.error('Error updating task:', err);
        // Revert
        setTasks((prev) =>
          prev.map((t) =>
            t.id === taskId
              ? { ...t, completed: task.completed, completed_at: task.completed_at }
              : t
          )
        );
        toast({ title: 'Failed to update task', variant: 'error' });
      }
    },
    [tasks, toast]
  );

  // Create / edit plan
  const handleSavePlan = async (formData: {
    exam_date: string;
    study_days_per_week: number;
    questions_per_day: number;
    focus_subjects: SubjectId[];
    intensity: Intensity;
  }) => {
    if (!user) return;
    setSaving(true);
    try {
      if (plan) {
        // Update existing plan
        const { error: updateError } = await supabase
          .from('study_plans')
          .update({
            exam_date: formData.exam_date,
            study_days_per_week: formData.study_days_per_week,
            questions_per_day: formData.questions_per_day,
            focus_subjects: formData.focus_subjects,
            intensity: formData.intensity,
            status: 'active',
          })
          .eq('id', plan.id);
        if (updateError) throw updateError;

        // Delete old tasks and generate new ones
        const { error: deleteError } = await supabase
          .from('study_tasks')
          .delete()
          .eq('plan_id', plan.id);
        if (deleteError) throw deleteError;

        // Generate new tasks
        const newTasks = generateSchedule(formData);
        if (newTasks.length > 0) {
          const rows = newTasks.map((t, i) => ({
            plan_id: plan.id,
            user_id: user.id,
            scheduled_date: t.scheduled_date,
            title: t.title,
            task_type: t.task_type,
            subject_id: t.subject_id,
            question_count: t.question_count,
            sort_order: i,
          }));
          const { error: insertError } = await supabase.from('study_tasks').insert(rows);
          if (insertError) throw insertError;
        }

        toast({ title: 'Study plan updated', variant: 'success' });
        setShowEdit(false);
      } else {
        // Create new plan
        const { data: newPlan, error: createError } = await supabase
          .from('study_plans')
          .insert({
            user_id: user.id,
            exam_date: formData.exam_date,
            study_days_per_week: formData.study_days_per_week,
            questions_per_day: formData.questions_per_day,
            focus_subjects: formData.focus_subjects,
            intensity: formData.intensity,
            status: 'active',
          })
          .select()
          .maybeSingle();
        if (createError) throw createError;
        if (!newPlan) throw new Error('Failed to create plan');

        // Generate tasks
        const newTasks = generateSchedule(formData);
        if (newTasks.length > 0) {
          const rows = newTasks.map((t, i) => ({
            plan_id: newPlan.id,
            user_id: user.id,
            scheduled_date: t.scheduled_date,
            title: t.title,
            task_type: t.task_type,
            subject_id: t.subject_id,
            question_count: t.question_count,
            sort_order: i,
          }));
          const { error: insertError } = await supabase.from('study_tasks').insert(rows);
          if (insertError) throw insertError;
        }

        toast({ title: 'Study plan created!', variant: 'success' });
        setShowCreate(false);
      }
      await loadData();
    } catch (err) {
      console.error('Error saving plan:', err);
      toast({ title: 'Failed to save study plan', variant: 'error' });
    } finally {
      setSaving(false);
    }
  };

  // Pause / resume plan
  const togglePause = async () => {
    if (!plan) return;
    const newStatus = plan.status === 'active' ? 'paused' : 'active';
    try {
      const { error } = await supabase.from('study_plans').update({ status: newStatus }).eq('id', plan.id);
      if (error) throw error;
      setPlan({ ...plan, status: newStatus });
      toast({ title: newStatus === 'paused' ? 'Plan paused' : 'Plan resumed', variant: 'info' });
    } catch (err) {
      console.error('Error toggling pause:', err);
      toast({ title: 'Failed to update plan', variant: 'error' });
    }
  };

  // Reset plan (delete all tasks, regenerate)
  const handleReset = async () => {
    if (!plan || !user) return;
    setSaving(true);
    try {
      const { error: deleteError } = await supabase.from('study_tasks').delete().eq('plan_id', plan.id);
      if (deleteError) throw deleteError;

      const newTasks = generateSchedule({
        exam_date: plan.exam_date,
        study_days_per_week: plan.study_days_per_week,
        questions_per_day: plan.questions_per_day,
        focus_subjects: plan.focus_subjects,
        intensity: plan.intensity,
      });
      if (newTasks.length > 0) {
        const rows = newTasks.map((t, i) => ({
          plan_id: plan.id,
          user_id: user.id,
          scheduled_date: t.scheduled_date,
          title: t.title,
          task_type: t.task_type,
          subject_id: t.subject_id,
          question_count: t.question_count,
          sort_order: i,
        }));
        const { error: insertError } = await supabase.from('study_tasks').insert(rows);
        if (insertError) throw insertError;
      }
      toast({ title: 'Study plan reset', variant: 'success' });
      setShowReset(false);
      await loadData();
    } catch (err) {
      console.error('Error resetting plan:', err);
      toast({ title: 'Failed to reset plan', variant: 'error' });
    } finally {
      setSaving(false);
    }
  };

  // Delete plan entirely
  const handleDelete = async () => {
    if (!plan) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('study_plans').delete().eq('id', plan.id);
      if (error) throw error;
      setPlan(null);
      setTasks([]);
      toast({ title: 'Study plan deleted', variant: 'info' });
      setShowReset(false);
    } catch (err) {
      console.error('Error deleting plan:', err);
      toast({ title: 'Failed to delete plan', variant: 'error' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface flex">
      <Sidebar active="study-plan" onNavigate={onNavigate} dark={dark} onToggleDark={onToggleDark} />

      <div className="flex-1 min-w-0 pb-20 lg:pb-0">
        {/* Top bar (mobile) */}
        <div className="lg:hidden sticky top-0 z-40 glass-strong border-b border-subtle px-5 h-14 flex items-center justify-between">
          <button onClick={() => onNavigate('landing')} className="flex items-center gap-2">
            <span className="w-7 h-7 gradient-brand rounded-full flex items-center justify-center">
              <span className="w-2 h-2 bg-white rounded-full" />
            </span>
            <span className="font-bold text-primary">Nursify</span>
          </button>
          <button
            onClick={onToggleDark}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors"
          >
            {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>
        </div>

        <main className="max-w-6xl mx-auto px-5 sm:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
          {/* Greeting */}
          <div className="animate-slide-up">
            <div className="flex items-center gap-2 text-sm text-secondary font-medium">
              <CalendarCheck className="w-4 h-4 text-violet-500" />
              {greeting}, {firstName}
            </div>
            <h1 className="mt-1 text-2xl sm:text-3xl font-extrabold text-primary">
              Your Study Plan
            </h1>
          </div>

          {loading ? (
            <div className="space-y-6">
              <Skeleton className="h-48 rounded-3xl" />
              <Skeleton className="h-32 rounded-3xl" />
              <Skeleton className="h-64 rounded-3xl" />
            </div>
          ) : !plan ? (
            /* Empty state */
            <div className="animate-slide-up animate-delay-100">
              <div className="relative overflow-hidden rounded-3xl border border-subtle bg-elevated p-10 sm:p-16 text-center">
                <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-violet-100 dark:bg-violet-950/30 blur-3xl" />
                <div className="absolute -left-10 -bottom-10 w-40 h-40 rounded-full bg-blue-100 dark:bg-blue-950/30 blur-3xl" />
                <div className="relative">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl gradient-brand-soft mb-5">
                    <CalendarCheck className="w-8 h-8 text-violet-600 dark:text-violet-400" />
                  </div>
                  <h2 className="text-xl font-bold text-primary">No study plan yet</h2>
                  <p className="mt-2 text-secondary text-sm max-w-md mx-auto">
                    Create a personalized NCLEX study schedule based on your exam date, weak areas, and preferred intensity.
                  </p>
                  <div className="mt-6">
                    <Button onClick={() => setShowCreate(true)} withArrow>
                      Create Study Plan
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Plan paused banner */}
              {plan.status === 'paused' && (
                <div className="animate-slide-up flex items-center gap-3 px-4 py-3 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 text-sm font-medium">
                  <Pause className="w-4 h-4 shrink-0" />
                  Your study plan is paused. Resume to continue tracking progress.
                </div>
              )}

              {/* Hero dashboard card */}
              <div className="animate-slide-up animate-delay-100">
                <div className="relative overflow-hidden rounded-3xl p-7 sm:p-8 gradient-brand text-white">
                  <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-white/10 blur-2xl" />
                  <div className="absolute -left-10 -bottom-10 w-40 h-40 rounded-full bg-blue-300/20 blur-2xl" />

                  <div className="relative flex flex-col lg:flex-row gap-6 lg:gap-8">
                    <div className="flex-1">
                      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-sm">
                        <Target className="w-3.5 h-3.5" />
                        <span className="text-[11px] font-semibold uppercase tracking-wide">NCLEX Target</span>
                      </div>

                      <h2 className="mt-4 text-2xl sm:text-3xl font-extrabold">{formatDate(plan.exam_date)}</h2>
                      <p className="mt-1 text-white/80 text-sm">
                        {daysRemaining === 0
                          ? 'Exam day is here — you\'ve got this!'
                          : `${daysRemaining} days remaining`}
                      </p>

                      <div className="mt-5 flex flex-wrap items-center gap-3">
                        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/15 backdrop-blur-sm">
                          <Flame className="w-4 h-4 text-amber-300" />
                          <span className="text-sm font-semibold">{streak} day streak</span>
                        </div>
                        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/15 backdrop-blur-sm">
                          <TrendingUp className="w-4 h-4 text-mint-300" />
                          <span className="text-sm font-semibold">{overallPct}% complete</span>
                        </div>
                        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/15 backdrop-blur-sm">
                          <CalendarCheck className="w-4 h-4 text-blue-200" />
                          <span className="text-sm font-semibold">{plan.study_days_per_week} days/wk</span>
                        </div>
                      </div>

                      <div className="mt-6 flex flex-wrap gap-2">
                        <Button
                          onClick={() => setShowEdit(true)}
                          className="bg-white text-violet-700 hover:bg-white hover:text-violet-800 shadow-lift"
                          size="sm"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                          Edit Plan
                        </Button>
                        <Button
                          onClick={togglePause}
                          variant="ghost"
                          size="sm"
                          className="bg-white/15 text-white hover:bg-white/25 backdrop-blur-sm"
                        >
                          {plan.status === 'active' ? (
                            <>
                              <Pause className="w-3.5 h-3.5" />
                              Pause
                            </>
                          ) : (
                            <>
                              <Play className="w-3.5 h-3.5" />
                              Resume
                            </>
                          )}
                        </Button>
                        <Button
                          onClick={() => setShowReset(true)}
                          variant="ghost"
                          size="sm"
                          className="bg-white/15 text-white hover:bg-white/25 backdrop-blur-sm"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          Reset
                        </Button>
                      </div>
                    </div>

                    {/* Progress ring */}
                    <div className="shrink-0">
                      <div className="relative">
                        <svg width="140" height="140" className="-rotate-90">
                          <circle cx="70" cy="70" r="60" fill="none" strokeWidth="10" stroke="rgba(255,255,255,0.2)" />
                          <circle
                            cx="70"
                            cy="70"
                            r="60"
                            fill="none"
                            strokeWidth="10"
                            stroke="white"
                            strokeLinecap="round"
                            strokeDasharray={2 * Math.PI * 60}
                            strokeDashoffset={2 * Math.PI * 60 - (overallPct / 100) * 2 * Math.PI * 60}
                            style={{ transition: 'stroke-dashoffset 1.2s cubic-bezier(0.16,1,0.3,1)' }}
                          />
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <span className="text-4xl font-extrabold tabular-nums">{overallPct}<span className="text-xl">%</span></span>
                          <span className="text-xs text-white/70 font-medium mt-0.5">complete</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats row */}
              <div className="animate-slide-up animate-delay-200 grid grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard
                  icon={Target}
                  label="Exam Date"
                  value={formatDate(plan.exam_date)}
                  accent="text-violet-500"
                  bg="bg-violet-50 dark:bg-violet-950/30"
                />
                <StatCard
                  icon={Clock}
                  label="Days Remaining"
                  value={daysRemaining.toString()}
                  accent="text-blue-500"
                  bg="bg-blue-50 dark:bg-blue-950/30"
                />
                <StatCard
                  icon={Flame}
                  label="Current Streak"
                  value={`${streak} days`}
                  accent="text-amber-500"
                  bg="bg-amber-50 dark:bg-amber-950/30"
                />
                <StatCard
                  icon={TrendingUp}
                  label="Completion"
                  value={`${overallPct}%`}
                  accent="text-mint-500"
                  bg="bg-mint-50 dark:bg-mint-950/30"
                />
              </div>

              {/* Today's Focus */}
              <div className="animate-slide-up animate-delay-200">
                <div className="rounded-3xl border border-subtle bg-elevated p-6 sm:p-7 shadow-soft">
                  <div className="flex items-center justify-between mb-5">
                    <div>
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-violet-500" />
                        <h3 className="text-lg font-bold text-primary">Today's Focus</h3>
                      </div>
                      <p className="text-sm text-secondary mt-0.5">
                        {todayTasks.length === 0
                          ? 'No tasks scheduled for today — rest day!'
                          : `${todayCompleted} of ${todayTasks.length} tasks complete`}
                      </p>
                    </div>
                    {todayTasks.length > 0 && (
                      <div className="hidden sm:block">
                        <ProgressRing value={todayPct} size={64} strokeWidth={6} fillClassName="text-violet-500" />
                      </div>
                    )}
                  </div>

                  {todayTasks.length === 0 ? (
                    <div className="flex items-center gap-3 py-6 text-secondary text-sm">
                      <CheckCircle2 className="w-5 h-5 text-mint-500" />
                      Enjoy your rest day. See you tomorrow!
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {todayTasks.map((task) => (
                        <TaskRow key={task.id} task={task} onToggle={toggleTask} />
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Calendar / Timeline view */}
              <div className="animate-slide-up animate-delay-300">
                <div className="rounded-3xl border border-subtle bg-elevated p-6 sm:p-7 shadow-soft">
                  <div className="flex items-center justify-between mb-5">
                    <div>
                      <h3 className="text-lg font-bold text-primary">Study Schedule</h3>
                      <p className="text-sm text-secondary mt-0.5">Your personalized 4-week timeline</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setCalendarOffset((o) => o - 1)}
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setCalendarOffset((o) => o + 1)}
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {calendarWeeks.map((week, wi) => (
                      <div key={wi}>
                        <p className="text-xs font-semibold text-ink-400 dark:text-ink-500 uppercase tracking-wider mb-3">
                          Week of {week.label}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-3">
                          {week.days.map((day) => {
                            const dayCompleted = day.tasks.filter((t) => t.completed).length;
                            const dayTotal = day.tasks.length;
                            const dayPct = dayTotal > 0 ? Math.round((dayCompleted / dayTotal) * 100) : 0;
                            return (
                              <div
                                key={day.date}
                                className={`rounded-2xl border p-3 transition-all ${
                                  day.isToday
                                    ? 'border-violet-300 dark:border-violet-700 bg-violet-50/50 dark:bg-violet-950/20'
                                    : day.isPast
                                    ? 'border-subtle bg-ink-50/50 dark:bg-ink-900/30'
                                    : 'border-subtle bg-elevated'
                                }`}
                              >
                                <div className="flex items-center justify-between mb-2">
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-xs font-semibold text-secondary">{formatDayLabel(day.date)}</span>
                                    <span className={`text-sm font-bold ${day.isToday ? 'text-violet-600 dark:text-violet-400' : 'text-primary'}`}>
                                      {formatDayNum(day.date)}
                                    </span>
                                  </div>
                                  {dayTotal > 0 && (
                                    <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
                                      dayPct === 100
                                        ? 'bg-mint-100 dark:bg-mint-950/40 text-mint-600 dark:text-mint-400'
                                        : dayPct > 0
                                        ? 'bg-violet-100 dark:bg-violet-950/40 text-violet-600 dark:text-violet-400'
                                        : 'bg-ink-100 dark:bg-ink-800 text-secondary'
                                    }`}>
                                      {dayCompleted}/{dayTotal}
                                    </span>
                                  )}
                                </div>
                                {dayTotal === 0 ? (
                                  <p className="text-xs text-ink-400 dark:text-ink-500 py-2">Rest day</p>
                                ) : (
                                  <div className="space-y-1.5">
                                    {day.tasks.map((task) => {
                                      const cfg = taskTypeConfig[task.task_type];
                                      const Icon = cfg.icon;
                                      return (
                                        <button
                                          key={task.id}
                                          onClick={() => toggleTask(task.id)}
                                          className={`w-full flex items-center gap-1.5 rounded-lg px-1.5 py-1 text-left transition-colors hover:bg-ink-100 dark:hover:bg-ink-800/50 ${
                                            task.completed ? 'opacity-50' : ''
                                          }`}
                                        >
                                          {task.completed ? (
                                            <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-mint-500" />
                                          ) : (
                                            <Circle className="w-3.5 h-3.5 shrink-0 text-ink-300 dark:text-ink-600" />
                                          )}
                                          <Icon className={`w-3 h-3 shrink-0 ${cfg.color}`} />
                                          <span className={`text-[11px] font-medium truncate ${task.completed ? 'line-through text-ink-400' : 'text-primary'}`}>
                                            {task.title}
                                          </span>
                                        </button>
                                      );
                                    })}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </main>
      </div>

      <MobileNav active="study-plan" onNavigate={onNavigate} />

      {/* Create / Edit modal */}
      {(showCreate || showEdit) && (
        <PlanFormModal
          open={showCreate || showEdit}
          onClose={() => {
            setShowCreate(false);
            setShowEdit(false);
          }}
          onSave={handleSavePlan}
          saving={saving}
          existingPlan={showEdit && plan ? plan : null}
        />
      )}

      {/* Reset / delete modal */}
      <Modal
        open={showReset}
        onClose={() => setShowReset(false)}
        title="Reset or Delete Plan"
      >
        <div className="space-y-4">
          <p className="text-sm text-secondary">
            Resetting regenerates all tasks based on your current settings. Deleting removes your plan entirely.
          </p>
          <div className="flex gap-2">
            <Button
              onClick={handleReset}
              disabled={saving}
              variant="secondary"
              size="sm"
              className="flex-1"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
              Reset Tasks
            </Button>
            <Button
              onClick={handleDelete}
              disabled={saving}
              size="sm"
              className="flex-1 !bg-rose-500 hover:!bg-rose-600 !text-white"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              Delete Plan
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

// --- Stat Card ---
function StatCard({
  icon: Icon,
  label,
  value,
  accent,
  bg,
}: {
  icon: typeof Target;
  label: string;
  value: string;
  accent: string;
  bg: string;
}) {
  return (
    <div className="rounded-2xl border border-subtle bg-elevated p-4 shadow-soft">
      <div className={`inline-flex items-center justify-center w-9 h-9 rounded-xl ${bg} mb-3`}>
        <Icon className={`w-4.5 h-4.5 ${accent}`} />
      </div>
      <p className="text-xs font-medium text-secondary">{label}</p>
      <p className="text-lg font-bold text-primary mt-0.5">{value}</p>
    </div>
  );
}

// --- Task Row ---
function TaskRow({
  task,
  onToggle,
}: {
  task: StudyTask;
  onToggle: (id: string) => void;
}) {
  const cfg = taskTypeConfig[task.task_type];
  const Icon = cfg.icon;
  return (
    <button
      onClick={() => onToggle(task.id)}
      className={`w-full flex items-center gap-3 rounded-2xl px-4 py-3 text-left transition-all hover:bg-ink-50 dark:hover:bg-ink-800/50 ${
        task.completed ? 'opacity-60' : ''
      }`}
    >
      {task.completed ? (
        <CheckCircle2 className="w-5 h-5 shrink-0 text-mint-500" />
      ) : (
        <Circle className="w-5 h-5 shrink-0 text-ink-300 dark:text-ink-600" />
      )}
      <div className={`flex items-center justify-center w-8 h-8 rounded-lg shrink-0 ${cfg.bg}`}>
        <Icon className={`w-4 h-4 ${cfg.color}`} />
      </div>
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-semibold ${task.completed ? 'line-through text-ink-400' : 'text-primary'}`}>
          {task.title}
        </p>
        {task.question_count && (
          <p className="text-xs text-secondary mt-0.5">{task.question_count} questions</p>
        )}
      </div>
      {task.subject_id && subjectMap[task.subject_id] && (
        <span
          className="text-[10px] font-semibold px-2 py-1 rounded-full shrink-0"
          style={{
            backgroundColor: `${subjectMap[task.subject_id].accent}20`,
            color: subjectMap[task.subject_id].accent,
          }}
        >
          {subjectMap[task.subject_id].shortName}
        </span>
      )}
    </button>
  );
}

// --- Plan Form Modal ---
function PlanFormModal({
  open,
  onClose,
  onSave,
  saving,
  existingPlan,
}: {
  open: boolean;
  onClose: () => void;
  onSave: (data: {
    exam_date: string;
    study_days_per_week: number;
    questions_per_day: number;
    focus_subjects: SubjectId[];
    intensity: Intensity;
  }) => void;
  saving: boolean;
  existingPlan: StudyPlanData | null;
}) {
  const defaultDate = new Date();
  defaultDate.setDate(defaultDate.getDate() + 30);

  const [examDate, setExamDate] = useState(
    existingPlan?.exam_date ?? defaultDate.toISOString().slice(0, 10)
  );
  const [daysPerWeek, setDaysPerWeek] = useState(existingPlan?.study_days_per_week ?? 5);
  const [questionsPerDay, setQuestionsPerDay] = useState(existingPlan?.questions_per_day ?? 50);
  const [focusSubjects, setFocusSubjects] = useState<SubjectId[]>(
    existingPlan?.focus_subjects ?? (['pharmacology', 'medsurg'] as SubjectId[])
  );
  const [intensity, setIntensity] = useState<Intensity>(existingPlan?.intensity ?? 'balanced');

  // Reset when modal opens
  useEffect(() => {
    if (open) {
      if (existingPlan) {
        setExamDate(existingPlan.exam_date);
        setDaysPerWeek(existingPlan.study_days_per_week);
        setQuestionsPerDay(existingPlan.questions_per_day);
        setFocusSubjects(existingPlan.focus_subjects);
        setIntensity(existingPlan.intensity);
      } else {
        const d = new Date();
        d.setDate(d.getDate() + 30);
        setExamDate(d.toISOString().slice(0, 10));
        setDaysPerWeek(5);
        setQuestionsPerDay(50);
        setFocusSubjects(['pharmacology', 'medsurg']);
        setIntensity('balanced');
      }
    }
  }, [open, existingPlan]);

  const toggleSubject = (id: SubjectId) => {
    setFocusSubjects((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    );
  };

  const handleSubmit = () => {
    if (!examDate) return;
    onSave({
      exam_date: examDate,
      study_days_per_week: daysPerWeek,
      questions_per_day: questionsPerDay,
      focus_subjects: focusSubjects,
      intensity,
    });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={existingPlan ? 'Edit Study Plan' : 'Create Study Plan'}
      footer={
        <>
          <Button variant="ghost" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={saving} size="sm">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            {existingPlan ? 'Save Changes' : 'Create Plan'}
          </Button>
        </>
      }
    >
      <div className="space-y-5">
        {/* Exam date */}
        <div>
          <label className="text-sm font-semibold text-primary mb-2 block">NCLEX Exam Date</label>
          <input
            type="date"
            value={examDate}
            min={todayStr()}
            onChange={(e) => setExamDate(e.target.value)}
            className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-elevated text-primary text-sm font-medium focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400 transition-all"
          />
          {examDate && (
            <p className="text-xs text-secondary mt-1.5">
              {Math.max(0, daysBetween(todayStr(), examDate))} days from today
            </p>
          )}
        </div>

        {/* Days per week */}
        <div>
          <label className="text-sm font-semibold text-primary mb-2 block">Study Days Per Week</label>
          <div className="flex gap-2 flex-wrap">
            {[3, 4, 5, 6, 7].map((n) => (
              <button
                key={n}
                onClick={() => setDaysPerWeek(n)}
                className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                  daysPerWeek === n
                    ? 'gradient-brand text-white shadow-lift'
                    : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300'
                }`}
              >
                {n} days
              </button>
            ))}
          </div>
        </div>

        {/* Questions per day */}
        <div>
          <label className="text-sm font-semibold text-primary mb-2 block">
            Questions Per Day: <span className="text-violet-600 dark:text-violet-400">{questionsPerDay}</span>
          </label>
          <input
            type="range"
            min={10}
            max={150}
            step={10}
            value={questionsPerDay}
            onChange={(e) => setQuestionsPerDay(Number(e.target.value))}
            className="w-full accent-violet-500"
          />
          <div className="flex justify-between text-xs text-secondary mt-1">
            <span>10</span>
            <span>150</span>
          </div>
        </div>

        {/* Focus subjects */}
        <div>
          <label className="text-sm font-semibold text-primary mb-2 block">Focus Subjects</label>
          <p className="text-xs text-secondary mb-3">Select your weak areas to prioritize</p>
          <div className="grid grid-cols-2 gap-2">
            {subjects.map((s) => {
              const selected = focusSubjects.includes(s.id);
              return (
                <button
                  key={s.id}
                  onClick={() => toggleSubject(s.id)}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    selected
                      ? 'border-2 text-primary'
                      : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300'
                  }`}
                  style={selected ? { borderColor: s.accent, backgroundColor: `${s.accent}10` } : {}}
                >
                  {selected ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0" style={{ color: s.accent }} />
                  ) : (
                    <Circle className="w-4 h-4 shrink-0 text-ink-300 dark:text-ink-600" />
                  )}
                  <span className="truncate">{s.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Intensity */}
        <div>
          <label className="text-sm font-semibold text-primary mb-2 block">Study Intensity</label>
          <div className="grid grid-cols-3 gap-2">
            {(Object.keys(intensityConfig) as Intensity[]).map((key) => {
              const cfg = intensityConfig[key];
              const selected = intensity === key;
              return (
                <button
                  key={key}
                  onClick={() => setIntensity(key)}
                  className={`px-3 py-3 rounded-xl text-sm font-semibold transition-all ${
                    selected
                      ? 'gradient-brand text-white shadow-lift'
                      : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300'
                  }`}
                >
                  {cfg.label}
                </button>
              );
            })}
          </div>
          <p className="text-xs text-secondary mt-2">
            {intensity === 'light' && '~60% of daily questions — steady pace'}
            {intensity === 'balanced' && '100% of daily questions — recommended'}
            {intensity === 'intensive' && '~150% of daily questions — max effort'}
          </p>
        </div>
      </div>
    </Modal>
  );
}
