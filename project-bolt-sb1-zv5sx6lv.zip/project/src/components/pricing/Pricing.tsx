import { useState } from 'react';
import { Check, Crown, Lock, ExternalLink, MessageCircle } from 'lucide-react';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import Modal from '@/components/ui/Modal';
import { PRICING_PLANS, PREMIUM_INSTRUCTION_IMAGE, PREMIUM_INSTRUCTION_TEXT, PREMIUM_FACEBOOK_URL } from '@/config';
import { useAuth } from '@/lib/auth';

interface PricingPageProps {
  onNavigate: (view: 'login' | 'signup' | 'dashboard' | 'landing') => void;
}

export default function Pricing({ onNavigate }: PricingPageProps) {
  const { user, isPremium } = useAuth();
  const [instructionsOpen, setInstructionsOpen] = useState(false);

  const handlePlanClick = (planId: string) => {
    if (planId === 'free') {
      onNavigate(user ? 'dashboard' : 'signup');
      return;
    }
    if (!user) {
      onNavigate('login');
      return;
    }
    if (isPremium) {
      onNavigate('dashboard');
      return;
    }
    setInstructionsOpen(true);
  };

  return (
    <div className="min-h-screen bg-surface">
      <header className="sticky top-0 z-50 glass border-b border-subtle">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
          <button onClick={() => onNavigate('landing')} className="flex items-center gap-2.5">
            <span className="w-8 h-8 gradient-brand rounded-full flex items-center justify-center">
              <span className="w-2.5 h-2.5 bg-white rounded-full animate-pulse" />
            </span>
            <span className="font-bold text-lg tracking-tight text-primary">
              Nursify<span className="text-lavender-600"> Coaching</span>
            </span>
          </button>
          <Button size="sm" variant="ghost" onClick={() => onNavigate(user ? 'dashboard' : 'login')}>
            {user ? 'Dashboard' : 'Sign In'}
          </Button>
        </div>
      </header>

      <section className="relative py-20 sm:py-28 overflow-hidden">
        <div className="absolute inset-0 gradient-hero-bg" />
        <div className="relative max-w-5xl mx-auto px-5 sm:px-8">
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-xs font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wide">
              Pricing
            </p>
            <h1 className="mt-3 text-4xl sm:text-5xl font-extrabold tracking-tight text-primary">
              Choose your <span className="gradient-text">prep plan</span>
            </h1>
            <p className="mt-4 text-lg text-secondary">
              Start free, upgrade when you're ready.
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
            {PRICING_PLANS.map((plan) => {
              const isCurrent = user && (
                (plan.id === 'free' && !isPremium) ||
                (plan.id === 'premium' && isPremium)
              );
              return (
                <Card
                  key={plan.id}
                  className={`relative p-7 flex flex-col ${
                    plan.highlighted
                      ? 'border-violet-300 dark:border-violet-700 shadow-lift md:scale-105'
                      : ''
                  }`}
                >
                  {plan.highlighted && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full gradient-brand text-white text-xs font-bold flex items-center gap-1.5 shadow-lift">
                      <Crown className="w-3 h-3" />
                      Most Popular
                    </div>
                  )}

                  <div>
                    <h3 className="text-xl font-bold text-primary">{plan.name}</h3>
                    <p className="mt-1 text-sm text-secondary">{plan.description}</p>
                  </div>

                  <div className="mt-5">
                    <span className="text-4xl font-extrabold text-primary">
                      {plan.id === 'free' ? 'Free' : 'Premium'}
                    </span>
                  </div>

                  <ul className="mt-6 space-y-3 flex-1">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2.5 text-sm text-secondary">
                        <span className="w-5 h-5 rounded-full bg-violet-50 dark:bg-violet-950/50 flex items-center justify-center shrink-0 mt-0.5">
                          <Check className="w-3 h-3 text-violet-600 dark:text-violet-400" />
                        </span>
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <div className="mt-7">
                    {isCurrent ? (
                      <div className="w-full py-3 rounded-2xl bg-mint-50 dark:bg-mint-950/40 border border-mint-200 dark:border-mint-800 text-mint-600 dark:text-mint-400 text-sm font-semibold text-center flex items-center justify-center gap-2">
                        <Check className="w-4 h-4" />
                        Your Current Plan
                      </div>
                    ) : (
                      <Button
                        size="lg"
                        withArrow
                        variant={plan.highlighted ? 'primary' : 'secondary'}
                        className="w-full"
                        onClick={() => handlePlanClick(plan.id)}
                      >
                        {plan.cta}
                      </Button>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      <Modal open={instructionsOpen} onClose={() => setInstructionsOpen(false)} title="Get Premium Access">
        <div className="space-y-5">
          <div className="flex justify-center">
            <div className="w-full max-w-sm rounded-2xl overflow-hidden border border-subtle">
              <img
                src={PREMIUM_INSTRUCTION_IMAGE}
                alt="Premium access instructions"
                className="w-full h-auto"
              />
            </div>
          </div>

          <div className="p-4 rounded-xl bg-violet-50 dark:bg-violet-950/40 border border-violet-200 dark:border-violet-800 text-center">
            <p className="text-sm font-medium text-violet-700 dark:text-violet-300 flex items-center justify-center gap-2">
              <MessageCircle className="w-4 h-4" />
              {PREMIUM_INSTRUCTION_TEXT}
            </p>
          </div>

          <a href={PREMIUM_FACEBOOK_URL} target="_blank" rel="noopener noreferrer" className="block">
            <Button size="lg" withArrow className="w-full">
              Message Facebook Page
              <ExternalLink className="w-4 h-4" />
            </Button>
          </a>

          <p className="text-xs text-secondary text-center">
            Once your Premium access is activated, you'll have full access to all QBank questions and features.
          </p>
        </div>
      </Modal>
    </div>
  );
}
