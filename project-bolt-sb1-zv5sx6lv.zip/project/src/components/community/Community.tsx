import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Moon,
  Sun,
  MessageCircle,
  Heart,
  Send,
  Trash2,
  Reply,
  Clock,
  Flame,
  Loader2,
  Users,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import type { View } from '@/types';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import Sidebar from '@/components/dashboard/Sidebar';
import MobileNav from '@/components/dashboard/MobileNav';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Modal from '@/components/ui/Modal';
import Skeleton from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';

interface CommunityPost {
  id: string;
  author_id: string;
  content: string;
  category: string;
  author_name: string;
  author_avatar_url: string;
  created_at: string;
  like_count: number;
  comment_count: number;
  liked_by_me: boolean;
}

interface CommunityComment {
  id: string;
  post_id: string;
  author_id: string;
  parent_comment_id: string | null;
  content: string;
  author_name: string;
  author_avatar_url: string;
  created_at: string;
  like_count: number;
  liked_by_me: boolean;
}

type SortMode = 'latest' | 'popular';

const CATEGORIES = [
  { id: 'general', label: 'General', color: 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40' },
  { id: 'nclex-help', label: 'NCLEX Help', color: 'text-violet-600 dark:text-violet-400 bg-violet-50 dark:bg-violet-950/40' },
  { id: 'study-tips', label: 'Study Tips', color: 'text-mint-600 dark:text-mint-400 bg-mint-50 dark:bg-mint-950/40' },
  { id: 'motivation', label: 'Motivation', color: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40' },
] as const;

const CATEGORY_MAP: Record<string, { label: string; color: string }> = Object.fromEntries(
  CATEGORIES.map((c) => [c.id, { label: c.label, color: c.color }]),
);

function formatRelativeTime(dateStr: string): string {
  const now = Date.now();
  const then = new Date(dateStr).getTime();
  const diff = Math.floor((now - then) / 1000);
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`;
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
}

interface CommunityProps {
  onNavigate: (view: View) => void;
  dark: boolean;
  onToggleDark: () => void;
}

export default function Community({ onNavigate, dark, onToggleDark }: CommunityProps) {
  const { user, profile, isAdmin } = useAuth();
  const { toast } = useToast();

  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortMode, setSortMode] = useState<SortMode>('latest');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const [newPost, setNewPost] = useState('');
  const [newPostCategory, setNewPostCategory] = useState<string>('general');
  const [posting, setPosting] = useState(false);

  const [expandedPosts, setExpandedPosts] = useState<Set<string>>(new Set());
  const [commentsByPost, setCommentsByPost] = useState<Record<string, CommunityComment[]>>({});
  const [loadingComments, setLoadingComments] = useState<Set<string>>(new Set());
  const [commentDrafts, setCommentDrafts] = useState<Record<string, string>>({});
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [submittingComment, setSubmittingComment] = useState<string | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<{ type: 'post' | 'comment'; id: string; label: string } | null>(null);
  const [deleting, setDeleting] = useState(false);

  const loadPosts = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('community_posts')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;

      const postRows = (data ?? []) as Omit<CommunityPost, 'like_count' | 'comment_count' | 'liked_by_me'>[];
      const postIds = postRows.map((p) => p.id);

      let likesData: { post_id: string | null; user_id: string }[] = [];
      let commentsData: { post_id: string }[] = [];

      if (postIds.length > 0) {
        const [likesRes, commentsRes] = await Promise.all([
          supabase.from('community_likes').select('post_id, user_id').in('post_id', postIds),
          supabase.from('community_comments').select('post_id').in('post_id', postIds),
        ]);
        likesData = (likesRes.data ?? []) as { post_id: string | null; user_id: string }[];
        commentsData = (commentsRes.data ?? []) as { post_id: string }[];
      }

      const likeCounts = new Map<string, number>();
      const myLikedPosts = new Set<string>();
      likesData.forEach((l) => {
        if (l.post_id) {
          likeCounts.set(l.post_id, (likeCounts.get(l.post_id) ?? 0) + 1);
          if (l.user_id === user?.id) myLikedPosts.add(l.post_id);
        }
      });

      const commentCounts = new Map<string, number>();
      commentsData.forEach((c) => {
        commentCounts.set(c.post_id, (commentCounts.get(c.post_id) ?? 0) + 1);
      });

      const enriched: CommunityPost[] = postRows.map((p) => ({
        ...p,
        like_count: likeCounts.get(p.id) ?? 0,
        comment_count: commentCounts.get(p.id) ?? 0,
        liked_by_me: myLikedPosts.has(p.id),
      }));

      setPosts(enriched);
    } catch (err) {
      console.error('Error loading posts:', err);
      toast({ title: 'Failed to load community posts', variant: 'error' });
    } finally {
      setLoading(false);
    }
  }, [toast, user?.id]);

  useEffect(() => {
    loadPosts();
  }, [loadPosts]);

  // Realtime: listen for changes on all three tables
  useEffect(() => {
    const channel = supabase
      .channel('community-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'community_posts' }, () => loadPosts())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'community_comments' }, (payload) => {
        const row = payload.new as { post_id?: string } | null;
        if (row?.post_id && expandedPosts.has(row.post_id)) {
          loadComments(row.post_id);
        }
        loadPosts();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'community_likes' }, () => loadPosts())
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [loadPosts, expandedPosts]);

  const sortedPosts = useMemo(() => {
    const filtered = categoryFilter === 'all'
      ? posts
      : posts.filter((p) => p.category === categoryFilter);

    if (sortMode === 'popular') {
      return [...filtered].sort((a, b) => b.like_count - a.like_count || b.comment_count - a.comment_count);
    }
    return [...filtered].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }, [posts, sortMode, categoryFilter]);

  const handleCreatePost = async () => {
    if (!newPost.trim()) {
      toast({ title: 'Post cannot be empty', variant: 'warning' });
      return;
    }
    setPosting(true);
    try {
      const { error } = await supabase.from('community_posts').insert({
        content: newPost.trim(),
        category: newPostCategory,
        author_name: profile?.full_name || 'User',
        author_avatar_url: profile?.avatar_url ?? '',
      });
      if (error) throw error;
      setNewPost('');
      setNewPostCategory('general');
      toast({ title: 'Post shared', variant: 'success' });
      loadPosts();
    } catch (err) {
      console.error('Error creating post:', err);
      toast({ title: 'Failed to create post', variant: 'error' });
    } finally {
      setPosting(false);
    }
  };

  const handleToggleLike = async (postId: string, liked: boolean) => {
    if (liked) {
      await supabase.from('community_likes').delete().eq('post_id', postId).eq('user_id', user!.id);
    } else {
      await supabase.from('community_likes').insert({ post_id: postId });
    }
    loadPosts();
  };

  const handleToggleCommentLike = async (commentId: string, liked: boolean) => {
    if (liked) {
      await supabase.from('community_likes').delete().eq('comment_id', commentId).eq('user_id', user!.id);
    } else {
      await supabase.from('community_likes').insert({ comment_id: commentId });
    }
    const postIds = Array.from(expandedPosts);
    postIds.forEach((pid) => loadComments(pid));
  };

  const loadComments = useCallback(async (postId: string) => {
    setLoadingComments((prev) => new Set(prev).add(postId));
    try {
      const { data, error } = await supabase
        .from('community_comments')
        .select('*')
        .eq('post_id', postId)
        .order('created_at', { ascending: true });
      if (error) throw error;

      const commentRows = (data ?? []) as Omit<CommunityComment, 'like_count' | 'liked_by_me'>[];
      const commentIds = commentRows.map((c) => c.id);

      let likesData: { comment_id: string | null; user_id: string }[] = [];
      if (commentIds.length > 0) {
        const { data: ld } = await supabase
          .from('community_likes')
          .select('comment_id, user_id')
          .in('comment_id', commentIds);
        likesData = (ld ?? []) as { comment_id: string | null; user_id: string }[];
      }

      const likeCounts = new Map<string, number>();
      const myLiked = new Set<string>();
      likesData.forEach((l) => {
        if (l.comment_id) {
          likeCounts.set(l.comment_id, (likeCounts.get(l.comment_id) ?? 0) + 1);
          if (l.user_id === user?.id) myLiked.add(l.comment_id);
        }
      });

      const enriched: CommunityComment[] = commentRows.map((c) => ({
        ...c,
        like_count: likeCounts.get(c.id) ?? 0,
        liked_by_me: myLiked.has(c.id),
      }));

      setCommentsByPost((prev) => ({ ...prev, [postId]: enriched }));
    } catch (err) {
      console.error('Error loading comments:', err);
    } finally {
      setLoadingComments((prev) => {
        const next = new Set(prev);
        next.delete(postId);
        return next;
      });
    }
  }, [user?.id]);

  const toggleComments = (postId: string) => {
    setExpandedPosts((prev) => {
      const next = new Set(prev);
      if (next.has(postId)) {
        next.delete(postId);
      } else {
        next.add(postId);
        loadComments(postId);
      }
      return next;
    });
  };

  const handleAddComment = async (postId: string) => {
    const text = (commentDrafts[postId] ?? '').trim();
    if (!text) return;
    setSubmittingComment(postId);
    try {
      const { error } = await supabase.from('community_comments').insert({
        post_id: postId,
        content: text,
        author_name: profile?.full_name || 'User',
        author_avatar_url: profile?.avatar_url ?? '',
      });
      if (error) throw error;
      setCommentDrafts((prev) => ({ ...prev, [postId]: '' }));
      loadComments(postId);
      loadPosts();
    } catch (err) {
      console.error('Error adding comment:', err);
      toast({ title: 'Failed to add comment', variant: 'error' });
    } finally {
      setSubmittingComment(null);
    }
  };

  const handleAddReply = async (postId: string, parentId: string) => {
    const text = (replyDrafts[parentId] ?? '').trim();
    if (!text) return;
    setSubmittingComment(parentId);
    try {
      const { error } = await supabase.from('community_comments').insert({
        post_id: postId,
        parent_comment_id: parentId,
        content: text,
        author_name: profile?.full_name || 'User',
        author_avatar_url: profile?.avatar_url ?? '',
      });
      if (error) throw error;
      setReplyDrafts((prev) => ({ ...prev, [parentId]: '' }));
      setReplyingTo(null);
      loadComments(postId);
      loadPosts();
    } catch (err) {
      console.error('Error adding reply:', err);
      toast({ title: 'Failed to add reply', variant: 'error' });
    } finally {
      setSubmittingComment(null);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      if (deleteTarget.type === 'post') {
        const { error } = await supabase.from('community_posts').delete().eq('id', deleteTarget.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('community_comments').delete().eq('id', deleteTarget.id);
        if (error) throw error;
      }
      toast({ title: 'Content deleted', variant: 'success' });
      loadPosts();
      if (deleteTarget.type === 'comment') {
        const postIds = Array.from(expandedPosts);
        postIds.forEach((pid) => loadComments(pid));
      }
      setDeleteTarget(null);
    } catch (err) {
      console.error('Error deleting:', err);
      toast({ title: 'Failed to delete', variant: 'error' });
    } finally {
      setDeleting(false);
    }
  };

  const canDeletePost = (post: CommunityPost) => post.author_id === user?.id || isAdmin;
  const canDeleteComment = (comment: CommunityComment) => comment.author_id === user?.id || isAdmin;

  const buildCommentTree = (comments: CommunityComment[]): (CommunityComment & { children: CommunityComment[] })[] => {
    const map = new Map<string, CommunityComment & { children: CommunityComment[] }>();
    const roots: (CommunityComment & { children: CommunityComment[] })[] = [];
    comments.forEach((c) => map.set(c.id, { ...c, children: [] }));
    comments.forEach((c) => {
      const node = map.get(c.id)!;
      if (c.parent_comment_id && map.has(c.parent_comment_id)) {
        map.get(c.parent_comment_id)!.children.push(node);
      } else {
        roots.push(node);
      }
    });
    return roots;
  };

  const renderComment = (comment: CommunityComment & { children: CommunityComment[] }, postId: string, depth: number) => {
    const cat = CATEGORY_MAP['general']!;
    return (
      <div key={comment.id} className={depth > 0 ? 'ml-6 pl-4 border-l border-subtle' : ''}>
        <div className="py-3">
          <div className="flex items-start gap-2.5">
            <Avatar name={comment.author_name} avatarUrl={comment.author_avatar_url} size="sm" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-semibold text-primary">{comment.author_name || 'User'}</span>
                <span className="text-xs text-secondary">{formatRelativeTime(comment.created_at)}</span>
                {comment.author_id === user?.id && (
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${cat.color}`}>You</span>
                )}
              </div>
              <p className="mt-1 text-sm text-primary leading-relaxed break-words whitespace-pre-wrap">{comment.content}</p>
              <div className="mt-1.5 flex items-center gap-3">
                <button
                  onClick={() => handleToggleCommentLike(comment.id, comment.liked_by_me)}
                  className={`inline-flex items-center gap-1 text-xs font-medium transition-colors ${
                    comment.liked_by_me
                      ? 'text-rose-500'
                      : 'text-secondary hover:text-rose-500'
                  }`}
                >
                  <Heart className={`w-3.5 h-3.5 ${comment.liked_by_me ? 'fill-rose-500' : ''}`} />
                  {comment.like_count > 0 && comment.like_count}
                </button>
                <button
                  onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)}
                  className="inline-flex items-center gap-1 text-xs font-medium text-secondary hover:text-primary transition-colors"
                >
                  <Reply className="w-3.5 h-3.5" />
                  Reply
                </button>
                {canDeleteComment(comment) && (
                  <button
                    onClick={() => setDeleteTarget({ type: 'comment', id: comment.id, label: 'this comment' })}
                    className="inline-flex items-center gap-1 text-xs font-medium text-secondary hover:text-rose-500 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete
                  </button>
                )}
              </div>

              {replyingTo === comment.id && (
                <div className="mt-2 flex items-start gap-2">
                  <input
                    type="text"
                    value={replyDrafts[comment.id] ?? ''}
                    onChange={(e) => setReplyDrafts((prev) => ({ ...prev, [comment.id]: e.target.value }))}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleAddReply(postId, comment.id);
                      }
                    }}
                    placeholder="Write a reply..."
                    className="flex-1 px-3 py-2 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
                    autoFocus
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleAddReply(postId, comment.id)}
                    disabled={submittingComment === comment.id || !(replyDrafts[comment.id] ?? '').trim()}
                  >
                    {submittingComment === comment.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
        {comment.children.length > 0 && (
          <div>
            {comment.children.map((child) => renderComment(child, postId, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  const firstName = (profile?.full_name || '').split(' ')[0] || 'there';

  return (
    <div className="min-h-screen bg-surface flex">
      <Sidebar active="community" onNavigate={onNavigate} dark={dark} onToggleDark={onToggleDark} />

      <div className="flex-1 min-w-0 pb-20 lg:pb-0">
        {/* Top bar (mobile) */}
        <div className="lg:hidden sticky top-0 z-40 glass-strong border-b border-subtle px-5 h-14 flex items-center justify-between">
          <button onClick={() => onNavigate('landing')} className="flex items-center gap-2">
            <span className="w-7 h-7 gradient-brand rounded-full flex items-center justify-center">
              <span className="w-2 h-2 bg-white rounded-full" />
            </span>
            <span className="font-bold text-primary">Nursify</span>
          </button>
          <button
            onClick={onToggleDark}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors"
          >
            {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>
        </div>

        <main className="max-w-3xl mx-auto px-5 sm:px-8 py-6 sm:py-8 space-y-6">
          {/* Header */}
          <div className="animate-slide-up">
            <div className="flex items-center gap-2 text-sm text-secondary font-medium">
              <MessageCircle className="w-4 h-4 text-violet-500" />
              Community
            </div>
            <h1 className="mt-1 text-2xl sm:text-3xl font-extrabold text-primary">
              Study together, {firstName}
            </h1>
            <p className="mt-1 text-sm text-secondary">
              Share tips, ask questions, and support fellow nursing students. Everyone sees the same posts.
            </p>
          </div>

          {/* Create Post */}
          <Card className="p-5 animate-slide-up animate-delay-100">
            <div className="flex items-start gap-3">
              <Avatar name={profile?.full_name ?? ''} avatarUrl={profile?.avatar_url ?? ''} size="md" />
              <div className="flex-1 space-y-3">
                <textarea
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  rows={3}
                  placeholder="Share something with the community..."
                  className="w-full px-4 py-3 rounded-xl border border-subtle bg-surface text-primary text-sm resize-none focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400 transition-all"
                />
                <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:justify-between">
                  <div className="flex gap-2 flex-wrap">
                    {CATEGORIES.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setNewPostCategory(cat.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                          newPostCategory === cat.id
                            ? cat.color + ' ring-2 ring-offset-1 ring-violet-400'
                            : 'bg-ink-50 dark:bg-ink-900/50 text-secondary hover:text-primary'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                  <Button
                    size="sm"
                    onClick={handleCreatePost}
                    disabled={posting || !newPost.trim()}
                    className="shrink-0"
                  >
                    {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    Post
                  </Button>
                </div>
              </div>
            </div>
          </Card>

          {/* Sort + Filter */}
          <div className="flex flex-col sm:flex-row gap-3 animate-slide-up animate-delay-100">
            <div className="flex gap-2">
              <button
                onClick={() => setSortMode('latest')}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all ${
                  sortMode === 'latest'
                    ? 'gradient-brand text-white shadow-lift'
                    : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300 bg-elevated'
                }`}
              >
                <Clock className="w-4 h-4" />
                Latest
              </button>
              <button
                onClick={() => setSortMode('popular')}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all ${
                  sortMode === 'popular'
                    ? 'gradient-brand text-white shadow-lift'
                    : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300 bg-elevated'
                }`}
              >
                <Flame className="w-4 h-4" />
                Popular
              </button>
            </div>
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
              <button
                onClick={() => setCategoryFilter('all')}
                className={`px-3.5 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
                  categoryFilter === 'all'
                    ? 'gradient-brand text-white shadow-lift'
                    : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300 bg-elevated'
                }`}
              >
                All
              </button>
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setCategoryFilter(cat.id)}
                  className={`px-3.5 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
                    categoryFilter === cat.id
                      ? 'gradient-brand text-white shadow-lift'
                      : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300 bg-elevated'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Posts */}
          {loading ? (
            <div className="space-y-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <Card key={i} className="p-5">
                  <div className="flex items-start gap-3">
                    <Skeleton className="w-10 h-10 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 rounded-lg w-1/3" />
                      <Skeleton className="h-3 rounded-lg w-1/4" />
                      <Skeleton className="h-16 rounded-xl w-full" />
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : sortedPosts.length === 0 ? (
            <div className="animate-slide-up animate-delay-100">
              <div className="relative overflow-hidden rounded-3xl border border-subtle bg-elevated p-10 sm:p-16 text-center">
                <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-violet-100 dark:bg-violet-950/30 blur-3xl" />
                <div className="relative">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl gradient-brand-soft mb-5">
                    <Users className="w-8 h-8 text-violet-600 dark:text-violet-400" />
                  </div>
                  <h2 className="text-xl font-bold text-primary">No posts yet</h2>
                  <p className="mt-2 text-secondary text-sm max-w-md mx-auto">
                    Be the first to start a conversation! Share a study tip or ask a question.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {sortedPosts.map((post) => {
                const cat = CATEGORY_MAP[post.category] ?? CATEGORY_MAP['general']!;
                const isExpanded = expandedPosts.has(post.id);
                const comments = commentsByPost[post.id] ?? [];
                const commentTree = buildCommentTree(comments);
                return (
                  <Card key={post.id} className="p-5 animate-slide-up">
                    {/* Author row */}
                    <div className="flex items-start gap-3">
                      <Avatar name={post.author_name} avatarUrl={post.author_avatar_url} size="md" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-primary text-sm">{post.author_name || 'User'}</span>
                          {post.author_id === user?.id && (
                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${cat.color}`}>You</span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${cat.color}`}>
                            {cat.label}
                          </span>
                          <span className="text-xs text-secondary">{formatRelativeTime(post.created_at)}</span>
                        </div>
                      </div>
                      {canDeletePost(post) && (
                        <button
                          onClick={() => setDeleteTarget({ type: 'post', id: post.id, label: 'this post' })}
                          className="w-8 h-8 rounded-lg flex items-center justify-center text-secondary hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors shrink-0"
                          aria-label="Delete post"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {/* Content */}
                    <p className="mt-3 text-sm text-primary leading-relaxed break-words whitespace-pre-wrap">{post.content}</p>

                    {/* Actions */}
                    <div className="mt-4 flex items-center gap-4">
                      <button
                        onClick={() => handleToggleLike(post.id, post.liked_by_me)}
                        className={`inline-flex items-center gap-1.5 text-sm font-medium transition-colors ${
                          post.liked_by_me ? 'text-rose-500' : 'text-secondary hover:text-rose-500'
                        }`}
                      >
                        <Heart className={`w-4 h-4 ${post.liked_by_me ? 'fill-rose-500' : ''}`} />
                        {post.like_count > 0 && <span>{post.like_count}</span>}
                        <span className="hidden sm:inline">{post.like_count === 1 ? 'Like' : 'Likes'}</span>
                      </button>
                      <button
                        onClick={() => toggleComments(post.id)}
                        className="inline-flex items-center gap-1.5 text-sm font-medium text-secondary hover:text-primary transition-colors"
                      >
                        <MessageCircle className="w-4 h-4" />
                        {post.comment_count > 0 && <span>{post.comment_count}</span>}
                        <span className="hidden sm:inline">{post.comment_count === 1 ? 'Comment' : 'Comments'}</span>
                        {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>
                    </div>

                    {/* Comments section */}
                    {isExpanded && (
                      <div className="mt-4 pt-4 border-t border-subtle space-y-3">
                        {/* Comment input */}
                        <div className="flex items-start gap-2.5">
                          <Avatar name={profile?.full_name ?? ''} avatarUrl={profile?.avatar_url ?? ''} size="sm" />
                          <div className="flex-1 flex items-center gap-2">
                            <input
                              type="text"
                              value={commentDrafts[post.id] ?? ''}
                              onChange={(e) => setCommentDrafts((prev) => ({ ...prev, [post.id]: e.target.value }))}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                  e.preventDefault();
                                  handleAddComment(post.id);
                                }
                              }}
                              placeholder="Write a comment..."
                              className="flex-1 px-3.5 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
                            />
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleAddComment(post.id)}
                              disabled={submittingComment === post.id || !(commentDrafts[post.id] ?? '').trim()}
                            >
                              {submittingComment === post.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                            </Button>
                          </div>
                        </div>

                        {/* Comment list */}
                        {loadingComments.has(post.id) ? (
                          <div className="flex items-center justify-center py-4">
                            <Loader2 className="w-5 h-5 animate-spin text-secondary" />
                          </div>
                        ) : comments.length === 0 ? (
                          <p className="text-xs text-secondary text-center py-3">No comments yet. Start the conversation!</p>
                        ) : (
                          <div className="space-y-1">
                            {commentTree.map((c) => renderComment(c, post.id, 0))}
                          </div>
                        )}
                      </div>
                    )}
                  </Card>
                );
              })}
            </div>
          )}
        </main>
      </div>

      <MobileNav active="community" onNavigate={onNavigate} />

      {/* Delete Confirmation Modal */}
      <Modal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        title="Delete Confirmation"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setDeleteTarget(null)}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleDelete}
              disabled={deleting}
              className="!bg-rose-500 hover:!bg-rose-600 !text-white"
            >
              {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              Delete
            </Button>
          </>
        }
      >
        {deleteTarget && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800">
              <span className="text-rose-500 shrink-0">
                <Trash2 className="w-5 h-5" />
              </span>
              <p className="text-sm text-rose-700 dark:text-rose-300 font-medium">
                Are you sure you want to delete {deleteTarget.label}? This action cannot be undone.
              </p>
            </div>
            {isAdmin && deleteTarget.type === 'post' && (
              <p className="text-xs text-secondary">
                As an admin, you can delete any community content.
              </p>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}

function Avatar({ name, avatarUrl, size }: { name: string; avatarUrl: string; size: 'sm' | 'md' }) {
  const initials = (name || '?').charAt(0).toUpperCase();
  const dims = size === 'md' ? 'w-10 h-10' : 'w-7 h-7';
  const text = size === 'md' ? 'text-sm' : 'text-[11px]';
  if (avatarUrl) {
    return (
      <img
        src={avatarUrl}
        alt={name}
        className={`${dims} rounded-full object-cover shrink-0 border border-subtle`}
      />
    );
  }
  return (
    <div className={`${dims} rounded-full gradient-brand flex items-center justify-center text-white font-bold ${text} shrink-0`}>
      {initials}
    </div>
  );
}
