import { useEffect, useState } from 'react';
import { ArrowLeft, TrendingUp, Target, Clock, Award } from 'lucide-react';
import type { View } from '@/types';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import { LineChart as LineChartSvg, BarChart as BarChartSvg, RadialChart } from '@/components/ui/Charts';
import { getLearningProgress, getStreak } from '@/lib/learning';
import {
  getDashboardStats,
  getScoreHistory,
  getWeeklyActivity,
  getSubjectPerformance,
} from '@/lib/questions';

interface AnalyticsProps {
  onNavigate: (view: View) => void;
  dark: boolean;
  onToggleDark: () => void;
}

const SUBJECT_ACCENTS: Record<string, string> = {
  pharmacology: '#8b5cf6',
  medsurg: '#6d28d9',
  pediatrics: '#10b981',
  mentalhealth: '#a78bfa',
  ob: '#f59e0b',
  fundamentals: '#7c3aed',
};

const accentBg: Record<string, string> = {
  violet: 'bg-violet-50 dark:bg-violet-950/40 text-violet-600 dark:text-violet-400',
  mint: 'bg-mint-50 dark:bg-mint-950/40 text-mint-600 dark:text-mint-400',
  amber: 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400',
  lavender: 'bg-lavender-50 dark:bg-lavender-950/40 text-lavender-600 dark:text-lavender-400',
};

function formatStudyTime(seconds: number): string {
  if (seconds < 60) return '0m';
  const hours = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m`;
}

export default function Analytics({ onNavigate, dark: _dark, onToggleDark: _onToggleDark }: AnalyticsProps) {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalAnswered: 0,
    accuracy: 0,
    studyTimeSeconds: 0,
    overallMastery: 0,
    recentScore: 0,
  });
  const [scoreHistory, setScoreHistory] = useState<{ label: string; score: number }[]>([]);
  const [weeklyActivity, setWeeklyActivity] = useState<{ dayLabel: string; answered: number; correct: number }[]>([]);
  const [subjects, setSubjects] = useState<{ subjectId: string; subjectName: string; mastery: number; answered: number; correct: number }[]>([]);
  const [learningActivity, setLearningActivity] = useState<{ activity_date: string; questions_answered: number; challenge_completed: boolean }[]>([]);

  useEffect(() => {
    Promise.all([
      getDashboardStats(),
      getScoreHistory(8),
      getWeeklyActivity(),
      getSubjectPerformance(),
      getLearningProgress(),
    ]).then(([dash, scores, weekly, subj, progress]) => {
      setStats({
        totalAnswered: dash.totalAnswered,
        accuracy: dash.accuracy,
        studyTimeSeconds: dash.studyTimeSeconds,
        overallMastery: dash.overallMastery,
        recentScore: dash.recentScore,
      });
      setScoreHistory(scores.map((s) => ({ label: s.label, score: s.score })));
      setWeeklyActivity(weekly);
      setSubjects(subj.map((s) => ({
        subjectId: s.subjectId,
        subjectName: s.subjectName,
        mastery: s.mastery,
        answered: s.answered,
        correct: s.correct,
      })));
      setLearningActivity(progress.activity);
      setLoading(false);
    });
  }, []);

  const hasData = stats.totalAnswered > 0;
  const hasScores = scoreHistory.length > 0;
  const hasSubjects = subjects.some((s) => s.answered > 0);
  const scoreDelta = scoreHistory.length > 1 ? scoreHistory[scoreHistory.length - 1].score - scoreHistory[0].score : 0;

  const summaryStats = [
    { icon: Target, label: 'Total Questions', value: loading ? '—' : stats.totalAnswered.toLocaleString(), accent: 'violet' },
    { icon: Award, label: 'Avg. Accuracy', value: loading ? '—' : `${stats.accuracy}%`, accent: 'mint' },
    { icon: Clock, label: 'Study Time', value: loading ? '—' : formatStudyTime(stats.studyTimeSeconds), accent: 'amber' },
    { icon: TrendingUp, label: 'Overall Mastery', value: loading ? '—' : `${stats.overallMastery}%`, accent: 'lavender' },
  ];

  return (
    <div className="min-h-screen bg-surface flex">
      <aside className="hidden lg:flex flex-col w-64 shrink-0 h-screen sticky top-0 bg-elevated border-r border-subtle px-4 py-5">
        <button onClick={() => onNavigate('landing')} className="flex items-center gap-2.5 px-2 mb-7">
          <span className="w-8 h-8 gradient-brand rounded-full flex items-center justify-center">
            <span className="w-2.5 h-2.5 bg-white rounded-full animate-pulse" />
          </span>
          <span className="font-bold text-lg tracking-tight text-primary">
            Nursify<span className="text-lavender-600"> Coaching</span>
          </span>
        </button>
        <div className="flex flex-col gap-1">
          {[
            { label: 'Home', view: 'dashboard' as View },
            { label: 'Practice', view: 'quiz' as View },
            { label: 'Analytics', view: 'analytics' as View },
          ].map((item) => (
            <button
              key={item.label}
              onClick={() => onNavigate(item.view)}
              className={`px-3 py-2.5 rounded-xl text-sm font-medium text-left transition-colors ${
                item.view === 'analytics'
                  ? 'bg-violet-50 dark:bg-violet-950/50 text-violet-700 dark:text-violet-300'
                  : 'text-secondary hover:text-primary hover:bg-ink-50 dark:hover:bg-ink-800/50'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </aside>

      <div className="flex-1 min-w-0 pb-20 lg:pb-0">
        <div className="lg:hidden sticky top-0 z-40 glass-strong border-b border-subtle px-5 h-14 flex items-center justify-between">
          <button onClick={() => onNavigate('dashboard')} className="flex items-center gap-2 text-secondary">
            <ArrowLeft className="w-4 h-4" />
            <span className="font-medium">Back</span>
          </button>
          <span className="font-bold text-primary">Analytics</span>
          <div className="w-12" />
        </div>

        <main className="max-w-6xl mx-auto px-5 sm:px-8 py-6 sm:py-8 space-y-6">
          <div className="animate-slide-up">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-primary">Analytics</h1>
            <p className="mt-1 text-secondary">Your performance at a glance.</p>
          </div>

          {!hasData && !loading ? (
            <Card className="p-12 text-center animate-slide-up animate-delay-100">
              <div className="w-16 h-16 rounded-2xl bg-ink-100 dark:bg-ink-800 flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-ink-400" />
              </div>
              <p className="text-lg font-bold text-primary">No analytics yet</p>
              <p className="text-sm text-secondary mt-2 max-w-md mx-auto">Start practicing to build your analytics. Your stats will appear here after you answer your first questions.</p>
              <div className="mt-6">
                <Button withArrow onClick={() => onNavigate('quiz')}>Start Practicing</Button>
              </div>
            </Card>
          ) : (
            <>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 animate-slide-up animate-delay-100">
                {summaryStats.map((s) => {
                  const Icon = s.icon;
                  return (
                    <Card key={s.label} className="p-5">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${accentBg[s.accent]}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <p className="mt-3 text-2xl font-extrabold text-primary">{s.value}</p>
                      <p className="text-xs text-secondary font-medium">{s.label}</p>
                    </Card>
                  );
                })}
              </div>

              <Card className="p-6 animate-slide-up animate-delay-200">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-primary">Score Trend</h3>
                    <p className="text-sm text-secondary">Recent completed quiz attempts</p>
                  </div>
                  {hasScores && (
                    <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-mint-50 dark:bg-mint-950/40">
                      <TrendingUp className="w-4 h-4 text-mint-600 dark:text-mint-400" />
                      <span className={`text-sm font-bold ${scoreDelta >= 0 ? 'text-mint-600 dark:text-mint-400' : 'text-rose-500'}`}>
                        {scoreDelta >= 0 ? '+' : ''}{scoreDelta} pts
                      </span>
                    </div>
                  )}
                </div>
                {hasScores ? (
                  <LineChartSvg data={scoreHistory.map((d) => ({ label: d.label, value: d.score }))} height={220} color="#8b5cf6" />
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <p className="text-sm font-semibold text-primary">No test data yet</p>
                    <p className="text-xs text-secondary mt-1">Complete a few practice tests to see your score trend.</p>
                  </div>
                )}
              </Card>

              <Card className="p-6 animate-slide-up animate-delay-300">
                <div className="flex flex-wrap items-end justify-between gap-4"><div><h3 className="text-lg font-bold text-primary">Study Activity</h3><p className="text-sm text-secondary">Only real answered questions and completed challenges count.</p></div><div className="flex gap-5 text-right"><div><p className="text-xl font-extrabold text-primary">{getStreak(learningActivity).current}</p><p className="text-xs text-secondary">Current streak</p></div><div><p className="text-xl font-extrabold text-primary">{getStreak(learningActivity).longest}</p><p className="text-xs text-secondary">Longest streak</p></div><div><p className="text-xl font-extrabold text-primary">{getStreak(learningActivity).activeDays}</p><p className="text-xs text-secondary">Active days</p></div></div></div>
                <div className="mt-5 grid grid-cols-7 gap-2">{learningActivity.slice(0, 28).reverse().map((day) => <div key={day.activity_date} title={day.activity_date} className={`h-7 rounded-md ${day.questions_answered > 0 || day.challenge_completed ? 'bg-violet-500' : 'bg-ink-100 dark:bg-ink-800'}`} />)}</div>
              </Card>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-slide-up animate-delay-300">
                <Card className="p-6">
                  <h3 className="text-lg font-bold text-primary">Weekly Activity</h3>
                  <p className="text-sm text-secondary">Questions answered vs correct (last 7 days)</p>
                  {hasData ? (
                    <div className="mt-5">
                      <BarChartSvg
                        data={weeklyActivity.map((d) => ({ label: d.dayLabel, value: d.answered, secondary: d.correct }))}
                        height={200}
                        color="#8b5cf6"
                        secondaryColor="#c4b5fd"
                      />
                      <div className="mt-3 flex items-center justify-center gap-5 text-xs">
                        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-violet-500" />Answered</span>
                        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-violet-300" />Correct</span>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <p className="text-sm font-semibold text-primary">No activity yet</p>
                      <p className="text-xs text-secondary mt-1">Answer questions to see your weekly activity.</p>
                    </div>
                  )}
                </Card>

                <Card className="p-6">
                  <h3 className="text-lg font-bold text-primary">Subject Mastery</h3>
                  <p className="text-sm text-secondary">Radial breakdown by subject</p>
                  {hasSubjects ? (
                    <>
                      <div className="mt-5 flex items-center justify-center">
                        <div className="relative">
                          <RadialChart
                            data={subjects.map((s) => ({
                              label: s.subjectName,
                              value: s.mastery,
                              color: SUBJECT_ACCENTS[s.subjectId] ?? '#6366f1',
                            }))}
                            size={220}
                          />
                          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                            <span className="text-2xl font-extrabold text-primary">{stats.overallMastery}%</span>
                            <span className="text-xs text-secondary">avg mastery</span>
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 grid grid-cols-2 gap-2">
                        {subjects.map((s) => (
                          <div key={s.subjectId} className="flex items-center gap-2">
                            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: SUBJECT_ACCENTS[s.subjectId] ?? '#6366f1' }} />
                            <span className="text-xs font-medium text-secondary">{s.subjectName}</span>
                            <span className="text-xs font-bold text-primary ml-auto">{s.mastery}%</span>
                          </div>
                        ))}
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <p className="text-sm font-semibold text-primary">No mastery data yet</p>
                      <p className="text-xs text-secondary mt-1">Answer questions across subjects to see your mastery breakdown.</p>
                    </div>
                  )}
                </Card>
              </div>
            </>
          )}

          <div className="flex flex-wrap gap-3 animate-slide-up animate-delay-300">
            <Button withArrow onClick={() => onNavigate('quiz')}>Practice Now</Button>
            <Button variant="secondary" onClick={() => onNavigate('dashboard')}>Back to Dashboard</Button>
          </div>
        </main>
      </div>
    </div>
  );
}
