import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import { Lock, Mail, ArrowRight, ShieldCheck } from 'lucide-react';

interface AdminLoginProps {
  onNavigate: (view: 'landing' | 'admin') => void;
  onLogin: () => void;
}

export default function AdminLogin({ onNavigate, onLogin }: AdminLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;
      if (!data.user) {
        setError('Login failed. Please check your credentials.');
        setLoading(false);
        return;
      }

      // Verify this user has admin role
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', data.user.id)
        .maybeSingle();

      if (profileError || !profile || profile.role !== 'admin') {
        await supabase.auth.signOut();
        setError('This account does not have admin access.');
        setLoading(false);
        return;
      }

      onLogin();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to sign in';
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface flex items-center justify-center px-5 py-12">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-2.5 mb-8 mx-auto justify-center">
          <span className="w-8 h-8 gradient-brand rounded-full flex items-center justify-center">
            <ShieldCheck className="w-4 h-4 text-white" />
          </span>
          <span className="font-bold text-lg tracking-tight text-primary">
            Nursify<span className="text-lavender-600"> Admin</span>
          </span>
        </div>

        <Card className="p-7">
          <h1 className="text-2xl font-extrabold text-primary text-center">Admin Login</h1>
          <p className="mt-2 text-sm text-secondary text-center">Sign in to manage users and questions</p>

          {error && (
            <div className="mt-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-sm text-rose-700 dark:text-rose-300">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
                  placeholder="admin@example.com"
                  autoComplete="email"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
                  placeholder="Admin password"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-ink-400 hover:text-secondary"
                >
                  {showPassword ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>

            <Button type="submit" size="lg" withArrow className="w-full" disabled={loading}>
              {loading ? 'Signing in...' : 'Sign In to Admin'}
            </Button>
          </form>
        </Card>

        <button
          onClick={() => onNavigate('landing')}
          className="mt-6 mx-auto flex items-center gap-1.5 text-sm text-secondary hover:text-primary transition-colors"
        >
          <ArrowRight className="w-3.5 h-3.5 rotate-180" />
          Back to home
        </button>
      </div>
    </div>
  );
}
