import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/components/ui/Toast';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Modal from '@/components/ui/Modal';
import {
  ShieldCheck, Users, FileText, Crown, Trash2, Plus, Pencil,
  Search, LogOut, Check, Upload, Download, FileUp, AlertCircle,
  Shield, User as UserIcon, Loader2, PlayCircle, Calendar,
  ChevronLeft, ChevronRight, GraduationCap, Eye, EyeOff,
} from 'lucide-react';

const CSV_HEADERS = [
  'question', 'subject', 'category', 'difficulty', 'question_type',
  'option_a', 'option_b', 'option_c', 'option_d',
  'correct_answer', 'rationale_a', 'rationale_b', 'rationale_c', 'rationale_d',
  'key_takeaway', 'nclex_tip',
];

const SUBJECT_MAP: Record<string, string> = {
  pharmacology: 'pharmacology',
  pharm: 'pharmacology',
  med: 'medsurg',
  'med-surg': 'medsurg',
  medsurg: 'medsurg',
  'med surg': 'medsurg',
  pediatrics: 'pediatrics',
  peds: 'pediatrics',
  'mental health': 'mentalhealth',
  mentalhealth: 'mentalhealth',
  psych: 'mentalhealth',
  psychiatry: 'mentalhealth',
  ob: 'ob',
  obstetrics: 'ob',
  'maternal': 'ob',
  'maternal & newborn': 'ob',
  fundamentals: 'fundamentals',
  'fund': 'fundamentals',
};

const SUBJECT_NAMES: Record<string, string> = {
  pharmacology: 'Pharmacology',
  medsurg: 'Med-Surg',
  pediatrics: 'Pediatrics',
  mentalhealth: 'Mental Health',
  ob: 'Maternal & Newborn',
  fundamentals: 'Fundamentals',
};

interface CsvRow {
  rowIndex: number;
  data: Record<string, string>;
  errors: string[];
}

interface ParsedCsv {
  rows: CsvRow[];
  validCount: number;
  errorCount: number;
}

function parseCsvLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current);
  return result.map((s) => s.trim());
}

function parseCsv(text: string): ParsedCsv {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length < 2) {
    return { rows: [], validCount: 0, errorCount: 0 };
  }

  const headers = parseCsvLine(lines[0]).map((h) => h.toLowerCase().trim());
  const rows: CsvRow[] = [];
  let validCount = 0;
  let errorCount = 0;

  for (let i = 1; i < lines.length; i++) {
    const values = parseCsvLine(lines[i]);
    const rowData: Record<string, string> = {};
    headers.forEach((h, idx) => {
      rowData[h] = values[idx] ?? '';
    });

    const errors: string[] = [];

    // Validate required fields
    if (!rowData.question?.trim()) errors.push('Question is required');
    if (!rowData.subject?.trim()) errors.push('Subject is required');
    if (!rowData.option_a?.trim()) errors.push('Option A is required');
    if (!rowData.option_b?.trim()) errors.push('Option B is required');
    if (!rowData.correct_answer?.trim()) errors.push('Correct answer is required');

    // Validate subject
    const subjectLower = (rowData.subject ?? '').toLowerCase().trim();
    if (subjectLower && !SUBJECT_MAP[subjectLower]) {
      errors.push(`Unknown subject "${rowData.subject}"`);
    }

    // Validate difficulty
    const difficulty = (rowData.difficulty ?? '').toLowerCase().trim() || 'medium';
    if (difficulty && !['easy', 'medium', 'hard', 'mixed'].includes(difficulty)) {
      errors.push(`Invalid difficulty "${difficulty}"`);
    }

    // Validate question_type
    const qType = (rowData.question_type ?? '').toLowerCase().trim() || 'multiple-choice';
    if (qType && !['multiple-choice', 'select-all-that-apply', 'ordered-response', 'hot-spot', 'ngn-case-study'].includes(qType)) {
      errors.push(`Invalid question_type "${qType}"`);
    }

    // Validate correct_answer format
    const correctRaw = (rowData.correct_answer ?? '').trim();
    if (correctRaw) {
      const correctLetters = correctRaw.split(',').map((s) => s.trim().toLowerCase());
      for (const letter of correctLetters) {
        if (!['a', 'b', 'c', 'd'].includes(letter)) {
          errors.push(`Invalid correct_answer "${letter}" (must be a, b, c, or d)`);
          break;
        }
      }
    }

    if (errors.length > 0) errorCount++;
    else validCount++;

    rows.push({ rowIndex: i + 1, data: rowData, errors });
  }

  return { rows, validCount, errorCount };
}

function downloadCsvTemplate() {
  const header = CSV_HEADERS.join(',');
  const sampleRow = [
    'A patient is prescribed warfarin. Which lab value should be monitored?',
    'Pharmacology',
    'Anticoagulants',
    'medium',
    'multiple-choice',
    'INR',
    'aPTT',
    'Platelet count',
    'WBC count',
    'a',
    'INR is the standard monitoring test for warfarin therapy.',
    'aPTT monitors heparin, not warfarin.',
    'Platelet count is not affected by warfarin.',
    'WBC count is unrelated to anticoagulation therapy.',
    'Warfarin is monitored using INR with a target of 2-3 for most indications.',
    'Remember: Warfarin = INR, Heparin = aPTT',
  ].map((v) => `"${v.replace(/"/g, '""')}"`).join(',');

  const csv = `${header}\n${sampleRow}\n`;
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'nursify_question_template.csv';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function rowToQuestionPayload(row: Record<string, string>) {
  const subjectLower = (row.subject ?? '').toLowerCase().trim();
  const subjectId = SUBJECT_MAP[subjectLower] || subjectLower || 'fundamentals';
  const subjectName = SUBJECT_NAMES[subjectId] || row.subject || 'Fundamentals';
  const difficulty = (row.difficulty ?? '').toLowerCase().trim() || 'medium';
  const qType = (row.question_type ?? '').toLowerCase().trim() || 'multiple-choice';
  const correctLetters = (row.correct_answer ?? '').split(',').map((s) => s.trim().toLowerCase());

  const options = [
    { id: 'a', label: row.option_a || '' },
    { id: 'b', label: row.option_b || '' },
    { id: 'c', label: row.option_c || '' },
    { id: 'd', label: row.option_d || '' },
  ].filter((o) => o.label);

  const optionRationales: Record<string, string> = {};
  if (row.rationale_a) optionRationales.a = row.rationale_a;
  if (row.rationale_b) optionRationales.b = row.rationale_b;
  if (row.rationale_c) optionRationales.c = row.rationale_c;
  if (row.rationale_d) optionRationales.d = row.rationale_d;

  return {
    id: `csv_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    question: row.question,
    subject_id: subjectId,
    subject_name: subjectName,
    category: row.category || 'General',
    topic: 'General',
    difficulty,
    question_type: qType,
    options,
    correct_answer: correctLetters,
    rationale: '',
    option_rationales: optionRationales,
    key_takeaway: row.key_takeaway || '',
    nclex_tip: row.nclex_tip || '',
  };
}

function getDaysRemaining(expiresAt: string | null): number | null {
  if (!expiresAt) return null;
  const now = new Date();
  const expires = new Date(expiresAt);
  const diffMs = expires.getTime() - now.getTime();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}

function formatPremiumStatus(expiresAt: string | null): { label: string; color: string } {
  const days = getDaysRemaining(expiresAt);
  if (days === null) return { label: 'Premium', color: 'text-violet-600 dark:text-violet-400' };
  if (days < 0) return { label: 'Expired', color: 'text-rose-600 dark:text-rose-400' };
  if (days === 0) return { label: 'Expires today', color: 'text-amber-600 dark:text-amber-400' };
  if (days <= 7) return { label: `${days} days remaining`, color: 'text-amber-600 dark:text-amber-400' };
  return { label: `${days} days remaining`, color: 'text-violet-600 dark:text-violet-400' };
}

type AdminTab = 'users' | 'questions' | 'videos';

interface AdminUser {
  id: string;
  full_name: string;
  email: string;
  role: string;
  subscription_status: string;
  created_at: string;
  premium_expires_at: string | null;
}

interface AdminQuestion {
  id: string;
  question: string;
  subject_id: string;
  subject_name: string;
  difficulty: string;
  question_type: string;
  category: string;
}

interface QuestionFormData {
  id: string;
  question: string;
  subject_id: string;
  subject_name: string;
  category: string;
  topic: string;
  difficulty: string;
  question_type: string;
  options: string;
  correct_answer: string;
  rationale: string;
  option_rationales: string;
  key_takeaway: string;
  nclex_tip: string;
  clinical_pearl: string;
  reference: string;
  tags: string;
  is_ngn: boolean;
  case_study: string;
  patient_data: string;
}

const EMPTY_FORM: QuestionFormData = {
  id: '',
  question: '',
  subject_id: 'fundamentals',
  subject_name: 'Fundamentals',
  category: 'General',
  topic: 'General',
  difficulty: 'medium',
  question_type: 'multiple-choice',
  options: '[{"id":"a","label":""},{"id":"b","label":""},{"id":"c","label":""},{"id":"d","label":""}]',
  correct_answer: '["a"]',
  rationale: '',
  option_rationales: '{}',
  key_takeaway: '',
  nclex_tip: '',
  clinical_pearl: '',
  reference: '',
  tags: '',
  is_ngn: false,
  case_study: '',
  patient_data: '',
};

interface AdminVideo {
  id: string;
  title: string;
  youtube_url: string;
  youtube_id: string;
  subject: string;
  lesson_date: string;
  created_at: string;
}

interface VideoFormData {
  id: string | null;
  title: string;
  youtube_url: string;
  subject: string;
  lesson_date: string;
}

const EMPTY_VIDEO_FORM: VideoFormData = {
  id: null,
  title: '',
  youtube_url: '',
  subject: 'general',
  lesson_date: new Date().toISOString().slice(0, 10),
};

const VIDEO_SUBJECT_OPTIONS: { value: string; label: string }[] = [
  { value: 'pharmacology', label: 'Pharmacology' },
  { value: 'medsurg', label: 'Med-Surg' },
  { value: 'pediatrics', label: 'Pediatrics' },
  { value: 'mentalhealth', label: 'Mental Health' },
  { value: 'ob', label: 'Maternal & Newborn' },
  { value: 'fundamentals', label: 'Fundamentals' },
  { value: 'general', label: 'General' },
];

const VIDEO_SUBJECT_LABELS: Record<string, string> = {
  pharmacology: 'Pharmacology',
  medsurg: 'Med-Surg',
  pediatrics: 'Pediatrics',
  mentalhealth: 'Mental Health',
  ob: 'Maternal & Newborn',
  fundamentals: 'Fundamentals',
  general: 'General',
};

function extractYouTubeId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=)([\w-]{11})/,
    /(?:youtu\.be\/)([\w-]{11})/,
    /(?:youtube\.com\/embed\/)([\w-]{11})/,
    /(?:youtube\.com\/shorts\/)([\w-]{11})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  // If it's just an 11-char ID
  if (/^[\w-]{11}$/.test(url.trim())) return url.trim();
  return null;
}

function formatVideoDate(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

interface AdminProps {
  onNavigate: (view: 'landing' | 'admin-login') => void;
  onLogout: () => void;
}

interface EditUserForm {
  id: string;
  role: string;
  subscription_status: string;
  premium_expires_at: string;
}

function getPageNumbers(current: number, total: number): (number | '...')[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const pages: (number | '...')[] = [1];
  if (current > 3) pages.push('...');
  const start = Math.max(2, current - 1);
  const end = Math.min(total - 1, current + 1);
  for (let i = start; i <= end; i++) pages.push(i);
  if (current < total - 2) pages.push('...');
  pages.push(total);
  return pages;
}

function PaginationControls({
  currentPage,
  totalPages,
  total,
  pageSize,
  goToPage,
  setGoToPage,
  onPageChange,
}: {
  currentPage: number;
  totalPages: number;
  total: number;
  pageSize: number;
  goToPage: string;
  setGoToPage: (v: string) => void;
  onPageChange: (p: number) => void;
}) {
  const pageNumbers = useMemo(() => getPageNumbers(currentPage, totalPages), [currentPage, totalPages]);

  const handleGoToPage = () => {
    const n = parseInt(goToPage, 10);
    if (!isNaN(n) && n >= 1 && n <= totalPages) {
      onPageChange(n);
      setGoToPage('');
    }
  };

  return (
    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
      <p className="text-xs text-secondary font-medium order-2 sm:order-1">
        Page {currentPage} of {totalPages.toLocaleString()}
      </p>

      <div className="flex items-center gap-1.5 order-1 sm:order-2">
        <button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage <= 1}
          className="w-9 h-9 rounded-lg flex items-center justify-center border border-subtle bg-elevated text-secondary hover:text-primary hover:border-violet-300 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          aria-label="Previous page"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        {pageNumbers.map((p, idx) =>
          p === '...' ? (
            <span key={`ellipsis-${idx}`} className="px-1.5 text-secondary text-sm font-medium">…</span>
          ) : (
            <button
              key={p}
              onClick={() => onPageChange(p)}
              className={`min-w-9 h-9 px-2.5 rounded-lg flex items-center justify-center text-sm font-semibold transition-all ${
                p === currentPage
                  ? 'gradient-brand text-white shadow-lift'
                  : 'border border-subtle bg-elevated text-secondary hover:text-primary hover:border-violet-300'
              }`}
            >
              {p}
            </button>
          ),
        )}

        <button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage >= totalPages}
          className="w-9 h-9 rounded-lg flex items-center justify-center border border-subtle bg-elevated text-secondary hover:text-primary hover:border-violet-300 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          aria-label="Next page"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="flex items-center gap-2 order-3">
        <input
          type="number"
          min={1}
          max={totalPages}
          value={goToPage}
          onChange={(e) => setGoToPage(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') handleGoToPage(); }}
          placeholder="Go to"
          className="w-20 px-2.5 py-2 rounded-lg border border-subtle bg-elevated text-primary text-sm text-center focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
        />
        <Button size="sm" variant="outline" onClick={handleGoToPage} disabled={!goToPage}>
          Go
        </Button>
      </div>
    </div>
  );
}

const MAIN_ADMIN_EMAIL = 'nursify@gmail.com';

export default function Admin({ onNavigate, onLogout }: AdminProps) {
  const { signOut, profile } = useAuth();
  const { toast } = useToast();
  const [tab, setTab] = useState<AdminTab>('users');
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [questions, setQuestions] = useState<AdminQuestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [questionPage, setQuestionPage] = useState(1);
  const [questionPageSize, setQuestionPageSize] = useState(50);
  const [questionTotal, setQuestionTotal] = useState(0);
  const [goToPage, setGoToPage] = useState('');
  const [editQuestion, setEditQuestion] = useState<QuestionFormData | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [csvOpen, setCsvOpen] = useState(false);
  const [csvParsed, setCsvParsed] = useState<ParsedCsv | null>(null);
  const [csvImporting, setCsvImporting] = useState(false);
  const [csvFileName, setCsvFileName] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [editUser, setEditUser] = useState<EditUserForm | null>(null);
  const [editUserSaving, setEditUserSaving] = useState(false);
  const [deleteUserConfirm, setDeleteUserConfirm] = useState<AdminUser | null>(null);
  const [deleteUserSaving, setDeleteUserSaving] = useState(false);
  const [videos, setVideos] = useState<AdminVideo[]>([]);
  const [editVideo, setEditVideo] = useState<VideoFormData | null>(null);
  const [videoSaving, setVideoSaving] = useState(false);
  const [deleteVideoConfirm, setDeleteVideoConfirm] = useState<AdminVideo | null>(null);
  const [deleteVideoSaving, setDeleteVideoSaving] = useState(false);
  const fetchUsers = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.rpc('admin_list_users');
    if (error) {
      console.error('Error fetching users:', error);
      setUsers([]);
    } else {
      setUsers((data as AdminUser[]) ?? []);
    }
    setLoading(false);
  }, []);

  const questionTotalPages = Math.max(1, Math.ceil(questionTotal / questionPageSize));

  const fetchQuestions = useCallback(async () => {
    setLoading(true);
    const from = (questionPage - 1) * questionPageSize;
    const to = from + questionPageSize - 1;
    const { data, error, count } = await supabase
      .from('questions')
      .select('id, question, subject_id, subject_name, difficulty, question_type, category', { count: 'exact' })
      .ilike('question', `%${search}%`)
      .order('created_at', { ascending: false })
      .range(from, to);
    if (error) {
      console.error('Error fetching questions:', error);
      setQuestions([]);
      setQuestionTotal(0);
    } else {
      setQuestions((data as AdminQuestion[]) ?? []);
      setQuestionTotal(count ?? 0);
    }
    setLoading(false);
  }, [search, questionPage, questionPageSize]);

  const fetchVideos = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('video_lessons')
      .select('*')
      .order('lesson_date', { ascending: false });
    if (error) {
      console.error('Error fetching videos:', error);
      setVideos([]);
    } else {
      setVideos((data as AdminVideo[]) ?? []);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    if (tab === 'users') fetchUsers();
    else if (tab === 'questions') fetchQuestions();
    else if (tab === 'videos') fetchVideos();
  }, [tab, fetchUsers, fetchQuestions, fetchVideos]);

  // Reset to page 1 when search changes
  useEffect(() => {
    if (tab === 'questions') setQuestionPage(1);
  }, [search, tab]);

  const handleSaveUser = async () => {
    if (!editUser) return;
    setEditUserSaving(true);
    let expiresAt: string | null = null;
    if (editUser.role === 'premium' && editUser.premium_expires_at) {
      expiresAt = new Date(editUser.premium_expires_at + 'T23:59:59').toISOString();
    }
    const { error } = await supabase.rpc('admin_set_user_role', {
      p_user_id: editUser.id,
      p_role: editUser.role,
      p_premium_expires_at: expiresAt,
    });
    if (error) {
      toast({ title: 'Update failed', description: error.message, variant: 'error' });
    } else {
      toast({ title: 'User updated', variant: 'success' });
      setEditUser(null);
      fetchUsers();
    }
    setEditUserSaving(false);
  };

  const handleDeleteUser = async () => {
    if (!deleteUserConfirm) return;
    setDeleteUserSaving(true);
    const { error } = await supabase.rpc('admin_delete_user', {
      p_user_id: deleteUserConfirm.id,
    });
    if (error) {
      toast({ title: 'Delete failed', description: error.message, variant: 'error' });
    } else {
      toast({ title: 'User deleted', variant: 'info' });
      setDeleteUserConfirm(null);
      fetchUsers();
    }
    setDeleteUserSaving(false);
  };

  const handleDeleteQuestion = async (questionId: string) => {
    if (!confirm('Delete this question? This cannot be undone.')) return;
    const { error } = await supabase.rpc('admin_delete_question', {
      p_question_id: questionId,
    });
    if (error) {
      toast({ title: 'Delete failed', description: error.message, variant: 'error' });
    } else {
      toast({ title: 'Question deleted', variant: 'info' });
      fetchQuestions();
    }
  };

  const handleEditQuestion = (q: AdminQuestion) => {
    supabase
      .from('questions')
      .select('*')
      .eq('id', q.id)
      .single()
      .then(({ data }) => {
        if (data) {
          setEditQuestion({
            id: data.id,
            question: data.question,
            subject_id: data.subject_id,
            subject_name: data.subject_name,
            category: data.category,
            topic: data.topic,
            difficulty: data.difficulty,
            question_type: data.question_type,
            options: JSON.stringify(data.options, null, 2),
            correct_answer: JSON.stringify(data.correct_answer, null, 2),
            rationale: data.rationale,
            option_rationales: JSON.stringify(data.option_rationales, null, 2),
            key_takeaway: data.key_takeaway,
            nclex_tip: data.nclex_tip,
            clinical_pearl: data.clinical_pearl,
            reference: data.reference,
            tags: Array.isArray(data.tags) ? data.tags.join(', ') : '',
            is_ngn: data.is_ngn,
            case_study: data.case_study ?? '',
            patient_data: data.patient_data ? JSON.stringify(data.patient_data, null, 2) : '',
          });
          setIsEditing(true);
        }
      });
  };

  const handleSaveQuestion = async () => {
    if (!editQuestion) return;
    if (!editQuestion.question.trim()) {
      toast({ title: 'Question text is required', variant: 'warning' });
      return;
    }

    let optionsJson: unknown;
    let correctAnswerJson: unknown;
    let optionRationalesJson: unknown;
    let patientDataJson: unknown | null;

    try {
      optionsJson = JSON.parse(editQuestion.options);
      correctAnswerJson = JSON.parse(editQuestion.correct_answer);
      optionRationalesJson = JSON.parse(editQuestion.option_rationales);
      patientDataJson = editQuestion.patient_data ? JSON.parse(editQuestion.patient_data) : null;
    } catch {
      toast({ title: 'Invalid JSON in one of the JSON fields', variant: 'error' });
      return;
    }

    const tagsArray = editQuestion.tags
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const params = {
      p_question: editQuestion.question,
      p_subject_id: editQuestion.subject_id,
      p_subject_name: editQuestion.subject_name,
      p_category: editQuestion.category,
      p_topic: editQuestion.topic,
      p_difficulty: editQuestion.difficulty,
      p_question_type: editQuestion.question_type,
      p_options: optionsJson,
      p_correct_answer: correctAnswerJson,
      p_rationale: editQuestion.rationale,
      p_option_rationales: optionRationalesJson,
      p_key_takeaway: editQuestion.key_takeaway,
      p_nclex_tip: editQuestion.nclex_tip,
      p_clinical_pearl: editQuestion.clinical_pearl,
      p_reference: editQuestion.reference,
      p_tags: tagsArray,
      p_is_ngn: editQuestion.is_ngn,
      p_case_study: editQuestion.case_study || null,
      p_patient_data: patientDataJson,
    };

    if (isEditing && editQuestion.id) {
      const { error } = await supabase.rpc('admin_update_question', {
        ...params,
        p_question_id: editQuestion.id,
      });
      if (error) {
        toast({ title: 'Update failed', description: error.message, variant: 'error' });
        return;
      }
      toast({ title: 'Question updated', variant: 'success' });
    } else {
      const newId = editQuestion.id || `q_${Date.now()}`;
      const { error } = await supabase.rpc('admin_insert_question', {
        ...params,
        p_id: newId,
      });
      if (error) {
        toast({ title: 'Insert failed', description: error.message, variant: 'error' });
        return;
      }
      toast({ title: 'Question added', variant: 'success' });
    }

    setEditQuestion(null);
    setIsEditing(false);
    fetchQuestions();
  };

  const handleSaveVideo = async () => {
    if (!editVideo) return;
    if (!editVideo.title.trim()) {
      toast({ title: 'Title is required', variant: 'warning' });
      return;
    }
    if (!editVideo.youtube_url.trim()) {
      toast({ title: 'YouTube URL is required', variant: 'warning' });
      return;
    }
    const ytId = extractYouTubeId(editVideo.youtube_url);
    if (!ytId) {
      toast({ title: 'Invalid YouTube URL', description: 'Could not extract video ID', variant: 'error' });
      return;
    }
    setVideoSaving(true);
    if (editVideo.id) {
      const { error } = await supabase.rpc('admin_update_video_lesson', {
        p_id: editVideo.id,
        p_title: editVideo.title,
        p_youtube_url: editVideo.youtube_url,
        p_youtube_id: ytId,
        p_subject: editVideo.subject,
        p_lesson_date: editVideo.lesson_date,
      });
      if (error) {
        toast({ title: 'Update failed', description: error.message, variant: 'error' });
      } else {
        toast({ title: 'Video updated', variant: 'success' });
        setEditVideo(null);
        fetchVideos();
      }
    } else {
      const { error } = await supabase.rpc('admin_add_video_lesson', {
        p_title: editVideo.title,
        p_youtube_url: editVideo.youtube_url,
        p_youtube_id: ytId,
        p_subject: editVideo.subject,
        p_lesson_date: editVideo.lesson_date,
      });
      if (error) {
        toast({ title: 'Add failed', description: error.message, variant: 'error' });
      } else {
        toast({ title: 'Video added', variant: 'success' });
        setEditVideo(null);
        fetchVideos();
      }
    }
    setVideoSaving(false);
  };

  const handleDeleteVideo = async () => {
    if (!deleteVideoConfirm) return;
    setDeleteVideoSaving(true);
    const { error } = await supabase.rpc('admin_delete_video_lesson', {
      p_id: deleteVideoConfirm.id,
    });
    if (error) {
      toast({ title: 'Delete failed', description: error.message, variant: 'error' });
    } else {
      toast({ title: 'Video deleted', variant: 'info' });
      setDeleteVideoConfirm(null);
      fetchVideos();
    }
    setDeleteVideoSaving(false);
  };

  const handleLogout = async () => {
    await signOut();
    onLogout();
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCsvFileName(file.name);
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      const parsed = parseCsv(text);
      setCsvParsed(parsed);
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleImportCsv = async () => {
    if (!csvParsed || csvParsed.validCount === 0) {
      toast({ title: 'No valid rows to import', variant: 'warning' });
      return;
    }

    setCsvImporting(true);
    const validRows = csvParsed.rows.filter((r) => r.errors.length === 0);
    const payload = validRows.map((r) => rowToQuestionPayload(r.data));

    const { data, error } = await supabase.rpc('admin_bulk_insert_questions', {
      p_questions: payload,
    });

    if (error) {
      toast({ title: 'Import failed', description: error.message, variant: 'error' });
    } else {
      const result = data as unknown as { inserted_count: number; error_message: string | null } | null;
      const inserted = result?.inserted_count ?? 0;
      const skipped = payload.length - inserted;
      toast({
        title: `Imported ${inserted} questions`,
        description: skipped > 0 ? `${skipped} duplicate(s) skipped` : undefined,
        variant: 'success',
      });
      setCsvOpen(false);
      setCsvParsed(null);
      setCsvFileName('');
      fetchQuestions();
    }
    setCsvImporting(false);
  };

  const filteredUsers = users.filter(
    (u) =>
      u.full_name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-surface">
      <header className="sticky top-0 z-50 glass border-b border-subtle">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 gradient-brand rounded-full flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-white" />
            </span>
            <span className="font-bold text-lg text-primary">Admin Dashboard</span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="ghost" onClick={() => onNavigate('landing')}>
              View Site
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={handleLogout}
            >
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-5 sm:px-8 py-8 space-y-6">
        <div className="flex items-center gap-2 border-b border-subtle">
          <button
            onClick={() => setTab('users')}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
              tab === 'users'
                ? 'border-violet-500 text-violet-600 dark:text-violet-400'
                : 'border-transparent text-secondary hover:text-primary'
            }`}
          >
            <Users className="w-4 h-4" />
            Users
          </button>
          <button
            onClick={() => setTab('questions')}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
              tab === 'questions'
                ? 'border-violet-500 text-violet-600 dark:text-violet-400'
                : 'border-transparent text-secondary hover:text-primary'
            }`}
          >
            <FileText className="w-4 h-4" />
            Questions
          </button>
          <button
            onClick={() => setTab('videos')}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
              tab === 'videos'
                ? 'border-violet-500 text-violet-600 dark:text-violet-400'
                : 'border-transparent text-secondary hover:text-primary'
            }`}
          >
            <PlayCircle className="w-4 h-4" />
            Video Lessons
          </button>

        </div>

        <div className="flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={
                tab === 'users'
                  ? 'Search users by name or email...'
                  : tab === 'questions'
                  ? 'Search questions...'
                  : 'Search videos by title...'
              }
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
            />
          </div>
          {tab === 'questions' && (
            <>
              <Button
                size="sm"
                variant="outline"
                onClick={downloadCsvTemplate}
              >
                <Download className="w-4 h-4" />
                Template
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setCsvOpen(true);
                  setCsvParsed(null);
                  setCsvFileName('');
                }}
              >
                <Upload className="w-4 h-4" />
                Import CSV
              </Button>
              <Button
                size="sm"
                onClick={() => {
                  setEditQuestion({ ...EMPTY_FORM });
                  setIsEditing(false);
                }}
              >
                <Plus className="w-4 h-4" />
                Add Question
              </Button>
            </>
          )}
          {tab === 'videos' && (
            <Button
              size="sm"
              onClick={() => setEditVideo({ ...EMPTY_VIDEO_FORM })}
            >
              <Plus className="w-4 h-4" />
              Add Video
            </Button>
          )}

        </div>

        {loading ? (
          <p className="text-secondary">Loading...</p>
        ) : tab === 'users' ? (
          <div className="space-y-3">
            {filteredUsers.length === 0 ? (
              <Card className="p-8 text-center text-sm text-secondary">No users found.</Card>
            ) : (
              filteredUsers.map((u) => {
                const isMainAdmin = u.email === MAIN_ADMIN_EMAIL;
                const isSelf = u.id === profile?.id;
                return (
                  <Card key={u.id} className="p-5">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                      <div className="flex items-center gap-3 flex-1">
                        <div className="w-10 h-10 rounded-full gradient-brand flex items-center justify-center text-white font-bold text-sm shrink-0">
                          {(u.full_name || u.email || '?').charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-primary">{u.full_name || 'Unnamed'}</p>
                          <p className="text-sm text-secondary truncate">{u.email}</p>
                          <div className="mt-1.5 flex flex-wrap items-center gap-2">
                            {/* Role badge */}
                            <span
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-semibold ${
                                u.role === 'admin'
                                  ? 'bg-amber-100 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300'
                                  : 'bg-ink-100 dark:bg-ink-800 text-secondary'
                              }`}
                            >
                              {u.role === 'admin' ? <Shield className="w-3 h-3" /> : <UserIcon className="w-3 h-3" />}
                              {u.role === 'admin' ? 'Admin' : 'User'}
                            </span>
                            {/* Plan badge */}
                            <span
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-semibold ${
                                u.role === 'premium' || u.role === 'admin'
                                  ? 'bg-violet-100 dark:bg-violet-950/50 text-violet-700 dark:text-violet-300'
                                  : 'bg-ink-100 dark:bg-ink-800 text-secondary'
                              }`}
                            >
                              {u.role === 'premium' || u.role === 'admin' ? <Crown className="w-3 h-3" /> : <UserIcon className="w-3 h-3" />}
                              {u.role === 'premium' || u.role === 'admin' ? 'Premium' : 'Free'}
                            </span>
                            <span className="text-xs text-secondary">
                              Joined {new Date(u.created_at).toLocaleDateString()}
                            </span>
                            {u.premium_expires_at && (
                              <span className="text-xs text-violet-600 dark:text-violet-400 font-medium">
                                Expires {new Date(u.premium_expires_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                              </span>
                            )}
                            {(() => {
                              const isUserPremium = u.role === 'premium' || u.role === 'admin';
                              if (!isUserPremium) return null;
                              if (u.role === 'admin') {
                                return (
                                  <span className="text-xs text-amber-600 dark:text-amber-400 font-medium">
                                    Admin • No expiration
                                  </span>
                                );
                              }
                              const status = formatPremiumStatus(u.premium_expires_at);
                              return (
                                <span className={`text-xs font-medium ${status.color}`}>
                                  Premium • {status.label}
                                </span>
                              );
                            })()}
                          </div>
                        </div>
                      </div>
                      <div className="shrink-0 flex items-center gap-2">
                        {isMainAdmin ? (
                          <span className="text-xs text-secondary italic flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                            Protected
                          </span>
                        ) : (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setEditUser({
                                id: u.id,
                                role: u.role,
                                subscription_status: u.subscription_status,
                                premium_expires_at: u.premium_expires_at
                                  ? u.premium_expires_at.slice(0, 10)
                                  : '',
                              })}
                            >
                              <Pencil className="w-4 h-4" />
                              Edit
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setDeleteUserConfirm(u)}
                              className="border-rose-300 text-rose-600 hover:bg-rose-50 dark:border-rose-700 dark:text-rose-400 dark:hover:bg-rose-950/40"
                              disabled={isSelf}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </Card>
                );
              })
            )}
          </div>
        ) : tab === 'questions' ? (
          <div className="space-y-3">
            {/* Question count summary */}
            <div className="flex items-center justify-between flex-wrap gap-2">
              <p className="text-sm text-secondary font-medium">
                {questionTotal > 0
                  ? `Showing ${(questionPage - 1) * questionPageSize + 1}–${Math.min(questionPage * questionPageSize, questionTotal)} of ${questionTotal.toLocaleString()} question${questionTotal === 1 ? '' : 's'}`
                  : 'No questions found.'}
              </p>
              <div className="flex items-center gap-2">
                <span className="text-xs text-secondary font-medium">Per page</span>
                <select
                  value={questionPageSize}
                  onChange={(e) => { setQuestionPageSize(Number(e.target.value)); setQuestionPage(1); }}
                  className="px-2.5 py-1.5 rounded-lg border border-subtle bg-elevated text-primary text-sm font-medium focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                >
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 animate-spin text-secondary" />
              </div>
            ) : questions.length === 0 ? (
              <Card className="p-8 text-center text-sm text-secondary">No questions found.</Card>
            ) : (
              <>
                {questions.map((q) => (
                  <Card key={q.id} className="p-5">
                    <div className="flex items-start gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-primary line-clamp-2">{q.question}</p>
                        <div className="mt-2 flex flex-wrap gap-2">
                          <span className="px-2 py-0.5 rounded-md text-xs font-medium bg-ink-100 dark:bg-ink-800 text-secondary">
                            {q.subject_name}
                          </span>
                          <span className="px-2 py-0.5 rounded-md text-xs font-medium bg-ink-100 dark:bg-ink-800 text-secondary">
                            {q.difficulty}
                          </span>
                          <span className="px-2 py-0.5 rounded-md text-xs font-medium bg-ink-100 dark:bg-ink-800 text-secondary">
                            {q.question_type}
                          </span>
                        </div>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEditQuestion(q)}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeleteQuestion(q.id)}
                          className="border-rose-300 text-rose-600 hover:bg-rose-50 dark:border-rose-700 dark:text-rose-400 dark:hover:bg-rose-950/40"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}

                {/* Pagination controls */}
                <PaginationControls
                  currentPage={questionPage}
                  totalPages={questionTotalPages}
                  total={questionTotal}
                  pageSize={questionPageSize}
                  goToPage={goToPage}
                  setGoToPage={setGoToPage}
                  onPageChange={(p) => setQuestionPage(p)}
                />
              </>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {videos.length === 0 ? (
              <Card className="p-8 text-center text-sm text-secondary">No video lessons yet. Click "Add Video" to add one.</Card>
            ) : (
              videos.map((v) => (
                <Card key={v.id} className="p-5">
                  <div className="flex items-start gap-4">
                    <div className="w-24 h-16 rounded-lg overflow-hidden shrink-0 bg-ink-100 dark:bg-ink-800">
                      <img
                        src={`https://i.ytimg.com/vi/${v.youtube_id}/hqdefault.jpg`}
                        alt={v.title}
                        className="w-full h-full object-cover"
                        onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-primary line-clamp-2">{v.title}</p>
                      <div className="mt-2 flex flex-wrap gap-2">
                        <span className="px-2 py-0.5 rounded-md text-xs font-medium bg-violet-100 dark:bg-violet-950/50 text-violet-700 dark:text-violet-300">
                          {VIDEO_SUBJECT_LABELS[v.subject] ?? v.subject}
                        </span>
                        <span className="px-2 py-0.5 rounded-md text-xs font-medium bg-ink-100 dark:bg-ink-800 text-secondary flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatVideoDate(v.lesson_date)}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setEditVideo({
                          id: v.id,
                          title: v.title,
                          youtube_url: v.youtube_url,
                          subject: v.subject,
                          lesson_date: v.lesson_date,
                        })}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setDeleteVideoConfirm(v)}
                        className="border-rose-300 text-rose-600 hover:bg-rose-50 dark:border-rose-700 dark:text-rose-400 dark:hover:bg-rose-950/40"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        )}
      </main>

      <Modal
        open={!!editQuestion}
        onClose={() => setEditQuestion(null)}
        title={isEditing ? 'Edit Question' : 'Add New Question'}
      >
        {editQuestion && (
          <div className="max-h-[70vh] overflow-y-auto space-y-4">
            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Question ID (optional for new)</label>
              <input
                type="text"
                value={editQuestion.id}
                onChange={(e) => setEditQuestion({ ...editQuestion, id: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                placeholder="auto-generated if blank"
                disabled={isEditing}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Question Text</label>
              <textarea
                value={editQuestion.question}
                onChange={(e) => setEditQuestion({ ...editQuestion, question: e.target.value })}
                rows={3}
                className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 resize-none"
                placeholder="Enter the question..."
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-primary mb-1.5">Subject ID</label>
                <input
                  type="text"
                  value={editQuestion.subject_id}
                  onChange={(e) => setEditQuestion({ ...editQuestion, subject_id: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-primary mb-1.5">Subject Name</label>
                <input
                  type="text"
                  value={editQuestion.subject_name}
                  onChange={(e) => setEditQuestion({ ...editQuestion, subject_name: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-primary mb-1.5">Difficulty</label>
                <select
                  value={editQuestion.difficulty}
                  onChange={(e) => setEditQuestion({ ...editQuestion, difficulty: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                >
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                  <option value="mixed">Mixed</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-primary mb-1.5">Question Type</label>
                <select
                  value={editQuestion.question_type}
                  onChange={(e) => setEditQuestion({ ...editQuestion, question_type: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                >
                  <option value="multiple-choice">Multiple Choice</option>
                  <option value="select-all-that-apply">Select All That Apply</option>
                  <option value="ordered-response">Ordered Response</option>
                  <option value="hot-spot">Hot Spot</option>
                  <option value="ngn-case-study">NGN Case Study</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Options (JSON)</label>
              <textarea
                value={editQuestion.options}
                onChange={(e) => setEditQuestion({ ...editQuestion, options: e.target.value })}
                rows={5}
                className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-xs font-mono focus:outline-none focus:ring-2 focus:ring-violet-500/50 resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Correct Answer (JSON array of option IDs)</label>
              <textarea
                value={editQuestion.correct_answer}
                onChange={(e) => setEditQuestion({ ...editQuestion, correct_answer: e.target.value })}
                rows={2}
                className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-xs font-mono focus:outline-none focus:ring-2 focus:ring-violet-500/50 resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Rationale</label>
              <textarea
                value={editQuestion.rationale}
                onChange={(e) => setEditQuestion({ ...editQuestion, rationale: e.target.value })}
                rows={3}
                className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Option Rationales (JSON)</label>
              <textarea
                value={editQuestion.option_rationales}
                onChange={(e) => setEditQuestion({ ...editQuestion, option_rationales: e.target.value })}
                rows={4}
                className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-xs font-mono focus:outline-none focus:ring-2 focus:ring-violet-500/50 resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-primary mb-1.5">Category</label>
                <input
                  type="text"
                  value={editQuestion.category}
                  onChange={(e) => setEditQuestion({ ...editQuestion, category: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-primary mb-1.5">Topic</label>
                <input
                  type="text"
                  value={editQuestion.topic}
                  onChange={(e) => setEditQuestion({ ...editQuestion, topic: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Tags (comma-separated)</label>
              <input
                type="text"
                value={editQuestion.tags}
                onChange={(e) => setEditQuestion({ ...editQuestion, tags: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                placeholder="pharmacology, dosage, iv"
              />
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="is-ngn"
                checked={editQuestion.is_ngn}
                onChange={(e) => setEditQuestion({ ...editQuestion, is_ngn: e.target.checked })}
                className="w-4 h-4 rounded border-subtle"
              />
              <label htmlFor="is-ngn" className="text-sm font-medium text-primary">NGN Question</label>
            </div>

            <div className="flex gap-2 justify-end pt-2">
              <Button variant="ghost" onClick={() => setEditQuestion(null)}>Cancel</Button>
              <Button onClick={handleSaveQuestion}>
                <Check className="w-4 h-4" />
                {isEditing ? 'Save Changes' : 'Add Question'}
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* CSV Import Modal */}
      <Modal
        open={csvOpen}
        onClose={() => {
          setCsvOpen(false);
          setCsvParsed(null);
          setCsvFileName('');
        }}
        title="Import Questions from CSV"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Button size="sm" variant="outline" onClick={downloadCsvTemplate}>
              <Download className="w-4 h-4" />
              Download Template
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,text/csv"
              onChange={handleFileSelect}
              className="hidden"
            />
            <Button
              size="sm"
              variant="secondary"
              onClick={() => fileInputRef.current?.click()}
            >
              <FileUp className="w-4 h-4" />
              Choose CSV File
            </Button>
          </div>

          {csvFileName && (
            <p className="text-sm text-secondary">
              File: <span className="font-medium text-primary">{csvFileName}</span>
            </p>
          )}

          {csvParsed && (
            <div className="space-y-3">
              <div className="flex items-center gap-4">
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-mint-50 dark:bg-mint-950/40 text-mint-700 dark:text-mint-300 text-sm font-semibold">
                  <Check className="w-4 h-4" />
                  {csvParsed.validCount} valid
                </span>
                {csvParsed.errorCount > 0 && (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-sm font-semibold">
                    <AlertCircle className="w-4 h-4" />
                    {csvParsed.errorCount} with errors
                  </span>
                )}
              </div>

              {csvParsed.rows.some((r) => r.errors.length > 0) && (
                <div className="max-h-48 overflow-y-auto space-y-2">
                  {csvParsed.rows
                    .filter((r) => r.errors.length > 0)
                    .map((r) => (
                      <div
                        key={r.rowIndex}
                        className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800"
                      >
                        <p className="text-xs font-semibold text-rose-700 dark:text-rose-300">
                          Row {r.rowIndex}
                        </p>
                        <p className="text-xs text-rose-600 dark:text-rose-400 mt-0.5">
                          {r.errors.join('; ')}
                        </p>
                      </div>
                    ))}
                </div>
              )}

              {csvParsed.validCount > 0 && (
                <div className="flex gap-2 justify-end pt-2">
                  <Button
                    variant="ghost"
                    onClick={() => {
                      setCsvOpen(false);
                      setCsvParsed(null);
                      setCsvFileName('');
                    }}
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleImportCsv} disabled={csvImporting}>
                    <Upload className="w-4 h-4" />
                    {csvImporting ? 'Importing...' : `Import ${csvParsed.validCount} Questions`}
                  </Button>
                </div>
              )}
            </div>
          )}

          {!csvParsed && (
            <div className="p-4 rounded-xl bg-ink-50 dark:bg-ink-900/50">
              <p className="text-xs text-secondary">
                Required columns: {CSV_HEADERS.join(', ')}
              </p>
              <p className="text-xs text-secondary mt-2">
                The <code className="text-primary">correct_answer</code> column accepts
                one or more letters (a, b, c, d) separated by commas. Valid subjects:
                Pharmacology, Med-Surg, Pediatrics, Mental Health, Maternal &amp; Newborn, Fundamentals.
              </p>
            </div>
          )}
        </div>
      </Modal>

      {/* Edit User Modal */}
      <Modal
        open={!!editUser}
        onClose={() => setEditUser(null)}
        title="Edit User"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setEditUser(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={handleSaveUser} disabled={editUserSaving}>
              {editUserSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              Save Changes
            </Button>
          </>
        }
      >
        {editUser && (
          <div className="space-y-5">
            <div>
              <label className="text-sm font-semibold text-primary mb-2 block">Role</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setEditUser({ ...editUser, role: 'free' })}
                  className={`flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                    editUser.role === 'free'
                      ? 'gradient-brand text-white shadow-lift'
                      : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300'
                  }`}
                >
                  <UserIcon className="w-4 h-4" />
                  User
                </button>
                <button
                  onClick={() => setEditUser({ ...editUser, role: 'admin' })}
                  className={`flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                    editUser.role === 'admin'
                      ? 'gradient-brand text-white shadow-lift'
                      : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300'
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  Admin
                </button>
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold text-primary mb-2 block">Plan</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setEditUser({ ...editUser, role: editUser.role === 'admin' ? 'admin' : 'free' })}
                  disabled={editUser.role === 'admin'}
                  className={`flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                    editUser.role !== 'premium' && editUser.role !== 'admin'
                      ? 'gradient-brand text-white shadow-lift'
                      : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300'
                  }`}
                >
                  <UserIcon className="w-4 h-4" />
                  Free
                </button>
                <button
                  onClick={() => setEditUser({ ...editUser, role: editUser.role === 'admin' ? 'admin' : 'premium' })}
                  disabled={editUser.role === 'admin'}
                  className={`flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                    editUser.role === 'premium' || editUser.role === 'admin'
                      ? 'gradient-brand text-white shadow-lift'
                      : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300'
                  }`}
                >
                  <Crown className="w-4 h-4" />
                  Premium
                </button>
              </div>
              {editUser.role === 'admin' && (
                <p className="text-xs text-secondary mt-2 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                  Admin accounts automatically have premium access
                </p>
              )}
              {editUser.role === 'premium' && (
                <div className="mt-3">
                  <label className="block text-sm font-semibold text-primary mb-1.5">Premium Expiration Date</label>
                  <input
                    type="date"
                    value={editUser.premium_expires_at}
                    onChange={(e) => setEditUser({ ...editUser, premium_expires_at: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
                  />
                  <p className="text-xs text-secondary mt-1">
                    Leave blank to auto-set to 3 months from today.
                  </p>
                  {editUser.premium_expires_at && (() => {
                    const status = formatPremiumStatus(editUser.premium_expires_at + 'T23:59:59');
                    return (
                      <p className={`text-xs font-medium mt-1.5 ${status.color}`}>
                        {status.label === 'Expired' ? 'Expired' : status.label === 'Expires today' ? 'Expires today' : `Premium • ${status.label}`}
                      </p>
                    );
                  })()}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* Delete User Confirmation Modal */}
      <Modal
        open={!!deleteUserConfirm}
        onClose={() => setDeleteUserConfirm(null)}
        title="Delete User"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setDeleteUserConfirm(null)}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleDeleteUser}
              disabled={deleteUserSaving}
              className="!bg-rose-500 hover:!bg-rose-600 !text-white"
            >
              {deleteUserSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              Delete User
            </Button>
          </>
        }
      >
        {deleteUserConfirm && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800">
              <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
              <p className="text-sm text-rose-700 dark:text-rose-300 font-medium">
                This action cannot be undone. All user data will be permanently deleted.
              </p>
            </div>
            <p className="text-sm text-secondary">
              Are you sure you want to delete{' '}
              <span className="font-semibold text-primary">{deleteUserConfirm.full_name || 'Unnamed'}</span>{' '}
              ({deleteUserConfirm.email})?
            </p>
          </div>
        )}
      </Modal>

      {/* Edit Video Modal */}
      <Modal
        open={!!editVideo}
        onClose={() => setEditVideo(null)}
        title={editVideo?.id ? 'Edit Video Lesson' : 'Add Video Lesson'}
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setEditVideo(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={handleSaveVideo} disabled={videoSaving}>
              {videoSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              {editVideo?.id ? 'Save Changes' : 'Add Video'}
            </Button>
          </>
        }
      >
        {editVideo && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Lesson Title</label>
              <input
                type="text"
                value={editVideo.title}
                onChange={(e) => setEditVideo({ ...editVideo, title: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                placeholder="e.g. Pharmacology: Cardiovascular Drugs"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">YouTube URL</label>
              <input
                type="text"
                value={editVideo.youtube_url}
                onChange={(e) => setEditVideo({ ...editVideo, youtube_url: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                placeholder="https://www.youtube.com/watch?v=..."
              />
              <p className="text-xs text-secondary mt-1">
                Paste the full YouTube link (watch, youtu.be, or embed URL).
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-primary mb-1.5">Subject</label>
                <select
                  value={editVideo.subject}
                  onChange={(e) => setEditVideo({ ...editVideo, subject: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                >
                  {VIDEO_SUBJECT_OPTIONS.map((s) => (
                    <option key={s.value} value={s.value}>{s.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-primary mb-1.5">Lesson Date</label>
                <input
                  type="date"
                  value={editVideo.lesson_date}
                  onChange={(e) => setEditVideo({ ...editVideo, lesson_date: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                />
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Delete Video Confirmation Modal */}
      <Modal
        open={!!deleteVideoConfirm}
        onClose={() => setDeleteVideoConfirm(null)}
        title="Delete Video Lesson"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setDeleteVideoConfirm(null)}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleDeleteVideo}
              disabled={deleteVideoSaving}
              className="!bg-rose-500 hover:!bg-rose-600 !text-white"
            >
              {deleteVideoSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              Delete Video
            </Button>
          </>
        }
      >
        {deleteVideoConfirm && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800">
              <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
              <p className="text-sm text-rose-700 dark:text-rose-300 font-medium">
                This action cannot be undone.
              </p>
            </div>
            <p className="text-sm text-secondary">
              Are you sure you want to delete{' '}
              <span className="font-semibold text-primary">{deleteVideoConfirm.title}</span>?
            </p>
          </div>
        )}
      </Modal>
    </div>
  );
}
