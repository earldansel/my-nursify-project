import { useState } from 'react';
import { Pill, Activity, Baby, Brain, Heart, BookOpen, ArrowRight, Search, Moon, Sun, GraduationCap, CheckCircle2, Circle, Stethoscope, HeartPulse } from 'lucide-react';
import Sidebar from '@/components/dashboard/Sidebar';
import MobileNav from '@/components/dashboard/MobileNav';
import { useStudyGuideSubjects, type StudyGuideSubject } from '@/lib/study-guide';
import type { View, SubjectId, ExamTrack } from '@/types';

const iconMap: Record<string, typeof Pill> = {
  pill: Pill,
  activity: Activity,
  baby: Baby,
  brain: Brain,
  heart: Heart,
  'book-open': BookOpen,
  'heart-pulse': HeartPulse,
  stethoscope: Stethoscope,
};

interface StudyGuideProps {
  onNavigate: (view: View) => void;
  onOpenSubject: (subjectId: string) => void;
  onStartPractice: (subjectId: SubjectId) => void;
  dark: boolean;
  onToggleDark: () => void;
  examTrack: ExamTrack;
}

export default function StudyGuide({ onNavigate, onOpenSubject, onStartPractice, dark, onToggleDark, examTrack }: StudyGuideProps) {
  const { subjects, progress, loading } = useStudyGuideSubjects(examTrack);
  const [search, setSearch] = useState('');

  const trackLabel = examTrack === 'pnle' ? 'PNLE' : 'NCLEX';
  const trackIcon = examTrack === 'pnle' ? '🇵🇭' : '🌎';

  const filtered = subjects.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.description.toLowerCase().includes(search.toLowerCase()),
  );

  const totalTopics = subjects.reduce((sum, s) => sum + s.topic_count, 0);
  const totalStudied = subjects.reduce((sum, s) => sum + (progress[s.id]?.studied ?? 0), 0);
  const overallPct = totalTopics > 0 ? Math.round((totalStudied / totalTopics) * 100) : 0;

  return (
    <div className="min-h-screen bg-surface flex">
      <Sidebar active={examTrack === 'pnle' ? 'pnle' : 'nclex'} onNavigate={onNavigate} dark={dark} onToggleDark={onToggleDark} />

      <div className="flex-1 min-w-0 pb-20 lg:pb-0">
        <div className="lg:hidden sticky top-0 z-40 glass-strong border-b border-subtle px-5 h-14 flex items-center justify-between">
          <button onClick={() => onNavigate('landing')} className="flex items-center gap-2">
            <span className="w-7 h-7 gradient-brand rounded-full flex items-center justify-center">
              <span className="w-2 h-2 bg-white rounded-full" />
            </span>
            <span className="font-bold text-primary">Nursify</span>
          </button>
          <button onClick={onToggleDark} className="w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors">
            {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>
        </div>

        <main className="max-w-6xl mx-auto px-5 sm:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
          <div className="animate-slide-up">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xl">{trackIcon}</span>
              <span className="text-sm font-semibold text-lavender-600 dark:text-lavender-400">{trackLabel} Preparation</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-primary">
              Your {trackLabel} Study Guide
            </h1>
            <p className="mt-2 text-sm text-secondary max-w-2xl">
              {examTrack === 'pnle'
                ? 'A structured guide to help you review important nursing concepts, track your progress, and prepare for the Philippine Nurse Licensure Examination.'
                : 'A structured roadmap of what to study for the NCLEX-RN. Track your progress as you work through each subject area.'}
            </p>
          </div>

          <div className="bg-elevated border border-subtle rounded-2xl p-5 sm:p-6 animate-slide-up animate-delay-100">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-xs font-semibold text-secondary uppercase tracking-wide">Overall Progress</p>
                <p className="text-2xl font-extrabold text-primary mt-1">
                  {totalStudied} <span className="text-base font-bold text-secondary">/ {totalTopics} topics studied</span>
                </p>
              </div>
              <div className="text-right">
                <span className="text-3xl font-extrabold gradient-text">{overallPct}%</span>
              </div>
            </div>
            <div className="h-2 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden">
              <div className="h-full gradient-brand rounded-full transition-all duration-1000" style={{ width: `${overallPct}%` }} />
            </div>
          </div>

          <div className="relative animate-slide-up animate-delay-200">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-ink-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search subjects..."
              className="w-full pl-12 pr-4 py-3 rounded-2xl bg-elevated border border-subtle text-sm text-primary placeholder:text-ink-400 focus:outline-none focus:ring-2 focus:ring-violet-400/40 focus:border-violet-400 transition-all"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 animate-slide-up animate-delay-300">
            {(loading ? [] : filtered).map((s) => (
              <SubjectCard
                key={s.id}
                subject={s}
                studied={progress[s.id]?.studied ?? 0}
                onOpen={() => onOpenSubject(s.id)}
                onPractice={() => onStartPractice(s.id as SubjectId)}
              />
            ))}
            {loading && Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-elevated border border-subtle rounded-2xl p-5 h-56 skeleton" />
            ))}
          </div>

          {!loading && filtered.length === 0 && (
            <div className="text-center py-16">
              <p className="text-sm text-secondary">No subjects found matching "{search}".</p>
            </div>
          )}
        </main>
      </div>

      <MobileNav active={examTrack === 'pnle' ? 'pnle' : 'nclex'} onNavigate={onNavigate} />
    </div>
  );
}

function SubjectCard({ subject, studied, onOpen, onPractice }: {
  subject: StudyGuideSubject;
  studied: number;
  onOpen: () => void;
  onPractice: () => void;
}) {
  const Icon = iconMap[subject.icon] ?? BookOpen;
  const pct = subject.topic_count > 0 ? Math.round((studied / subject.topic_count) * 100) : 0;
  const isComplete = studied === subject.topic_count && subject.topic_count > 0;

  return (
    <div
      className="group bg-elevated border border-subtle rounded-2xl p-5 card-hover hover:shadow-card hover:border-violet-200 dark:hover:border-violet-800 cursor-pointer"
      onClick={onOpen}
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className="w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110"
          style={{ backgroundColor: `${subject.accent_color}14`, color: subject.accent_color }}
        >
          <Icon className="w-6 h-6" />
        </div>
        {isComplete ? (
          <span className="flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Complete
          </span>
        ) : (
          <span
            className="text-xs font-bold px-2.5 py-1 rounded-lg"
            style={{ backgroundColor: `${subject.accent_color}14`, color: subject.accent_color }}
          >
            {pct}%
          </span>
        )}
      </div>

      <h4 className="text-base font-bold text-primary">{subject.name}</h4>
      <p className="text-xs text-secondary mt-1 leading-relaxed line-clamp-2">{subject.description}</p>

      <div className="flex items-center gap-1.5 mt-3 text-xs text-secondary">
        <Circle className="w-3.5 h-3.5" />
        <span>{subject.topic_count} topics to study</span>
      </div>

      <div className="mt-3 h-1.5 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-1000"
          style={{ width: `${pct}%`, backgroundColor: subject.accent_color }}
        />
      </div>

      <div className="mt-4 flex items-center justify-between">
        <button
          onClick={(e) => { e.stopPropagation(); onOpen(); }}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-violet-600 dark:text-violet-400 group-hover:gap-2.5 transition-all"
        >
          View Study Guide
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); onPractice(); }}
          className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-ink-100 dark:bg-ink-800 text-secondary hover:text-primary hover:bg-ink-200 dark:hover:bg-ink-700 transition-colors"
        >
          Practice
        </button>
      </div>
    </div>
  );
}
