import { useState, useMemo, useEffect } from 'react';
import { ArrowLeft, Search, ChevronDown, CheckCircle2, Circle, Lightbulb, Stethoscope, Play, Moon, Sun, BookOpen } from 'lucide-react';
import Sidebar from '@/components/dashboard/Sidebar';
import MobileNav from '@/components/dashboard/MobileNav';
import { useStudyGuideTopics } from '@/lib/study-guide';
import { supabase } from '@/lib/supabase';
import type { View, SubjectId, ExamTrack } from '@/types';

interface SubjectMeta {
  name: string;
  accent: string;
  icon: string;
}

interface StudyGuideSubjectPageProps {
  subjectId: string;
  onNavigate: (view: View) => void;
  onBack: () => void;
  onStartPractice: (subjectId: SubjectId) => void;
  dark: boolean;
  onToggleDark: () => void;
  examTrack: ExamTrack;
}

export default function StudyGuideSubjectPage({ subjectId, onNavigate, onBack, onStartPractice, dark, onToggleDark, examTrack }: StudyGuideSubjectPageProps) {
  const { topics, loading, toggleStudied } = useStudyGuideTopics(subjectId);
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [showStudiedOnly, setShowStudiedOnly] = useState(false);
  const [meta, setMeta] = useState<SubjectMeta>({ name: subjectId, accent: '#3b82f6', icon: 'book-open' });

  useEffect(() => {
    supabase
      .from('study_guide_subjects')
      .select('name, accent_color, icon')
      .eq('id', subjectId)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setMeta({ name: (data as SubjectMeta).name, accent: (data as SubjectMeta).accent, icon: (data as SubjectMeta).icon });
      });
  }, [subjectId]);

  const trackLabel = examTrack === 'pnle' ? 'PNLE' : 'NCLEX';

  const filtered = useMemo(() => {
    let result = topics;
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter((t) =>
        t.title.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.key_concepts.some((c) => c.toLowerCase().includes(q)) ||
        t.nursing_considerations.some((c) => c.toLowerCase().includes(q)),
      );
    }
    if (showStudiedOnly) {
      result = result.filter((t) => t.studied);
    }
    return result;
  }, [topics, search, showStudiedOnly]);

  const studiedCount = topics.filter((t) => t.studied).length;
  const pct = topics.length > 0 ? Math.round((studiedCount / topics.length) * 100) : 0;

  const toggleExpand = (id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const expandAll = () => setExpanded(new Set(filtered.map((t) => t.id)));
  const collapseAll = () => setExpanded(new Set());

  const markAllStudied = async () => {
    for (const t of topics) {
      if (!t.studied) await toggleStudied(t.id, true);
    }
  };

  return (
    <div className="min-h-screen bg-surface flex">
      <Sidebar active={examTrack === 'pnle' ? 'pnle' : 'nclex'} onNavigate={onNavigate} dark={dark} onToggleDark={onToggleDark} />

      <div className="flex-1 min-w-0 pb-20 lg:pb-0">
        <div className="lg:hidden sticky top-0 z-40 glass-strong border-b border-subtle px-5 h-14 flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-2 text-sm font-medium text-secondary hover:text-primary">
            <ArrowLeft className="w-4.5 h-4.5" />
            <span>{trackLabel} Study Guide</span>
          </button>
          <button onClick={onToggleDark} className="w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors">
            {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>
        </div>

        <main className="max-w-4xl mx-auto px-5 sm:px-8 py-6 sm:py-8 space-y-6">
          <button onClick={onBack} className="hidden lg:flex items-center gap-2 text-sm font-medium text-secondary hover:text-primary transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to {trackLabel} Study Guide
          </button>

          <div className="animate-slide-up">
            <div className="flex items-center gap-3 mb-2">
              <div
                className="w-10 h-10 rounded-2xl flex items-center justify-center"
                style={{ backgroundColor: `${meta.accent}14`, color: meta.accent }}
              >
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="text-sm font-semibold text-secondary">{trackLabel} Study Guide</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-primary">{meta.name}</h1>
          </div>

          <div className="bg-elevated border border-subtle rounded-2xl p-5 animate-slide-up animate-delay-100">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-xs font-semibold text-secondary uppercase tracking-wide">Study Progress</p>
                <p className="text-2xl font-extrabold text-primary mt-1">
                  {studiedCount} <span className="text-base font-bold text-secondary">/ {topics.length} topics studied</span>
                </p>
              </div>
              <span className="text-3xl font-extrabold" style={{ color: meta.accent }}>{pct}%</span>
            </div>
            <div className="h-2 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden">
              <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${pct}%`, backgroundColor: meta.accent }} />
            </div>
            <div className="flex items-center gap-2 mt-4 flex-wrap">
              <button
                onClick={() => onStartPractice(subjectId as SubjectId)}
                className="inline-flex items-center gap-1.5 text-sm font-semibold px-4 py-2 rounded-xl gradient-brand text-white hover:opacity-90 transition-opacity btn-press"
              >
                <Play className="w-3.5 h-3.5" />
                Start Practice
              </button>
              {studiedCount < topics.length && (
                <button
                  onClick={markAllStudied}
                  className="text-xs font-semibold px-3 py-2 rounded-xl bg-ink-100 dark:bg-ink-800 text-secondary hover:text-primary transition-colors"
                >
                  Mark All Studied
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 animate-slide-up animate-delay-200 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-ink-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search topics..."
                className="w-full pl-12 pr-4 py-3 rounded-2xl bg-elevated border border-subtle text-sm text-primary placeholder:text-ink-400 focus:outline-none focus:ring-2 focus:ring-violet-400/40 focus:border-violet-400 transition-all"
              />
            </div>
            <button
              onClick={() => setShowStudiedOnly((v) => !v)}
              className={`flex items-center gap-1.5 text-sm font-semibold px-4 py-3 rounded-2xl border transition-all ${
                showStudiedOnly
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-600 dark:text-emerald-400'
                  : 'bg-elevated border-subtle text-secondary hover:text-primary'
              }`}
            >
              {showStudiedOnly ? <CheckCircle2 className="w-4 h-4" /> : <Circle className="w-4 h-4" />}
              Studied Only
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs text-secondary animate-slide-up animate-delay-200">
            <button onClick={expandAll} className="font-semibold hover:text-primary transition-colors">Expand All</button>
            <span>·</span>
            <button onClick={collapseAll} className="font-semibold hover:text-primary transition-colors">Collapse All</button>
          </div>

          <div className="space-y-3 animate-slide-up animate-delay-300">
            {loading && Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="bg-elevated border border-subtle rounded-2xl p-5 h-20 skeleton" />
            ))}

            {!loading && filtered.map((topic, idx) => {
              const isOpen = expanded.has(topic.id);
              return (
                <div
                  key={topic.id}
                  className={`bg-elevated border rounded-2xl overflow-hidden transition-all ${
                    topic.studied
                      ? 'border-emerald-200 dark:border-emerald-900'
                      : 'border-subtle'
                  }`}
                >
                  <div
                    className="flex items-start gap-3 p-4 sm:p-5 cursor-pointer"
                    onClick={() => toggleExpand(topic.id)}
                  >
                    <button
                      onClick={(e) => { e.stopPropagation(); toggleStudied(topic.id, !topic.studied); }}
                      className="shrink-0 mt-0.5 btn-press"
                      aria-label={topic.studied ? 'Mark as not studied' : 'Mark as studied'}
                    >
                      {topic.studied ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                      ) : (
                        <Circle className="w-5 h-5 text-ink-300 dark:text-ink-600 hover:text-violet-400 transition-colors" />
                      )}
                    </button>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-ink-400 dark:text-ink-500">{String(idx + 1).padStart(2, '0')}</span>
                        <h3 className={`text-sm sm:text-base font-bold ${topic.studied ? 'text-secondary line-through' : 'text-primary'}`}>
                          {topic.title}
                        </h3>
                      </div>
                      <p className="text-xs text-secondary mt-1 line-clamp-1">{topic.description}</p>
                    </div>

                    <ChevronDown
                      className={`w-5 h-5 text-ink-400 shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`}
                    />
                  </div>

                  {isOpen && (
                    <div className="px-4 sm:px-5 pb-5 pl-12 sm:pl-14 space-y-4 animate-fade-in">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <Lightbulb className="w-4 h-4 text-amber-500" />
                          <h4 className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wide">Key Concepts</h4>
                        </div>
                        <ul className="space-y-1.5">
                          {topic.key_concepts.map((c, i) => (
                            <li key={i} className="text-sm text-secondary leading-relaxed flex items-start gap-2">
                              <span className="text-amber-400 mt-1.5 w-1 h-1 rounded-full bg-amber-400 shrink-0" />
                              {c}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <Stethoscope className="w-4 h-4 text-violet-500" />
                          <h4 className="text-xs font-bold text-violet-600 dark:text-violet-400 uppercase tracking-wide">Nursing Considerations</h4>
                        </div>
                        <ul className="space-y-1.5">
                          {topic.nursing_considerations.map((c, i) => (
                            <li key={i} className="text-sm text-secondary leading-relaxed flex items-start gap-2">
                              <span className="text-violet-400 mt-1.5 w-1 h-1 rounded-full bg-violet-400 shrink-0" />
                              {c}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {!loading && filtered.length === 0 && (
              <div className="text-center py-16">
                <p className="text-sm text-secondary">
                  {showStudiedOnly ? 'No studied topics yet. Start studying!' : `No topics found matching "${search}".`}
                </p>
              </div>
            )}
          </div>
        </main>
      </div>

      <MobileNav active={examTrack === 'pnle' ? 'pnle' : 'nclex'} onNavigate={onNavigate} />
    </div>
  );
}
