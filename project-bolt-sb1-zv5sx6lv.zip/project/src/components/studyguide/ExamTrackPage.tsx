import { Moon, Sun, ArrowRight, GraduationCap, Target, BookOpen, BarChart3, AlertCircle, History } from 'lucide-react';
import Sidebar from '@/components/dashboard/Sidebar';
import MobileNav from '@/components/dashboard/MobileNav';
import { useStudyGuideSubjects } from '@/lib/study-guide';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { useState, useEffect } from 'react';
import type { View, ExamTrack } from '@/types';

interface ExamTrackPageProps {
  examTrack: ExamTrack;
  onNavigate: (view: View) => void;
  onOpenStudyGuide: () => void;
  onOpenStudyGuideSubject: (subjectId: string) => void;
  onStartPractice: () => void;
  dark: boolean;
  onToggleDark: () => void;
}

export default function ExamTrackPage({ examTrack, onNavigate, onOpenStudyGuide, onOpenStudyGuideSubject, onStartPractice, dark, onToggleDark }: ExamTrackPageProps) {
  const { subjects, progress, loading } = useStudyGuideSubjects(examTrack);
  const { isFreeUser } = useAuth();
  const [stats, setStats] = useState({ totalAnswered: 0, accuracy: 0, weakAreas: 0 });

  const trackLabel = examTrack === 'pnle' ? 'PNLE' : 'NCLEX';
  const trackIcon = examTrack === 'pnle' ? '🇵🇭' : '🌎';
  const trackDesc = examTrack === 'pnle'
    ? 'Philippine Nurse Licensure Examination'
    : 'National Council Licensure Examination';

  useEffect(() => {
    supabase
      .rpc('get_user_dashboard_stats')
      .then(({ data }) => {
        if (data) {
          const d = data as { total_answered: number; accuracy: number };
          setStats((prev) => ({ ...prev, totalAnswered: d.total_answered, accuracy: d.accuracy }));
        }
      })
      .catch(() => {});
  }, []);

  const totalTopics = subjects.reduce((sum, s) => sum + s.topic_count, 0);
  const totalStudied = subjects.reduce((sum, s) => sum + (progress[s.id]?.studied ?? 0), 0);
  const overallPct = totalTopics > 0 ? Math.round((totalStudied / totalTopics) * 100) : 0;

  return (
    <div className="min-h-screen bg-surface flex">
      <Sidebar active={examTrack === 'pnle' ? 'pnle' : 'nclex'} onNavigate={onNavigate} dark={dark} onToggleDark={onToggleDark} />

      <div className="flex-1 min-w-0 pb-20 lg:pb-0">
        <div className="lg:hidden sticky top-0 z-40 glass-strong border-b border-subtle px-5 h-14 flex items-center justify-between">
          <button onClick={() => onNavigate('landing')} className="flex items-center gap-2">
            <span className="w-7 h-7 gradient-brand rounded-full flex items-center justify-center">
              <span className="w-2 h-2 bg-white rounded-full" />
            </span>
            <span className="font-bold text-primary">Nursify</span>
          </button>
          <button onClick={onToggleDark} className="w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors">
            {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>
        </div>

        <main className="max-w-6xl mx-auto px-5 sm:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
          {/* Header */}
          <div className="animate-slide-up">
            <div className="flex items-center gap-3 mb-2">
              <span className="text-2xl">{trackIcon}</span>
              <span className="text-sm font-semibold text-lavender-600 dark:text-lavender-400">{trackLabel} Preparation</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-primary">
              Your {trackLabel} Study Guide
            </h1>
            <p className="mt-2 text-sm text-secondary max-w-2xl">
              {examTrack === 'pnle'
                ? 'A structured guide to help you review important nursing concepts, track your progress, and prepare for the Philippine Nurse Licensure Examination.'
                : 'A structured roadmap of what to study for the NCLEX-RN. Track your progress as you work through each subject area.'}
            </p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 animate-slide-up animate-delay-100">
            <div className="bg-elevated border border-subtle rounded-2xl p-4">
              <p className="text-xs font-semibold text-secondary uppercase tracking-wide">Questions Answered</p>
              <p className="text-2xl font-extrabold text-primary mt-1">{stats.totalAnswered}</p>
            </div>
            <div className="bg-elevated border border-subtle rounded-2xl p-4">
              <p className="text-xs font-semibold text-secondary uppercase tracking-wide">Accuracy</p>
              <p className="text-2xl font-extrabold text-primary mt-1">{stats.accuracy}%</p>
            </div>
            <div className="bg-elevated border border-subtle rounded-2xl p-4">
              <p className="text-xs font-semibold text-secondary uppercase tracking-wide">Topics Studied</p>
              <p className="text-2xl font-extrabold text-primary mt-1">{totalStudied}/{totalTopics}</p>
            </div>
            <div className="bg-elevated border border-subtle rounded-2xl p-4">
              <p className="text-xs font-semibold text-secondary uppercase tracking-wide">Guide Progress</p>
              <p className="text-2xl font-extrabold gradient-text mt-1">{overallPct}%</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 animate-slide-up animate-delay-150">
            <button
              onClick={onStartPractice}
              className="flex items-center gap-2 px-4 py-3 rounded-2xl gradient-brand text-white text-sm font-semibold hover:opacity-90 transition-opacity btn-press"
            >
              <BookOpen className="w-4 h-4" />
              Practice
            </button>
            <button
              onClick={() => onNavigate('analytics')}
              className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-elevated border border-subtle text-sm font-semibold text-secondary hover:text-primary transition-colors"
            >
              <BarChart3 className="w-4 h-4" />
              Progress
            </button>
            <button
              onClick={() => onNavigate('weak-areas')}
              className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-elevated border border-subtle text-sm font-semibold text-secondary hover:text-primary transition-colors"
            >
              <AlertCircle className="w-4 h-4" />
              Weak Areas
            </button>
            <button
              onClick={() => onNavigate('study-history')}
              className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-elevated border border-subtle text-sm font-semibold text-secondary hover:text-primary transition-colors"
            >
              <History className="w-4 h-4" />
              History
            </button>
          </div>

          {/* Study Guide Progress */}
          <div className="bg-elevated border border-subtle rounded-2xl p-5 sm:p-6 animate-slide-up animate-delay-200">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-xs font-semibold text-secondary uppercase tracking-wide">Overall {trackLabel} Progress</p>
                <p className="text-2xl font-extrabold text-primary mt-1">
                  {totalStudied} <span className="text-base font-bold text-secondary">/ {totalTopics} topics studied</span>
                </p>
              </div>
              <div className="text-right">
                <span className="text-3xl font-extrabold gradient-text">{overallPct}%</span>
              </div>
            </div>
            <div className="h-2 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden">
              <div className="h-full gradient-brand rounded-full transition-all duration-1000" style={{ width: `${overallPct}%` }} />
            </div>
          </div>

          {/* Nursing Practice Cards (PNLE) or Subject Cards (NCLEX) */}
          <div className="animate-slide-up animate-delay-300">
            <h2 className="text-lg font-bold text-primary mb-4">
              {examTrack === 'pnle' ? 'Nursing Practice Areas' : 'Subject Areas'}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
              {loading && Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="bg-elevated border border-subtle rounded-2xl p-5 h-48 skeleton" />
              ))}
              {!loading && subjects.map((s) => {
                const studied = progress[s.id]?.studied ?? 0;
                const pct = s.topic_count > 0 ? Math.round((studied / s.topic_count) * 100) : 0;
                return (
                  <div
                    key={s.id}
                    className="group bg-elevated border border-subtle rounded-2xl p-5 card-hover hover:shadow-card cursor-pointer"
                    onClick={() => onOpenStudyGuideSubject(s.id)}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div
                        className="w-11 h-11 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110"
                        style={{ backgroundColor: `${s.accent_color}14`, color: s.accent_color }}
                      >
                        {examTrack === 'pnle' ? <GraduationCap className="w-5 h-5" /> : <Target className="w-5 h-5" />}
                      </div>
                      <span
                        className="text-xs font-bold px-2.5 py-1 rounded-lg"
                        style={{ backgroundColor: `${s.accent_color}14`, color: s.accent_color }}
                      >
                        {pct}%
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-primary">{s.name}</h4>
                    <p className="text-xs text-secondary mt-1 leading-relaxed line-clamp-2">{s.description}</p>
                    <div className="mt-3 h-1.5 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${pct}%`, backgroundColor: s.accent_color }} />
                    </div>
                    <div className="mt-3 flex items-center justify-between">
                      <span className="text-xs text-secondary">{s.topic_count} topics</span>
                      <button className="inline-flex items-center gap-1 text-xs font-semibold text-violet-600 dark:text-violet-400 group-hover:gap-2 transition-all">
                        {pct > 0 ? 'Continue' : 'Explore'}
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </main>
      </div>

      <MobileNav active={examTrack === 'pnle' ? 'pnle' : 'nclex'} onNavigate={onNavigate} />
    </div>
  );
}
