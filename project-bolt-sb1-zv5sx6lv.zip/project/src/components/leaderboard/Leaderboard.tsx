import { useState, useEffect, useCallback } from 'react';
import {
  Moon,
  Sun,
  Trophy,
  Medal,
  Flame,
  Target,
  CheckCircle,
  Loader2,
  Crown,
  TrendingUp,
} from 'lucide-react';
import type { View } from '@/types';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import Sidebar from '@/components/dashboard/Sidebar';
import MobileNav from '@/components/dashboard/MobileNav';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Skeleton from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';

interface LeaderboardEntry {
  rank: number;
  user_id: string;
  full_name: string;
  avatar_url: string;
  total_answered: number;
  total_correct: number;
  accuracy: number;
  current_streak: number;
}

type Period = 'all' | 'month' | 'week';

const PERIODS: { id: Period; label: string }[] = [
  { id: 'all', label: 'All Time' },
  { id: 'month', label: 'This Month' },
  { id: 'week', label: 'This Week' },
];

const PAGE_SIZE = 20;

function Avatar({ name, avatarUrl, size = 'md' }: { name: string; avatarUrl: string; size?: 'sm' | 'md' | 'lg' }) {
  const initials = (name || '?').charAt(0).toUpperCase();
  const dims = size === 'lg' ? 'w-16 h-16' : size === 'sm' ? 'w-8 h-8' : 'w-10 h-10';
  const text = size === 'lg' ? 'text-xl' : size === 'sm' ? 'text-xs' : 'text-sm';
  if (avatarUrl) {
    return (
      <img
        src={avatarUrl}
        alt={name}
        className={`${dims} rounded-full object-cover shrink-0 border border-subtle`}
      />
    );
  }
  return (
    <div className={`${dims} rounded-full gradient-brand flex items-center justify-center text-white font-bold ${text} shrink-0`}>
      {initials}
    </div>
  );
}

interface LeaderboardProps {
  onNavigate: (view: View) => void;
  dark: boolean;
  onToggleDark: () => void;
}

export default function Leaderboard({ onNavigate, dark, onToggleDark }: LeaderboardProps) {
  const { user } = useAuth();
  const { toast } = useToast();

  const [period, setPeriod] = useState<Period>('all');
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [myRank, setMyRank] = useState<LeaderboardEntry | null>(null);
  const [myRankLoading, setMyRankLoading] = useState(true);

  const loadLeaderboard = useCallback(async (p: Period, offset: number, append: boolean) => {
    if (!append) setLoading(true);
    else setLoadingMore(true);
    try {
      const { data, error } = await supabase.rpc('get_leaderboard', {
        p_period: p,
        p_limit: PAGE_SIZE,
        p_offset: offset,
        p_current_user_id: user?.id ?? null,
      });
      if (error) throw error;
      const rows = (data ?? []) as LeaderboardEntry[];
      setEntries(append ? (prev) => [...prev, ...rows] : rows);
    } catch (err) {
      console.error('Error loading leaderboard:', err);
      toast({ title: 'Failed to load leaderboard', variant: 'error' });
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, [toast, user?.id]);

  const loadTotalCount = useCallback(async (p: Period) => {
    try {
      const { data, error } = await supabase.rpc('get_leaderboard_total_count', { p_period: p });
      if (error) throw error;
      setTotalCount((data as number) ?? 0);
    } catch (err) {
      console.error('Error loading count:', err);
    }
  }, []);

  const loadMyRank = useCallback(async (p: Period) => {
    if (!user?.id) {
      setMyRankLoading(false);
      return;
    }
    setMyRankLoading(true);
    try {
      const { data, error } = await supabase.rpc('get_user_rank', {
        p_period: p,
        p_user_id: user.id,
      });
      if (error) throw error;
      setMyRank((data as LeaderboardEntry[])?.[0] ?? null);
    } catch (err) {
      console.error('Error loading my rank:', err);
    } finally {
      setMyRankLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    loadLeaderboard(period, 0, false);
    loadTotalCount(period);
    loadMyRank(period);
  }, [period, loadLeaderboard, loadTotalCount, loadMyRank]);

  const handleLoadMore = () => {
    loadLeaderboard(period, entries.length, true);
  };

  const top3 = entries.slice(0, 3);
  const restEntries = entries.slice(3);
  const hasMore = entries.length < totalCount;

  const getMedalColor = (rank: number) => {
    if (rank === 1) return { bg: 'from-amber-400 to-yellow-500', text: 'text-amber-600 dark:text-amber-400', ring: 'ring-amber-300 dark:ring-amber-600', label: '🥇' };
    if (rank === 2) return { bg: 'from-slate-300 to-slate-400', text: 'text-slate-500 dark:text-slate-400', ring: 'ring-slate-300 dark:ring-slate-600', label: '🥈' };
    return { bg: 'from-orange-400 to-orange-600', text: 'text-orange-600 dark:text-orange-400', ring: 'ring-orange-300 dark:ring-orange-600', label: '🥉' };
  };

  return (
    <div className="min-h-screen bg-surface flex">
      <Sidebar active="leaderboard" onNavigate={onNavigate} dark={dark} onToggleDark={onToggleDark} />

      <div className="flex-1 min-w-0 pb-20 lg:pb-0">
        {/* Top bar (mobile) */}
        <div className="lg:hidden sticky top-0 z-40 glass-strong border-b border-subtle px-5 h-14 flex items-center justify-between">
          <button onClick={() => onNavigate('landing')} className="flex items-center gap-2">
            <span className="w-7 h-7 gradient-brand rounded-full flex items-center justify-center">
              <span className="w-2 h-2 bg-white rounded-full" />
            </span>
            <span className="font-bold text-primary">Nursify</span>
          </button>
          <button
            onClick={onToggleDark}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors"
          >
            {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>
        </div>

        <main className="max-w-4xl mx-auto px-5 sm:px-8 py-6 sm:py-8 space-y-6">
          {/* Header */}
          <div className="animate-slide-up">
            <div className="flex items-center gap-2 text-sm text-secondary font-medium">
              <Trophy className="w-4 h-4 text-amber-500" />
              Leaderboard
            </div>
            <h1 className="mt-1 text-2xl sm:text-3xl font-extrabold text-primary">
              Top Performers
            </h1>
            <p className="mt-1 text-sm text-secondary">
              See how you stack up against fellow nursing students. Rankings update automatically as you answer questions.
            </p>
          </div>

          {/* Period Filters */}
          <div className="flex gap-2 animate-slide-up animate-delay-100">
            {PERIODS.map((p) => (
              <button
                key={p.id}
                onClick={() => setPeriod(p.id)}
                className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                  period === p.id
                    ? 'gradient-brand text-white shadow-lift'
                    : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300 bg-elevated'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Loading state */}
          {loading ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-48 rounded-3xl" />
                ))}
              </div>
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-20 rounded-2xl" />
              ))}
            </div>
          ) : entries.length === 0 ? (
            <div className="animate-slide-up animate-delay-100">
              <div className="relative overflow-hidden rounded-3xl border border-subtle bg-elevated p-10 sm:p-16 text-center">
                <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-amber-100 dark:bg-amber-950/30 blur-3xl" />
                <div className="relative">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl gradient-brand-soft mb-5">
                    <Trophy className="w-8 h-8 text-amber-600 dark:text-amber-400" />
                  </div>
                  <h2 className="text-xl font-bold text-primary">No rankings yet</h2>
                  <p className="mt-2 text-secondary text-sm max-w-md mx-auto">
                    Be the first to answer questions and claim the top spot! Start a practice quiz to get ranked.
                  </p>
                  <Button size="sm" className="mt-5" onClick={() => onNavigate('quiz')}>
                    <TrendingUp className="w-4 h-4" />
                    Start Practicing
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Top 3 Premium Cards */}
              {top3.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 animate-slide-up animate-delay-100">
                  {/* Rank 1 */}
                  {top3[0] && (
                    <PodiumCard entry={top3[0]} isCurrentUser={top3[0].user_id === user?.id} highlight />
                  )}
                  {/* Rank 2 */}
                  {top3[1] && (
                    <PodiumCard entry={top3[1]} isCurrentUser={top3[1].user_id === user?.id} />
                  )}
                  {/* Rank 3 */}
                  {top3[2] && (
                    <PodiumCard entry={top3[2]} isCurrentUser={top3[2].user_id === user?.id} />
                  )}
                </div>
              )}

              {/* Ranked List (4+) */}
              {restEntries.length > 0 && (
                <div className="space-y-2 animate-slide-up animate-delay-200">
                  {restEntries.map((entry) => {
                    const isMe = entry.user_id === user?.id;
                    return (
                      <Card
                        key={entry.user_id}
                        className={`p-4 ${isMe ? 'ring-2 ring-violet-400 dark:ring-violet-600' : ''}`}
                      >
                        <div className="flex items-center gap-3 sm:gap-4">
                          {/* Rank number */}
                          <div className="w-10 h-10 rounded-xl bg-ink-100 dark:bg-ink-800 flex items-center justify-center shrink-0">
                            <span className="text-sm font-bold text-secondary">{entry.rank}</span>
                          </div>

                          {/* Avatar + name */}
                          <Avatar name={entry.full_name} avatarUrl={entry.avatar_url} size="md" />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-primary text-sm truncate">{entry.full_name || 'User'}</span>
                              {isMe && (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-violet-100 dark:bg-violet-950/50 text-violet-700 dark:text-violet-300 shrink-0">
                                  You
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-3 mt-1 text-xs text-secondary">
                              <span className="flex items-center gap-1">
                                <Target className="w-3.5 h-3.5" />
                                {entry.accuracy.toFixed(1)}%
                              </span>
                              <span className="flex items-center gap-1">
                                <CheckCircle className="w-3.5 h-3.5" />
                                {entry.total_correct.toLocaleString()} correct
                              </span>
                              {entry.current_streak > 0 && (
                                <span className="flex items-center gap-1">
                                  <Flame className="w-3.5 h-3.5 text-orange-500" />
                                  {entry.current_streak}
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Accuracy bar (desktop) */}
                          <div className="hidden sm:flex items-center gap-2 shrink-0">
                            <div className="w-24 h-2 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden">
                              <div
                                className="h-full gradient-brand rounded-full transition-all"
                                style={{ width: `${Math.min(entry.accuracy, 100)}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              )}

              {/* Load More */}
              {hasMore && (
                <div className="flex justify-center pt-2">
                  <Button
                    variant="outline"
                    onClick={handleLoadMore}
                    disabled={loadingMore}
                  >
                    {loadingMore ? <Loader2 className="w-4 h-4 animate-spin" /> : <TrendingUp className="w-4 h-4" />}
                    Load More
                  </Button>
                </div>
              )}

              {/* Total count summary */}
              <p className="text-center text-xs text-secondary font-medium">
                Showing {entries.length} of {totalCount.toLocaleString()} ranked {totalCount === 1 ? 'user' : 'users'}
              </p>
            </>
          )}

          {/* Your Rank Card (always visible if logged in and has data) */}
          {!loading && myRank && !entries.some((e) => e.user_id === user?.id) && (
            <div className="animate-slide-up">
              <div className="relative">
                <div className="absolute inset-0 gradient-brand opacity-5 rounded-3xl" />
                <Card className="p-5 ring-2 ring-violet-400 dark:ring-violet-600 relative">
                  <div className="flex items-center gap-2 mb-3">
                    <Crown className="w-4 h-4 text-violet-500" />
                    <span className="text-xs font-bold text-violet-600 dark:text-violet-400 uppercase tracking-wider">Your Rank</span>
                  </div>
                  <div className="flex items-center gap-3 sm:gap-4">
                    <div className="w-12 h-12 rounded-xl bg-violet-100 dark:bg-violet-950/50 flex items-center justify-center shrink-0">
                      <span className="text-base font-bold text-violet-600 dark:text-violet-400">#{myRank.rank}</span>
                    </div>
                    <Avatar name={myRank.full_name} avatarUrl={myRank.avatar_url} size="md" />
                    <div className="flex-1 min-w-0">
                      <span className="font-semibold text-primary text-sm">{myRank.full_name || 'You'}</span>
                      <div className="flex items-center gap-3 mt-1 text-xs text-secondary">
                        <span className="flex items-center gap-1">
                          <Target className="w-3.5 h-3.5" />
                          {myRank.accuracy.toFixed(1)}%
                        </span>
                        <span className="flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5" />
                          {myRank.total_correct.toLocaleString()} correct
                        </span>
                        {myRank.current_streak > 0 && (
                          <span className="flex items-center gap-1">
                            <Flame className="w-3.5 h-3.5 text-orange-500" />
                            {myRank.current_streak}
                          </span>
                        )}
                      </div>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => onNavigate('quiz')}>
                      <TrendingUp className="w-4 h-4" />
                      Improve
                    </Button>
                  </div>
                </Card>
              </div>
            </div>
          )}

          {/* No rank yet (user hasn't answered questions) */}
          {!loading && !myRank && !myRankLoading && (
            <div className="animate-slide-up">
              <Card className="p-5 border-dashed">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-ink-100 dark:bg-ink-800 flex items-center justify-center shrink-0">
                    <Medal className="w-5 h-5 text-secondary" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-primary">You're not ranked yet</p>
                    <p className="text-xs text-secondary mt-0.5">Answer some practice questions to appear on the leaderboard.</p>
                  </div>
                  <Button size="sm" onClick={() => onNavigate('quiz')}>
                    Start Quiz
                  </Button>
                </div>
              </Card>
            </div>
          )}
        </main>
      </div>

      <MobileNav active="leaderboard" onNavigate={onNavigate} />
    </div>
  );
}

function PodiumCard({ entry, isCurrentUser, highlight }: { entry: LeaderboardEntry; isCurrentUser: boolean; highlight?: boolean }) {
  const medal = entry.rank <= 3 ? getMedalColorStatic(entry.rank) : null;

  return (
    <Card className={`p-5 relative overflow-hidden ${highlight ? 'sm:scale-105 shadow-card' : ''} ${isCurrentUser ? 'ring-2 ring-violet-400 dark:ring-violet-600' : ''}`}>
      {/* Gradient glow */}
      {medal && (
        <div className={`absolute -top-8 -right-8 w-32 h-32 rounded-full bg-gradient-to-br ${medal.bg} opacity-10 blur-2xl`} />
      )}

      <div className="relative">
        {/* Medal / Rank */}
        <div className="flex items-center justify-between mb-4">
          <div className={`inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-br ${medal?.bg ?? 'from-ink-200 to-ink-300 dark:from-ink-700 dark:to-ink-800'} shadow-lift`}>
            <span className="text-2xl">{medal?.label ?? `#${entry.rank}`}</span>
          </div>
          {isCurrentUser && (
            <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-violet-100 dark:bg-violet-950/50 text-violet-700 dark:text-violet-300">
              You
            </span>
          )}
        </div>

        {/* Avatar */}
        <div className="flex flex-col items-center text-center">
          <Avatar name={entry.full_name} avatarUrl={entry.avatar_url} size="lg" />
          <h3 className="mt-3 font-bold text-primary text-sm truncate max-w-full">
            {entry.full_name || 'User'}
          </h3>

          {/* Stats */}
          <div className="mt-3 grid grid-cols-3 gap-2 w-full">
            <div className="text-center">
              <p className="text-lg font-extrabold text-primary">{entry.accuracy.toFixed(0)}%</p>
              <p className="text-[10px] text-secondary font-medium uppercase tracking-wide">Accuracy</p>
            </div>
            <div className="text-center border-x border-subtle">
              <p className="text-lg font-extrabold text-primary">{entry.total_correct.toLocaleString()}</p>
              <p className="text-[10px] text-secondary font-medium uppercase tracking-wide">Correct</p>
            </div>
            <div className="text-center">
              <p className="text-lg font-extrabold text-primary flex items-center justify-center gap-0.5">
                {entry.current_streak > 0 && <Flame className="w-4 h-4 text-orange-500" />}
                {entry.current_streak}
              </p>
              <p className="text-[10px] text-secondary font-medium uppercase tracking-wide">Streak</p>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}

function getMedalColorStatic(rank: number) {
  if (rank === 1) return { bg: 'from-amber-400 to-yellow-500', label: '🥇' };
  if (rank === 2) return { bg: 'from-slate-300 to-slate-400', label: '🥈' };
  return { bg: 'from-orange-400 to-orange-600', label: '🥉' };
}
