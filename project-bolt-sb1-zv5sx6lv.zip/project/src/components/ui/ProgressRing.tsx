interface ProgressRingProps {
  value: number;
  size?: number;
  strokeWidth?: number;
  showLabel?: boolean;
  labelSuffix?: string;
  className?: string;
  trackClassName?: string;
  fillClassName?: string;
  animate?: boolean;
}

export default function ProgressRing({
  value,
  size = 120,
  strokeWidth = 10,
  showLabel = true,
  labelSuffix = '%',
  className = '',
  trackClassName = 'text-ink-200 dark:text-ink-800',
  fillClassName = 'text-violet-500',
  animate = true,
}: ProgressRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.min(100, Math.max(0, value)) / 100) * circumference;

  return (
    <div className={`relative inline-flex items-center justify-center ${className}`} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          strokeWidth={strokeWidth}
          className={trackClassName}
          stroke="currentColor"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          strokeWidth={strokeWidth}
          className={fillClassName}
          stroke="currentColor"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{
            transition: animate ? 'stroke-dashoffset 1s cubic-bezier(0.16, 1, 0.3, 1)' : 'none',
          }}
        />
      </svg>
      {showLabel && (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-primary tabular-nums">
            {Math.round(value)}
            <span className="text-base font-semibold text-secondary">{labelSuffix}</span>
          </span>
        </div>
      )}
    </div>
  );
}
