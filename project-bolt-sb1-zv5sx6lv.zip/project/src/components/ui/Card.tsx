import { type HTMLAttributes, forwardRef } from 'react';

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  hover?: boolean;
  glass?: boolean;
}

const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ hover = false, glass = false, className = '', children, ...props }, ref) => {
    const base = glass
      ? 'glass-strong border border-subtle rounded-3xl'
      : 'bg-elevated border border-subtle rounded-3xl shadow-soft';
    const hoverCls = hover ? 'card-hover hover:shadow-card hover:border-violet-200 dark:hover:border-violet-800' : '';
    return (
      <div ref={ref} className={`${base} ${hoverCls} ${className}`} {...props}>
        {children}
      </div>
    );
  }
);

Card.displayName = 'Card';
export default Card;
