interface BulletProgressProps {
  total: number;
  completed: number;
  current?: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export default function BulletProgress({
  total,
  completed,
  current = -1,
  size = 'md',
  className = '',
}: BulletProgressProps) {
  const dims = {
    sm: { dot: 'w-2 h-2', gap: 'gap-1' },
    md: { dot: 'w-2.5 h-2.5', gap: 'gap-1.5' },
    lg: { dot: 'w-3.5 h-3.5', gap: 'gap-2' },
  }[size];

  return (
    <div className={`flex items-center ${dims.gap} ${className}`}>
      {Array.from({ length: total }).map((_, i) => {
        const isCompleted = i < completed;
        const isCurrent = i === current;
        return (
          <span
            key={i}
            className={`rounded-full transition-all duration-500 ${
              dims.dot
            } ${
              isCompleted
                ? 'bg-violet-500 scale-100'
                : isCurrent
                ? 'bg-violet-300 ring-2 ring-violet-400/40 scale-110'
                : 'bg-ink-200 dark:bg-ink-700'
            }`}
            style={{
              animationDelay: `${i * 40}ms`,
            }}
          />
        );
      })}
    </div>
  );
}
