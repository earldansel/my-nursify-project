interface LineChartProps {
  data: { label: string; value: number }[];
  height?: number;
  className?: string;
  color?: string;
  showDots?: boolean;
  showAxis?: boolean;
}

export function LineChart({
  data,
  height = 160,
  className = '',
  color = '#8b5cf6',
  showDots = true,
  showAxis = true,
}: LineChartProps) {
  const width = 600;
  const padding = { top: 16, right: 16, bottom: 28, left: 28 };
  const w = width - padding.left - padding.right;
  const h = height - padding.top - padding.bottom;

  const max = Math.max(...data.map((d) => d.value));
  const min = Math.min(...data.map((d) => d.value));
  const range = max - min || 1;

  const points = data.map((d, i) => {
    const x = padding.left + (i / (data.length - 1)) * w;
    const y = padding.top + h - ((d.value - min) / range) * h;
    return { x, y, ...d };
  });

  const pathD = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaD = `${pathD} L ${points[points.length - 1].x} ${padding.top + h} L ${points[0].x} ${padding.top + h} Z`;

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className={`w-full ${className}`} style={{ height }}>
      <defs>
        <linearGradient id={`grad-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {showAxis && (
        <>
          {[0, 0.5, 1].map((t) => (
            <line
              key={t}
              x1={padding.left}
              x2={width - padding.right}
              y1={padding.top + h * t}
              y2={padding.top + h * t}
              className="stroke-ink-200 dark:stroke-ink-800"
              strokeWidth="1"
              strokeDasharray="3 4"
            />
          ))}
          {points.map((p, i) => (
            <text
              key={i}
              x={p.x}
              y={height - 8}
              textAnchor="middle"
              className="fill-ink-400 text-[10px]"
              fontSize="10"
            >
              {p.label}
            </text>
          ))}
        </>
      )}
      <path d={areaD} fill={`url(#grad-${color.replace('#', '')})`} />
      <path
        d={pathD}
        fill="none"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="animate-draw-line"
        style={{ strokeDasharray: 1000, animation: 'draw-line 1.4s cubic-bezier(0.16, 1, 0.3, 1) forwards' }}
      />
      {showDots &&
        points.map((p, i) => (
          <g key={i}>
            <circle cx={p.x} cy={p.y} r="4" fill="white" stroke={color} strokeWidth="2.5" />
          </g>
        ))}
    </svg>
  );
}

interface BarChartProps {
  data: { label: string; value: number; secondary?: number }[];
  height?: number;
  className?: string;
  color?: string;
  secondaryColor?: string;
}

export function BarChart({
  data,
  height = 180,
  className = '',
  color = '#8b5cf6',
  secondaryColor = '#c4b5fd',
}: BarChartProps) {
  const width = 600;
  const padding = { top: 16, right: 16, bottom: 28, left: 28 };
  const w = width - padding.left - padding.right;
  const h = height - padding.top - padding.bottom;
  const max = Math.max(...data.map((d) => d.value)) || 1;
  const barW = (w / data.length) * 0.5;

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className={`w-full ${className}`} style={{ height }}>
      <defs>
        <linearGradient id={`bar-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.95" />
          <stop offset="100%" stopColor={color} stopOpacity="0.6" />
        </linearGradient>
      </defs>
      {[0, 0.5, 1].map((t) => (
        <line
          key={t}
          x1={padding.left}
          x2={width - padding.right}
          y1={padding.top + h * t}
          y2={padding.top + h * t}
          className="stroke-ink-200 dark:stroke-ink-800"
          strokeWidth="1"
          strokeDasharray="3 4"
        />
      ))}
      {data.map((d, i) => {
        const x = padding.left + (i + 0.5) * (w / data.length) - barW / 2;
        const barH = (d.value / max) * h;
        const y = padding.top + h - barH;
        return (
          <g key={i}>
            <rect
              x={x}
              y={y}
              width={barW}
              height={barH}
              rx="6"
              fill={`url(#bar-${color.replace('#', '')})`}
              style={{ animation: `slide-up 0.7s ${i * 80}ms cubic-bezier(0.16,1,0.3,1) both` }}
            />
            {d.secondary !== undefined && (
              <rect
                x={x}
                y={padding.top + h - (d.secondary / max) * h}
                width={barW}
                height={(d.secondary / max) * h}
                rx="6"
                fill={secondaryColor}
                opacity="0.5"
              />
            )}
            <text
              x={padding.left + (i + 0.5) * (w / data.length)}
              y={height - 8}
              textAnchor="middle"
              className="fill-ink-400 text-[10px]"
              fontSize="10"
            >
              {d.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

interface RadialChartProps {
  data: { label: string; value: number; color: string }[];
  size?: number;
  className?: string;
}

export function RadialChart({ data, size = 220, className = '' }: RadialChartProps) {
  const stroke = 16;
  const gap = 6;
  const radius = (size - stroke) / 2;
  const cx = size / 2;
  const cy = size / 2;

  const rings = data.map((d, i) => {
    const r = radius - i * (stroke + gap);
    const circumference = 2 * Math.PI * r;
    const offset = circumference - (d.value / 100) * circumference;
    return { ...d, r, circumference, offset };
  });

  return (
    <div className={`relative inline-flex items-center justify-center ${className}`} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        {rings.map((ring, i) => (
          <g key={i}>
            <circle
              cx={cx}
              cy={cy}
              r={ring.r}
              fill="none"
              strokeWidth={stroke}
              className="stroke-ink-100 dark:stroke-ink-800"
            />
            <circle
              cx={cx}
              cy={cy}
              r={ring.r}
              fill="none"
              strokeWidth={stroke}
              stroke={ring.color}
              strokeLinecap="round"
              strokeDasharray={ring.circumference}
              strokeDashoffset={ring.offset}
              style={{ transition: 'stroke-dashoffset 1.2s cubic-bezier(0.16, 1, 0.3, 1)' }}
            />
          </g>
        ))}
      </svg>
    </div>
  );
}
