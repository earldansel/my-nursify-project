import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import { CheckCircle2, Info, AlertTriangle, XCircle, X } from 'lucide-react';
import type { ToastMessage } from '@/types';

interface ToastContextValue {
  toast: (t: Omit<ToastMessage, 'id'>) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}

const variantConfig = {
  success: { icon: CheckCircle2, accent: 'text-mint-500', ring: 'ring-mint-200 dark:ring-mint-900' },
  info: { icon: Info, accent: 'text-violet-500', ring: 'ring-violet-200 dark:ring-violet-900' },
  warning: { icon: AlertTriangle, accent: 'text-amber-500', ring: 'ring-amber-200 dark:ring-amber-900' },
  error: { icon: XCircle, accent: 'text-rose-500', ring: 'ring-rose-200 dark:ring-rose-900' },
} as const;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const toast = useCallback((t: Omit<ToastMessage, 'id'>) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev, { ...t, id }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((x) => x.id !== id));
    }, 3200);
  }, []);

  const dismiss = (id: string) => setToasts((prev) => prev.filter((x) => x.id !== id));

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="fixed top-5 right-5 z-[100] flex flex-col gap-2.5 w-[320px] max-w-[calc(100vw-2.5rem)]">
        {toasts.map((t) => {
          const cfg = variantConfig[t.variant];
          const Icon = cfg.icon;
          return (
            <div
              key={t.id}
              className="glass-strong border border-subtle rounded-2xl shadow-lift p-3.5 flex items-start gap-3 animate-slide-in-right"
            >
              <Icon className={`w-5 h-5 mt-0.5 shrink-0 ${cfg.accent}`} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-primary">{t.title}</p>
                {t.description && <p className="text-xs text-secondary mt-0.5">{t.description}</p>}
              </div>
              <button
                onClick={() => dismiss(t.id)}
                className="text-secondary hover:text-primary transition-colors"
                aria-label="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}
