import { type ButtonHTMLAttributes, forwardRef } from 'react';
import { ArrowRight } from 'lucide-react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'outline';
type Size = 'sm' | 'md' | 'lg';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  withArrow?: boolean;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'primary', size = 'md', withArrow = false, className = '', children, ...props }, ref) => {
    const base =
      'btn-press group relative inline-flex items-center justify-center gap-2 font-semibold rounded-2xl transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-violet-500/50 focus-visible:ring-offset-2 focus-visible:ring-offset-transparent disabled:opacity-50 disabled:pointer-events-none';

    const variants: Record<Variant, string> = {
      primary:
        'gradient-brand text-white shadow-lift hover:shadow-glow-strong hover:-translate-y-0.5',
      secondary:
        'bg-elevated text-primary border border-subtle shadow-soft hover:border-violet-300 hover:shadow-card hover:-translate-y-0.5 dark:hover:border-violet-700',
      ghost:
        'text-secondary hover:text-primary hover:bg-violet-50 dark:hover:bg-violet-950/40',
      outline:
        'border border-violet-300 text-violet-700 hover:bg-violet-50 dark:border-violet-700 dark:text-violet-300 dark:hover:bg-violet-950/40',
    };

    const sizes: Record<Size, string> = {
      sm: 'text-sm px-4 py-2',
      md: 'text-sm px-5 py-2.5',
      lg: 'text-base px-7 py-3.5',
    };

    return (
      <button
        ref={ref}
        className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}
        {...props}
      >
        {children}
        {withArrow && (
          <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
        )}
      </button>
    );
  }
);

Button.displayName = 'Button';
export default Button;
