import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import { Mail, ArrowRight, CheckCircle2 } from 'lucide-react';

interface ForgotPasswordProps {
  onNavigate: (view: 'login' | 'landing') => void;
}

export default function ForgotPassword({ onNavigate }: ForgotPasswordProps) {
  const { resetPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error } = await resetPassword(email);
    setLoading(false);
    if (error) {
      setError(error);
    } else {
      setSent(true);
    }
  };

  return (
    <div className="min-h-screen bg-surface flex items-center justify-center px-5 py-12">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-2.5 mb-8 mx-auto justify-center">
          <span className="w-8 h-8 gradient-brand rounded-full flex items-center justify-center">
            <span className="w-2.5 h-2.5 bg-white rounded-full animate-pulse" />
          </span>
          <span className="font-bold text-lg tracking-tight text-primary">
            Nursify<span className="text-lavender-600"> Coaching</span>
          </span>
        </div>

        <Card className="p-7">
          {sent ? (
            <div className="text-center py-4">
              <div className="w-14 h-14 rounded-full bg-mint-50 dark:bg-mint-950/40 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7 text-mint-500" />
              </div>
              <h1 className="mt-4 text-xl font-extrabold text-primary">Check your email</h1>
              <p className="mt-2 text-sm text-secondary">
                We've sent a password reset link to <span className="font-semibold text-primary">{email}</span>.
                Click the link in the email to reset your password.
              </p>
              <Button className="mt-6 w-full" onClick={() => onNavigate('login')}>
                Back to Sign In
              </Button>
            </div>
          ) : (
            <>
              <h1 className="text-2xl font-extrabold text-primary text-center">Forgot password?</h1>
              <p className="mt-2 text-sm text-secondary text-center">
                Enter your email and we'll send you a reset link
              </p>

              {error && (
                <div className="mt-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-sm text-rose-700 dark:text-rose-300">
                  {error}
                </div>
              )}

              <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-primary mb-1.5">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
                      placeholder="you@example.com"
                    />
                  </div>
                </div>

                <Button type="submit" size="lg" className="w-full" disabled={loading}>
                  {loading ? 'Sending...' : 'Send Reset Link'}
                </Button>
              </form>

              <p className="mt-6 text-center text-sm text-secondary">
                Remember your password?{' '}
                <button onClick={() => onNavigate('login')} className="font-semibold text-violet-600 dark:text-violet-400 hover:underline">
                  Sign in
                </button>
              </p>
            </>
          )}
        </Card>

        <button
          onClick={() => onNavigate('landing')}
          className="mt-6 mx-auto flex items-center gap-1.5 text-sm text-secondary hover:text-primary transition-colors"
        >
          <ArrowRight className="w-3.5 h-3.5 rotate-180" />
          Back to home
        </button>
      </div>
    </div>
  );
}
