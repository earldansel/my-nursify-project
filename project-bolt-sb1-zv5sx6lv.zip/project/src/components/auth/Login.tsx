import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import { Mail, Lock, ArrowRight, Eye, EyeOff } from 'lucide-react';

interface LoginProps {
  onNavigate: (view: 'signup' | 'forgot-password' | 'dashboard') => void;
}

export default function Login({ onNavigate }: LoginProps) {
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error } = await signIn(email, password);
    setLoading(false);
    if (error) {
      setError(error);
    } else {
      onNavigate('dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-surface flex items-center justify-center px-5 py-12">
      <div className="w-full max-w-md">
        <button onClick={() => onNavigate('signup' as any)} className="flex items-center gap-2.5 mb-8 mx-auto">
          <span className="w-8 h-8 gradient-brand rounded-full flex items-center justify-center">
            <span className="w-2.5 h-2.5 bg-white rounded-full animate-pulse" />
          </span>
          <span className="font-bold text-lg tracking-tight text-primary">
            Nursify<span className="text-lavender-600"> Coaching</span>
          </span>
        </button>

        <Card className="p-7">
          <h1 className="text-2xl font-extrabold text-primary text-center">Welcome back</h1>
          <p className="mt-2 text-sm text-secondary text-center">Sign in to continue your NCLEX prep</p>

          {error && (
            <div className="mt-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-sm text-rose-700 dark:text-rose-300">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
                  placeholder="you@example.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
                  placeholder="Your password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-ink-400 hover:text-secondary"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => onNavigate('forgot-password')}
                className="text-xs font-medium text-violet-600 dark:text-violet-400 hover:underline"
              >
                Forgot password?
              </button>
            </div>

            <Button type="submit" size="lg" withArrow className="w-full" disabled={loading}>
              {loading ? 'Signing in...' : 'Sign In'}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-secondary">
            Don't have an account?{' '}
            <button onClick={() => onNavigate('signup')} className="font-semibold text-violet-600 dark:text-violet-400 hover:underline">
              Sign up
            </button>
          </p>
        </Card>

        <button
          onClick={() => onNavigate('landing' as any)}
          className="mt-6 mx-auto flex items-center gap-1.5 text-sm text-secondary hover:text-primary transition-colors"
        >
          <ArrowRight className="w-3.5 h-3.5 rotate-180" />
          Back to home
        </button>
      </div>
    </div>
  );
}
