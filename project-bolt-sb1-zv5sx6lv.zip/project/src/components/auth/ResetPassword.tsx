import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import { Lock, Eye, EyeOff, CheckCircle2 } from 'lucide-react';

interface ResetPasswordProps {
  onNavigate: (view: 'login' | 'dashboard') => void;
}

export default function ResetPassword({ onNavigate }: ResetPasswordProps) {
  const { updatePassword } = useAuth();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    const { error } = await updatePassword(password);
    setLoading(false);
    if (error) {
      setError(error);
    } else {
      setDone(true);
    }
  };

  if (done) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center px-5 py-12">
        <div className="w-full max-w-md">
          <Card className="p-7 text-center">
            <div className="w-14 h-14 rounded-full bg-mint-50 dark:bg-mint-950/40 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-7 h-7 text-mint-500" />
            </div>
            <h1 className="mt-4 text-xl font-extrabold text-primary">Password updated</h1>
            <p className="mt-2 text-sm text-secondary">Your password has been successfully changed.</p>
            <Button className="mt-6 w-full" onClick={() => onNavigate('dashboard')}>
              Go to Dashboard
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface flex items-center justify-center px-5 py-12">
      <div className="w-full max-w-md">
        <Card className="p-7">
          <h1 className="text-2xl font-extrabold text-primary text-center">Set a new password</h1>
          <p className="mt-2 text-sm text-secondary text-center">Choose a new password for your account</p>

          {error && (
            <div className="mt-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-sm text-rose-700 dark:text-rose-300">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">New Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
                  placeholder="At least 6 characters"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-ink-400 hover:text-secondary"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Confirm Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-subtle bg-surface text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400"
                  placeholder="Re-enter your password"
                />
              </div>
            </div>

            <Button type="submit" size="lg" className="w-full" disabled={loading}>
              {loading ? 'Updating...' : 'Update Password'}
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
}
