import Navbar from '@/components/landing/Navbar';
import Hero from '@/components/landing/Hero';
import Features from '@/components/landing/Features';
import CTA from '@/components/landing/CTA';
import Footer from '@/components/landing/Footer';

interface LandingProps {
  onNavigate: (view: 'landing' | 'dashboard') => void;
  dark: boolean;
  onToggleDark: () => void;
}

export default function Landing({ onNavigate, dark, onToggleDark }: LandingProps) {
  return (
    <div className="min-h-screen bg-surface">
      <Navbar onNavigate={onNavigate} dark={dark} onToggleDark={onToggleDark} />
      <main>
        <Hero onLaunch={() => onNavigate('dashboard')} />
        <Features />
        <CTA onLaunch={() => onNavigate('dashboard')} />
      </main>
      <Footer onNavigate={onNavigate} />
    </div>
  );
}
