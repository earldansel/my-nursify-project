import { useEffect, useState } from 'react';
import { Moon, Sun, User, LogOut, ShieldCheck, Menu, X } from 'lucide-react';
import Button from '@/components/ui/Button';
import { useAuth } from '@/lib/auth';
import type { View } from '@/types';

interface NavbarProps {
  onNavigate: (view: View) => void;
  dark: boolean;
  onToggleDark: () => void;
}

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'PNLE Prep', href: '#pnle' },
  { label: 'NCLEX Prep', href: '#nclex' },
  { label: 'Coaching', href: '#coaching' },
  { label: 'Success Stories', href: '#stories' },
];

export default function Navbar({ onNavigate, dark, onToggleDark }: NavbarProps) {
  const { user, profile, signOut, isAdmin } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass border-b border-subtle shadow-soft' : 'bg-transparent'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
        <button onClick={() => onNavigate('landing')} className="flex items-center gap-2.5 group">
          <span className="relative w-8 h-8 flex items-center justify-center">
            <span className="absolute inset-0 gradient-brand rounded-full blur-[6px] opacity-40 group-hover:opacity-70 transition-opacity" />
            <span className="relative w-7 h-7 gradient-brand rounded-full flex items-center justify-center">
              <span className="w-2.5 h-2.5 bg-white rounded-full animate-pulse" />
            </span>
          </span>
          <span className="font-bold text-lg tracking-tight text-primary">
            Nursify<span className="text-lavender-600"> Coaching</span>
          </span>
        </button>

        <div className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="px-3.5 py-2 text-sm font-medium text-secondary hover:text-primary rounded-xl transition-colors hover:bg-lavender-50 dark:hover:bg-lavender-950/40"
            >
              {link.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onToggleDark}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors"
            aria-label="Toggle dark mode"
          >
            {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>

          {user ? (
            <>
              {isAdmin && (
                <button
                  onClick={() => onNavigate('admin')}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium text-lavender-700 dark:text-lavender-300 hover:bg-lavender-50 dark:hover:bg-lavender-950/40 transition-colors"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Admin
                </button>
              )}
              <button
                onClick={() => onNavigate('profile')}
                className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-medium text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors"
              >
                <span className="w-7 h-7 rounded-full gradient-brand flex items-center justify-center text-white font-bold text-xs">
                  {(profile?.full_name ?? user.email ?? '?').charAt(0).toUpperCase()}
                </span>
                <span className="max-w-[100px] truncate">{profile?.full_name || 'Account'}</span>
              </button>
              <button
                onClick={async () => {
                  await signOut();
                  onNavigate('landing');
                }}
                className="w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors"
                aria-label="Sign out"
              >
                <LogOut className="w-4.5 h-4.5" />
              </button>
            </>
          ) : (
            <>
              <Button size="sm" variant="ghost" onClick={() => onNavigate('login')} className="hidden sm:inline-flex">
                Sign In
              </Button>
              <Button size="sm" onClick={() => onNavigate('signup')} className="hidden sm:inline-flex">
                Get Started
              </Button>
            </>
          )}

          <button
            onClick={() => setMobileOpen((v) => !v)}
            className="md:hidden w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:bg-ink-100 dark:hover:bg-ink-800"
            aria-label="Menu"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {mobileOpen && (
        <div className="md:hidden glass-strong border-t border-subtle animate-fade-in-fast">
          <div className="px-5 py-3 flex flex-col gap-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="px-3 py-2.5 text-sm font-medium text-secondary hover:text-primary rounded-xl hover:bg-lavender-50 dark:hover:bg-lavender-950/40"
              >
                {link.label}
              </a>
            ))}
            {user ? (
              <>
                {isAdmin && (
                  <button
                    onClick={() => { onNavigate('admin'); setMobileOpen(false); }}
                    className="flex items-center gap-2 px-3 py-2.5 text-sm font-medium text-lavender-700 dark:text-lavender-300 hover:text-primary rounded-xl hover:bg-lavender-50 dark:hover:bg-lavender-950/40 text-left"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    Admin Dashboard
                  </button>
                )}
                <button
                  onClick={() => { onNavigate('profile'); setMobileOpen(false); }}
                  className="flex items-center gap-2 px-3 py-2.5 text-sm font-medium text-secondary hover:text-primary rounded-xl hover:bg-lavender-50 dark:hover:bg-lavender-950/40 text-left"
                >
                  <User className="w-4 h-4" />
                  My Profile
                </button>
                <button
                  onClick={async () => { await signOut(); onNavigate('landing'); setMobileOpen(false); }}
                  className="flex items-center gap-2 px-3 py-2.5 text-sm font-medium text-secondary hover:text-primary rounded-xl hover:bg-lavender-50 dark:hover:bg-lavender-950/40 text-left"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Button size="sm" variant="ghost" onClick={() => { onNavigate('login'); setMobileOpen(false); }} className="mt-2">
                  Sign In
                </Button>
                <Button size="sm" onClick={() => { onNavigate('signup'); setMobileOpen(false); }}>
                  Get Started
                </Button>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
