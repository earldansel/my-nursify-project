import { ArrowRight, BookOpen, PencilRuler, TrendingUp, GraduationCap, CheckCircle2, Circle } from 'lucide-react';
import Button from '@/components/ui/Button';

interface HeroProps {
  onLaunch: () => void;
}

const journeySteps = [
  {
    num: '01',
    icon: BookOpen,
    title: 'Learn & Review',
    description: 'Build your nursing foundation with structured study guides and lessons.',
  },
  {
    num: '02',
    icon: PencilRuler,
    title: 'Practice',
    description: 'Strengthen your knowledge with thousands of PNLE and NCLEX questions.',
  },
  {
    num: '03',
    icon: TrendingUp,
    title: 'Track Progress',
    description: 'Identify strengths and weak areas with detailed analytics.',
  },
  {
    num: '04',
    icon: GraduationCap,
    title: 'Exam Ready',
    description: 'Prepare with confidence and walk into your exam fully ready.',
  },
];

export default function Hero({ onLaunch }: HeroProps) {
  return (
    <section id="home" className="relative pt-32 pb-20 sm:pt-40 sm:pb-28 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 gradient-hero-bg" />
      <div className="absolute inset-0 woven-pattern opacity-80" />
      {/* Floating organic shapes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-20 -right-20 w-96 h-96 organic-shape bg-lavender-200/20 dark:bg-lavender-800/10 blur-3xl animate-float-slow" />
        <div className="absolute top-1/2 -left-32 w-80 h-80 organic-shape bg-mint-200/15 dark:bg-mint-800/10 blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        {[
          { l: '12%', t: '22%', d: '0s', s: '6s' },
          { l: '85%', t: '30%', d: '1s', s: '7s' },
          { l: '25%', t: '70%', d: '2s', s: '8s' },
          { l: '70%', t: '75%', d: '0.5s', s: '6.5s' },
          { l: '50%', t: '15%', d: '1.5s', s: '7.5s' },
          { l: '92%', t: '60%', d: '2.5s', s: '9s' },
          { l: '8%', t: '55%', d: '3s', s: '8s' },
        ].map((p, i) => (
          <span
            key={i}
            className="absolute w-1.5 h-1.5 rounded-full bg-lavender-400/50"
            style={{ left: p.l, top: p.t, animation: `float ${p.s} ease-in-out ${p.d} infinite` }}
          />
        ))}
      </div>

      <div className="relative max-w-7xl mx-auto px-5 sm:px-8 grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
        {/* Left */}
        <div className="animate-slide-up">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-lavender-50 dark:bg-lavender-950/60 border border-lavender-200 dark:border-lavender-800">
            <span className="w-1.5 h-1.5 rounded-full bg-lavender-500 animate-pulse" />
            <span className="text-xs font-semibold text-lavender-700 dark:text-lavender-300 tracking-wide uppercase">
              Built for Filipino Nursing Students
            </span>
          </div>

          <h1 className="mt-5 text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.05] text-primary">
            From Nursing Student
            <br />
            to <span className="gradient-text">Licensed Nurse.</span>
          </h1>

          <p className="mt-5 text-lg text-secondary max-w-lg leading-relaxed">
            Nursify Coaching Services gives nursing students a smarter and more structured way to
            learn, practice, and prepare for the PNLE and NCLEX.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Button size="lg" withArrow onClick={onLaunch}>
              Start Your Journey
            </Button>
            <Button size="lg" variant="secondary" onClick={onLaunch}>
              Explore Nursify
            </Button>
          </div>

          <div className="mt-10 flex items-center gap-6">
            <div>
              <p className="text-2xl font-bold text-primary">12k+</p>
              <p className="text-xs text-secondary font-medium">Questions</p>
            </div>
            <div className="w-px h-10 bg-ink-200 dark:bg-ink-700" />
            <div>
              <p className="text-2xl font-bold text-primary">PNLE + NCLEX</p>
              <p className="text-xs text-secondary font-medium">Dual Exam Prep</p>
            </div>
            <div className="w-px h-10 bg-ink-200 dark:bg-ink-700" />
            <div>
              <p className="text-2xl font-bold text-primary">94%</p>
              <p className="text-xs text-secondary font-medium">Pass Rate</p>
            </div>
          </div>
        </div>

        {/* Right — Nursing Journey Roadmap */}
        <div className="relative animate-scale-in animate-delay-200">
          <NursingJourneyVisual />
        </div>
      </div>
    </section>
  );
}

function NursingJourneyVisual() {
  return (
    <div className="relative perspective-1000">
      {/* Glow */}
      <div className="absolute -inset-8 gradient-brand opacity-15 blur-3xl rounded-full" />

      {/* Main card */}
      <div className="relative bg-elevated border border-subtle rounded-3xl shadow-lift p-6 sm:p-8 animate-float">
        <div className="flex items-center gap-2 mb-6">
          <div className="w-8 h-8 rounded-xl gradient-brand flex items-center justify-center">
            <GraduationCap className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="text-xs font-semibold text-secondary uppercase tracking-wide">Your Nursing Journey</p>
            <p className="text-sm font-bold text-primary">A guided path to licensure</p>
          </div>
        </div>

        {/* Vertical roadmap */}
        <div className="relative space-y-1">
          {/* Connecting line */}
          <div className="absolute left-[22px] top-4 bottom-4 w-0.5 bg-gradient-to-b from-lavender-300 via-lavender-400 to-mint-400 dark:from-lavender-700 dark:via-lavender-600 dark:to-mint-700" />

          {journeySteps.map((step, i) => {
            const Icon = step.icon;
            const completed = i < 2;
            return (
              <div
                key={step.num}
                className="relative flex items-start gap-4 p-3 rounded-2xl hover:bg-ink-50 dark:hover:bg-ink-900/50 transition-colors animate-slide-up"
                style={{ animationDelay: `${0.3 + i * 0.15}s` }}
              >
                <div className="relative shrink-0">
                  <div className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all ${
                    completed
                      ? 'gradient-brand text-white shadow-glow'
                      : 'bg-ink-100 dark:bg-ink-800 text-secondary'
                  }`}>
                    {completed ? <CheckCircle2 className="w-5 h-5" /> : <Icon className="w-5 h-5" />}
                  </div>
                  {i < journeySteps.length - 1 && (
                    <div className="absolute left-1/2 -translate-x-1/2 -bottom-3 w-0.5 h-3 bg-ink-200 dark:bg-ink-700" />
                  )}
                </div>
                <div className="flex-1 pt-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-lavender-600 dark:text-lavender-400">{step.num}</span>
                    <h3 className="text-sm font-bold text-primary">{step.title}</h3>
                  </div>
                  <p className="text-xs text-secondary mt-0.5 leading-relaxed">{step.description}</p>
                </div>
                {completed && (
                  <span className="text-xs font-bold text-mint-600 dark:text-mint-400 shrink-0 pt-1.5">Done</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Progress footer */}
        <div className="mt-5 pt-4 border-t border-subtle">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-secondary">Journey Progress</span>
            <span className="text-xs font-bold text-lavender-600 dark:text-lavender-400">50%</span>
          </div>
          <div className="h-2 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden">
            <div className="h-full gradient-brand rounded-full transition-all duration-1000" style={{ width: '50%' }} />
          </div>
        </div>
      </div>

      {/* Floating mini card — exam track */}
      <div
        className="absolute -left-4 sm:-left-8 -bottom-6 bg-elevated border border-subtle rounded-2xl shadow-lift p-3.5 animate-float-slow"
        style={{ animationDelay: '1s' }}
      >
        <div className="flex items-center gap-2">
          <span className="text-lg">🇵🇭</span>
          <div>
            <p className="text-[10px] font-semibold text-secondary uppercase tracking-wide">PNLE</p>
            <p className="text-sm font-bold text-primary">72% Ready</p>
          </div>
        </div>
      </div>

      {/* Floating mini card — NCLEX */}
      <div
        className="absolute -right-4 sm:-right-8 top-8 bg-elevated border border-subtle rounded-2xl shadow-lift px-4 py-3 animate-float"
        style={{ animationDelay: '2s' }}
      >
        <div className="flex items-center gap-2">
          <span className="text-lg">🌎</span>
          <div>
            <p className="text-[10px] font-semibold text-secondary uppercase tracking-wide">NCLEX</p>
            <p className="text-sm font-bold text-primary">68% Ready</p>
          </div>
        </div>
      </div>
    </div>
  );
}
