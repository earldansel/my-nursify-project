import Button from '@/components/ui/Button';
import { Check, Quote } from 'lucide-react';

interface CTAProps {
  onLaunch: () => void;
}

const perks = [
  '12,000+ PNLE & NCLEX-style questions',
  'Personalized study plans',
  'Detailed rationales for every answer',
  'Coaching and community support',
];

const successStories = [
  {
    name: 'Maria Santos, RN',
    exam: 'Passed PNLE 2025',
    quote: 'Nursify kept me on track every single day. The study plans made reviewing manageable, and the practice questions felt like the real exam.',
  avatar: 'M',
  accent: 'lavender',
  span: 'lg:col-span-2',
  featured: true,
  },
  {
    name: 'John Dela Cruz, RN',
    exam: 'Passed NCLEX-RN 2025',
    quote: 'The weak area tracking was a game-changer. I knew exactly what to study and walked in confident.',
    avatar: 'J',
    accent: 'mint',
    span: '',
    featured: false,
  },
  {
    name: 'Andrea Reyes, RN',
    exam: 'Passed PNLE & NCLEX',
    quote: 'Studying for both exams felt impossible until Nursify. Having separate tracks kept everything organized.',
    avatar: 'A',
    accent: 'amber',
    span: '',
    featured: false,
  },
];

const accentBg: Record<string, string> = {
  lavender: 'bg-lavender-50 dark:bg-lavender-950/40 text-lavender-600 dark:text-lavender-400',
  mint: 'bg-mint-50 dark:bg-mint-950/40 text-mint-600 dark:text-mint-400',
  amber: 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400',
};

export default function CTA({ onLaunch }: CTAProps) {
  return (
    <>
      {/* Success Stories */}
      <section id="stories" className="relative py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="max-w-2xl mb-12">
            <p className="text-xs font-semibold text-lavender-600 dark:text-lavender-400 uppercase tracking-wide">
              Success Stories
            </p>
            <h2 className="mt-3 text-3xl sm:text-4xl font-extrabold tracking-tight text-primary">
              From students to licensed nurses.
            </h2>
            <p className="mt-4 text-secondary text-lg">
              Real journeys from real Nursify users who passed their exams and started their nursing careers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {successStories.map((story) => (
              <div
                key={story.name}
                className={`relative overflow-hidden rounded-3xl border border-subtle bg-elevated p-6 card-hover hover:shadow-card ${story.span}`}
              >
                {story.featured && (
                  <div className="absolute -top-6 -right-6 w-24 h-24 organic-shape bg-lavender-100 dark:bg-lavender-950/20 blur-2xl" />
                )}
                <div className="relative">
                  <Quote className="w-8 h-8 text-lavender-300 dark:text-lavender-700 mb-3" />
                  <p className="text-sm text-primary leading-relaxed">"{story.quote}"</p>
                  <div className="mt-5 flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-full gradient-brand flex items-center justify-center text-white font-bold text-sm`}>
                      {story.avatar}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-primary">{story.name}</p>
                      <p className="text-xs text-secondary">{story.exam}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section id="pricing" className="relative py-20 sm:py-28">
        <div className="max-w-5xl mx-auto px-5 sm:px-8">
          <div className="relative overflow-hidden rounded-3xl gradient-brand p-8 sm:p-14 text-center">
            {/* Decorative particles */}
            <div className="absolute inset-0 opacity-30 pointer-events-none">
              {[
                { l: '10%', t: '20%', d: '0s' },
                { l: '80%', t: '30%', d: '1s' },
                { l: '30%', t: '70%', d: '2s' },
                { l: '70%', t: '75%', d: '0.5s' },
                { l: '50%', t: '15%', d: '1.5s' },
              ].map((p, i) => (
                <span
                  key={i}
                  className="absolute w-2 h-2 rounded-full bg-white/60"
                  style={{ left: p.l, top: p.t, animation: `float 6s ease-in-out ${p.d} infinite` }}
                />
              ))}
            </div>

            <div className="relative">
              <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
                Ready to begin your nursing journey?
              </h2>
              <p className="mt-4 text-white/80 text-lg max-w-xl mx-auto">
                Start your first lesson today. No credit card required.
              </p>

              <div className="mt-8 flex flex-wrap justify-center gap-x-6 gap-y-2.5">
                {perks.map((perk) => (
                  <div key={perk} className="flex items-center gap-2 text-white/90 text-sm font-medium">
                    <span className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center">
                      <Check className="w-3 h-3" />
                    </span>
                    {perk}
                  </div>
                ))}
              </div>

              <div className="mt-10">
                <Button
                  size="lg"
                  withArrow
                  onClick={onLaunch}
                  className="bg-white text-lavender-700 hover:bg-white hover:text-lavender-800 shadow-lift"
                >
                  Start Your Journey
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
