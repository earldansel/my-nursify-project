import { BookOpen, PencilRuler, TrendingUp, GraduationCap, Users, Heart, ArrowRight } from 'lucide-react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import { LineChart as LineChartSvg } from '@/components/ui/Charts';

const features = [
  {
    icon: BookOpen,
    title: 'Learn & Review',
    description: 'Structured study guides and lessons for every nursing subject, designed for PNLE and NCLEX success.',
    accent: 'lavender',
    span: 'lg:col-span-2',
    visual: 'chart' as const,
  },
  {
    icon: PencilRuler,
    title: 'Guided Practice',
    description: 'Thousands of exam-style questions with instant rationales and key takeaways.',
    accent: 'mint',
    span: '',
    visual: 'icon' as const,
  },
  {
    icon: TrendingUp,
    title: 'Track Your Progress',
    description: 'Detailed analytics show your strengths, weak areas, and exam readiness over time.',
    accent: 'amber',
    span: '',
    visual: 'icon' as const,
  },
  {
    icon: GraduationCap,
    title: 'Study Plans',
    description: 'Personalized schedules based on your exam date, weak areas, and study intensity.',
    accent: 'lavender',
    span: '',
    visual: 'icon' as const,
  },
  {
    icon: Users,
    title: 'Community & Coaching',
    description: 'Connect with fellow nursing students, share tips, and get support on your journey.',
    accent: 'mint',
    span: 'lg:col-span-2',
    visual: 'icon' as const,
  },
];

const accentMap: Record<string, { bg: string; text: string; ring: string }> = {
  lavender: { bg: 'bg-lavender-50 dark:bg-lavender-950/50', text: 'text-lavender-600 dark:text-lavender-400', ring: 'group-hover:ring-lavender-200 dark:group-hover:ring-lavender-800' },
  mint: { bg: 'bg-mint-50 dark:bg-mint-950/40', text: 'text-mint-600 dark:text-mint-400', ring: 'group-hover:ring-mint-200 dark:group-hover:ring-mint-800' },
  amber: { bg: 'bg-amber-50 dark:bg-amber-950/40', text: 'text-amber-600 dark:text-amber-400', ring: 'group-hover:ring-amber-200 dark:group-hover:ring-amber-800' },
  rose: { bg: 'bg-rose-50 dark:bg-rose-950/40', text: 'text-rose-600 dark:text-rose-400', ring: 'group-hover:ring-rose-200 dark:group-hover:ring-rose-800' },
  violet: { bg: 'bg-violet-50 dark:bg-violet-950/50', text: 'text-violet-600 dark:text-violet-400', ring: 'group-hover:ring-violet-200 dark:group-hover:ring-violet-800' },
};

export default function Features() {
  return (
    <section id="features" className="relative py-20 sm:py-28">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold text-lavender-600 dark:text-lavender-400 uppercase tracking-wide">
            Your Complete Nursing Journey
          </p>
          <h2 className="mt-3 text-3xl sm:text-4xl font-extrabold tracking-tight text-primary">
            Learn, practice, and grow — all in one platform.
          </h2>
          <p className="mt-4 text-secondary text-lg">
            Nursify guides you from your first lesson to exam day, with coaching and community every step of the way.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((f) => {
            const accent = accentMap[f.accent];
            const Icon = f.icon;
            return (
              <Card
                key={f.title}
                hover
                className={`group p-6 ${f.span} flex flex-col`}
              >
                <div className="flex items-start justify-between">
                  <div className={`w-12 h-12 rounded-2xl ${accent.bg} flex items-center justify-center ring-1 ring-transparent transition-all ${accent.ring}`}>
                    <Icon className={`w-5.5 h-5.5 ${accent.text}`} />
                  </div>
                </div>

                {f.visual === 'chart' ? (
                  <div className="mt-5 mb-2 -mx-2">
                    <LineChartSvg
                      data={[
                        { label: 'W1', value: 62 },
                        { label: 'W2', value: 68 },
                        { label: 'W3', value: 71 },
                        { label: 'W4', value: 75 },
                        { label: 'W5', value: 78 },
                        { label: 'W6', value: 82 },
                        { label: 'W7', value: 85 },
                        { label: 'W8', value: 89 },
                      ]}
                      height={150}
                      showDots={false}
                    />
                    <div className="flex items-center gap-1.5 mt-1 px-2">
                      <span className="text-xs font-semibold text-secondary">Score:</span>
                      <span className="text-xs font-bold text-primary">78 → 82 → 85 → 89</span>
                    </div>
                  </div>
                ) : (
                  <div className="flex-1" />
                )}

                <h3 className="text-lg font-bold text-primary mt-4">{f.title}</h3>
                <p className="mt-1.5 text-sm text-secondary leading-relaxed">{f.description}</p>
              </Card>
            );
          })}
        </div>

        {/* PNLE + NCLEX Cards */}
        <div id="pnle" className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* PNLE Card */}
          <Card className="relative overflow-hidden p-7 border-lavender-200 dark:border-lavender-800">
            <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-lavender-100 dark:bg-lavender-950/30 blur-2xl" />
            <div className="relative">
              <div className="flex items-center gap-3 mb-4">
                <span className="text-3xl">🇵🇭</span>
                <div>
                  <h3 className="text-xl font-extrabold text-primary">PNLE</h3>
                  <p className="text-xs text-secondary">Philippine Nurse Licensure Examination</p>
                </div>
              </div>
              <div className="flex items-end gap-2 mb-4">
                <span className="text-3xl font-extrabold gradient-text">72%</span>
                <span className="text-sm text-secondary mb-1">Ready</span>
              </div>
              <div className="h-2 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden mb-4">
                <div className="h-full gradient-brand rounded-full" style={{ width: '72%' }} />
              </div>
              <button className="inline-flex items-center gap-1.5 text-sm font-semibold text-lavender-600 dark:text-lavender-400 hover:gap-2.5 transition-all">
                Continue PNLE <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </Card>

          {/* NCLEX Card */}
          <Card className="relative overflow-hidden p-7 border-mint-200 dark:border-mint-800" id="nclex">
            <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-mint-100 dark:bg-mint-950/30 blur-2xl" />
            <div className="relative">
              <div className="flex items-center gap-3 mb-4">
                <span className="text-3xl">🌎</span>
                <div>
                  <h3 className="text-xl font-extrabold text-primary">NCLEX-RN</h3>
                  <p className="text-xs text-secondary">National Council Licensure Examination</p>
                </div>
              </div>
              <div className="flex items-end gap-2 mb-4">
                <span className="text-3xl font-extrabold gradient-text">68%</span>
                <span className="text-sm text-secondary mb-1">Ready</span>
              </div>
              <div className="h-2 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden mb-4">
                <div className="h-full gradient-brand rounded-full" style={{ width: '68%' }} />
              </div>
              <button className="inline-flex items-center gap-1.5 text-sm font-semibold text-mint-600 dark:text-mint-400 hover:gap-2.5 transition-all">
                Continue NCLEX <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </Card>
        </div>

        {/* Coaching section */}
        <div id="coaching" className="mt-16">
          <Card className="relative overflow-hidden p-8 sm:p-10">
            <div className="absolute -bottom-10 -left-10 w-48 h-48 organic-shape bg-lavender-100 dark:bg-lavender-950/20 blur-3xl" />
            <div className="relative flex flex-col sm:flex-row items-center gap-6">
              <div className="w-16 h-16 rounded-3xl gradient-brand flex items-center justify-center shrink-0">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1 text-center sm:text-left">
                <h3 className="text-xl font-extrabold text-primary">Coaching & Community Support</h3>
                <p className="mt-2 text-sm text-secondary max-w-lg">
                  You're not alone on this journey. Get coaching guidance, join study groups, and connect with
                  a community of Filipino nursing students who understand your path.
                </p>
              </div>
              <Button variant="secondary" withArrow>
                Join Community
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}
