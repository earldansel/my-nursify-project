interface FooterProps {
  onNavigate: (view: 'landing' | 'dashboard' | 'admin-login') => void;
}

const cols = [
  {
    title: 'Platform',
    links: ['PNLE Prep', 'NCLEX Prep', 'Study Plans', 'Analytics', 'Pricing'],
  },
  {
    title: 'Resources',
    links: ['Study Guides', 'Video Lessons', 'Community', 'Help Center'],
  },
  {
    title: 'Company',
    links: ['About', 'Contact', 'Privacy', 'Terms'],
  },
];

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="border-t border-subtle bg-elevated">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-14">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2">
            <button onClick={() => onNavigate('landing')} className="flex items-center gap-2.5">
              <span className="w-7 h-7 gradient-brand rounded-full flex items-center justify-center">
                <span className="w-2.5 h-2.5 bg-white rounded-full" />
              </span>
              <span className="font-bold text-lg tracking-tight text-primary">
                Nursify<span className="text-lavender-600"> Coaching</span>
              </span>
            </button>
            <p className="mt-4 text-sm text-secondary max-w-xs leading-relaxed">
              Your complete nursing journey — PNLE, NCLEX, learning, and coaching in one platform.
            </p>
          </div>

          {cols.map((col) => (
            <div key={col.title}>
              <h4 className="text-sm font-semibold text-primary">{col.title}</h4>
              <ul className="mt-3 space-y-2.5">
                {col.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-secondary hover:text-primary transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-6 border-t border-subtle flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-secondary">© 2026 Nursify Coaching Services. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <button
              onClick={() => onNavigate('admin-login')}
              className="text-xs text-ink-400 dark:text-ink-500 hover:text-secondary transition-colors"
            >
              Admin
            </button>
            <p className="text-xs text-secondary">Built for Filipino nursing students.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
