import { useEffect, useState } from 'react';
import { X, Check, Target, Brain, Clock, BookOpen, ChevronRight } from 'lucide-react';
import type { TestConfig, TestMode, QuestionType, Difficulty } from '@/types';
import {
  TEST_MODES,
  QUESTION_TYPES,
  DIFFICULTIES,
  QUESTION_COUNTS,
  NCLEX_CATEGORIES,
  getTotalQuestionCount,
  getSubjectNameCounts,
} from '@/lib/questions';
import { useToast } from '@/components/ui/Toast';
import { getSmartReview, type ReviewQuestion } from '@/lib/learning';
import { fetchBookmarkedQuestionIds } from '@/lib/questions';
import { useAuth } from '@/lib/auth';
import { Crown } from 'lucide-react';

interface CreateTestModalProps {
  open: boolean;
  onClose: () => void;
  onStart: (config: TestConfig) => void;
  onStartQuestionSet?: (ids: string[]) => void;
}

const modeIcons: Record<string, typeof Target> = {
  Target,
  Brain,
  Clock,
  BookOpen,
};

export default function CreateTestModal({ open, onClose, onStart, onStartQuestionSet }: CreateTestModalProps) {
  const [mode, setMode] = useState<TestMode>('practice-test');
  const [categories, setCategories] = useState<string[]>([]);
  const [questionTypes, setQuestionTypes] = useState<QuestionType[]>([]);
  const [difficulty, setDifficulty] = useState<Difficulty>('mixed');
  const [questionCount, setQuestionCount] = useState(20);
  const [customCount, setCustomCount] = useState('');
  const [ngnOnly, setNgnOnly] = useState(false);
  const [unusedFirst, setUnusedFirst] = useState(true);
  const [randomize, setRandomize] = useState(true);
  const [totalQuestions, setTotalQuestions] = useState<number | null>(null);
  const [categoryCounts, setCategoryCounts] = useState<Record<string, number>>({});
  const [questionsLoading, setQuestionsLoading] = useState(true);
  const [questionsError, setQuestionsError] = useState(false);
  const [starting, setStarting] = useState(false);
  const [reviewCount, setReviewCount] = useState(0);
  const [reviewItems, setReviewItems] = useState<ReviewQuestion[]>([]);
  const [reviewTab, setReviewTab] = useState<'incorrect' | 'review' | 'mastered'>('incorrect');
  const [savedCount, setSavedCount] = useState(0);
  const { toast } = useToast();
  const { isFreeUser } = useAuth();
  const FREE_LIMIT = 50;
  const maxCount = isFreeUser ? FREE_LIMIT : 100;
  const availableCounts = isFreeUser ? QUESTION_COUNTS.filter((c) => c <= FREE_LIMIT) : QUESTION_COUNTS;

  useEffect(() => {
    if (!open) return;
    setQuestionsLoading(true);
    setQuestionsError(false);
    Promise.all([getTotalQuestionCount(), getSubjectNameCounts(), getSmartReview(), fetchBookmarkedQuestionIds()])
      .then(([count, counts, review, saved]) => {
        setTotalQuestions(count);
        setCategoryCounts(counts);
        setReviewItems(review);
        setReviewCount(review.filter((item) => item.status === 'incorrect').length);
        setSavedCount(saved.size);
        setQuestionsLoading(false);
      })
      .catch(() => {
        setQuestionsError(true);
        setQuestionsLoading(false);
      });
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  if (!open) return null;

  const toggleCategory = (cat: string) => {
    setCategories((prev) =>
      prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat],
    );
  };

  const selectAllCategories = () => setCategories([...NCLEX_CATEGORIES]);
  const deselectAllCategories = () => setCategories([]);

  const toggleQuestionType = (qt: QuestionType) => {
    setQuestionTypes((prev) =>
      prev.includes(qt) ? prev.filter((t) => t !== qt) : [...prev, qt],
    );
  };

  const selectAllQTypes = () => setQuestionTypes([...QUESTION_TYPES.map((q) => q.id)]);
  const deselectAllQTypes = () => setQuestionTypes([]);

  const effectiveCount = Math.min(customCount ? parseInt(customCount, 10) || questionCount : questionCount, maxCount);
  const estimatedMinutes = Math.round(effectiveCount * 1.2);

  const handleStart = async () => {
    setStarting(true);
    const config: TestConfig = {
      mode,
      categories,
      questionTypes,
      difficulty,
      questionCount: effectiveCount,
      ngnOnly,
      unusedFirst,
      randomize,
    };
    toast({
      title: 'Creating your test',
      description: `${effectiveCount} questions selected`,
      variant: 'info',
    });
    await new Promise((r) => setTimeout(r, 300));
    setStarting(false);
    onStart(config);
  };

  return (
    <div className="fixed inset-0 z-[95] flex flex-col">
      <div
        className="absolute inset-0 bg-ink-950/50 backdrop-blur-sm animate-fade-in-fast"
        onClick={onClose}
      />

      {/* Modal panel — full height on mobile, centered on desktop */}
      <div className="relative flex flex-col w-full max-w-2xl mx-auto my-0 sm:my-8 bg-surface sm:rounded-3xl shadow-lift overflow-hidden animate-scale-in h-full sm:h-auto sm:max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-7 py-4 border-b border-subtle bg-elevated shrink-0">
          <div>
            <h2 className="text-xl font-extrabold text-primary">Create a Test</h2>
            <p className="text-xs text-secondary mt-0.5">
              Build a custom NCLEX practice test tailored to your needs.
            </p>
            {isFreeUser && (
              <div className="mt-2 flex items-center gap-2 px-3 py-2 rounded-xl bg-violet-50 dark:bg-violet-950/40 border border-violet-200 dark:border-violet-800">
                <Crown className="w-4 h-4 text-violet-600 dark:text-violet-400 shrink-0" />
                <p className="text-xs font-medium text-violet-700 dark:text-violet-300">
                  You have access to 50 practice questions on your current plan.
                </p>
              </div>
            )}
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto px-5 sm:px-7 py-5 space-y-6">
          {/* Test Mode */}
          <section>
            <h3 className="text-sm font-bold text-primary mb-1">Test Mode</h3>
            <p className="text-xs text-secondary mb-3">Choose how you want to practice.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {TEST_MODES.map((m) => {
                const Icon = modeIcons[m.icon] ?? BookOpen;
                const selected = mode === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => setMode(m.id as TestMode)}
                    className={`relative flex items-start gap-3 p-4 rounded-2xl border-2 text-left transition-all btn-press ${
                      selected
                        ? 'border-violet-500 bg-violet-50 dark:bg-violet-950/30 shadow-glow'
                        : 'border-subtle bg-elevated hover:border-violet-300 dark:hover:border-violet-700'
                    }`}
                  >
                    <div
                      className={`shrink-0 w-10 h-10 rounded-xl flex items-center justify-center ${
                        selected
                          ? 'gradient-brand text-white'
                          : 'bg-ink-100 dark:bg-ink-800 text-secondary'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-primary">{m.label}</p>
                      <p className="text-xs text-secondary mt-0.5 leading-relaxed">{m.description}</p>
                    </div>
                    {selected && (
                      <span className="absolute top-3 right-3 w-5 h-5 rounded-full gradient-brand flex items-center justify-center">
                        <Check className="w-3 h-3 text-white" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </section>

          <section className="p-4 rounded-2xl border border-subtle bg-elevated">
            <div className="flex items-center justify-between gap-4"><div><h3 className="text-sm font-bold text-primary">Smart Review</h3><p className="text-xs text-secondary mt-1">Practice from your real answer history or saved questions.</p></div><BookOpen className="w-5 h-5 text-violet-500 shrink-0" /></div>
            <div className="flex gap-1 mt-3 p-1 rounded-xl bg-ink-100 dark:bg-ink-800 w-fit">{(['incorrect', 'review', 'mastered'] as const).map((tab) => <button key={tab} onClick={() => setReviewTab(tab)} className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize ${reviewTab === tab ? 'bg-elevated text-primary shadow-sm' : 'text-secondary'}`}>{tab === 'review' ? 'Review Again' : tab} ({reviewItems.filter((item) => tab === 'mastered' ? item.status === 'mastered' : item.status === 'incorrect').length})</button>)}</div>
            <div className="flex flex-wrap gap-2 mt-3"><button disabled={!reviewItems.some((item) => reviewTab === 'mastered' ? item.status === 'mastered' : item.status === 'incorrect')} onClick={() => onStartQuestionSet?.(reviewItems.filter((item) => reviewTab === 'mastered' ? item.status === 'mastered' : item.status === 'incorrect').map((item) => item.question.id))} className="px-3 py-2 rounded-xl text-xs font-semibold bg-violet-600 text-white disabled:opacity-50">Start this review</button><button disabled={!savedCount} onClick={async () => { const saved = await fetchBookmarkedQuestionIds(); onStartQuestionSet?.([...saved]); }} className="px-3 py-2 rounded-xl text-xs font-semibold border border-subtle text-primary disabled:opacity-50">Saved questions ({savedCount})</button></div>
          </section>

          {/* Question Pool */}
          <section>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-sm font-bold text-primary">Question Pool</h3>
              <span className="text-xs font-semibold text-violet-600 dark:text-violet-400">
                {questionsLoading ? 'Loading questions...' : questionsError ? 'Unable to load questions. Please try again.' : `${totalQuestions?.toLocaleString() ?? 0} questions available`}
              </span>
            </div>
            <p className="text-xs text-secondary mb-3">Filter and customize your question selection.</p>
            <div className="space-y-2.5">
              <ToggleRow
                label="NGN only"
                description="Include only Next Generation NCLEX questions"
                checked={ngnOnly}
                onChange={setNgnOnly}
              />
              <ToggleRow
                label="Unused questions first"
                description="Prioritize questions you haven't answered yet"
                checked={unusedFirst}
                onChange={setUnusedFirst}
              />
              <ToggleRow
                label="Randomize questions"
                description="Shuffle question order on each test"
                checked={randomize}
                onChange={setRandomize}
              />
            </div>
          </section>

          {/* Category Selection */}
          <section>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-sm font-bold text-primary">Categories</h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={selectAllCategories}
                  className="text-xs font-semibold text-violet-600 dark:text-violet-400 hover:underline"
                >
                  Select All
                </button>
                <span className="text-ink-300">|</span>
                <button
                  onClick={deselectAllCategories}
                  className="text-xs font-semibold text-secondary hover:text-primary hover:underline"
                >
                  Deselect All
                </button>
              </div>
            </div>
            <p className="text-xs text-secondary mb-3">
              {categories.length === 0
                ? 'All categories will be included.'
                : `${categories.length} categor${categories.length === 1 ? 'y' : 'ies'} selected.`}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {NCLEX_CATEGORIES.map((cat) => {
                const checked = categories.length === 0 || categories.includes(cat);
                const count = categoryCounts[cat] ?? 0;
                return (
                  <button
                    key={cat}
                    onClick={() => toggleCategory(cat)}
                    className={`flex items-center gap-3 p-3 rounded-xl border transition-all text-left ${
                      checked
                        ? 'border-violet-300 dark:border-violet-700 bg-violet-50/50 dark:bg-violet-950/20'
                        : 'border-subtle bg-elevated hover:border-ink-300 dark:hover:border-ink-700'
                    }`}
                  >
                    <span
                      className={`shrink-0 w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${
                        checked
                          ? 'gradient-brand border-transparent'
                          : 'border-ink-300 dark:border-ink-600'
                      }`}
                    >
                      {checked && <Check className="w-3 h-3 text-white" />}
                    </span>
                    <span className="flex-1 text-xs font-medium text-primary">{cat}</span>
                    <span className="text-[10px] font-semibold text-secondary tabular-nums">
                      {questionsLoading ? '…' : count}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Question Count */}
          <section>
            <h3 className="text-sm font-bold text-primary mb-1">Question Count</h3>
            <p className="text-xs text-secondary mb-3">
              Estimated time: ~{estimatedMinutes} min ({effectiveCount} questions)
            </p>
            <div className="flex flex-wrap gap-2">
              {availableCounts.map((c) => (
                <button
                  key={c}
                  onClick={() => {
                    setQuestionCount(c);
                    setCustomCount('');
                  }}
                  className={`px-4 py-2.5 rounded-xl text-sm font-bold transition-all btn-press ${
                    !customCount && questionCount === c
                      ? 'gradient-brand text-white shadow-lift'
                      : 'bg-ink-100 dark:bg-ink-800 text-secondary hover:text-primary hover:bg-ink-200 dark:hover:bg-ink-700'
                  }`}
                >
                  {c}
                </button>
              ))}
              <div className="relative">
                <input
                  type="number"
                  value={customCount}
                  onChange={(e) => {
                    const v = e.target.value;
                    if (isFreeUser && v) {
                      const n = parseInt(v, 10);
                      setCustomCount(n > maxCount ? String(maxCount) : v);
                    } else {
                      setCustomCount(v);
                    }
                  }}
                  placeholder="Custom"
                  className={`w-24 px-4 py-2.5 rounded-xl text-sm font-bold border-2 bg-elevated text-primary placeholder:text-ink-400 focus:outline-none transition-all ${
                    customCount
                      ? 'border-violet-500'
                      : 'border-subtle focus:border-violet-300'
                  }`}
                />
              </div>
            </div>
          </section>

          {/* Difficulty */}
          <section>
            <h3 className="text-sm font-bold text-primary mb-3">Difficulty</h3>
            <div className="flex flex-wrap gap-2">
              {DIFFICULTIES.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setDifficulty(d.id as Difficulty)}
                  className={`px-4 py-2.5 rounded-xl text-sm font-bold transition-all btn-press ${
                    difficulty === d.id
                      ? 'gradient-brand text-white shadow-lift'
                      : 'bg-ink-100 dark:bg-ink-800 text-secondary hover:text-primary hover:bg-ink-200 dark:hover:bg-ink-700'
                  }`}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </section>

          {/* Question Types */}
          <section>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-sm font-bold text-primary">Question Types</h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={selectAllQTypes}
                  className="text-xs font-semibold text-violet-600 dark:text-violet-400 hover:underline"
                >
                  Select All
                </button>
                <span className="text-ink-300">|</span>
                <button
                  onClick={deselectAllQTypes}
                  className="text-xs font-semibold text-secondary hover:text-primary hover:underline"
                >
                  Deselect All
                </button>
              </div>
            </div>
            <p className="text-xs text-secondary mb-3">
              {questionTypes.length === 0
                ? 'All question types will be included.'
                : `${questionTypes.length} type${questionTypes.length === 1 ? '' : 's'} selected.`}
            </p>
            <div className="flex flex-wrap gap-2">
              {QUESTION_TYPES.map((qt) => {
                const checked = questionTypes.length === 0 || questionTypes.includes(qt.id);
                return (
                  <button
                    key={qt.id}
                    onClick={() => toggleQuestionType(qt.id as QuestionType)}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all btn-press ${
                      checked
                        ? 'border-2 border-violet-400 dark:border-violet-600 bg-violet-50 dark:bg-violet-950/30 text-violet-700 dark:text-violet-300'
                        : 'border-2 border-subtle bg-elevated text-secondary hover:text-primary hover:border-ink-300'
                    }`}
                  >
                    <span
                      className={`w-4 h-4 rounded border-2 flex items-center justify-center ${
                        checked ? 'gradient-brand border-transparent' : 'border-ink-300 dark:border-ink-600'
                      }`}
                    >
                      {checked && <Check className="w-2.5 h-2.5 text-white" />}
                    </span>
                    {qt.label}
                  </button>
                );
              })}
            </div>
          </section>
        </div>

        {/* Sticky bottom action */}
        <div className="shrink-0 px-5 sm:px-7 py-4 border-t border-subtle bg-elevated">
          <button
            onClick={handleStart}
            disabled={starting || effectiveCount < 1}
            className="w-full flex items-center justify-center gap-2 px-6 py-4 rounded-2xl gradient-brand text-white font-bold text-base shadow-lift hover:shadow-glow-strong hover:-translate-y-0.5 transition-all btn-press disabled:opacity-50 disabled:pointer-events-none"
          >
            {starting ? 'Creating...' : 'Create Test'}
            {!starting && <ChevronRight className="w-5 h-5" />}
          </button>
        </div>
      </div>
    </div>
  );
}

function ToggleRow({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className="flex items-center justify-between w-full p-3.5 rounded-xl border border-subtle bg-elevated hover:border-violet-200 dark:hover:border-violet-800 transition-all text-left"
    >
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-primary">{label}</p>
        <p className="text-xs text-secondary mt-0.5">{description}</p>
      </div>
      <span
        className={`relative shrink-0 w-11 h-6 rounded-full transition-colors ${
          checked ? 'gradient-brand' : 'bg-ink-200 dark:bg-ink-700'
        }`}
      >
        <span
          className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-soft transition-transform ${
            checked ? 'translate-x-5' : 'translate-x-0.5'
          }`}
        />
      </span>
    </button>
  );
}
