import { Check, Square } from 'lucide-react';
import type { Question } from '@/types';

interface AnswerOptionProps {
  option: Question['options'][number];
  index: number;
  state: 'idle' | 'selected' | 'correct' | 'incorrect' | 'dimmed';
  onClick: () => void;
  disabled?: boolean;
  multi?: boolean;
}

const letters = ['A', 'B', 'C', 'D', 'E', 'F'];

const stateClasses: Record<AnswerOptionProps['state'], string> = {
  idle: 'border-subtle bg-elevated hover:border-violet-300 hover:bg-violet-50/50 dark:hover:bg-violet-950/20',
  selected: 'border-violet-500 bg-violet-50 dark:bg-violet-950/40 shadow-glow',
  correct: 'border-mint-500 bg-mint-50 dark:bg-mint-950/40',
  incorrect: 'border-rose-500 bg-rose-50 dark:bg-rose-950/40',
  dimmed: 'border-subtle bg-elevated opacity-50',
};

export default function AnswerOption({ option, index, state, onClick, disabled, multi = false }: AnswerOptionProps) {
  const showCheck = state === 'correct';
  const showCross = state === 'incorrect';

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`w-full flex items-center gap-4 p-4 sm:p-5 rounded-2xl border-2 transition-all duration-300 text-left btn-press ${stateClasses[state]} ${
        disabled ? 'cursor-default' : 'cursor-pointer'
      }`}
    >
      {multi ? (
        <span
          className={`shrink-0 w-7 h-7 rounded-lg border-2 flex items-center justify-center transition-colors ${
            state === 'correct'
              ? 'bg-mint-500 border-mint-500'
              : state === 'incorrect'
              ? 'bg-rose-500 border-rose-500'
              : state === 'selected'
              ? 'bg-violet-500 border-violet-500'
              : 'border-ink-300 dark:border-ink-600 bg-transparent'
          }`}
        >
          {showCheck && <Check className="w-4 h-4 text-white" />}
          {showCross && <span className="text-white text-sm font-bold">✕</span>}
          {state === 'selected' && <Check className="w-4 h-4 text-white" />}
        </span>
      ) : (
        <span
          className={`shrink-0 w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold transition-colors ${
            state === 'correct'
              ? 'bg-mint-500 text-white'
              : state === 'incorrect'
              ? 'bg-rose-500 text-white'
              : state === 'selected'
              ? 'bg-violet-500 text-white'
              : 'bg-ink-100 dark:bg-ink-800 text-secondary'
          }`}
        >
          {showCheck ? <Check className="w-4 h-4" /> : showCross ? '✕' : letters[index]}
        </span>
      )}
      <span className="flex-1 text-sm sm:text-base font-medium text-primary leading-relaxed">
        {option.label}
      </span>
    </button>
  );
}
