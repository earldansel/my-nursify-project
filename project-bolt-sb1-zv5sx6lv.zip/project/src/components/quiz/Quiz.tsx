import { useState, useEffect, useCallback } from 'react';
import {
  ArrowLeft,
  Bookmark,
  Clock,
  ChevronLeft,
  ChevronRight,
  StickyNote,
  Loader2,
  Plus,
  RefreshCw,
} from 'lucide-react';
import type { View, QuizResult, Question, TestConfig, SubjectId } from '@/types';
import Button from '@/components/ui/Button';
import BulletProgress from '@/components/ui/BulletProgress';
import AnswerOption from '@/components/quiz/AnswerOption';
import QuestionNavigator from '@/components/quiz/QuestionNavigator';
import Rationale from '@/components/quiz/Rationale';
import CreateTestModal from '@/components/quiz/CreateTestModal';
import Modal from '@/components/ui/Modal';
import { useToast } from '@/components/ui/Toast';
import { completeDailyChallenge } from '@/lib/learning';
import {
  fetchQuestions,
  fetchQuestionsByIds,
  fetchOneMoreLikeThis,
  createQuizAttempt,
  saveAnswer,
  completeQuizAttempt,
  toggleBookmarkDb,
  updateBookmarkCategory,
  fetchBookmarkedQuestionIds,
  saveNote,
  fetchNote,
  getUserAnsweredCount,
} from '@/lib/questions';
import { useAuth } from '@/lib/auth';
import { Crown, Lock } from 'lucide-react';

const FREE_QUESTION_LIMIT = 50;

interface QuizProps {
  onNavigate: (view: View) => void;
  onFinish: (results: (QuizResult | null)[], questions: Question[]) => void;
  preselectedSubject?: SubjectId;
  presetQuestionIds?: string[];
  onStartQuestionSet?: (ids: string[]) => void;
  dailyChallengeId?: string;
  onConsumePresetQuestions?: () => void;
  onConsumePreselectedSubject?: () => void;
}

export default function Quiz({ onNavigate, onFinish, preselectedSubject, presetQuestionIds, onStartQuestionSet, dailyChallengeId, onConsumePresetQuestions, onConsumePreselectedSubject }: QuizProps) {
  const [showCreateModal, setShowCreateModal] = useState(true);
  const [quizQuestions, setQuizQuestions] = useState<Question[]>([]);
  const [current, setCurrent] = useState(0);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [results, setResults] = useState<(QuizResult | null)[]>([]);
  const [bookmarks, setBookmarks] = useState<Set<string>>(new Set());
  const [bookmarkCategory, setBookmarkCategory] = useState('Important');
  const [elapsed, setElapsed] = useState(0);
  const [showEndModal, setShowEndModal] = useState(false);
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [loading, setLoading] = useState(false);
  const [attemptId, setAttemptId] = useState<string | null>(null);
  const [config, setConfig] = useState<TestConfig | null>(null);
  const { toast } = useToast();
  const { isFreeUser } = useAuth();
  const [autoStarting, setAutoStarting] = useState(false);
  const [answeredCount, setAnsweredCount] = useState(0);
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [limitChecked, setLimitChecked] = useState(false);
  const [freeSessionLoaded, setFreeSessionLoaded] = useState(false);

  const q = quizQuestions[current];

  useEffect(() => {
    if (isFreeUser && !limitChecked) {
      getUserAnsweredCount().then((count) => {
        setAnsweredCount(count);
        setLimitChecked(true);
      });
    } else if (!isFreeUser) {
      setLimitChecked(true);
    }
  }, [isFreeUser, limitChecked]);

  useEffect(() => {
    if (isFreeUser && limitChecked && !freeSessionLoaded && !autoStarting && !presetQuestionIds?.length) {
      if (answeredCount >= FREE_QUESTION_LIMIT) {
        setShowLimitModal(true);
        setShowCreateModal(false);
        setFreeSessionLoaded(true);
        return;
      }
      setAutoStarting(true);
      setFreeSessionLoaded(true);
      const autoConfig: TestConfig = {
        mode: 'practice-test',
        categories: [],
        questionTypes: [],
        difficulty: 'mixed',
        questionCount: FREE_QUESTION_LIMIT,
        ngnOnly: false,
        unusedFirst: true,
        randomize: true,
      };
      handleStartTest(autoConfig);
    }
  }, [isFreeUser, limitChecked, freeSessionLoaded, autoStarting, answeredCount, presetQuestionIds]);

  useEffect(() => {
    if (presetQuestionIds?.length && showCreateModal && !autoStarting) {
      setAutoStarting(true);
      const startPreset = async () => {
        if (isFreeUser) {
          const count = await getUserAnsweredCount();
          if (count >= FREE_QUESTION_LIMIT) {
            setShowLimitModal(true);
            setAutoStarting(false);
            return;
          }
        }
        setLoading(true);
        setShowCreateModal(false);
        const presetConfig: TestConfig = { mode: 'practice-test', categories: [], questionTypes: [], difficulty: 'mixed', questionCount: presetQuestionIds.length, ngnOnly: false, unusedFirst: false, randomize: false };
        const questions = await fetchQuestionsByIds(presetQuestionIds);
        if (questions.length === 0) {
          toast({ title: 'Unable to load questions', description: 'Please try again.', variant: 'error' });
          setLoading(false);
          setShowCreateModal(true);
          setAutoStarting(false);
          return;
        }
        const aid = await createQuizAttempt(presetConfig);
        setAttemptId(aid);
        setConfig(presetConfig);
        setQuizQuestions(questions);
        setResults(Array(questions.length).fill(null));
        setCurrent(0);
        setSelectedIds([]);
        setSubmitted(false);
        setElapsed(0);
        setLoading(false);
        setAutoStarting(false);
        onConsumePresetQuestions?.();
      };
      startPreset();
    }
  }, [presetQuestionIds, showCreateModal, autoStarting, isFreeUser, onConsumePresetQuestions, toast]);

  useEffect(() => {
    if (!isFreeUser && preselectedSubject && showCreateModal && !autoStarting && !presetQuestionIds?.length) {
      setAutoStarting(true);
      const autoConfig: TestConfig = {
        mode: 'practice-test',
        categories: [],
        questionTypes: [],
        difficulty: 'mixed',
        questionCount: 20,
        ngnOnly: false,
        unusedFirst: true,
        randomize: true,
        subjectId: preselectedSubject,
      };
      handleStartTest(autoConfig).then(() => {
        onConsumePreselectedSubject?.();
      });
    }
  }, [preselectedSubject, showCreateModal, autoStarting, isFreeUser, presetQuestionIds]);

  useEffect(() => {
    if (!showCreateModal && quizQuestions.length > 0) {
      fetchBookmarkedQuestionIds().then((ids) => setBookmarks(ids));
    }
  }, [showCreateModal, quizQuestions.length]);

  useEffect(() => {
    if (showCreateModal) return;
    const t = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(t);
  }, [showCreateModal]);

  const mm = String(Math.floor(elapsed / 60)).padStart(2, '0');
  const ss = String(elapsed % 60).padStart(2, '0');

  const handleStartTest = async (cfg: TestConfig) => {
    if (isFreeUser) {
      const count = await getUserAnsweredCount();
      setAnsweredCount(count);
      if (count >= FREE_QUESTION_LIMIT) {
        setShowLimitModal(true);
        return;
      }
    }
    setLoading(true);
    setShowCreateModal(false);
    setConfig(cfg);
    const questions = await fetchQuestions(cfg).catch((err) => {
      console.error('Failed to fetch questions:', err);
      toast({ title: 'Unable to load questions', description: 'Please try again.', variant: 'error' });
      setLoading(false);
      setShowCreateModal(true);
      return null;
    });
    if (!questions || questions.length === 0) {
      if (questions && questions.length === 0) {
        toast({ title: 'No questions found', description: 'Try adjusting your filters.', variant: 'warning' });
      }
      setLoading(false);
      setShowCreateModal(true);
      return;
    }
    const aid = await createQuizAttempt(cfg);
    setAttemptId(aid);
    setQuizQuestions(questions);
    setResults(Array(questions.length).fill(null));
    setCurrent(0);
    setSelectedIds([]);
    setSubmitted(false);
    setElapsed(0);
    setLoading(false);
    toast({ title: 'Test started', description: `${questions.length} questions loaded`, variant: 'success' });
  };

  const isSata = q?.questionType === 'select-all-that-apply';

  const handleSelect = (optionId: string) => {
    if (submitted) return;
    if (isSata) {
      setSelectedIds((prev) =>
        prev.includes(optionId) ? prev.filter((id) => id !== optionId) : [...prev, optionId],
      );
    } else {
      setSelectedIds([optionId]);
    }
  };

  const checkCorrect = (question: Question, selected: string[]): boolean => {
    if (selected.length === 0) return false;
    const correctSet = new Set(question.correctAnswer);
    const selectedSet = new Set(selected);
    if (correctSet.size !== selectedSet.size) return false;
    for (const id of correctSet) {
      if (!selectedSet.has(id)) return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!q || selectedIds.length === 0) return;
    const isAnsCorrect = checkCorrect(q, selectedIds);
    const timeSpent = elapsed;
    const newResults = [...results];
    newResults[current] = {
      questionId: q.id,
      selectedOptionIds: selectedIds,
      isCorrect: isAnsCorrect,
      bookmarked: bookmarks.has(q.id),
      timeSpentSeconds: timeSpent,
    };
    setResults(newResults);
    setSubmitted(true);

    if (attemptId) {
      await saveAnswer(attemptId, q.id, selectedIds, isAnsCorrect, timeSpent, q.subjectId);
    }

    if (isFreeUser) {
      const newCount = answeredCount + 1;
      setAnsweredCount(newCount);
    }

    toast({
      title: isAnsCorrect ? 'Correct!' : 'Not quite',
      description: isAnsCorrect ? 'Nice work.' : 'Review the rationale below.',
      variant: isAnsCorrect ? 'success' : 'warning',
    });
  };

  const handleNext = () => {
    if (current < quizQuestions.length - 1) {
      setCurrent((c) => c + 1);
      setSelectedIds([]);
      setSubmitted(false);
    } else {
      finishQuiz();
    }
  };

  const handlePrev = () => {
    if (current > 0) {
      setCurrent((c) => c - 1);
      const prevResult = results[current - 1];
      setSelectedIds(prevResult?.selectedOptionIds ?? []);
      setSubmitted(prevResult !== null && prevResult !== undefined);
    }
  };

  const handleJump = (index: number) => {
    setCurrent(index);
    const r = results[index];
    setSelectedIds(r?.selectedOptionIds ?? []);
    setSubmitted(r !== null && r !== undefined);
  };

  const toggleBookmark = async () => {
    if (!q) return;
    const next = new Set(bookmarks);
    if (next.has(q.id)) {
      next.delete(q.id);
      toast({ title: 'Bookmark removed', variant: 'info' });
    } else {
      next.add(q.id);
      toast({ title: 'Question bookmarked', variant: 'success' });
    }
    setBookmarks(next);
    await toggleBookmarkDb(q.id, next.has(q.id), bookmarkCategory);
  };

  const handleOpenNote = async () => {
    if (!q) return;
    const existing = await fetchNote(q.id);
    setNoteText(existing ?? '');
    setShowNoteModal(true);
  };

  const handleSaveNote = async () => {
    if (!q) return;
    await saveNote(q.id, noteText);
    setShowNoteModal(false);
    toast({ title: 'Note saved', variant: 'success' });
  };

  const handleOneMore = async () => {
    if (!q) return;
    if (isFreeUser) {
      const count = await getUserAnsweredCount();
      setAnsweredCount(count);
      if (count >= FREE_QUESTION_LIMIT) {
        setShowLimitModal(true);
        return;
      }
    }
    setLoading(true);
    const excludeIds = quizQuestions.map((qq) => qq.id);
    const newQ = await fetchOneMoreLikeThis(q, excludeIds);
    if (newQ) {
      setQuizQuestions((prev) => [...prev, newQ]);
      setResults((prev) => [...prev, null]);
      setCurrent(quizQuestions.length);
      setSelectedIds([]);
      setSubmitted(false);
      toast({ title: 'New question loaded', description: `Testing: ${newQ.topic}`, variant: 'info' });
    } else {
      toast({ title: 'No more questions', description: 'No similar questions available.', variant: 'warning' });
    }
    setLoading(false);
  };

  const finishQuiz = useCallback(async () => {
    if (attemptId && config) {
      const answered = results.filter((r) => r !== null) as QuizResult[];
      const correct = answered.filter((r) => r.isCorrect).length;
      const incorrect = answered.filter((r) => !r.isCorrect).length;
      const unanswered = results.length - answered.length;
      await completeQuizAttempt(attemptId, correct, incorrect, unanswered, elapsed);
    }
    if (dailyChallengeId) await completeDailyChallenge(dailyChallengeId);
    onFinish(results, quizQuestions);
  }, [attemptId, config, results, elapsed, onFinish, quizQuestions, dailyChallengeId]);

  const quizAnsweredCount = results.filter((r) => r !== null).length;
  const progressPct = quizQuestions.length > 0 ? Math.round((quizAnsweredCount / quizQuestions.length) * 100) : 0;

  if (showCreateModal) {
    return <CreateTestModal open={showCreateModal} onClose={() => onNavigate('dashboard')} onStart={handleStartTest} onStartQuestionSet={onStartQuestionSet} />;
  }

  if (loading || quizQuestions.length === 0) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 text-violet-500 animate-spin" />
          <p className="text-sm text-secondary">Loading your test...</p>
        </div>
      </div>
    );
  }

  if (!q) return null;

  return (
    <div className="min-h-screen bg-surface">
      {/* Top bar */}
      <header className="sticky top-0 z-40 glass-strong border-b border-subtle">
        <div className="max-w-5xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between gap-4">
          <button
            onClick={() => setShowEndModal(true)}
            className="flex items-center gap-2 text-sm font-medium text-secondary hover:text-primary transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">End Test</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="w-7 h-7 gradient-brand rounded-full flex items-center justify-center">
              <span className="w-2 h-2 bg-white rounded-full" />
            </span>
            <span className="font-bold text-primary hidden sm:inline">Nursify</span>
          </div>

          <div className="flex items-center gap-2">
            {isFreeUser && (
              <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl ${answeredCount >= FREE_QUESTION_LIMIT ? 'bg-rose-50 dark:bg-rose-950/40' : 'bg-ink-100 dark:bg-ink-800'}`}>
                <span className={`text-xs font-semibold tabular-nums ${answeredCount >= FREE_QUESTION_LIMIT ? 'text-rose-600 dark:text-rose-400' : 'text-secondary'}`}>
                  {answeredCount} / {FREE_QUESTION_LIMIT}
                </span>
                <span className="text-[10px] text-secondary hidden sm:inline">free</span>
              </div>
            )}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-ink-100 dark:bg-ink-800">
              <Clock className="w-3.5 h-3.5 text-secondary" />
              <span className="text-sm font-semibold text-primary tabular-nums">{mm}:{ss}</span>
            </div>
          </div>
        </div>
        {/* Progress bar */}
        <div className="h-1 bg-ink-100 dark:bg-ink-800">
          <div className="h-full gradient-brand transition-all duration-500" style={{ width: `${progressPct}%` }} />
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-5 sm:px-8 py-6 sm:py-8">
        {/* Question meta */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-sm font-semibold text-secondary">
              Question <span className="text-primary">{current + 1}</span> / {quizQuestions.length}
            </span>
            <span className="text-xs font-medium px-2.5 py-1 rounded-lg bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300">
              {q.subjectName} · {q.topic}
            </span>
            {isSata && (
              <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400">
                Select All That Apply
              </span>
            )}
            {q.isNgn && (
              <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-mint-50 dark:bg-mint-950/40 text-mint-600 dark:text-mint-400">
                NGN
              </span>
            )}
          </div>
          <BulletProgress total={quizQuestions.length} completed={quizAnsweredCount} size="sm" />
        </div>

        {/* NGN case study */}
        {q.isNgn && q.caseStudy && (
          <div className="mb-4 p-5 rounded-2xl bg-violet-50 dark:bg-violet-950/20 border border-violet-200 dark:border-violet-800">
            <p className="text-xs font-bold text-violet-600 dark:text-violet-400 uppercase tracking-wide mb-2">Case Study</p>
            <p className="text-sm text-primary leading-relaxed">{q.caseStudy}</p>
          </div>
        )}

        {/* Question card */}
        <div className="bg-elevated border border-subtle rounded-3xl p-6 sm:p-8 shadow-soft animate-fade-in">
          <div className="flex items-start justify-between gap-4">
            <p className="text-lg sm:text-xl font-semibold text-primary leading-relaxed">{q.prompt}</p>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={handleOpenNote}
                className="w-10 h-10 rounded-xl flex items-center justify-center transition-all btn-press bg-ink-100 dark:bg-ink-800 text-secondary hover:text-primary"
                aria-label="Add note"
              >
                <StickyNote className="w-4.5 h-4.5" />
              </button>
              <button
                onClick={toggleBookmark}
                className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all btn-press ${
                  bookmarks.has(q.id)
                    ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-500'
                    : 'bg-ink-100 dark:bg-ink-800 text-secondary hover:text-primary'
                }`}
                aria-label="Bookmark"
              >
                <Bookmark className={`w-4.5 h-4.5 ${bookmarks.has(q.id) ? 'fill-current' : ''}`} />
              </button>
              {bookmarks.has(q.id) && <select value={bookmarkCategory} onChange={(event) => { setBookmarkCategory(event.target.value); void updateBookmarkCategory(q.id, event.target.value); }} className="h-10 rounded-xl border border-subtle bg-ink-100 dark:bg-ink-800 px-2 text-xs text-primary" aria-label="Saved question category"><option>Important</option><option>Confusing</option><option>Review Later</option></select>}
            </div>
          </div>

          {/* Options */}
          <div className="mt-6 space-y-3">
            {q.options.map((opt, i) => {
              let state: 'idle' | 'selected' | 'correct' | 'incorrect' | 'dimmed' = 'idle';
              if (submitted) {
                if (q.correctAnswer.includes(opt.id)) state = 'correct';
                else if (selectedIds.includes(opt.id)) state = 'incorrect';
                else state = 'dimmed';
              } else if (selectedIds.includes(opt.id)) {
                state = 'selected';
              }
              return (
                <AnswerOption
                  key={opt.id}
                  option={opt}
                  index={i}
                  state={state}
                  onClick={() => handleSelect(opt.id)}
                  disabled={submitted}
                  multi={isSata}
                />
              );
            })}
          </div>

          {/* Actions */}
          {!submitted ? (
            <div className="mt-6 flex items-center justify-between gap-3">
              <Button variant="ghost" size="md" onClick={handlePrev} disabled={current === 0}>
                <ChevronLeft className="w-4 h-4" /> Prev
              </Button>
              <Button onClick={handleSubmit} disabled={selectedIds.length === 0} size="md">
                {isSata ? 'Submit Answers' : 'Submit Answer'}
              </Button>
              <Button variant="ghost" size="md" onClick={handleNext} disabled={current === quizQuestions.length - 1}>
                Skip <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          ) : (
            <div className="mt-6 space-y-5">
              <Rationale question={q} selectedOptionIds={selectedIds} isCorrect={checkCorrect(q, selectedIds)} />

              {/* One More Like This */}
              <div className="relative overflow-hidden rounded-2xl gradient-brand p-5 text-white">
                <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-white/10 blur-2xl" />
                <div className="relative flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-white/70">Ready for another?</p>
                    <p className="text-lg font-bold mt-1">One More Like This</p>
                    <p className="text-sm text-white/80 mt-0.5">Targeting: {q.subjectName} — {q.topic}</p>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Button
                      onClick={handleOneMore}
                      disabled={loading}
                      className="bg-white/15 text-white hover:bg-white/25 border border-white/20"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                      One More
                    </Button>
                    <Button
                      onClick={handleNext}
                      withArrow
                      className="bg-white text-violet-700 hover:bg-white hover:text-violet-800 shadow-lift"
                    >
                      {current < quizQuestions.length - 1 ? 'Next Question' : 'Finish'}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigator */}
        <div className="mt-6">
          <QuestionNavigator
            total={quizQuestions.length}
            results={results}
            currentIndex={current}
            onJump={handleJump}
            bookmarks={bookmarks}
            questionIds={quizQuestions.map((qq) => qq.id)}
          />
        </div>
      </main>

      {/* End Test modal */}
      <Modal
        open={showEndModal}
        onClose={() => setShowEndModal(false)}
        title="End Test?"
        footer={
          <>
            <Button variant="secondary" onClick={() => setShowEndModal(false)}>Continue Test</Button>
            <Button onClick={() => { setShowEndModal(false); finishQuiz(); }}>End Test</Button>
          </>
        }
      >
        <p className="text-sm text-secondary leading-relaxed">
          Your progress will be saved. You can review your answers and rationales from the results screen.
        </p>
      </Modal>

      {/* Note modal */}
      <Modal
        open={showNoteModal}
        onClose={() => setShowNoteModal(false)}
        title="Add Note"
        footer={
          <>
            <Button variant="secondary" onClick={() => setShowNoteModal(false)}>Cancel</Button>
            <Button onClick={handleSaveNote}>Save Note</Button>
          </>
        }
      >
        <textarea
          value={noteText}
          onChange={(e) => setNoteText(e.target.value)}
          placeholder="Write your note about this question..."
          rows={5}
          className="w-full p-3 rounded-xl border-2 border-subtle bg-surface text-sm text-primary placeholder:text-ink-400 focus:outline-none focus:border-violet-400 transition-colors resize-none"
        />
      </Modal>

      {/* Free user limit modal */}
      <Modal
        open={showLimitModal}
        onClose={() => { setShowLimitModal(false); onNavigate('dashboard'); }}
        title="Free Question Limit Reached"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setShowLimitModal(false); onNavigate('dashboard'); }}>Back to Dashboard</Button>
            <Button onClick={() => onNavigate('pricing')} className="gradient-brand text-white">
              <Crown className="w-4 h-4" /> Upgrade to Premium
            </Button>
          </>
        }
      >
        <div className="text-center py-2">
          <div className="w-14 h-14 rounded-2xl bg-violet-50 dark:bg-violet-950/40 flex items-center justify-center mx-auto mb-4">
            <Lock className="w-7 h-7 text-violet-600 dark:text-violet-400" />
          </div>
          <p className="text-sm text-secondary leading-relaxed">
            You've completed all 50 practice questions included in your Free plan. Upgrade to Premium for unlimited practice access.
          </p>
          <p className="mt-3 text-2xl font-extrabold text-primary tabular-nums">
            {FREE_QUESTION_LIMIT} / {FREE_QUESTION_LIMIT}
          </p>
          <p className="text-xs text-secondary font-medium mt-1">Free Questions Used</p>
        </div>
      </Modal>
    </div>
  );
}
