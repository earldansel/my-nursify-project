import { useState } from 'react';
import { ChevronDown, Lightbulb, Sparkles, BookOpen, CheckCircle2, XCircle, Heart } from 'lucide-react';
import type { Question } from '@/types';

interface RationaleProps {
  question: Question;
  selectedOptionIds: string[];
  isCorrect: boolean;
}

function Collapsible({
  title,
  icon: Icon,
  children,
  defaultOpen = false,
  accent = 'violet',
}: {
  title: string;
  icon: typeof Lightbulb;
  children: React.ReactNode;
  defaultOpen?: boolean;
  accent?: string;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const accentCls = {
    violet: 'text-violet-600 dark:text-violet-400 bg-violet-50 dark:bg-violet-950/40',
    amber: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40',
    mint: 'text-mint-600 dark:text-mint-400 bg-mint-50 dark:bg-mint-950/40',
    rose: 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40',
  }[accent] ?? '';

  return (
    <div className="border border-subtle rounded-2xl overflow-hidden">
      <button
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center gap-3 p-3.5 text-left hover:bg-ink-50 dark:hover:bg-ink-900/40 transition-colors"
      >
        <span className={`w-8 h-8 rounded-xl flex items-center justify-center ${accentCls}`}>
          <Icon className="w-4 h-4" />
        </span>
        <span className="flex-1 text-sm font-semibold text-primary">{title}</span>
        <ChevronDown className={`w-4 h-4 text-secondary transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="px-3.5 pb-3.5 pt-1 text-sm text-secondary leading-relaxed animate-fade-in-fast">
          {children}
        </div>
      )}
    </div>
  );
}

const letters = ['A', 'B', 'C', 'D', 'E', 'F'];

export default function Rationale({ question, selectedOptionIds, isCorrect }: RationaleProps) {
  const correctSet = new Set(question.correctAnswer);
  const selectedSet = new Set(selectedOptionIds);

  return (
    <div className="animate-slide-up space-y-4">
      {/* Result banner */}
      <div
        className={`flex items-center gap-3 p-4 rounded-2xl border-2 ${
          isCorrect
            ? 'border-mint-200 dark:border-mint-900 bg-mint-50 dark:bg-mint-950/30'
            : 'border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/30'
        }`}
      >
        {isCorrect ? (
          <CheckCircle2 className="w-6 h-6 text-mint-500 shrink-0" />
        ) : (
          <XCircle className="w-6 h-6 text-rose-500 shrink-0" />
        )}
        <div>
          <p className={`font-bold ${isCorrect ? 'text-mint-700 dark:text-mint-300' : 'text-rose-700 dark:text-rose-300'}`}>
            {isCorrect ? 'Correct Answer' : 'Review This Concept'}
          </p>
          <p className="text-sm text-secondary">
            {isCorrect
              ? 'Nice work — this one is locked in.'
              : `Correct answer: ${question.correctAnswer.map((a) => a.toUpperCase()).join(', ')}.`}
          </p>
        </div>
      </div>

      {/* Per-option explanations */}
      <div className="space-y-2">
        {question.options.map((opt, i) => {
          const isOptCorrect = correctSet.has(opt.id);
          const wasSelected = selectedSet.has(opt.id);
          const rationaleText = question.optionRationales[opt.id] ?? '';
          const showCorrect = isOptCorrect;
          const showIncorrect = wasSelected && !isOptCorrect;

          return (
            <div
              key={opt.id}
              className={`p-4 rounded-2xl border-2 ${
                showCorrect
                  ? 'border-mint-300 dark:border-mint-700 bg-mint-50/60 dark:bg-mint-950/20'
                  : showIncorrect
                  ? 'border-rose-300 dark:border-rose-700 bg-rose-50/60 dark:bg-rose-950/20'
                  : 'border-subtle bg-elevated'
              }`}
            >
              <div className="flex items-start gap-3">
                <span
                  className={`shrink-0 w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                    showCorrect
                      ? 'bg-mint-500 text-white'
                      : showIncorrect
                      ? 'bg-rose-500 text-white'
                      : 'bg-ink-100 dark:bg-ink-800 text-secondary'
                  }`}
                >
                  {showCorrect ? <CheckCircle2 className="w-4 h-4" /> : showIncorrect ? <XCircle className="w-4 h-4" /> : letters[i]}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-primary">{opt.label}</p>
                  <div className="flex items-center gap-2 mt-1">
                    {showCorrect && (
                      <span className="text-xs font-bold text-mint-600 dark:text-mint-400">
                        ✓ Correct
                      </span>
                    )}
                    {showIncorrect && (
                      <span className="text-xs font-bold text-rose-600 dark:text-rose-400">
                        ✕ Incorrect
                      </span>
                    )}
                    {!showCorrect && !showIncorrect && (
                      <span className="text-xs font-medium text-secondary">Not selected</span>
                    )}
                  </div>
                  {rationaleText && (
                    <div className="mt-2 pt-2 border-t border-subtle">
                      <p className="text-[10px] font-bold text-secondary uppercase tracking-wide mb-1">Why</p>
                      <p className="text-xs text-secondary leading-relaxed">{rationaleText}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Expandable sections */}
      <Collapsible title="Why this is correct" icon={Sparkles} defaultOpen accent="violet">
        {question.rationale}
      </Collapsible>

      <Collapsible title="Key Takeaway" icon={Lightbulb} defaultOpen accent="amber">
        {question.keyTakeaway}
      </Collapsible>

      <Collapsible title="NCLEX Tip" icon={BookOpen} accent="mint">
        {question.nclexTip}
      </Collapsible>

      {question.clinicalPearl && (
        <Collapsible title="Clinical Pearl" icon={Heart} accent="rose">
          {question.clinicalPearl}
        </Collapsible>
      )}
    </div>
  );
}
