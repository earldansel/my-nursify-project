import type { QuizResult } from '@/types';

interface QuestionNavigatorProps {
  total: number;
  results: (QuizResult | null)[];
  currentIndex: number;
  onJump: (index: number) => void;
  bookmarks: Set<string>;
  questionIds: string[];
}

export default function QuestionNavigator({
  total,
  results,
  currentIndex,
  onJump,
  bookmarks,
  questionIds,
}: QuestionNavigatorProps) {
  return (
    <div className="bg-elevated border border-subtle rounded-2xl p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-semibold text-secondary uppercase tracking-wide">Navigator</p>
        <div className="flex items-center gap-3 text-[10px] text-secondary">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-violet-500" />Done</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-amber-400" />Flag</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-ink-200 dark:bg-ink-700" />Open</span>
        </div>
      </div>
      <div className="grid grid-cols-8 sm:grid-cols-10 gap-1.5">
        {Array.from({ length: total }).map((_, i) => {
          const r = results[i];
          const isCurrent = i === currentIndex;
          const isBookmarked = bookmarks.has(questionIds[i] ?? '');
          const isAnswered = r !== null && r !== undefined;
          const isCorrect = isAnswered && r!.isCorrect;

          return (
            <button
              key={i}
              onClick={() => onJump(i)}
              title={`Question ${i + 1}`}
              className={`relative aspect-square rounded-lg text-[11px] font-bold transition-all btn-press ${
                isCurrent
                  ? 'ring-2 ring-violet-500 ring-offset-1 ring-offset-transparent scale-105'
                  : ''
              } ${
                isCorrect
                  ? 'bg-violet-500 text-white'
                  : isAnswered
                  ? 'bg-rose-400 text-white'
                  : 'bg-ink-100 dark:bg-ink-800 text-secondary hover:bg-ink-200 dark:hover:bg-ink-700'
              }`}
            >
              {i + 1}
              {isBookmarked && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 border-2 border-white dark:border-ink-900" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
