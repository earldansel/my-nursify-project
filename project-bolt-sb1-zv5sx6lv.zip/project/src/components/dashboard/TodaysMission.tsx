import { useEffect, useState } from 'react';
import { Flame, Lock } from 'lucide-react';
import Button from '@/components/ui/Button';
import BulletProgress from '@/components/ui/BulletProgress';
import { getDashboardStats, getUserAnsweredCount } from '@/lib/questions';
import { useAuth } from '@/lib/auth';

interface TodaysMissionProps {
  onStart: () => void;
}

const DAILY_GOAL = 50;

export default function TodaysMission({ onStart }: TodaysMissionProps) {
  const { isFreeUser } = useAuth();
  const [completed, setCompleted] = useState(0);
  const [streak, setStreak] = useState(0);
  const [loading, setLoading] = useState(true);
  const [limitReached, setLimitReached] = useState(false);

  useEffect(() => {
    if (isFreeUser) {
      getUserAnsweredCount().then((count) => {
        setCompleted(count);
        setLimitReached(count >= DAILY_GOAL);
        setLoading(false);
      });
      getDashboardStats().then((data) => setStreak(data.currentStreak));
    } else {
      getDashboardStats().then((data) => {
        setCompleted(data.todayAnswered);
        setStreak(data.currentStreak);
        setLoading(false);
      });
    }
  }, [isFreeUser]);

  const pct = Math.round((Math.min(completed, DAILY_GOAL) / DAILY_GOAL) * 100);

  return (
    <div className="relative overflow-hidden rounded-3xl p-7 sm:p-8 gradient-brand text-white">
      <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-white/10 blur-2xl" />
      <div className="absolute -left-10 -bottom-10 w-40 h-40 rounded-full bg-violet-300/20 blur-2xl" />

      <div className="relative flex flex-col sm:flex-row items-center gap-6 sm:gap-8">
        <div className="flex-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
            <span className="text-[11px] font-semibold uppercase tracking-wide">Today's Mission</span>
          </div>

          <h2 className="mt-4 text-2xl sm:text-3xl font-extrabold">{DAILY_GOAL} Questions</h2>
          <p className="mt-1 text-white/80 text-sm">
            {isFreeUser
              ? limitReached
                ? "You've completed all your free practice questions."
                : 'Keep your streak alive — finish your free practice set.'
              : 'Keep your streak alive — finish today\'s set.'}
          </p>

          <div className="mt-5 flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/15 backdrop-blur-sm">
              <Flame className="w-4 h-4 text-amber-300" />
              <span className="text-sm font-semibold">{streak} day{streak !== 1 ? 's' : ''} streak</span>
            </div>
            <span className="text-sm font-medium text-white/80">
              {loading ? '—' : `${completed} / ${DAILY_GOAL}`} {isFreeUser ? 'completed' : 'today'}
            </span>
          </div>

          <div className="mt-4">
            <BulletProgress total={10} completed={Math.round((Math.min(completed, DAILY_GOAL) / DAILY_GOAL) * 10)} size="md" className="[&_span]:bg-white/90 [&_span:last-child]:bg-white/20" />
          </div>

          <div className="mt-6">
            {isFreeUser && limitReached ? (
              <Button
                onClick={onStart}
                disabled
                className="bg-white/20 text-white/60 cursor-not-allowed shadow-none"
              >
                <Lock className="w-4 h-4" /> Practice Locked
              </Button>
            ) : (
              <Button
                onClick={onStart}
                withArrow
                className="bg-white text-violet-700 hover:bg-white hover:text-violet-800 shadow-lift"
              >
                {isFreeUser ? (completed > 0 ? 'Continue Practice' : 'Start Practicing') : 'Continue Practice'}
              </Button>
            )}
          </div>
        </div>

        <div className="shrink-0">
          <div className="relative">
            <svg width="140" height="140" className="-rotate-90">
              <circle cx="70" cy="70" r="60" fill="none" strokeWidth="10" stroke="rgba(255,255,255,0.2)" />
              <circle
                cx="70"
                cy="70"
                r="60"
                fill="none"
                strokeWidth="10"
                stroke="white"
                strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 60}
                strokeDashoffset={2 * Math.PI * 60 - (pct / 100) * 2 * Math.PI * 60}
                style={{ transition: 'stroke-dashoffset 1.2s cubic-bezier(0.16,1,0.3,1)' }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl font-extrabold tabular-nums">{pct}<span className="text-xl">%</span></span>
              <span className="text-xs text-white/70 font-medium mt-0.5">complete</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
