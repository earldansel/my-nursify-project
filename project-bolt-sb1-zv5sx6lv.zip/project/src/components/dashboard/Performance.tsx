import { useEffect, useState } from 'react';
import Card from '@/components/ui/Card';
import { LineChart as LineChartSvg } from '@/components/ui/Charts';
import { TrendingUp } from 'lucide-react';
import { getScoreHistory } from '@/lib/questions';

export default function Performance() {
  const [history, setHistory] = useState<{ label: string; score: number }[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getScoreHistory(8).then((data) => {
      setHistory(data.map((d) => ({ label: d.label, score: d.score })));
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <Card className="p-6">
        <div className="h-48 flex items-center justify-center">
          <span className="text-sm text-secondary">Loading...</span>
        </div>
      </Card>
    );
  }

  if (history.length === 0) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-[11px] font-semibold text-ink-400 dark:text-ink-500 uppercase tracking-wide">Performance</p>
            <h3 className="text-lg font-bold text-primary">Score Trend</h3>
          </div>
        </div>
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-ink-100 dark:bg-ink-800 flex items-center justify-center mb-4">
            <TrendingUp className="w-7 h-7 text-ink-400" />
          </div>
          <p className="text-sm font-semibold text-primary">No data yet</p>
          <p className="text-xs text-secondary mt-1 max-w-xs">Complete a few practice tests to see your score trend.</p>
        </div>
      </Card>
    );
  }

  const delta = history.length > 1 ? history[history.length - 1].score - history[0].score : 0;

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="text-[11px] font-semibold text-ink-400 dark:text-ink-500 uppercase tracking-wide">Performance</p>
          <h3 className="text-lg font-bold text-primary">Score Trend</h3>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-mint-50 dark:bg-mint-950/40">
          <TrendingUp className="w-4 h-4 text-mint-600 dark:text-mint-400" />
          <span className={`text-sm font-bold ${delta >= 0 ? 'text-mint-600 dark:text-mint-400' : 'text-rose-500'}`}>
            {delta >= 0 ? '+' : ''}{delta} pts
          </span>
        </div>
      </div>

      <LineChartSvg
        data={history.map((d) => ({ label: d.label, value: d.score }))}
        height={180}
        color="#8b5cf6"
      />

      {history.length > 1 && (
        <div className="mt-4 grid grid-cols-4 gap-3">
          {history.slice(-4).map((d, i) => (
            <div key={`${d.label}-${i}`} className="text-center p-2.5 rounded-xl bg-ink-50 dark:bg-ink-900/50">
              <p className="text-[11px] font-medium text-secondary">{d.label}</p>
              <p className="text-lg font-bold text-primary">{d.score}%</p>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
