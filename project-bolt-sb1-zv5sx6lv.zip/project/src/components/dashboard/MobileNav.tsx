import { Home, BookOpen, BarChart3, CalendarCheck, PlayCircle, User, ShieldCheck, Trophy, GraduationCap, Target } from 'lucide-react';
import type { View } from '@/types';
import { useAuth } from '@/lib/auth';

interface MobileNavProps {
  active: View;
  onNavigate: (view: View) => void;
}

const FREE_RESTRICTED_VIEWS: View[] = ['pnle-study-guide', 'nclex-study-guide', 'study-plan', 'video-lessons'];

const baseItems = [
  { id: 'dashboard' as View, label: 'Home', icon: Home },
  { id: 'quiz' as View, label: 'Practice', icon: BookOpen },
  { id: 'pnle' as View, label: 'PNLE', icon: GraduationCap },
  { id: 'nclex' as View, label: 'NCLEX', icon: Target },
  { id: 'analytics' as View, label: 'Stats', icon: BarChart3 },
  { id: 'study-plan' as View, label: 'Plan', icon: CalendarCheck },
  { id: 'video-lessons' as View, label: 'Videos', icon: PlayCircle },
  { id: 'leaderboard' as View, label: 'Ranks', icon: Trophy },
  { id: 'profile' as View, label: 'Profile', icon: User },
];

export default function MobileNav({ active, onNavigate }: MobileNavProps) {
  const { isAdmin, isFreeUser } = useAuth();
  const items = baseItems.filter((item) => !isFreeUser || !FREE_RESTRICTED_VIEWS.includes(item.id));
  const finalItems = isAdmin
    ? [...items.slice(0, 4), { id: 'admin' as View, label: 'Admin', icon: ShieldCheck }]
    : items;
  return (
    <nav className="lg:hidden fixed bottom-0 inset-x-0 z-50 glass-strong border-t border-subtle">
      <div className="flex items-center justify-around px-2 py-2 pb-[max(0.5rem,env(safe-area-inset-bottom))]">
        {finalItems.map((item) => {
          const isActive = active === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-colors ${
                isActive ? 'text-lavender-600 dark:text-lavender-400' : 'text-secondary'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-semibold">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
