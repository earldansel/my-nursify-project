import { Home, BookOpen, BarChart3, CalendarCheck, Crown, Moon, Sun, User, ShieldCheck, Trophy, GraduationCap, Target, AlertCircle, History, PencilRuler, Settings, type LucideIcon } from 'lucide-react';
import type { View } from '@/types';
import { useAuth } from '@/lib/auth';

interface SidebarProps {
  active: View;
  onNavigate: (view: View) => void;
  dark: boolean;
  onToggleDark: () => void;
}

interface NavItem {
  id: View;
  label: string;
  icon: LucideIcon;
  badge?: string;
}

const FREE_RESTRICTED_VIEWS: View[] = ['pnle-study-guide', 'nclex-study-guide', 'study-plan', 'video-lessons'];

const navSections: { label: string; items: NavItem[] }[] = [
  {
    label: 'Main',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: Home },
      { id: 'study-plan', label: 'My Study Plan', icon: CalendarCheck },
      { id: 'quiz', label: 'Practice', icon: PencilRuler },
    ],
  },
  {
    label: 'Exam Preparation',
    items: [
      { id: 'pnle', label: 'PNLE', icon: GraduationCap },
      { id: 'nclex', label: 'NCLEX', icon: Target },
    ],
  },
  {
    label: 'Progress',
    items: [
      { id: 'analytics', label: 'Analytics', icon: BarChart3 },
      { id: 'weak-areas', label: 'Weak Areas', icon: AlertCircle },
      { id: 'study-history', label: 'Study History', icon: History },
    ],
  },
  {
    label: 'Account',
    items: [
      { id: 'profile', label: 'Profile', icon: User },
      { id: 'profile', label: 'Settings', icon: Settings },
    ],
  },
];

export default function Sidebar({ active, onNavigate, dark, onToggleDark }: SidebarProps) {
  const { profile, isFreeUser, isPremium, isAdmin } = useAuth();

  const isVisible = (item: NavItem) => !isFreeUser || !FREE_RESTRICTED_VIEWS.includes(item.id);

  return (
    <aside className="hidden lg:flex flex-col w-64 shrink-0 h-screen sticky top-0 bg-elevated border-r border-subtle px-4 py-5">
      <button onClick={() => onNavigate('landing')} className="flex items-center gap-2.5 px-2 mb-7">
        <span className="w-8 h-8 gradient-brand rounded-full flex items-center justify-center">
          <span className="w-2.5 h-2.5 bg-white rounded-full animate-pulse" />
        </span>
        <span className="font-bold text-lg tracking-tight text-primary">
          Nursify
        </span>
      </button>

      <nav className="flex-1 flex flex-col gap-6">
        {navSections.map((section) => (
          <div key={section.label}>
            <p className="px-3 mb-2 text-[11px] font-semibold text-ink-400 dark:text-ink-500 uppercase tracking-wider">
              {section.label}
            </p>
            <div className="flex flex-col gap-1">
              {section.items.filter(isVisible).map((item, idx) => {
                const isActive = active === item.id;
                const Icon = item.icon;
                return (
                  <button
                    key={`${section.label}-${item.label}-${idx}`}
                    onClick={() => onNavigate(item.id)}
                    className={`group flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                      isActive
                        ? 'bg-lavender-50 dark:bg-lavender-950/50 text-lavender-700 dark:text-lavender-300'
                        : 'text-secondary hover:text-primary hover:bg-ink-50 dark:hover:bg-ink-800/50'
                    }`}
                  >
                    <Icon className={`w-4.5 h-4.5 ${isActive ? 'text-lavender-600 dark:text-lavender-400' : ''}`} />
                    <span className="flex-1 text-left">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="mt-auto flex flex-col gap-3">
        {isAdmin && (
          <button
            onClick={() => onNavigate('admin')}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-lavender-700 dark:text-lavender-300 bg-lavender-50 dark:bg-lavender-950/50 hover:bg-lavender-100 dark:hover:bg-lavender-900/50 transition-colors"
          >
            <ShieldCheck className="w-4.5 h-4.5" />
            Admin Dashboard
          </button>
        )}
        {!isPremium && (
          <button
            onClick={() => onNavigate('pricing')}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-lavender-700 dark:text-lavender-300 bg-lavender-50 dark:bg-lavender-950/50 hover:bg-lavender-100 dark:hover:bg-lavender-900/50 transition-colors"
          >
            <Crown className="w-4.5 h-4.5" />
            Upgrade to Premium
          </button>
        )}

        <button
          onClick={onToggleDark}
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-secondary hover:text-primary hover:bg-ink-50 dark:hover:bg-ink-800/50 transition-colors"
        >
          {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          {dark ? 'Light mode' : 'Dark mode'}
        </button>

        <button
          onClick={() => onNavigate('profile')}
          className="p-3 rounded-2xl bg-ink-50 dark:bg-ink-900/50 border border-subtle hover:border-lavender-200 dark:hover:border-lavender-800 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full gradient-brand flex items-center justify-center text-white font-bold text-sm overflow-hidden shrink-0">
              {profile?.avatar_url ? (
                <img src={profile.avatar_url} alt={profile?.full_name ?? 'User'} className="w-full h-full object-cover" />
              ) : (
                (profile?.full_name ?? '?').charAt(0).toUpperCase()
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-primary truncate">
                {profile?.full_name || 'User'}
              </p>
              <div className="flex items-center gap-1 text-[11px] font-medium">
                {isPremium ? (
                  <span className="flex items-center gap-1 text-lavender-600 dark:text-lavender-400">
                    <Crown className="w-3 h-3" />
                    Premium
                  </span>
                ) : (
                  <span className="text-secondary">Free plan</span>
                )}
              </div>
            </div>
          </div>
        </button>
      </div>
    </aside>
  );
}
