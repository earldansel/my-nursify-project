import { useState, useEffect, useCallback } from 'react';
import { Pill, Activity, Baby, Brain, Heart, BookOpen, ArrowRight } from 'lucide-react';
import type { Subject, SubjectId } from '@/types';
import { subjects } from '@/data';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';

const iconMap: Record<string, typeof Pill> = {
  pill: Pill,
  activity: Activity,
  baby: Baby,
  brain: Brain,
  heart: Heart,
  book: BookOpen,
};

const SUBJECT_META: Record<string, { name: string; accent: string; icon: string }> = {
  pharmacology: { name: 'Pharmacology', accent: '#8b5cf6', icon: 'pill' },
  medsurg: { name: 'Med-Surg', accent: '#6d28d9', icon: 'activity' },
  pediatrics: { name: 'Pediatrics', accent: '#10b981', icon: 'baby' },
  mentalhealth: { name: 'Mental Health', accent: '#a78bfa', icon: 'brain' },
  ob: { name: 'Maternal & Newborn', accent: '#f59e0b', icon: 'heart' },
  fundamentals: { name: 'Fundamentals', accent: '#7c3aed', icon: 'book' },
};

interface SubjectCardsProps {
  onPractice: (subjectId: Subject['id']) => void;
}

interface SubjectStats {
  questionsTotal: number;
  questionsCompleted: number;
  mastery: number;
}

interface SubjectCardData {
  id: string;
  name: string;
  accent: string;
  icon: string;
}

export default function SubjectCards({ onPractice }: SubjectCardsProps) {
  const { user } = useAuth();
  const [stats, setStats] = useState<Record<string, SubjectStats>>({});
  const [loading, setLoading] = useState(true);
  const [activeSubjects, setActiveSubjects] = useState<SubjectCardData[]>([]);

  const fetchStats = useCallback(async () => {
    setLoading(true);

    const [subjectRes, answerRes] = await Promise.all([
      supabase.rpc('get_subject_question_counts'),
      user
        ? supabase.rpc('get_user_subject_answer_stats')
        : Promise.resolve({ data: null, error: null }),
    ]);

    if (subjectRes.error || !subjectRes.data) {
      setLoading(false);
      return;
    }

    const answerMap = new Map<string, { answered: number; correct: number }>();
    if (answerRes.data) {
      for (const row of answerRes.data as { subject_id: string; answered: number; correct: number }[]) {
        answerMap.set(row.subject_id, { answered: row.answered, correct: row.correct });
      }
    }

    const newStats: Record<string, SubjectStats> = {};
    const cards: SubjectCardData[] = [];

    for (const row of subjectRes.data as { subject_id: string; total: number }[]) {
      const sid = row.subject_id;
      const meta = SUBJECT_META[sid];
      const a = answerMap.get(sid);
      const completed = a?.answered ?? 0;
      const correct = a?.correct ?? 0;
      const mastery = completed > 0 ? Math.round((correct / completed) * 100) : 0;
      newStats[sid] = { questionsTotal: row.total, questionsCompleted: completed, mastery };

      if (meta) {
        cards.push({ id: sid, name: meta.name, accent: meta.accent, icon: meta.icon });
      } else {
        const displayName = sid.charAt(0).toUpperCase() + sid.slice(1);
        cards.push({ id: sid, name: displayName, accent: '#6366f1', icon: 'book' });
      }
    }

    const order: Record<string, number> = {};
    subjects.forEach((s, i) => { order[s.id] = i; });
    cards.sort((a, b) => {
      const oa = order[a.id] ?? 99;
      const ob = order[b.id] ?? 99;
      if (oa !== ob) return oa - ob;
      return a.name.localeCompare(b.name);
    });

    setStats(newStats);
    setActiveSubjects(cards);
    setLoading(false);
  }, [user?.id]);

  useEffect(() => {
    fetchStats();

    const channel = supabase
      .channel('questions-count-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'questions' }, () => {
        fetchStats();
      })
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'question_answers' },
        () => {
          fetchStats();
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchStats]);

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-primary">Subjects</h3>
        <button className="text-sm font-medium text-violet-600 dark:text-violet-400 hover:underline">
          View all
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {(loading ? subjects.map((s) => ({ id: s.id, name: s.name, accent: s.accent, icon: s.icon })) : activeSubjects).map((s) => {
          const Icon = iconMap[s.icon] ?? BookOpen;
          const stat = stats[s.id];
          const total = stat?.questionsTotal ?? 0;
          const completed = stat?.questionsCompleted ?? 0;
          const mastery = stat?.mastery ?? 0;
          const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
          return (
            <div
              key={s.id}
              className="group bg-elevated border border-subtle rounded-2xl p-5 card-hover hover:shadow-card hover:border-violet-200 dark:hover:border-violet-800"
            >
              <div className="flex items-start justify-between">
                <div
                  className="w-11 h-11 rounded-2xl flex items-center justify-center"
                  style={{ backgroundColor: `${s.accent}14`, color: s.accent }}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span
                  className="text-xs font-bold px-2 py-1 rounded-lg"
                  style={{ backgroundColor: `${s.accent}14`, color: s.accent }}
                >
                  {loading ? '—' : mastery}% Mastery
                </span>
              </div>

              <h4 className="mt-4 text-base font-bold text-primary">{s.name}</h4>
              <p className="text-xs text-secondary mt-0.5">
                {loading ? (
                  <span className="inline-block w-24 h-3 rounded bg-ink-100 dark:bg-ink-800 animate-pulse" />
                ) : (
                  `${completed} / ${total} questions`
                )}
              </p>

              <div className="mt-3 h-1.5 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-1000"
                  style={{ width: `${pct}%`, backgroundColor: s.accent }}
                />
              </div>

              <button
                onClick={() => onPractice(s.id as SubjectId)}
                className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-violet-600 dark:text-violet-400 group-hover:gap-2.5 transition-all"
              >
                Practice
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
