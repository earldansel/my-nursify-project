import { useEffect, useState } from 'react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import { RadialChart } from '@/components/ui/Charts';
import { getSubjectPerformance, type SubjectPerformance } from '@/lib/questions';

const SUBJECT_ACCENTS: Record<string, string> = {
  pharmacology: '#8b5cf6',
  medsurg: '#6d28d9',
  pediatrics: '#10b981',
  mentalhealth: '#a78bfa',
  ob: '#f59e0b',
  fundamentals: '#7c3aed',
};

function getStatus(mastery: number, answered: number): { label: string; color: string } {
  if (answered === 0) return { label: 'No Data', color: 'text-ink-400' };
  if (mastery < 60) return { label: 'Needs Attention', color: 'text-rose-500' };
  if (mastery < 80) return { label: 'Progressing', color: 'text-amber-500' };
  return { label: 'Strong', color: 'text-mint-500' };
}

export default function WeakSpots({ onPractice }: { onPractice?: (subjectId: string) => void }) {
  const [subjects, setSubjects] = useState<SubjectPerformance[]>([]);
  const [hovered, setHovered] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getSubjectPerformance().then((data) => {
      setSubjects(data);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <Card className="p-6">
        <div className="h-48 flex items-center justify-center">
          <span className="text-sm text-secondary">Loading...</span>
        </div>
      </Card>
    );
  }

  const hasData = subjects.some((s) => s.answered > 0);

  if (!hasData) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-between mb-5">
          <div>
            <p className="text-[11px] font-semibold text-ink-400 dark:text-ink-500 uppercase tracking-wide">Mastery</p>
            <h3 className="text-lg font-bold text-primary">Weak Spots</h3>
          </div>
        </div>
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-ink-100 dark:bg-ink-800 flex items-center justify-center mb-4">
            <span className="text-2xl">📊</span>
          </div>
          <p className="text-sm font-semibold text-primary">No data yet</p>
          <p className="text-xs text-secondary mt-1 max-w-xs">Start practicing to identify your weak areas.</p>
        </div>
      </Card>
    );
  }

  const sorted = [...subjects].sort((a, b) => a.mastery - b.mastery);
  const active = sorted.find((s) => s.subjectId === hovered) ?? sorted[0];
  const accent = SUBJECT_ACCENTS[active?.subjectId ?? ''] ?? '#6366f1';
  const status = getStatus(active?.mastery ?? 0, active?.answered ?? 0);

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-5">
        <div>
          <p className="text-[11px] font-semibold text-ink-400 dark:text-ink-500 uppercase tracking-wide">Mastery</p>
          <h3 className="text-lg font-bold text-primary">Weak Spots</h3>
        </div>
        <span className="text-xs font-medium text-secondary">Hover a subject</span>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-6">
        <div className="relative shrink-0">
          <RadialChart
            data={sorted.map((s) => ({
              label: s.subjectName,
              value: s.mastery,
              color: SUBJECT_ACCENTS[s.subjectId] ?? '#6366f1',
            }))}
            size={200}
          />
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-3xl font-extrabold text-primary tabular-nums">{active?.mastery ?? 0}%</span>
            <span className="text-xs text-secondary font-medium mt-0.5">{active?.subjectName}</span>
          </div>
        </div>

        <div className="flex-1 w-full space-y-2">
          {sorted.map((s) => {
            const sStatus = getStatus(s.mastery, s.answered);
            return (
              <button
                key={s.subjectId}
                onMouseEnter={() => setHovered(s.subjectId)}
                onFocus={() => setHovered(s.subjectId)}
                className={`w-full flex items-center gap-3 p-2.5 rounded-2xl transition-all text-left ${
                  active?.subjectId === s.subjectId
                    ? 'bg-ink-50 dark:bg-ink-900/50'
                    : 'hover:bg-ink-50 dark:hover:bg-ink-900/40'
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: SUBJECT_ACCENTS[s.subjectId] ?? '#6366f1' }} />
                <span className="text-sm font-semibold text-primary flex-1">{s.subjectName}</span>
                <span className={`text-xs font-medium ${sStatus.color}`}>{sStatus.label}</span>
                <span className="text-sm font-bold text-primary tabular-nums w-10 text-right">{s.mastery}%</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-5 pt-5 border-t border-subtle flex items-end justify-between gap-4">
        <div className="grid grid-cols-3 gap-4 flex-1">
          <div>
            <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wide">Questions</p>
            <p className="text-lg font-bold text-primary mt-0.5">{active?.answered ?? 0}</p>
          </div>
          <div>
            <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wide">Accuracy</p>
            <p className="text-lg font-bold text-primary mt-0.5">{active?.mastery ?? 0}%</p>
          </div>
          <div>
            <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wide">Status</p>
            <p className={`text-lg font-bold mt-0.5 ${status.color}`}>{status.label}</p>
          </div>
        </div>
        {onPractice && active && <Button size="sm" variant="outline" onClick={() => onPractice(active.subjectId)}>Practice this weakness</Button>}
      </div>
    </Card>
  );
}
