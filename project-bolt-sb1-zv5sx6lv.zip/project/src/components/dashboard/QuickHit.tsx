import { useState } from 'react';
import { Clock, Zap, ArrowRight } from 'lucide-react';
import Button from '@/components/ui/Button';
import { useToast } from '@/components/ui/Toast';

const options = [
  { minutes: 5, questions: 6, difficulty: 'Easy', subject: 'Fundamentals' },
  { minutes: 10, questions: 12, difficulty: 'Medium', subject: 'Pharmacology' },
  { minutes: 20, questions: 25, difficulty: 'Mixed', subject: 'Your Weak Spots' },
  { minutes: 30, questions: 40, difficulty: 'Hard', subject: 'Full Review' },
];

interface QuickHitProps {
  onStart: () => void;
}

export default function QuickHit({ onStart }: QuickHitProps) {
  const [selected, setSelected] = useState<number | null>(1);
  const { toast } = useToast();
  const opt = selected !== null ? options[selected] : null;

  return (
    <div className="bg-elevated border border-subtle rounded-3xl p-6 shadow-soft">
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/40 flex items-center justify-center">
          <Zap className="w-4.5 h-4.5 text-rose-500" />
        </div>
        <div>
          <p className="text-[11px] font-semibold text-ink-400 dark:text-ink-500 uppercase tracking-wide">Quick Hit</p>
          <h3 className="text-base font-bold text-primary">How much time do you have?</h3>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-4 gap-2">
        {options.map((o, i) => (
          <button
            key={o.minutes}
            onClick={() => setSelected(i)}
            className={`relative py-3 rounded-2xl text-sm font-bold transition-all btn-press ${
              selected === i
                ? 'gradient-brand text-white shadow-lift'
                : 'bg-ink-50 dark:bg-ink-900/50 text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 border border-subtle'
            }`}
          >
            {o.minutes}
            <span className="block text-[10px] font-medium opacity-70 mt-0.5">min</span>
          </button>
        ))}
      </div>

      {opt && (
        <div className="mt-4 p-4 rounded-2xl bg-violet-50 dark:bg-violet-950/30 border border-violet-100 dark:border-violet-900 animate-fade-in-fast">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-violet-500" />
                <span className="text-sm font-semibold text-primary">≈ {opt.questions} questions</span>
              </div>
              <span className="text-xs font-medium text-secondary">·</span>
              <span className="text-sm font-medium text-secondary">{opt.difficulty}</span>
              <span className="text-xs font-medium text-secondary">·</span>
              <span className="text-sm font-medium text-violet-700 dark:text-violet-300">{opt.subject}</span>
            </div>
            <Button
              size="sm"
              withArrow
              onClick={() => {
                toast({ title: 'Quick Hit starting', description: `Targeting: ${opt.subject}`, variant: 'info' });
                onStart();
              }}
            >
              Start Quick Hit
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
