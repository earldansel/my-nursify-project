import { useEffect, useState } from 'react';
import { Target, Flame, CheckCircle2, Clock } from 'lucide-react';
import { getDashboardStats } from '@/lib/questions';

interface Stats {
  totalAnswered: number;
  accuracy: number;
  currentStreak: number;
  studyTimeSeconds: number;
  todayAnswered: number;
}

const accentBg: Record<string, string> = {
  violet: 'bg-violet-50 dark:bg-violet-950/40 text-violet-600 dark:text-violet-400',
  mint: 'bg-mint-50 dark:bg-mint-950/40 text-mint-600 dark:text-mint-400',
  amber: 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400',
  lavender: 'bg-lavender-50 dark:bg-lavender-950/40 text-lavender-600 dark:text-lavender-400',
};

function formatStudyTime(seconds: number): string {
  if (seconds < 60) return '0m';
  const hours = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m`;
}

export default function StatGrid() {
  const [stats, setStats] = useState<Stats>({
    totalAnswered: 0,
    accuracy: 0,
    currentStreak: 0,
    studyTimeSeconds: 0,
    todayAnswered: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getDashboardStats().then((data) => {
      setStats({
        totalAnswered: data.totalAnswered,
        accuracy: data.accuracy,
        currentStreak: data.currentStreak,
        studyTimeSeconds: data.studyTimeSeconds,
        todayAnswered: data.todayAnswered,
      });
      setLoading(false);
    });
  }, []);

  const items = [
    { icon: Target, label: 'Questions Today', value: loading ? '—' : String(stats.todayAnswered), accent: 'violet' },
    { icon: CheckCircle2, label: 'Accuracy', value: loading ? '—' : `${stats.accuracy}%`, accent: 'mint' },
    { icon: Flame, label: 'Streak', value: loading ? '—' : `${stats.currentStreak} day${stats.currentStreak !== 1 ? 's' : ''}`, accent: 'amber' },
    { icon: Clock, label: 'Study Time', value: loading ? '—' : formatStudyTime(stats.studyTimeSeconds), accent: 'lavender' },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {items.map((s) => {
        const Icon = s.icon;
        return (
          <div key={s.label} className="bg-elevated border border-subtle rounded-2xl p-4 card-hover hover:shadow-card">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${accentBg[s.accent]}`}>
              <Icon className="w-4.5 h-4.5" />
            </div>
            <p className="mt-3 text-2xl font-extrabold text-primary">{s.value}</p>
            <p className="text-xs text-secondary font-medium">{s.label}</p>
          </div>
        );
      })}
    </div>
  );
}
