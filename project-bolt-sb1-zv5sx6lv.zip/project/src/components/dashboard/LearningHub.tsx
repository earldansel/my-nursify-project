import { useEffect, useState } from 'react';
import { Award, BookOpen, CalendarCheck, Flame, Play, Target } from 'lucide-react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import { getDailyChallenge, getLearningProgress, getLevel, getSmartReview, getWeakSpots, type DailyChallenge, type WeakSpot } from '@/lib/learning';
import { fetchBookmarkedQuestionIds } from '@/lib/questions';

interface LearningHubProps {
  onStartQuestions: (ids: string[], dailyChallengeId?: string) => void;
  onStartSubject: (subjectId: string) => void;
}

export default function LearningHub({ onStartQuestions, onStartSubject }: LearningHubProps) {
  const [challenge, setChallenge] = useState<DailyChallenge | null>(null);
  const [weakest, setWeakest] = useState<WeakSpot | null>(null);
  const [reviewCount, setReviewCount] = useState(0);
  const [savedCount, setSavedCount] = useState(0);
  const [xp, setXp] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    Promise.all([getDailyChallenge(), getWeakSpots(), getSmartReview(), getLearningProgress(), fetchBookmarkedQuestionIds()])
      .then(([daily, spots, review, progress, saved]) => {
        if (!active) return;
        setChallenge(daily);
        setWeakest(spots[0] ?? null);
        setReviewCount(review.filter((item) => item.status === 'incorrect').length);
        setSavedCount(saved.size);
        setXp(progress.xp);
      })
      .finally(() => active && setLoading(false));
    return () => { active = false; };
  }, []);

  const level = getLevel(xp);
  const startReview = async () => {
    const review = await getSmartReview();
    onStartQuestions(review.filter((item) => item.status === 'incorrect').map((item) => item.question.id));
  };
  const startSaved = async () => {
    const saved = await fetchBookmarkedQuestionIds();
    onStartQuestions([...saved]);
  };

  if (loading) return <Card className="p-6"><p className="text-sm text-secondary">Personalizing your study plan...</p></Card>;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <Card className="p-5 lg:col-span-2 border-violet-200 dark:border-violet-900/60 bg-gradient-to-br from-violet-50/70 to-elevated dark:from-violet-950/25">
        <div className="flex items-start gap-4">
          <div className="w-11 h-11 rounded-2xl gradient-brand text-white flex items-center justify-center shrink-0"><CalendarCheck className="w-5 h-5" /></div>
          <div className="flex-1 min-w-0">
            <p className="text-[11px] font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wide">Daily Challenge</p>
            <h3 className="text-lg font-bold text-primary mt-1">{challenge?.completed ? 'Challenge complete' : `${challenge?.questionIds.length ?? 0} mixed questions for today`}</h3>
            <p className="text-sm text-secondary mt-1">{challenge?.completed ? 'Your learning activity is saved for today.' : 'One focused burst keeps your streak moving.'}</p>
            {!challenge?.completed && challenge && <Button size="sm" className="mt-4" onClick={() => onStartQuestions(challenge.questionIds, challenge.id)}><Play className="w-4 h-4" /> Start challenge</Button>}
          </div>
        </div>
      </Card>

      <Card className="p-5">
        <div className="flex items-center gap-3 mb-3"><div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/30 text-amber-600 flex items-center justify-center"><Award className="w-4 h-4" /></div><div><p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wide">Level {level.level}</p><p className="font-bold text-primary">{level.title}</p></div></div>
        <div className="h-2 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden"><div className="h-full gradient-brand rounded-full" style={{ width: `${level.current}%` }} /></div>
        <p className="text-xs text-secondary mt-2">{level.current} / {level.next} XP to next level</p>
      </Card>

      <Card className="p-5">
        <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wide">What should I study next?</p>
        {weakest ? <><h3 className="text-lg font-bold text-primary mt-1">{weakest.subjectName}</h3><p className="text-sm text-secondary mt-0.5">{weakest.topic ?? 'Your weakest subject'}</p><p className="text-2xl font-extrabold text-rose-500 mt-3">{weakest.accuracy}% <span className="text-xs font-medium text-secondary">accuracy</span></p><Button size="sm" variant="outline" className="mt-3" onClick={() => onStartSubject(weakest.subjectId)}><Target className="w-4 h-4" /> Start recommended practice</Button></> : <p className="text-sm text-secondary mt-3">Keep practicing to receive personalized recommendations.</p>}
      </Card>

      <Card className="p-5 lg:col-span-2">
        <div className="flex items-center justify-between gap-3"><div><p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wide">Smart Review</p><h3 className="text-lg font-bold text-primary mt-1">Turn misses into momentum</h3><p className="text-sm text-secondary mt-1">{reviewCount ? `${reviewCount} incorrect questions are ready to review.` : 'Answer more questions to build your review queue.'}</p></div><Flame className="w-5 h-5 text-rose-500 shrink-0" /></div><div className="flex flex-wrap gap-2 mt-4"><Button size="sm" onClick={startReview} disabled={!reviewCount}><BookOpen className="w-4 h-4" /> Review weak questions</Button><Button size="sm" variant="outline" onClick={startSaved} disabled={!savedCount}>Saved questions ({savedCount})</Button></div>
      </Card>
    </div>
  );
}
