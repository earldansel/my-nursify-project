import { Moon, Sun, GraduationCap, ChevronRight, ArrowRight, BookOpen, PencilRuler, CalendarCheck, Target, TrendingUp, CheckCircle2, Circle, Flame, Award } from 'lucide-react';
import { useState, useEffect } from 'react';
import Sidebar from '@/components/dashboard/Sidebar';
import MobileNav from '@/components/dashboard/MobileNav';
import QuickHit from '@/components/dashboard/QuickHit';
import WeakSpots from '@/components/dashboard/WeakSpots';
import StatGrid from '@/components/dashboard/StatGrid';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import type { View, ExamTrack } from '@/types';

interface StudyTask {
  id: string;
  title: string;
  completed: boolean;
  icon: typeof BookOpen;
}

function getGreeting(hour: number): string {
  if (hour >= 5 && hour < 12) return 'Good morning';
  if (hour >= 12 && hour < 18) return 'Good afternoon';
  return 'Good evening';
}

interface DashboardProps {
  onNavigate: (view: View) => void;
  dark: boolean;
  onToggleDark: () => void;
  onStartQuestions: (ids: string[], dailyChallengeId?: string) => void;
  onStartSubject: (subjectId: string) => void;
  examTrack: ExamTrack;
  onTrackChange: (track: ExamTrack) => void;
}



export default function Dashboard({ onNavigate, dark, onToggleDark, onStartQuestions, onStartSubject, examTrack, onTrackChange }: DashboardProps) {
  const { profile, isFreeUser } = useAuth();
  const [greeting, setGreeting] = useState(() => getGreeting(new Date().getHours()));
  const [todaysTasks, setTodaysTasks] = useState<StudyTask[]>([]);
  const [pnleProgress, setPnleProgress] = useState(0);
  const [nclexProgress, setNclexProgress] = useState(0);

  useEffect(() => {
    const update = () => setGreeting(getGreeting(new Date().getHours()));
    update();
    const interval = setInterval(update, 60_000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Fetch real study tasks from database
    const fetchTasks = async () => {
      const today = new Date().toISOString().split('T')[0];
      const { data } = await supabase
        .from('study_tasks')
        .select('id, title, completed, sort_order')
        .eq('scheduled_date', today)
        .order('sort_order', { ascending: true })
        .limit(4);
      if (data && data.length > 0) {
        setTodaysTasks(data.map((t: { id: string; title: string; completed: boolean }) => ({
          id: t.id, title: t.title, completed: t.completed, icon: BookOpen,
        })));
      } else {
        setTodaysTasks([]);
      }
    };
    fetchTasks();
  }, []);

  useEffect(() => {
    // Fetch real study guide progress per track
    const fetchProgress = async () => {
      for (const track of ['pnle', 'nclex'] as const) {
        const { data: subjects } = await supabase
          .from('study_guide_subjects')
          .select('id')
          .eq('exam_track', track);
        if (!subjects || subjects.length === 0) continue;
        const subjectIds = subjects.map((s: { id: string }) => s.id);
        const { data: topics } = await supabase
          .from('study_guide_topics')
          .select('id')
          .in('subject_id', subjectIds);
        if (!topics || topics.length === 0) continue;
        const topicIds = topics.map((t: { id: string }) => t.id);
        const { data: progress } = await supabase
          .from('study_guide_progress')
          .select('topic_id')
          .in('topic_id', topicIds)
          .eq('studied', true)
          .eq('exam_track', track);
        const pct = topics.length > 0 ? Math.round(((progress?.length ?? 0) / topics.length) * 100) : 0;
        if (track === 'pnle') setPnleProgress(pct);
        else setNclexProgress(pct);
      }
    };
    fetchProgress();
  }, []);

  const firstName = (profile?.full_name || '').split(' ')[0] || 'there';
  const completedTasks = todaysTasks.filter((t) => t.completed).length;
  const totalTasks = todaysTasks.length;
  const taskPct = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  return (
    <div className="min-h-screen bg-surface flex">
      <Sidebar active="dashboard" onNavigate={onNavigate} dark={dark} onToggleDark={onToggleDark} />

      <div className="flex-1 min-w-0 pb-20 lg:pb-0">
        {/* Top bar (mobile) */}
        <div className="lg:hidden sticky top-0 z-40 glass-strong border-b border-subtle px-5 h-14 flex items-center justify-between">
          <button onClick={() => onNavigate('landing')} className="flex items-center gap-2">
            <span className="w-7 h-7 gradient-brand rounded-full flex items-center justify-center">
              <span className="w-2 h-2 bg-white rounded-full" />
            </span>
            <span className="font-bold text-primary">Nursify</span>
          </button>
          <button
            onClick={onToggleDark}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors"
          >
            {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>
        </div>

        <main className="max-w-6xl mx-auto px-5 sm:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
          {/* Greeting + Exam Track Selector */}
          <div className="animate-slide-up">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <p className="text-sm text-secondary font-medium">{greeting}, {firstName}</p>
                <h1 className="mt-1 text-2xl sm:text-3xl font-extrabold text-primary">
                  Your nursing journey continues.
                </h1>
              </div>
              {/* Exam Track Selector */}
              <div className="flex items-center gap-1 p-1 rounded-2xl bg-elevated border border-subtle">
                <button
                  onClick={() => onTrackChange('pnle')}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                    examTrack === 'pnle'
                      ? 'gradient-brand text-white shadow-lift'
                      : 'text-secondary hover:text-primary'
                  }`}
                >
                  🇵🇭 PNLE
                </button>
                <button
                  onClick={() => onTrackChange('nclex')}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                    examTrack === 'nclex'
                      ? 'gradient-brand text-white shadow-lift'
                      : 'text-secondary hover:text-primary'
                  }`}
                >
                  🌎 NCLEX
                </button>
              </div>
            </div>
          </div>

          {/* Continue Learning */}
          <div className="animate-slide-up animate-delay-100">
            <div className="relative overflow-hidden rounded-3xl gradient-navy p-6 sm:p-7 text-white">
              <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full bg-lavender-500/20 blur-3xl" />
              <div className="absolute -left-10 -bottom-10 w-32 h-32 rounded-full bg-mint-500/15 blur-3xl" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-xl bg-white/15 backdrop-blur-sm flex items-center justify-center">
                    <BookOpen className="w-4 h-4 text-white" />
                  </div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-white/70">Continue Learning</p>
                </div>
                <h2 className="text-xl sm:text-2xl font-extrabold">
                  {examTrack === 'pnle' ? 'Continue PNLE Review' : 'Continue NCLEX Practice'}
                </h2>
                <p className="mt-1 text-sm text-white/70">
                  Pick up where you left off and keep your streak alive.
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    onClick={() => onNavigate('quiz')}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white text-violet-900 hover:bg-white/90 text-sm font-semibold shadow-lift transition-all"
                  >
                    Resume Practice <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onNavigate('study-plan')}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/15 backdrop-blur-sm text-white hover:bg-white/25 text-sm font-semibold transition-all"
                  >
                    <CalendarCheck className="w-3.5 h-3.5" />
                    Resume Study Plan
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Today's Study Plan */}
          <div className="animate-slide-up animate-delay-100">
            <div className="rounded-3xl border border-subtle bg-elevated p-6 sm:p-7 shadow-soft">
              <div className="flex items-center justify-between mb-5">
                <div>
                  <div className="flex items-center gap-2">
                    <CalendarCheck className="w-4 h-4 text-lavender-500" />
                    <h3 className="text-lg font-bold text-primary">Today's Study Plan</h3>
                  </div>
                  <p className="text-sm text-secondary mt-0.5">
                    {completedTasks} of {totalTasks} completed
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-extrabold gradient-text">{taskPct}%</span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="h-2 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden mb-5">
                <div className="h-full gradient-brand rounded-full transition-all duration-1000" style={{ width: `${taskPct}%` }} />
              </div>

              {/* Task list */}
              <div className="space-y-2.5">
                {todaysTasks.length === 0 && (
                  <p className="text-sm text-secondary py-4 text-center">No tasks scheduled for today. Create a study plan to get started!</p>
                )}
                {todaysTasks.map((task) => {
                  const Icon = task.icon;
                  return (
                    <div
                      key={task.id}
                      className={`flex items-center gap-3 rounded-2xl px-4 py-3 transition-all ${
                        task.completed ? 'opacity-60' : ''
                      }`}
                    >
                      {task.completed ? (
                        <CheckCircle2 className="w-5 h-5 shrink-0 text-mint-500" />
                      ) : (
                        <Circle className="w-5 h-5 shrink-0 text-ink-300 dark:text-ink-600" />
                      )}
                      <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-lavender-50 dark:bg-lavender-950/40 shrink-0">
                        <Icon className="w-4 h-4 text-lavender-600 dark:text-lavender-400" />
                      </div>
                      <p className={`flex-1 text-sm font-semibold ${task.completed ? 'line-through text-ink-400' : 'text-primary'}`}>
                        {task.title}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Exam Progress — PNLE + NCLEX Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 animate-slide-up animate-delay-200">
            {/* PNLE Card */}
            <div className="relative overflow-hidden rounded-3xl border border-lavender-200 dark:border-lavender-800 bg-elevated p-6 card-hover hover:shadow-card">
              <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-lavender-100 dark:bg-lavender-950/30 blur-2xl" />
              <div className="relative">
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-2xl">🇵🇭</span>
                  <div>
                    <h3 className="text-lg font-extrabold text-primary">PNLE</h3>
                    <p className="text-xs text-secondary">Philippine Nurse Licensure Examination</p>
                  </div>
                </div>
                <div className="flex items-end gap-2 mb-3">
                  <span className="text-3xl font-extrabold gradient-text">{pnleProgress}%</span>
                  <span className="text-sm text-secondary mb-1">{pnleProgress >= 80 ? 'Ready' : 'In Progress'}</span>
                </div>
                <div className="h-2 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden mb-4">
                  <div className="h-full gradient-brand rounded-full transition-all duration-1000" style={{ width: `${pnleProgress}%` }} />
                </div>
                <button
                  onClick={() => { onTrackChange('pnle'); onNavigate('pnle'); }}
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-lavender-600 dark:text-lavender-400 hover:gap-2.5 transition-all"
                >
                  Continue PNLE <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* NCLEX Card */}
            <div className="relative overflow-hidden rounded-3xl border border-mint-200 dark:border-mint-800 bg-elevated p-6 card-hover hover:shadow-card">
              <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-mint-100 dark:bg-mint-950/30 blur-2xl" />
              <div className="relative">
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-2xl">🌎</span>
                  <div>
                    <h3 className="text-lg font-extrabold text-primary">NCLEX-RN</h3>
                    <p className="text-xs text-secondary">National Council Licensure Examination</p>
                  </div>
                </div>
                <div className="flex items-end gap-2 mb-3">
                  <span className="text-3xl font-extrabold gradient-text">{nclexProgress}%</span>
                  <span className="text-sm text-secondary mb-1">{nclexProgress >= 80 ? 'Ready' : 'In Progress'}</span>
                </div>
                <div className="h-2 rounded-full bg-ink-100 dark:bg-ink-800 overflow-hidden mb-4">
                  <div className="h-full gradient-brand rounded-full transition-all duration-1000" style={{ width: `${nclexProgress}%` }} />
                </div>
                <button
                  onClick={() => { onTrackChange('nclex'); onNavigate('nclex'); }}
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-mint-600 dark:text-mint-400 hover:gap-2.5 transition-all"
                >
                  Continue NCLEX <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Practice entry points */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 animate-slide-up animate-delay-200">
            <button
              onClick={() => { onTrackChange('pnle'); onNavigate('pnle'); }}
              className="group relative overflow-hidden rounded-2xl border border-subtle bg-elevated p-5 card-hover hover:shadow-card hover:border-lavender-200 dark:hover:border-lavender-800 text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-lavender-50 dark:bg-lavender-950/40 flex items-center justify-center">
                  <span className="text-lg">🇵🇭</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold text-primary">PNLE Practice</p>
                  <p className="text-xs text-secondary">Philippine board exam questions</p>
                </div>
                <ChevronRight className="w-4 h-4 text-secondary group-hover:translate-x-0.5 transition-transform" />
              </div>
            </button>
            <button
              onClick={() => { onTrackChange('nclex'); onNavigate('nclex'); }}
              className="group relative overflow-hidden rounded-2xl border border-subtle bg-elevated p-5 card-hover hover:shadow-card hover:border-mint-200 dark:hover:border-mint-800 text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-mint-50 dark:bg-mint-950/40 flex items-center justify-center">
                  <span className="text-lg">🌎</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold text-primary">NCLEX Practice</p>
                  <p className="text-xs text-secondary">NCLEX-RN style questions</p>
                </div>
                <ChevronRight className="w-4 h-4 text-secondary group-hover:translate-x-0.5 transition-transform" />
              </div>
            </button>
          </div>

          {/* Stats */}
          <div className="animate-slide-up animate-delay-200">
            <StatGrid />
          </div>

          {/* Quick Hit */}
          <div className="animate-slide-up animate-delay-200">
            <QuickHit onStart={() => onNavigate('quiz')} />
          </div>

          {/* Weak Spots */}
          <div className="animate-slide-up animate-delay-300">
            <WeakSpots onPractice={onStartSubject} />
          </div>

          {/* Study Guide — hidden for free users */}
          {!isFreeUser && (
          <div className="animate-slide-up animate-delay-300">
            <div className="bg-elevated border border-subtle rounded-2xl p-6 card-hover hover:shadow-card hover:border-lavender-200 dark:hover:border-lavender-800 cursor-pointer" onClick={() => onNavigate(examTrack === 'pnle' ? 'pnle' : 'nclex')}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-lavender-50 dark:bg-lavender-950/40 text-lavender-600 dark:text-lavender-400">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-primary">Study Guide</h3>
                  <p className="text-sm text-secondary mt-0.5">A structured roadmap of what to study for each nursing subject.</p>
                </div>
                <ChevronRight className="w-5 h-5 text-secondary" />
              </div>
            </div>
          </div>
          )}
        </main>
      </div>

      <MobileNav active="dashboard" onNavigate={onNavigate} />
    </div>
  );
}
