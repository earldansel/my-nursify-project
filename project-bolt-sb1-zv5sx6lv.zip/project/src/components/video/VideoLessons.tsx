import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Moon,
  Sun,
  PlayCircle,
  Play,
  Search,
  Calendar,
  ExternalLink,
} from 'lucide-react';
import type { View } from '@/types';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import Sidebar from '@/components/dashboard/Sidebar';
import MobileNav from '@/components/dashboard/MobileNav';
import Card from '@/components/ui/Card';
import Skeleton from '@/components/ui/Skeleton';
import { useToast } from '@/components/ui/Toast';

interface VideoLesson {
  id: string;
  title: string;
  youtube_url: string;
  youtube_id: string;
  subject: string;
  lesson_date: string;
  created_at: string;
}

const SUBJECT_FILTERS: { id: string; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'pharmacology', label: 'Pharmacology' },
  { id: 'medsurg', label: 'Med-Surg' },
  { id: 'pediatrics', label: 'Pediatrics' },
  { id: 'mentalhealth', label: 'Mental Health' },
  { id: 'ob', label: 'Maternal & Newborn' },
  { id: 'fundamentals', label: 'Fundamentals' },
  { id: 'general', label: 'General' },
];

const SUBJECT_LABELS: Record<string, string> = {
  pharmacology: 'Pharmacology',
  medsurg: 'Med-Surg',
  pediatrics: 'Pediatrics',
  mentalhealth: 'Mental Health',
  ob: 'Maternal & Newborn',
  fundamentals: 'Fundamentals',
  general: 'General',
};

const SUBJECT_COLORS: Record<string, string> = {
  pharmacology: '#8b5cf6',
  medsurg: '#6d28d9',
  pediatrics: '#10b981',
  mentalhealth: '#a78bfa',
  ob: '#f59e0b',
  fundamentals: '#7c3aed',
  general: '#3b82f6',
};

function formatDate(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function getYouTubeThumbnail(youtubeId: string): string {
  return `https://i.ytimg.com/vi/${youtubeId}/hqdefault.jpg`;
}

function openVideo(url: string) {
  window.open(url, '_blank', 'noopener,noreferrer');
}

interface VideoLessonsProps {
  onNavigate: (view: View) => void;
  dark: boolean;
  onToggleDark: () => void;
}

export default function VideoLessons({ onNavigate, dark, onToggleDark }: VideoLessonsProps) {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [videos, setVideos] = useState<VideoLesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('all');

  const loadVideos = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('video_lessons')
        .select('*')
        .order('lesson_date', { ascending: false });
      if (error) throw error;
      setVideos((data as VideoLesson[]) ?? []);
    } catch (err) {
      console.error('Error loading videos:', err);
      toast({ title: 'Failed to load video lessons', variant: 'error' });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadVideos();
  }, [loadVideos]);

  const filteredVideos = useMemo(() => {
    return videos.filter((v) => {
      const matchesSearch =
        !search ||
        v.title.toLowerCase().includes(search.toLowerCase());
      const matchesSubject = subjectFilter === 'all' || v.subject === subjectFilter;
      return matchesSearch && matchesSubject;
    });
  }, [videos, search, subjectFilter]);

  // Group by month for timeline feel
  const groupedVideos = useMemo(() => {
    const groups: { label: string; videos: VideoLesson[] }[] = [];
    const monthMap = new Map<string, VideoLesson[]>();
    filteredVideos.forEach((v) => {
      const d = new Date(v.lesson_date + 'T00:00:00');
      const label = d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      if (!monthMap.has(label)) monthMap.set(label, []);
      monthMap.get(label)!.push(v);
    });
    monthMap.forEach((vids, label) => groups.push({ label, videos: vids }));
    return groups;
  }, [filteredVideos]);

  const firstName = (profile?.full_name || '').split(' ')[0] || 'there';

  return (
    <div className="min-h-screen bg-surface flex">
      <Sidebar active="video-lessons" onNavigate={onNavigate} dark={dark} onToggleDark={onToggleDark} />

      <div className="flex-1 min-w-0 pb-20 lg:pb-0">
        {/* Top bar (mobile) */}
        <div className="lg:hidden sticky top-0 z-40 glass-strong border-b border-subtle px-5 h-14 flex items-center justify-between">
          <button onClick={() => onNavigate('landing')} className="flex items-center gap-2">
            <span className="w-7 h-7 gradient-brand rounded-full flex items-center justify-center">
              <span className="w-2 h-2 bg-white rounded-full" />
            </span>
            <span className="font-bold text-primary">Nursify</span>
          </button>
          <button
            onClick={onToggleDark}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-secondary hover:text-primary hover:bg-ink-100 dark:hover:bg-ink-800 transition-colors"
          >
            {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>
        </div>

        <main className="max-w-6xl mx-auto px-5 sm:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
          {/* Header */}
          <div className="animate-slide-up">
            <div className="flex items-center gap-2 text-sm text-secondary font-medium">
              <PlayCircle className="w-4 h-4 text-violet-500" />
              Video Lessons
            </div>
            <h1 className="mt-1 text-2xl sm:text-3xl font-extrabold text-primary">
              Replay Lessons, {firstName}
            </h1>
            <p className="mt-1 text-sm text-secondary">
              Browse and watch recorded lessons anytime, at your own pace.
            </p>
          </div>

          {/* Search + filters */}
          <div className="animate-slide-up animate-delay-100 flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search lessons..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-subtle bg-elevated text-primary text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-400 transition-all"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
              {SUBJECT_FILTERS.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setSubjectFilter(f.id)}
                  className={`px-3.5 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
                    subjectFilter === f.id
                      ? 'gradient-brand text-white shadow-lift'
                      : 'border border-subtle text-secondary hover:text-primary hover:border-violet-300 bg-elevated'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Content */}
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="space-y-3">
                  <Skeleton className="h-44 rounded-2xl" />
                  <Skeleton className="h-5 rounded-lg w-3/4" />
                  <Skeleton className="h-4 rounded-lg w-1/2" />
                </div>
              ))}
            </div>
          ) : filteredVideos.length === 0 ? (
            <div className="animate-slide-up animate-delay-100">
              <div className="relative overflow-hidden rounded-3xl border border-subtle bg-elevated p-10 sm:p-16 text-center">
                <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-violet-100 dark:bg-violet-950/30 blur-3xl" />
                <div className="relative">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl gradient-brand-soft mb-5">
                    <PlayCircle className="w-8 h-8 text-violet-600 dark:text-violet-400" />
                  </div>
                  <h2 className="text-xl font-bold text-primary">No video lessons yet</h2>
                  <p className="mt-2 text-secondary text-sm max-w-md mx-auto">
                    Video lessons will appear here once they're added. Check back soon!
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-8">
              {groupedVideos.map((group) => (
                <div key={group.label} className="animate-slide-up animate-delay-100">
                  <p className="text-xs font-semibold text-ink-400 dark:text-ink-500 uppercase tracking-wider mb-4">
                    {group.label}
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                    {group.videos.map((video) => {
                      const color = SUBJECT_COLORS[video.subject] ?? '#3b82f6';
                      return (
                        <Card
                          key={video.id}
                          hover
                          className="overflow-hidden cursor-pointer group"
                          onClick={() => openVideo(video.youtube_url)}
                        >
                          {/* Thumbnail */}
                          <div className="relative h-44 overflow-hidden bg-ink-100 dark:bg-ink-800">
                            <img
                              src={getYouTubeThumbnail(video.youtube_id)}
                              alt={video.title}
                              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                              loading="lazy"
                              onError={(e) => {
                                (e.target as HTMLImageElement).style.display = 'none';
                              }}
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-ink-950/60 to-transparent" />
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                              <div className="w-14 h-14 rounded-full gradient-brand flex items-center justify-center shadow-lift">
                                <Play className="w-6 h-6 text-white ml-0.5" fill="white" />
                              </div>
                            </div>
                            {/* Subject badge */}
                            <span
                              className="absolute top-3 left-3 px-2.5 py-1 rounded-lg text-xs font-semibold text-white backdrop-blur-sm"
                              style={{ backgroundColor: `${color}cc` }}
                            >
                              {SUBJECT_LABELS[video.subject] ?? video.subject}
                            </span>
                          </div>
                          {/* Info */}
                          <div className="p-4">
                            <h3 className="font-bold text-primary text-sm line-clamp-2 leading-snug">
                              {video.title}
                            </h3>
                            <div className="mt-2 flex items-center justify-between">
                              <div className="flex items-center gap-1.5 text-xs text-secondary">
                                <Calendar className="w-3.5 h-3.5" />
                                {formatDate(video.lesson_date)}
                              </div>
                              <span className="inline-flex items-center gap-1 text-xs font-semibold text-violet-600 dark:text-violet-400">
                                <ExternalLink className="w-3 h-3" />
                                Watch on YouTube
                              </span>
                            </div>
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>

      <MobileNav active="video-lessons" onNavigate={onNavigate} />
    </div>
  );
}
