import { useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight, RotateCcw, Target, ListChecks } from 'lucide-react';
import type { View, QuizResult } from '@/types';
import type { Question } from '@/types';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import { BarChart as BarChartSvg } from '@/components/ui/Charts';

interface ResultsProps {
  onNavigate: (view: View) => void;
  onRetry: () => void;
  results: (QuizResult | null)[];
  questions: Question[];
  onStartQuestions?: (ids: string[]) => void;
  onStartSubject?: (subjectId: string) => void;
}

const accentBg: Record<string, string> = {
  violet: 'bg-violet-50 dark:bg-violet-950/40 text-violet-600 dark:text-violet-400',
  rose: 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400',
  amber: 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400',
  mint: 'bg-mint-50 dark:bg-mint-950/40 text-mint-600 dark:text-mint-400',
};

export default function Results({ onNavigate, onRetry, results, questions, onStartQuestions, onStartSubject }: ResultsProps) {
  const answered = results.filter((r) => r !== null && r !== undefined) as QuizResult[];
  const correct = answered.filter((r) => r.isCorrect).length;
  const incorrect = answered.filter((r) => !r.isCorrect).length;
  const unanswered = results.length - answered.length;
  const timeSpent = answered.reduce((sum, result) => sum + result.timeSpentSeconds, 0);
  const score = answered.length ? Math.round((correct / answered.length) * 100) : 0;
  const isHigh = score >= 80;

  const [displayScore, setDisplayScore] = useState(0);
  useEffect(() => {
    const dur = 1200;
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplayScore(Math.round(score * eased));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [score]);

  const ringSize = 200;
  const stroke = 14;
  const radius = (ringSize - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  // Subject breakdown
  const subjectGroups = new Map<string, { subjectId: string; label: string; answered: number; correct: number }>();
  for (const result of answered) {
    const question = questions.find((item) => item.id === result.questionId);
    if (!question) continue;
    const group = subjectGroups.get(question.subjectId) ?? { subjectId: question.subjectId, label: question.subjectName, answered: 0, correct: 0 };
    group.answered += 1;
    if (result.isCorrect) group.correct += 1;
    subjectGroups.set(question.subjectId, group);
  }
  const subjectPerformance = [...subjectGroups.values()].map((group) => ({ ...group, accuracy: Math.round((group.correct / group.answered) * 100) }));
  const subjectBreakdown = subjectPerformance.map((group) => ({ label: group.label, value: group.answered, secondary: group.correct, color: '#8b5cf6' }));
  const bestSubject = [...subjectPerformance].sort((a, b) => b.accuracy - a.accuracy)[0];
  const weakestSubject = [...subjectPerformance].sort((a, b) => a.accuracy - b.accuracy)[0];

  const verdict = isHigh ? 'Strong performance' : score >= 60 ? 'Almost there' : "Here's where we can improve";

  return (
    <div className="min-h-screen bg-surface">
      <header className="sticky top-0 z-40 glass-strong border-b border-subtle">
        <div className="max-w-4xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2 text-sm font-medium text-secondary hover:text-primary transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </button>
          <span className="font-bold text-primary">Results</span>
          <div className="w-16" />
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-5 sm:px-8 py-8 sm:py-12 space-y-8">
        {/* Score centerpiece */}
        <div className="relative flex flex-col items-center text-center animate-scale-in">
          {/* Subtle celebration particles */}
          {isHigh && (
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              {Array.from({ length: 12 }).map((_, i) => (
                <span
                  key={i}
                  className="absolute w-1.5 h-1.5 rounded-full bg-violet-400"
                  style={{
                    left: `${50 + Math.cos((i / 12) * 2 * Math.PI) * 40}%`,
                    top: `${50 + Math.sin((i / 12) * 2 * Math.PI) * 40}%`,
                    animation: `float ${4 + (i % 3)}s ease-in-out ${i * 0.15}s infinite`,
                  }}
                />
              ))}
            </div>
          )}

          <div className="relative">
            <svg width={ringSize} height={ringSize} className="-rotate-90">
              <circle cx={ringSize / 2} cy={ringSize / 2} r={radius} fill="none" strokeWidth={stroke} className="stroke-ink-100 dark:stroke-ink-800" />
              <circle
                cx={ringSize / 2}
                cy={ringSize / 2}
                r={radius}
                fill="none"
                strokeWidth={stroke}
                stroke={isHigh ? '#10b981' : '#f43f5e'}
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={offset}
                style={{ transition: 'stroke-dashoffset 1.2s cubic-bezier(0.16,1,0.3,1)' }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl font-extrabold text-primary tabular-nums">{displayScore}<span className="text-2xl text-secondary">%</span></span>
              <span className="text-sm font-medium text-secondary mt-1">{verdict}</span>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3 w-full max-w-xl">
            <div className="p-4 rounded-2xl bg-mint-50 dark:bg-mint-950/30 border border-mint-100 dark:border-mint-900">
              <p className="text-2xl font-extrabold text-mint-600 dark:text-mint-400">{correct}</p>
              <p className="text-xs font-medium text-secondary">Correct</p>
            </div>
            <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-900">
              <p className="text-2xl font-extrabold text-rose-600 dark:text-rose-400">{incorrect}</p>
              <p className="text-xs font-medium text-secondary">Incorrect</p>
            </div>
            <div className="p-4 rounded-2xl bg-ink-50 dark:bg-ink-900/40 border border-subtle">
              <p className="text-2xl font-extrabold text-secondary">{Math.floor(timeSpent / 60)}:{String(timeSpent % 60).padStart(2, '0')}</p>
              <p className="text-xs font-medium text-secondary">Time spent</p>
            </div>
            <div className="p-4 rounded-2xl bg-ink-50 dark:bg-ink-900/40 border border-subtle">
              <p className="text-2xl font-extrabold text-secondary">{unanswered}</p>
              <p className="text-xs font-medium text-secondary">Unanswered</p>
            </div>
          </div>

          {!isHigh && (
            <p className="mt-5 text-sm text-secondary max-w-sm">
              Every missed question is a map to your next win. Let's turn these into strengths.
            </p>
          )}
        </div>

        {/* Performance breakdown */}
        <Card className="p-6 animate-slide-up">
          <h3 className="text-lg font-bold text-primary">Performance Breakdown</h3>
          <p className="text-sm text-secondary mt-0.5">Correct vs. answered by subject</p>
          <div className="mt-5">
            <BarChartSvg data={subjectBreakdown} height={200} color="#8b5cf6" secondaryColor="#c4b5fd" />
            <div className="mt-3 flex items-center justify-center gap-5 text-xs">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-violet-500" />Answered</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-violet-300" />Correct</span>
            </div>
          </div>
        </Card>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 animate-slide-up animate-delay-100">
          <Card className="p-5"><p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wide">Best subject</p><p className="text-lg font-bold text-primary mt-1">{bestSubject?.label ?? 'Not enough data'}</p><p className="text-2xl font-extrabold text-mint-600 dark:text-mint-400 mt-2">{bestSubject ? `${bestSubject.accuracy}%` : '—'}</p></Card>
          <Card className="p-5"><p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wide">Needs more practice</p><p className="text-lg font-bold text-primary mt-1">{weakestSubject?.label ?? 'Not enough data'}</p><p className="text-2xl font-extrabold text-rose-600 dark:text-rose-400 mt-2">{weakestSubject ? `${weakestSubject.accuracy}%` : '—'}</p></Card>
        </div>

        <div className="animate-slide-up animate-delay-100">
          <h3 className="text-lg font-bold text-primary mb-4">Your Next Moves</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[{ icon: ListChecks, title: 'Review Incorrect Answers', detail: `${incorrect} question${incorrect === 1 ? '' : 's'} to revisit`, accent: 'amber' }, { icon: Target, title: 'Practice Weak Areas', detail: weakestSubject ? `${weakestSubject.label} · ${weakestSubject.accuracy}% accuracy` : 'Keep practicing to build a focus area', accent: 'rose' }].map((a, i) => {
              const Icon = a.icon;
              return (
                <button
                  key={i}
                  onClick={() => { if (i === 0) onStartQuestions?.(answered.filter((result) => !result.isCorrect).map((result) => result.questionId)); else if (weakestSubject) onStartSubject?.(weakestSubject.subjectId); else onNavigate('quiz'); }}
                  className="group flex items-center gap-4 p-4 bg-elevated border border-subtle rounded-2xl card-hover hover:shadow-card hover:border-violet-200 dark:hover:border-violet-800 text-left"
                >
                  <span className="shrink-0 text-lg font-extrabold text-violet-300 dark:text-violet-700 w-7">
                    {i + 1}
                  </span>
                  <span className={`shrink-0 w-10 h-10 rounded-xl flex items-center justify-center ${accentBg[a.accent]}`}>
                    <Icon className="w-5 h-5" />
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-primary">{a.title}</p>
                    <p className="text-xs text-secondary mt-0.5">{a.detail}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-secondary group-hover:text-violet-500 group-hover:translate-x-0.5 transition-all shrink-0" />
                </button>
              );
            })}
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap justify-center gap-3 animate-slide-up animate-delay-200">
          <Button variant="secondary" onClick={onRetry}>
            <RotateCcw className="w-4 h-4" /> Retry Quiz
          </Button>
          <Button withArrow onClick={() => onNavigate('analytics')}>
            View Analytics
          </Button>
        </div>
      </main>
    </div>
  );
}
