export type View =
  | 'landing'
  | 'login'
  | 'signup'
  | 'forgot-password'
  | 'reset-password'
  | 'dashboard'
  | 'quiz'
  | 'results'
  | 'analytics'
  | 'pricing'
  | 'profile'
  | 'bookmarks'
  | 'study-plan'
  | 'video-lessons'
  | 'leaderboard'
  | 'pnle'
  | 'pnle-study-guide'
  | 'pnle-study-guide-subject'
  | 'nclex'
  | 'nclex-study-guide'
  | 'nclex-study-guide-subject'
  | 'study-history'
  | 'weak-areas'
  | 'admin'
  | 'admin-login'
  | 'payment-success';

export type ExamTrack = 'pnle' | 'nclex';

export type SubjectId =
  | 'pharmacology'
  | 'medsurg'
  | 'pediatrics'
  | 'mentalhealth'
  | 'ob'
  | 'fundamentals';

export type QuestionType =
  | 'multiple-choice'
  | 'select-all-that-apply'
  | 'ordered-response'
  | 'hot-spot'
  | 'ngn-case-study';

export type Difficulty = 'easy' | 'medium' | 'hard' | 'mixed';

export type TestMode =
  | 'readiness-assessment'
  | 'cat-simulation'
  | 'test-day-mode'
  | 'practice-test';

export interface Subject {
  id: SubjectId;
  name: string;
  shortName: string;
  mastery: number;
  questionsCompleted: number;
  questionsTotal: number;
  accuracy: number;
  recentScore: number;
  status: 'needs-attention' | 'progressing' | 'strong';
  accent: string;
  icon: string;
}

export interface QuestionOption {
  id: string;
  label: string;
}

export interface Question {
  id: string;
  subjectId: SubjectId;
  subjectName: string;
  category: string;
  topic: string;
  difficulty: Difficulty;
  questionType: QuestionType;
  prompt: string;
  options: QuestionOption[];
  correctAnswer: string[];
  rationale: string;
  optionRationales: Record<string, string>;
  keyTakeaway: string;
  nclexTip: string;
  clinicalPearl: string;
  reference: string;
  tags: string[];
  isNgn: boolean;
  caseStudy?: string;
  patientData?: Record<string, unknown>;
}

export interface QuizResult {
  questionId: string;
  selectedOptionIds: string[];
  isCorrect: boolean;
  bookmarked: boolean;
  timeSpentSeconds: number;
}

export interface TestConfig {
  mode: TestMode;
  categories: string[];
  questionTypes: QuestionType[];
  difficulty: Difficulty;
  questionCount: number;
  ngnOnly: boolean;
  unusedFirst: boolean;
  randomize: boolean;
  subjectId?: SubjectId;
}

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  variant: 'success' | 'info' | 'warning' | 'error';
}

export interface QuizAttempt {
  id: string;
  test_config: TestConfig;
  total_questions: number;
  correct_count: number;
  incorrect_count: number;
  unanswered_count: number;
  score: number;
  time_spent_seconds: number;
  completed: boolean;
  created_at: string;
  completed_at: string | null;
}

export interface QuestionAnswer {
  id: string;
  attempt_id: string;
  question_id: string;
  subject_id: string;
  selected_option_ids: string[];
  is_correct: boolean;
  bookmarked: boolean;
  time_spent_seconds: number;
  created_at: string;
}
