export interface PricingPlan {
  id: 'free' | 'premium';
  name: string;
  description: string;
  features: string[];
  highlighted?: boolean;
  cta: string;
}

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'free',
    name: 'Free',
    description: 'Get started with basic PNLE & NCLEX prep.',
    features: [
      'Limited questions (10 per test)',
      'Basic progress tracking',
      'Instant rationales',
      '1 practice test per day',
    ],
    cta: 'Current Plan',
  },
  {
    id: 'premium',
    name: 'Premium',
    description: 'Everything you need to pass the PNLE and NCLEX.',
    features: [
      'Full QBank access (12,000+ questions)',
      'Unlimited practice tests',
      'Detailed rationales for every answer',
      'NGN case study questions',
      'CAT Simulation',
      'Advanced analytics & trends',
      'Weak area tracking & targeting',
    ],
    highlighted: true,
    cta: 'Get Premium',
  },
];

export const FREE_QUESTION_LIMIT = 10;
export const FREE_DAILY_TEST_LIMIT = 1;

// === Premium access instructions ===
// These are easy to change later — just update the values below.
export const PREMIUM_INSTRUCTION_IMAGE =
  'https://res.cloudinary.com/s6regtbs/image/upload/f_auto,q_auto/Screenshot_2026-08-19_162946';
export const PREMIUM_INSTRUCTION_TEXT =
  'Message our official Facebook page to get Premium access.';
export const PREMIUM_FACEBOOK_URL = 'https://www.facebook.com/rypolletevargasrn';
