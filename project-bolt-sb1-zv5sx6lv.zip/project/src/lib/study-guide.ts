import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { useState, useEffect, useCallback } from 'react';
import type { ExamTrack } from '@/types';

export interface StudyGuideSubject {
  id: string;
  name: string;
  slug: string;
  description: string;
  accent_color: string;
  icon: string;
  sort_order: number;
  topic_count: number;
}

export interface StudyGuideTopic {
  id: string;
  subject_id: string;
  title: string;
  description: string;
  key_concepts: string[];
  nursing_considerations: string[];
  sort_order: number;
  studied: boolean;
}

export async function fetchStudyGuideSubjects(examTrack: ExamTrack): Promise<StudyGuideSubject[]> {
  const { data, error } = await supabase
    .from('study_guide_subjects')
    .select('id, name, slug, description, accent_color, icon, sort_order')
    .eq('exam_track', examTrack)
    .order('sort_order', { ascending: true });

  if (error || !data) return [];

  const subjects = data as Omit<StudyGuideSubject, 'topic_count'>[];

  const { data: topicCounts } = await supabase
    .from('study_guide_topics')
    .select('subject_id');

  const countMap: Record<string, number> = {};
  if (topicCounts) {
    for (const row of topicCounts as { subject_id: string }[]) {
      countMap[row.subject_id] = (countMap[row.subject_id] ?? 0) + 1;
    }
  }

  return subjects.map((s) => ({ ...s, topic_count: countMap[s.id] ?? 0 }));
}

export async function fetchStudyGuideTopics(subjectId: string): Promise<StudyGuideTopic[]> {
  const { data, error } = await supabase
    .from('study_guide_topics')
    .select('id, subject_id, title, description, key_concepts, nursing_considerations, sort_order')
    .eq('subject_id', subjectId)
    .order('sort_order', { ascending: true });

  if (error || !data) return [];

  return data as Omit<StudyGuideTopic, 'studied'>[];
}

export async function fetchStudyProgress(topicIds: string[]): Promise<Set<string>> {
  if (topicIds.length === 0) return new Set();
  const { data, error } = await supabase
    .from('study_guide_progress')
    .select('topic_id')
    .in('topic_id', topicIds)
    .eq('studied', true);

  if (error || !data) return new Set();
  return new Set((data as { topic_id: string }[]).map((r) => r.topic_id));
}

export async function toggleTopicStudied(topicId: string, studied: boolean): Promise<void> {
  if (studied) {
    const { error } = await supabase
      .from('study_guide_progress')
      .upsert(
        { topic_id: topicId, studied: true, studied_at: new Date().toISOString() },
        { onConflict: 'user_id,topic_id,exam_track' },
      );
    if (error) console.error('Error marking topic studied:', error);
  } else {
    const { error } = await supabase
      .from('study_guide_progress')
      .upsert(
        { topic_id: topicId, studied: false, studied_at: null },
        { onConflict: 'user_id,topic_id,exam_track' },
      );
    if (error) console.error('Error unmarking topic:', error);
  }
}

export async function fetchAllProgress(examTrack: ExamTrack): Promise<Record<string, { total: number; studied: number }>> {
  const { data: subjects } = await supabase
    .from('study_guide_subjects')
    .select('id')
    .eq('exam_track', examTrack);

  if (!subjects || subjects.length === 0) return {};

  const subjectIds = (subjects as { id: string }[]).map((s) => s.id);

  const { data: topics } = await supabase
    .from('study_guide_topics')
    .select('id, subject_id')
    .in('subject_id', subjectIds);

  const { data: progress } = await supabase
    .from('study_guide_progress')
    .select('topic_id, studied')
    .eq('studied', true)
    .eq('exam_track', examTrack);

  if (!topics) return {};

  const subjectTotals: Record<string, number> = {};
  for (const t of topics as { id: string; subject_id: string }[]) {
    subjectTotals[t.subject_id] = (subjectTotals[t.subject_id] ?? 0) + 1;
  }

  const studiedIds = new Set((progress ?? []).map((p: { topic_id: string }) => p.topic_id));
  const subjectStudied: Record<string, number> = {};
  for (const t of topics as { id: string; subject_id: string }[]) {
    if (studiedIds.has(t.id)) {
      subjectStudied[t.subject_id] = (subjectStudied[t.subject_id] ?? 0) + 1;
    }
  }

  const result: Record<string, { total: number; studied: number }> = {};
  for (const sid of Object.keys(subjectTotals)) {
    result[sid] = { total: subjectTotals[sid], studied: subjectStudied[sid] ?? 0 };
  }
  return result;
}

export function useStudyGuideSubjects(examTrack: ExamTrack) {
  const [subjects, setSubjects] = useState<StudyGuideSubject[]>([]);
  const [progress, setProgress] = useState<Record<string, { total: number; studied: number }>>({});
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const [subs, prog] = await Promise.all([fetchStudyGuideSubjects(examTrack), fetchAllProgress(examTrack)]);
    setSubjects(subs);
    setProgress(prog);
    setLoading(false);
  }, [examTrack]);

  useEffect(() => {
    load();
    const channel = supabase
      .channel('study-guide-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'study_guide_topics' }, () => load())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'study_guide_progress' }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [load]);

  return { subjects, progress, loading, reload: load };
}

export function useStudyGuideTopics(subjectId: string) {
  const { user } = useAuth();
  const [topics, setTopics] = useState<StudyGuideTopic[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const fetched = await fetchStudyGuideTopics(subjectId);
    if (fetched.length === 0) {
      setTopics([]);
      setLoading(false);
      return;
    }
    const studiedIds = user ? await fetchStudyProgress(fetched.map((t) => t.id)) : new Set<string>();
    setTopics(fetched.map((t) => ({ ...t, studied: studiedIds.has(t.id) })));
    setLoading(false);
  }, [subjectId, user?.id]);

  useEffect(() => {
    load();
    const channel = supabase
      .channel(`study-topics-${subjectId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'study_guide_topics', filter: `subject_id=eq.${subjectId}` }, () => load())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'study_guide_progress' }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [load, subjectId]);

  const toggleStudied = useCallback(async (topicId: string, studied: boolean) => {
    setTopics((prev) => prev.map((t) => (t.id === topicId ? { ...t, studied } : t)));
    await toggleTopicStudied(topicId, studied);
  }, []);

  return { topics, loading, toggleStudied, reload: load };
}
