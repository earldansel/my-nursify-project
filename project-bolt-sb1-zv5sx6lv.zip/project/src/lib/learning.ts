import { supabase } from '@/lib/supabase';
import type { Question, QuestionAnswer } from '@/types';
import { fetchQuestionsByIds, fetchAllAnswers } from '@/lib/questions';

export interface ReviewQuestion {
  question: Question;
  status: 'incorrect' | 'review' | 'mastered';
  answeredAt: string;
}

export interface WeakSpot {
  key: string;
  subjectId: string;
  subjectName: string;
  topic?: string;
  answered: number;
  correct: number;
  accuracy: number;
}

export interface DailyChallenge {
  id: string;
  challengeDate: string;
  questionIds: string[];
  completed: boolean;
}

export interface Achievement {
  key: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt: string | null;
}

export const ACHIEVEMENTS: Omit<Achievement, 'unlockedAt'>[] = [
  { key: 'first_steps', title: 'First Steps', description: 'Complete your first practice session', icon: 'flag' },
  { key: 'on_fire', title: 'On Fire', description: 'Build a 7-day study streak', icon: 'flame' },
  { key: 'sharp_shooter', title: 'Sharp Shooter', description: 'Score 90% or higher in a completed test', icon: 'target' },
  { key: 'century', title: 'Century', description: 'Answer 100 questions', icon: 'trophy' },
  { key: 'pharma_master', title: 'Pharma Master', description: 'Reach 85% Pharmacology accuracy', icon: 'brain' },
];

function groupLatestAnswers(answers: QuestionAnswer[]): Map<string, QuestionAnswer> {
  const latest = new Map<string, QuestionAnswer>();
  for (const answer of answers) {
    if (!latest.has(answer.question_id)) latest.set(answer.question_id, answer);
  }
  return latest;
}

export async function getSmartReview(): Promise<ReviewQuestion[]> {
  const answers = await fetchAllAnswers();
  const latest = groupLatestAnswers(answers);
  const questions = await fetchQuestionsByIds([...latest.keys()]);
  const questionMap = new Map(questions.map((question) => [question.id, question]));
  return [...latest.entries()]
    .map(([questionId, answer]) => {
      const question = questionMap.get(questionId);
      if (!question) return null;
      return {
        question,
        status: answer.is_correct ? 'mastered' : 'incorrect',
        answeredAt: answer.created_at,
      } as ReviewQuestion;
    })
    .filter((item): item is ReviewQuestion => Boolean(item));
}

export async function getWeakSpots(): Promise<WeakSpot[]> {
  const answers = await fetchAllAnswers();
  const questions = await fetchQuestionsByIds([...new Set(answers.map((answer) => answer.question_id))]);
  const questionMap = new Map(questions.map((question) => [question.id, question]));
  const groups = new Map<string, WeakSpot>();

  for (const answer of answers) {
    const question = questionMap.get(answer.question_id);
    const subjectId = question?.subjectId ?? answer.subject_id;
    const subjectName = question?.subjectName ?? subjectId;
    const topic = question?.topic || undefined;
    const key = `${subjectId}:${topic ?? 'subject'}`;
    const current = groups.get(key) ?? { key, subjectId, subjectName, topic, answered: 0, correct: 0, accuracy: 0 };
    current.answered += 1;
    if (answer.is_correct) current.correct += 1;
    current.accuracy = Math.round((current.correct / current.answered) * 100);
    groups.set(key, current);
  }

  return [...groups.values()]
    .filter((spot) => spot.answered >= 3)
    .sort((a, b) => a.accuracy - b.accuracy || b.answered - a.answered);
}

export async function getDailyChallenge(): Promise<DailyChallenge | null> {
  const { data, error } = await supabase.rpc('get_or_create_daily_challenge');
  if (error || !data?.[0]) return null;
  const row = data[0] as { id: string; challenge_date: string; question_ids: string[]; completed: boolean };
  return {
    id: row.id,
    challengeDate: row.challenge_date,
    questionIds: Array.isArray(row.question_ids) ? row.question_ids : [],
    completed: row.completed,
  };
}

export async function completeDailyChallenge(id: string): Promise<boolean> {
  const { data, error } = await supabase.rpc('complete_daily_challenge', { p_challenge_id: id });
  if (error) return false;
  if (data) await supabase.rpc('award_learning_event', { p_event_key: `daily:${id}`, p_event_type: 'daily_challenge' });
  return Boolean(data);
}

export async function getLearningProgress(): Promise<{
  xp: number;
  activity: { activity_date: string; questions_answered: number; challenge_completed: boolean }[];
  achievements: Achievement[];
}> {
  const [xpResult, activityResult, achievementResult] = await Promise.all([
    supabase.from('user_xp').select('total_xp').maybeSingle(),
    supabase.from('learning_activity').select('activity_date, questions_answered, challenge_completed').order('activity_date', { ascending: false }).limit(90),
    supabase.from('user_achievements').select('achievement_key, unlocked_at'),
  ]);
  const unlocked = new Map((achievementResult.data ?? []).map((row) => [row.achievement_key, row.unlocked_at]));
  return {
    xp: xpResult.data?.total_xp ?? 0,
    activity: (activityResult.data ?? []) as { activity_date: string; questions_answered: number; challenge_completed: boolean }[],
    achievements: ACHIEVEMENTS.map((achievement) => ({ ...achievement, unlockedAt: unlocked.get(achievement.key) ?? null })),
  };
}

export async function syncAchievements(): Promise<void> {
  await supabase.rpc('sync_learning_achievements');
}

export function getLevel(xp: number): { level: number; title: string; current: number; next: number } {
  const level = Math.max(1, Math.floor(xp / 100) + 1);
  const title = level <= 5 ? 'Nursing Student' : level <= 10 ? 'NCLEX Challenger' : level <= 20 ? 'NCLEX Achiever' : 'NCLEX Ready';
  return { level, title, current: xp % 100, next: 100 };
}

export function getStreak(activity: { activity_date: string }[]): { current: number; longest: number; activeDays: number } {
  const days = [...new Set(activity.map((row) => row.activity_date))].sort();
  let longest = 0;
  let run = 0;
  let previous = '';
  for (const day of days) {
    const date = new Date(`${day}T00:00:00Z`);
    const prior = previous ? new Date(`${previous}T00:00:00Z`) : null;
    if (prior && date.getTime() - prior.getTime() === 86_400_000) run += 1;
    else run = 1;
    longest = Math.max(longest, run);
    previous = day;
  }
  const today = new Date();
  const todayKey = today.toISOString().slice(0, 10);
  const yesterday = new Date(today.getTime() - 86_400_000).toISOString().slice(0, 10);
  const current = days.includes(todayKey) || days.includes(yesterday) ? run : 0;
  return { current, longest, activeDays: days.length };
}
