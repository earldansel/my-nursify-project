import { supabase } from '@/lib/supabase';
import type { Question, TestConfig, QuizAttempt, QuestionAnswer, SubjectId } from '@/types';

const NCLEX_CATEGORIES = [
  'Management of Care',
  'Safety & Infection Control',
  'Health Promotion & Maintenance',
  'Psychosocial Integrity',
  'Basic Care & Comfort',
  'Pharmacological & Parenteral Therapies',
  'Reduction of Risk Potential',
  'Physiological Adaptation',
] as const;

export const QUESTION_TYPES = [
  { id: 'multiple-choice', label: 'Multiple Choice' },
  { id: 'select-all-that-apply', label: 'Select All That Apply' },
  { id: 'ordered-response', label: 'Ordered Response' },
  { id: 'hot-spot', label: 'Hot Spot' },
  { id: 'ngn-case-study', label: 'NGN Case Study' },
] as const;

export const TEST_MODES = [
  {
    id: 'readiness-assessment',
    label: 'Readiness Assessment',
    description: 'A comprehensive 75-question exam to gauge your readiness for the NCLEX.',
    icon: 'Target',
  },
  {
    id: 'cat-simulation',
    label: 'CAT Simulation',
    description: 'Computer Adaptive Test that adjusts difficulty based on your performance.',
    icon: 'Brain',
  },
  {
    id: 'test-day-mode',
    label: 'Test-Day Mode',
    description: 'Simulate the real NCLEX environment with timed conditions and no rationales.',
    icon: 'Clock',
  },
  {
    id: 'practice-test',
    label: 'Practice Test',
    description: 'A flexible test with instant feedback and rationales after each question.',
    icon: 'BookOpen',
  },
] as const;

export const QUESTION_COUNTS = [10, 20, 30, 50, 75, 100];

export const DIFFICULTIES = [
  { id: 'easy', label: 'Easy' },
  { id: 'medium', label: 'Medium' },
  { id: 'hard', label: 'Hard' },
  { id: 'mixed', label: 'Mixed' },
] as const;

export { NCLEX_CATEGORIES };

interface RawQuestionRow {
  id: string;
  question: string;
  subject_id: string;
  subject_name: string;
  category: string;
  topic: string;
  difficulty: string;
  question_type: string;
  options: Question['options'] | string;
  correct_answer: string[] | string;
  rationale: string;
  option_rationales: Record<string, string> | string;
  key_takeaway: string;
  nclex_tip: string;
  clinical_pearl: string;
  reference: string;
  tags: string[];
  is_ngn: boolean;
  case_study: string | null;
  patient_data: Record<string, unknown> | null;
}

function mapRow(row: RawQuestionRow): Question {
  const options =
    typeof row.options === 'string' ? JSON.parse(row.options) : row.options;
  const correctAnswer =
    typeof row.correct_answer === 'string'
      ? JSON.parse(row.correct_answer)
      : row.correct_answer;
  const optionRationales =
    typeof row.option_rationales === 'string'
      ? JSON.parse(row.option_rationales)
      : row.option_rationales;

  return {
    id: row.id,
    subjectId: row.subject_id as SubjectId,
    subjectName: row.subject_name,
    category: row.category,
    topic: row.topic,
    difficulty: (row.difficulty || 'medium') as Question['difficulty'],
    questionType: (row.question_type || 'multiple-choice') as Question['questionType'],
    prompt: row.question,
    options,
    correctAnswer,
    rationale: row.rationale,
    optionRationales,
    keyTakeaway: row.key_takeaway,
    nclexTip: row.nclex_tip,
    clinicalPearl: row.clinical_pearl,
    reference: row.reference,
    tags: row.tags ?? [],
    isNgn: row.is_ngn ?? false,
    caseStudy: row.case_study ?? undefined,
    patientData: row.patient_data ?? undefined,
  };
}

export async function getTotalQuestionCount(): Promise<number> {
  const assignedIds = await getAssignedQuestionIds();
  if (assignedIds !== null) return assignedIds.length;

  const { count, error } = await supabase
    .from('questions')
    .select('*', { count: 'exact', head: true });
  if (error) throw new Error(`Failed to count questions: ${error.message}`);
  return count ?? 0;
}

export async function getCategoryCounts(): Promise<Record<string, number>> {
  const { data, error } = await supabase.rpc('get_category_question_counts');
  if (error || !data) {
    console.error('Error fetching category counts:', error);
    return {};
  }
  const counts: Record<string, number> = {};
  for (const row of data as { category: string; total: number }[]) {
    counts[row.category] = row.total;
  }
  return counts;
}

export async function getSubjectNameCounts(): Promise<Record<string, number>> {
  const { data, error } = await supabase.rpc('get_subject_name_question_counts');
  if (error || !data) {
    console.error('Error fetching subject name counts:', error);
    return {};
  }
  const counts: Record<string, number> = {};
  for (const row of data as { subject_name: string; total: number }[]) {
    counts[row.subject_name] = row.total;
  }
  return counts;
}

export async function getPreviouslyAnsweredIds(): Promise<Set<string>> {
  const { data, error } = await supabase
    .from('question_answers')
    .select('question_id');
  if (error || !data) return new Set();
  return new Set((data as { question_id: string }[]).map((r) => r.question_id));
}

export async function getIncorrectQuestionIds(): Promise<Set<string>> {
  const { data, error } = await supabase
    .from('question_answers')
    .select('question_id')
    .eq('is_correct', false);
  if (error || !data) return new Set();
  return new Set((data as { question_id: string }[]).map((r) => r.question_id));
}

async function getAssignedQuestionIds(): Promise<string[] | null> {
  const { data: user } = await supabase.auth.getUser();
  if (!user.user) return null;

  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.user.id)
    .maybeSingle();

  if (profileError || !profile || profile.role !== 'free') return null;

  const { data, error } = await supabase.rpc('get_free_user_question_ids');
  if (error || !data) return null;

  const assignedIds = (data as { question_id: string }[])
    .map((row) => row.question_id)
    .filter((id): id is string => typeof id === 'string' && id.length > 0);

  return assignedIds.length > 0 ? assignedIds : null;
}

export async function fetchQuestionsByIds(ids: string[]): Promise<Question[]> {
  if (ids.length === 0) return [];
  const { data, error } = await supabase.from('questions').select('*').in('id', ids);
  if (error || !data) {
    console.error('Error fetching question references:', error);
    return [];
  }
  const questionMap = new Map((data as RawQuestionRow[]).map((row) => [row.id, mapRow(row)]));
  return ids.map((id) => questionMap.get(id)).filter((question): question is Question => Boolean(question));
}

export async function fetchQuestions(config: TestConfig): Promise<Question[]> {
  const assignedIds = await getAssignedQuestionIds();

  let query = supabase.from('questions').select('*');

  if (assignedIds !== null) {
    query = query.in('id', assignedIds);
  }

  if (config.subjectId) {
    query = query.eq('subject_id', config.subjectId);
  }

  if (config.ngnOnly) {
    query = query.eq('is_ngn', true);
  }

  if (config.categories.length > 0 && config.categories.length < NCLEX_CATEGORIES.length) {
    query = query.in('subject_name', config.categories);
  }

  if (config.questionTypes.length > 0 && config.questionTypes.length < QUESTION_TYPES.length) {
    query = query.in('question_type', config.questionTypes);
  }

  if (config.difficulty !== 'mixed') {
    query = query.eq('difficulty', config.difficulty);
  }

  query = query.limit(1000);

  const { data, error } = await query;
  if (error) {
    console.error('Error fetching questions:', error);
    throw new Error(`Failed to fetch questions: ${error.message}`);
  }
  if (!data) return [];

  let questions = (data as RawQuestionRow[]).map(mapRow);
  console.debug('[Practice] question availability', {
    liveDatabaseQuestions: data.length,
    matchingQuestions: questions.length,
    requestedQuestions: config.questionCount,
  });

  const answeredIds = await getPreviouslyAnsweredIds();
  const incorrectIds = await getIncorrectQuestionIds();

  if (config.unusedFirst) {
    const unused = questions.filter((q) => !answeredIds.has(q.id));
    const used = questions.filter((q) => answeredIds.has(q.id));
    const usedIncorrect = used.filter((q) => incorrectIds.has(q.id));
    const usedCorrect = used.filter((q) => !incorrectIds.has(q.id));
    questions = [...unused, ...usedIncorrect, ...usedCorrect];
  } else if (config.randomize) {
    questions = shuffle(questions);
  }

  return questions.slice(0, config.questionCount);
}

export async function fetchOneMoreLikeThis(
  currentQuestion: Question,
  excludeIds: string[],
): Promise<Question | null> {
  const assignedIds = await getAssignedQuestionIds();

  let query = supabase
    .from('questions')
    .select('*')
    .eq('subject_id', currentQuestion.subjectId)
    .eq('topic', currentQuestion.topic)
    .not('id', 'in', `(${excludeIds.join(',')})`)
    .limit(5);

  if (assignedIds !== null) {
    if (assignedIds.length === 0) return null;
    query = query.in('id', assignedIds);
  }

  const { data, error } = await query;
  if (error || !data || data.length === 0) {
    const fallback = await supabase
      .from('questions')
      .select('*')
      .eq('subject_id', currentQuestion.subjectId)
      .not('id', 'in', `(${excludeIds.join(',')})`)
      .limit(5);
    if (fallback.error || !fallback.data || fallback.data.length === 0) return null;
    const rows = (fallback.data as RawQuestionRow[]).map(mapRow);
    return shuffle(rows)[0] ?? null;
  }
  const rows = (data as RawQuestionRow[]).map(mapRow);
  return shuffle(rows)[0] ?? null;
}

export async function createQuizAttempt(config: TestConfig): Promise<string | null> {
  const { data, error } = await supabase
    .from('quiz_attempts')
    .insert({
      test_config: config,
      total_questions: config.questionCount,
      correct_count: 0,
      incorrect_count: 0,
      unanswered_count: config.questionCount,
      score: 0,
      time_spent_seconds: 0,
      completed: false,
    })
    .select('id')
    .maybeSingle();
  if (error) {
    console.error('Error creating quiz attempt:', error);
    return null;
  }
  return (data as { id: string } | null)?.id ?? null;
}

export async function saveAnswer(
  attemptId: string,
  questionId: string,
  selectedOptionIds: string[],
  isCorrect: boolean,
  timeSpentSeconds: number,
  subjectId: string,
): Promise<void> {
  const { data, error } = await supabase.from('question_answers').insert({
    attempt_id: attemptId,
    question_id: questionId,
    subject_id: subjectId,
    selected_option_ids: selectedOptionIds,
    is_correct: isCorrect,
    time_spent_seconds: timeSpentSeconds,
  }).select('id').maybeSingle();
  if (error) {
    console.error('Error saving answer:', error);
    return;
  }
  await supabase.rpc('record_learning_activity', { p_questions: 1 });
  if (isCorrect && data?.id) {
    await supabase.rpc('award_learning_event', { p_event_key: `answer:${data.id}`, p_event_type: 'correct_answer' });
  }
  await supabase.rpc('sync_learning_achievements');
}

export async function completeQuizAttempt(
  attemptId: string,
  correctCount: number,
  incorrectCount: number,
  unansweredCount: number,
  timeSpentSeconds: number,
): Promise<void> {
  const total = correctCount + incorrectCount + unansweredCount;
  const score = total > 0 ? Math.round((correctCount / total) * 100) : 0;
  const { error } = await supabase
    .from('quiz_attempts')
    .update({
      correct_count: correctCount,
      incorrect_count: incorrectCount,
      unanswered_count: unansweredCount,
      score,
      time_spent_seconds: timeSpentSeconds,
      completed: true,
      completed_at: new Date().toISOString(),
    })
    .eq('id', attemptId);
  if (error) {
    console.error('Error completing quiz attempt:', error);
    return;
  }
  await supabase.rpc('award_learning_event', { p_event_key: `attempt:${attemptId}`, p_event_type: 'practice_complete' });
  await supabase.rpc('sync_learning_achievements');
}

export async function fetchAttemptHistory(): Promise<QuizAttempt[]> {
  const { data, error } = await supabase
    .from('quiz_attempts')
    .select('*')
    .eq('completed', true)
    .order('completed_at', { ascending: false })
    .limit(20);
  if (error || !data) return [];
  return data as QuizAttempt[];
}

export async function fetchAllAnswers(): Promise<QuestionAnswer[]> {
  const { data, error } = await supabase
    .from('question_answers')
    .select('*')
    .order('created_at', { ascending: false });
  if (error || !data) return [];
  return data as QuestionAnswer[];
}

export async function toggleBookmarkDb(
  questionId: string,
  bookmarked: boolean,
  category = 'Important',
): Promise<void> {
  if (bookmarked) {
    const { data: existing } = await supabase
      .from('bookmarks')
      .select('id')
      .eq('question_id', questionId)
      .maybeSingle();
    if (!existing) {
      await supabase.from('bookmarks').insert({ question_id: questionId, category });
    }
  } else {
    await supabase.from('bookmarks').delete().eq('question_id', questionId);
  }
}

export async function updateBookmarkCategory(questionId: string, category: string): Promise<void> {
  await supabase.from('bookmarks').update({ category }).eq('question_id', questionId);
}

export async function fetchBookmarkedQuestionIds(): Promise<Set<string>> {
  const { data, error } = await supabase.from('bookmarks').select('question_id');
  if (error || !data) return new Set();
  return new Set((data as { question_id: string }[]).map((r) => r.question_id));
}

export async function saveNote(questionId: string, content: string): Promise<void> {
  const { data: existing } = await supabase
    .from('notes')
    .select('id')
    .eq('question_id', questionId)
    .maybeSingle();
  if (existing) {
    await supabase
      .from('notes')
      .update({ content, updated_at: new Date().toISOString() })
      .eq('question_id', questionId);
  } else {
    await supabase.from('notes').insert({ question_id: questionId, content });
  }
}

export async function fetchNote(questionId: string): Promise<string | null> {
  const { data, error } = await supabase
    .from('notes')
    .select('content')
    .eq('question_id', questionId)
    .maybeSingle();
  if (error || !data) return null;
  return (data as { content: string } | null)?.content ?? null;
}

export async function fetchSubjectStats(): Promise<
  { subjectId: SubjectId; total: number; answered: number; correct: number }[]
> {
  const [subjectRes, answerRes] = await Promise.all([
    supabase.rpc('get_subject_question_counts'),
    supabase.rpc('get_user_subject_answer_stats'),
  ]);

  if (subjectRes.error || !subjectRes.data) return [];

  const answerMap = new Map<string, { answered: number; correct: number }>();
  if (answerRes.data) {
    for (const row of answerRes.data as { subject_id: string; answered: number; correct: number }[]) {
      answerMap.set(row.subject_id, { answered: row.answered, correct: row.correct });
    }
  }

  return (subjectRes.data as { subject_id: string; total: number }[]).map((row) => {
    const a = answerMap.get(row.subject_id);
    return {
      subjectId: row.subject_id as SubjectId,
      total: row.total,
      answered: a?.answered ?? 0,
      correct: a?.correct ?? 0,
    };
  });
}

export async function getUserAnsweredCount(): Promise<number> {
  const { data, error } = await supabase.rpc('get_user_answered_count');
  if (error || !data) return 0;
  return data as number;
}

export async function getDashboardStats(): Promise<{
  totalAnswered: number;
  totalCorrect: number;
  accuracy: number;
  todayAnswered: number;
  todayCorrect: number;
  studyTimeSeconds: number;
  currentStreak: number;
  recentScore: number;
  overallMastery: number;
}> {
  const { data, error } = await supabase.rpc('get_user_dashboard_stats');
  if (error || !data) {
    return {
      totalAnswered: 0, totalCorrect: 0, accuracy: 0,
      todayAnswered: 0, todayCorrect: 0, studyTimeSeconds: 0,
      currentStreak: 0, recentScore: 0, overallMastery: 0,
    };
  }
  const r = (data as Record<string, number>[]);
  const row = r[0] ?? {};
  return {
    totalAnswered: row.total_answered ?? 0,
    totalCorrect: row.total_correct ?? 0,
    accuracy: Number(row.accuracy ?? 0),
    todayAnswered: row.today_answered ?? 0,
    todayCorrect: row.today_correct ?? 0,
    studyTimeSeconds: row.study_time_seconds ?? 0,
    currentStreak: row.current_streak ?? 0,
    recentScore: Number(row.recent_score ?? 0),
    overallMastery: Number(row.overall_mastery ?? 0),
  };
}

export async function getScoreHistory(limit = 20): Promise<{
  label: string; score: number; completedAt: string;
}[]> {
  const { data, error } = await supabase.rpc('get_user_score_history', { p_limit: limit });
  if (error || !data) return [];
  return (data as { label: string; score: number; completed_at: string }[])
    .map((d) => ({ label: d.label, score: Number(d.score), completedAt: d.completed_at }))
    .reverse();
}

export async function getWeeklyActivity(): Promise<{
  dayLabel: string; answered: number; correct: number;
}[]> {
  const { data, error } = await supabase.rpc('get_user_weekly_activity');
  if (error || !data) return [];
  return (data as { day_label: string; answered: number; correct: number }[])
    .map((d) => ({ dayLabel: d.day_label, answered: Number(d.answered), correct: Number(d.correct) }));
}

export interface SubjectPerformance {
  subjectId: string;
  subjectName: string;
  answered: number;
  correct: number;
  mastery: number;
  totalQuestions: number;
}

export async function getSubjectPerformance(): Promise<SubjectPerformance[]> {
  const { data, error } = await supabase.rpc('get_user_subject_performance');
  if (error || !data) return [];
  return (data as {
    subject_id: string; subject_name: string; answered: number;
    correct: number; mastery: number; total_questions: number;
  }[]).map((d) => ({
    subjectId: d.subject_id,
    subjectName: d.subject_name,
    answered: Number(d.answered),
    correct: Number(d.correct),
    mastery: Number(d.mastery),
    totalQuestions: Number(d.total_questions),
  }));
}

function shuffle<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}
