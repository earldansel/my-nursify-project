import { useState, useEffect } from 'react';
import type { View, QuizResult, SubjectId, ExamTrack } from '@/types';
import { ToastProvider } from '@/components/ui/Toast';
import { AuthProvider, useAuth } from '@/lib/auth';
import Landing from '@/components/landing/Landing';
import Dashboard from '@/components/dashboard/Dashboard';
import Quiz from '@/components/quiz/Quiz';
import Results from '@/components/results/Results';
import Analytics from '@/components/analytics/Analytics';
import Login from '@/components/auth/Login';
import SignUp from '@/components/auth/SignUp';
import ForgotPassword from '@/components/auth/ForgotPassword';
import ResetPassword from '@/components/auth/ResetPassword';
import Pricing from '@/components/pricing/Pricing';
import Profile from '@/components/profile/Profile';
import StudyPlan from '@/components/studyplan/StudyPlan';
import VideoLessons from '@/components/video/VideoLessons';
import Admin from '@/components/admin/Admin';
import AdminLogin from '@/components/admin/AdminLogin';
import Leaderboard from '@/components/leaderboard/Leaderboard';
import StudyGuide from '@/components/studyguide/StudyGuide';
import StudyGuideSubjectPage from '@/components/studyguide/StudyGuideSubjectPage';
import ExamTrackPage from '@/components/studyguide/ExamTrackPage';

function AppContent() {
  const { user, loading, isPremium, isAdmin, isFreeUser } = useAuth();
  const [view, setView] = useState<View>('landing');
  const [dark, setDark] = useState(false);
  const [quizResults, setQuizResults] = useState<(QuizResult | null)[]>([]);
  const [quizQuestions, setQuizQuestions] = useState<import('@/types').Question[]>([]);
  const [presetQuestionIds, setPresetQuestionIds] = useState<string[]>([]);
  const [dailyChallengeId, setDailyChallengeId] = useState<string | undefined>();
  const [preselectedSubject, setPreselectedSubject] = useState<SubjectId | undefined>(undefined);
  const [studyGuideSubject, setStudyGuideSubject] = useState<string | null>(null);
  const [examTrack, setExamTrack] = useState<ExamTrack>(() => {
    const saved = localStorage.getItem('nursify_exam_track');
    return saved === 'pnle' || saved === 'nclex' ? saved : 'pnle';
  });

  const FREE_RESTRICTED_VIEWS: View[] = [
    'video-lessons',
    'study-plan',
    'pnle-study-guide',
    'nclex-study-guide',
    'pnle-study-guide-subject',
    'nclex-study-guide-subject',
  ];

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
  }, [dark]);

  useEffect(() => {
    localStorage.setItem('nursify_exam_track', examTrack);
  }, [examTrack]);

  const navigate = (v: View) => {
    setView(v);
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  };

  const navigateWithSubject = (v: View, subjectId?: SubjectId) => {
    setPreselectedSubject(subjectId);
    setView(v);
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  };

  const toggleDark = () => setDark((d) => !d);

  const handleFinishQuiz = (results: (QuizResult | null)[], completedQuestions: import('@/types').Question[]) => {
    setQuizResults(results);
    setQuizQuestions(completedQuestions);
    navigate('results');
  };

  const startQuestionSet = (ids: string[], challengeId?: string) => {
    setPresetQuestionIds(ids);
    setDailyChallengeId(challengeId);
    navigate('quiz');
  };

  const startSubjectPractice = (subjectId: string) => {
    setPresetQuestionIds([]);
    setPreselectedSubject(subjectId as SubjectId);
    navigate('quiz');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <span className="w-10 h-10 gradient-brand rounded-full flex items-center justify-center animate-pulse">
            <span className="w-3 h-3 bg-white rounded-full" />
          </span>
          <p className="text-sm text-secondary">Loading...</p>
        </div>
      </div>
    );
  }

  const authRequiredViews: View[] = ['dashboard', 'quiz', 'results', 'analytics', 'profile', 'study-plan', 'video-lessons', 'leaderboard', 'pnle', 'nclex', 'pnle-study-guide', 'nclex-study-guide', 'pnle-study-guide-subject', 'nclex-study-guide-subject', 'study-history', 'weak-areas'];
  const needsAuth = authRequiredViews.includes(view);

  if (needsAuth && !user) {
    return <Login onNavigate={navigate} />;
  }

  if (isFreeUser && FREE_RESTRICTED_VIEWS.includes(view)) {
    navigate('dashboard');
    return null;
  }

  // Admin login view
  if (view === 'admin-login') {
    if (isAdmin) {
      return <Admin onNavigate={navigate} onLogout={() => navigate('landing')} />;
    }
    return <AdminLogin onNavigate={navigate} onLogin={() => navigate('admin')} />;
  }

  // Admin dashboard view
  if (view === 'admin') {
    if (!isAdmin) {
      return <AdminLogin onNavigate={navigate} onLogin={() => navigate('admin')} />;
    }
    return <Admin onNavigate={navigate} onLogout={() => navigate('landing')} />;
  }

  const activeTrackView: View = examTrack === 'pnle' ? 'pnle' : 'nclex';
  const studyGuideView: View = examTrack === 'pnle' ? 'pnle-study-guide' : 'nclex-study-guide';
  const studyGuideSubjectView: View = examTrack === 'pnle' ? 'pnle-study-guide-subject' : 'nclex-study-guide-subject';

  return (
    <>
      {view === 'landing' && (
        <Landing onNavigate={navigate} dark={dark} onToggleDark={toggleDark} />
      )}
      {view === 'login' && <Login onNavigate={navigate} />}
      {view === 'signup' && <SignUp onNavigate={navigate} />}
      {view === 'forgot-password' && <ForgotPassword onNavigate={navigate} />}
      {view === 'reset-password' && <ResetPassword onNavigate={navigate} />}
      {view === 'dashboard' && (
        <Dashboard onNavigate={navigate} dark={dark} onToggleDark={toggleDark} onStartQuestions={startQuestionSet} onStartSubject={startSubjectPractice} examTrack={examTrack} onTrackChange={setExamTrack} />
      )}
      {view === 'quiz' && (
        <Quiz onNavigate={navigate} onFinish={handleFinishQuiz} preselectedSubject={preselectedSubject} presetQuestionIds={presetQuestionIds} onStartQuestionSet={startQuestionSet} dailyChallengeId={dailyChallengeId} onConsumePresetQuestions={() => { setPresetQuestionIds([]); setDailyChallengeId(undefined); }} onConsumePreselectedSubject={() => setPreselectedSubject(undefined)} />
      )}
      {view === 'results' && (
        <Results
          onNavigate={navigate}
          onRetry={() => navigate('quiz')}
          results={quizResults}
          questions={quizQuestions}
          onStartQuestions={startQuestionSet}
          onStartSubject={startSubjectPractice}
        />
      )}
      {view === 'analytics' && (
        <Analytics onNavigate={navigate} dark={dark} onToggleDark={toggleDark} />
      )}
      {view === 'pricing' && <Pricing onNavigate={navigate} />}
      {view === 'study-plan' && (
        <StudyPlan onNavigate={navigate} dark={dark} onToggleDark={toggleDark} />
      )}
      {view === 'video-lessons' && (
        <VideoLessons onNavigate={navigate} dark={dark} onToggleDark={toggleDark} />
      )}
      {view === 'profile' && <Profile onNavigate={navigate} />}
      {view === 'leaderboard' && (
        <Leaderboard onNavigate={navigate} dark={dark} onToggleDark={toggleDark} />
      )}

      {/* PNLE Hub */}
      {view === 'pnle' && (
        <ExamTrackPage
          examTrack="pnle"
          onNavigate={navigate}
          onOpenStudyGuide={() => navigate('pnle-study-guide')}
          onOpenStudyGuideSubject={(sid) => { setStudyGuideSubject(sid); navigate('pnle-study-guide-subject'); }}
          onStartPractice={() => { setExamTrack('pnle'); navigate('quiz'); }}
          dark={dark}
          onToggleDark={toggleDark}
        />
      )}

      {/* NCLEX Hub */}
      {view === 'nclex' && (
        <ExamTrackPage
          examTrack="nclex"
          onNavigate={navigate}
          onOpenStudyGuide={() => navigate('nclex-study-guide')}
          onOpenStudyGuideSubject={(sid) => { setStudyGuideSubject(sid); navigate('nclex-study-guide-subject'); }}
          onStartPractice={() => { setExamTrack('nclex'); navigate('quiz'); }}
          dark={dark}
          onToggleDark={toggleDark}
        />
      )}

      {/* PNLE Study Guide */}
      {view === 'pnle-study-guide' && (
        <StudyGuide
          onNavigate={navigate}
          onOpenSubject={(sid) => { setStudyGuideSubject(sid); navigate('pnle-study-guide-subject'); }}
          onStartPractice={(sid) => navigateWithSubject('quiz', sid)}
          dark={dark}
          onToggleDark={toggleDark}
          examTrack="pnle"
        />
      )}
      {view === 'pnle-study-guide-subject' && studyGuideSubject && (
        <StudyGuideSubjectPage
          subjectId={studyGuideSubject}
          onNavigate={navigate}
          onBack={() => navigate('pnle-study-guide')}
          onStartPractice={(sid) => navigateWithSubject('quiz', sid)}
          dark={dark}
          onToggleDark={toggleDark}
          examTrack="pnle"
        />
      )}

      {/* NCLEX Study Guide */}
      {view === 'nclex-study-guide' && (
        <StudyGuide
          onNavigate={navigate}
          onOpenSubject={(sid) => { setStudyGuideSubject(sid); navigate('nclex-study-guide-subject'); }}
          onStartPractice={(sid) => navigateWithSubject('quiz', sid)}
          dark={dark}
          onToggleDark={toggleDark}
          examTrack="nclex"
        />
      )}
      {view === 'nclex-study-guide-subject' && studyGuideSubject && (
        <StudyGuideSubjectPage
          subjectId={studyGuideSubject}
          onNavigate={navigate}
          onBack={() => navigate('nclex-study-guide')}
          onStartPractice={(sid) => navigateWithSubject('quiz', sid)}
          dark={dark}
          onToggleDark={toggleDark}
          examTrack="nclex"
        />
      )}

      {/* Weak Areas — alias to analytics for now */}
      {view === 'weak-areas' && (
        <Analytics onNavigate={navigate} dark={dark} onToggleDark={toggleDark} />
      )}

      {/* Study History — alias to analytics for now */}
      {view === 'study-history' && (
        <Analytics onNavigate={navigate} dark={dark} onToggleDark={toggleDark} />
      )}
    </>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ToastProvider>
  );
}
