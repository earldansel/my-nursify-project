import type { Subject, Question } from './types';

export const subjects: Subject[] = [
  {
    id: 'pharmacology',
    name: 'Pharmacology',
    shortName: 'Pharm',
    mastery: 64,
    questionsCompleted: 128,
    questionsTotal: 200,
    accuracy: 68,
    recentScore: 62,
    status: 'needs-attention',
    accent: '#8b5cf6',
    icon: 'pill',
  },
  {
    id: 'medsurg',
    name: 'Med-Surg',
    shortName: 'Med-Surg',
    mastery: 72,
    questionsCompleted: 214,
    questionsTotal: 300,
    accuracy: 75,
    recentScore: 74,
    status: 'progressing',
    accent: '#6d28d9',
    icon: 'activity',
  },
  {
    id: 'pediatrics',
    name: 'Pediatrics',
    shortName: 'Peds',
    mastery: 91,
    questionsCompleted: 182,
    questionsTotal: 200,
    accuracy: 90,
    recentScore: 88,
    status: 'strong',
    accent: '#10b981',
    icon: 'baby',
  },
  {
    id: 'mentalhealth',
    name: 'Mental Health',
    shortName: 'Psych',
    mastery: 88,
    questionsCompleted: 176,
    questionsTotal: 200,
    accuracy: 87,
    recentScore: 85,
    status: 'strong',
    accent: '#a78bfa',
    icon: 'brain',
  },
  {
    id: 'ob',
    name: 'Maternal & Newborn',
    shortName: 'OB',
    mastery: 79,
    questionsCompleted: 158,
    questionsTotal: 200,
    accuracy: 81,
    recentScore: 80,
    status: 'progressing',
    accent: '#f59e0b',
    icon: 'heart',
  },
  {
    id: 'fundamentals',
    name: 'Fundamentals',
    shortName: 'Fund',
    mastery: 84,
    questionsCompleted: 168,
    questionsTotal: 200,
    accuracy: 85,
    recentScore: 83,
    status: 'strong',
    accent: '#7c3aed',
    icon: 'book',
  },
];

export const questions: Question[] = [
  {
    id: 'q1',
    subjectId: 'pharmacology',
    subjectName: 'Pharmacology',
    topic: 'Anticoagulants',
    prompt:
      'A patient receiving IV heparin for a deep vein thrombosis develops an sudden nosebleed lasting 20 minutes. The nurse reviews the aPTT, which is 98 seconds (control 30). Which action should the nurse take first?',
    options: [
      { id: 'a', label: 'Apply pressure to the nares and notify the provider' },
      { id: 'b', label: 'Administer protamine sulfate immediately' },
      { id: 'c', label: 'Discontinue the heparin infusion and reassess' },
      { id: 'd', label: 'Document the finding and continue monitoring' },
    ],
    correctOptionId: 'c',
    rationale:
      'With an aPTT of 98 seconds (well above the therapeutic range of 1.5–2.5x control), the heparin is the likely cause of the bleeding. The priority is to stop the source of over-anticoagulation by discontinuing the infusion, then reassess and notify the provider for possible antidote.',
    keyTakeaway:
      'When a heparin patient bleeds AND the aPTT is supratherapeutic, stop the infusion first — before administering antidote.',
    nclexTip:
      'NCLEX prioritization: if a medication is causing the adverse effect, remove the medication before treating the effect.',
    otherOptions: {
      a: 'Applying pressure is appropriate but does not address the cause — the heparin is still running.',
      b: 'Protamine sulfate is the antidote, but it should not precede stopping the infusion.',
      d: 'Active bleeding with a supratherapeutic aPTT requires action, not continued monitoring.',
    },
  },
  {
    id: 'q2',
    subjectId: 'pharmacology',
    subjectName: 'Pharmacology',
    topic: 'Anticoagulants',
    prompt:
      'A patient is transitioning from continuous IV heparin to oral warfarin. The INR is currently 1.4. Which statement by the patient indicates teaching has been effective?',
    options: [
      { id: 'a', label: '"I will stop the heparin as soon as I take my first warfarin dose."' },
      { id: 'b', label: '"I should expect my warfarin to work within a few hours."' },
      { id: 'c', label: '"I will continue both medications until my provider tells me to stop the heparin."' },
      { id: 'd', label: '"I should avoid all foods containing vitamin K."' },
    ],
    correctOptionId: 'c',
    rationale:
      'Warfarin takes 3–5 days to reach a therapeutic INR because it inhibits synthesis of new clotting factors but does not affect those already circulating. Heparin provides immediate anticoagulation, so both are continued (bridge therapy) until the INR is therapeutic.',
    keyTakeaway:
      'Bridge therapy: continue heparin with warfarin until the INR reaches the target range for 2 consecutive days.',
    nclexTip:
      'Warfarin onset is delayed (3–5 days). Never stop heparin prematurely during the transition.',
    otherOptions: {
      a: 'Stopping heparin immediately leaves the patient under-anticoagulated while warfarin has not yet taken effect.',
      b: 'Warfarin does not work for several hours — its full effect requires days.',
      d: 'Patients should maintain a consistent (not zero) intake of vitamin K foods.',
    },
  },
  {
    id: 'q3',
    subjectId: 'pharmacology',
    subjectName: 'Pharmacology',
    topic: 'Anticoagulants',
    prompt:
      'A nurse is preparing to administer subcutaneous enoxaparin. Which technique is correct?',
    options: [
      { id: 'a', label: 'Expel the air bubble from the prefilled syringe before injection' },
      { id: 'b', label: 'Massage the injection site gently after administration' },
      { id: 'c', label: 'Administer in the abdomen at least 2 inches from the umbilicus' },
      { id: 'd', label: 'Aspirate for blood return before injecting the medication' },
    ],
    correctOptionId: 'c',
    rationale:
      'Enoxaparin is administered in the abdominal fat layer at least 2 inches from the umbilicus. The air bubble in the prefilled syringe should remain to seal the medication and prevent leakage. Do not massage or aspirate.',
    keyTakeaway:
      'Low-molecular-weight heparin is given SC in the abdomen, without expelling the air bubble, without massage, without aspiration.',
    nclexTip:
      'Massaging an injection site after enoxaparin increases bruising and bleeding risk.',
    otherOptions: {
      a: 'The air bubble seals the medication in the subcutaneous space — do not expel it.',
      b: 'Massaging increases bruising and bleeding.',
      d: 'Aspiration is not required for subcutaneous injections of enoxaparin.',
    },
  },
  {
    id: 'q4',
    subjectId: 'medsurg',
    subjectName: 'Med-Surg',
    topic: 'Cardiac',
    prompt:
      'A patient with a history of heart failure presents with dyspnea, bilateral crackles, and a weight gain of 3 kg over 3 days. Which finding most strongly suggests worsening heart failure?',
    options: [
      { id: 'a', label: 'Heart rate 88 bpm' },
      { id: 'b', label: 'Orthopnea requiring 3 pillows' },
      { id: 'c', label: 'Blood pressure 134/82 mmHg' },
      { id: 'd', label: 'Serum sodium 138 mEq/L' },
    ],
    correctOptionId: 'b',
    rationale:
      'Orthopnea is a hallmark of left-sided heart failure worsening — fluid backs into the pulmonary vasculature, causing dyspnea that worsens when supine. The 3 kg weight gain confirms fluid retention. Three-pillow orthopnea is a significant clinical indicator.',
    keyTakeaway:
      'Orthopnea + recent weight gain + crackles = decompensated left heart failure.',
    nclexTip:
      'Daily weights are the most sensitive noninvasive marker of fluid status in heart failure.',
    otherOptions: {
      a: 'A heart rate of 88 is within normal limits and not the strongest indicator.',
      c: 'This blood pressure is not remarkable.',
      d: 'Sodium 138 is normal.',
    },
  },
  {
    id: 'q5',
    subjectId: 'pediatrics',
    subjectName: 'Pediatrics',
    topic: 'Growth & Development',
    prompt:
      'A 4-year-old child is hospitalized. Which play activity is most developmentally appropriate?',
    options: [
      { id: 'a', label: 'Stacking large blocks independently' },
      { id: 'b', label: 'Cooperative board games with strict rules' },
      { id: 'c', label: 'Imitative play with dolls and a toy stethoscope' },
      { id: 'd', label: 'Solitary video games' },
    ],
    correctOptionId: 'c',
    rationale:
      'The preschool-age child (3–5 years) is in the initiative stage and engages in imitative and dramatic play. Playing doctor with dolls and a toy stethoscope allows the child to process the hospital experience through pretend play.',
    keyTakeaway:
      'Preschoolers use dramatic and imitative play to understand the world and master fears.',
    nclexTip:
      'Use play to assess and support the hospitalized child — it is their language.',
    otherOptions: {
      a: 'More appropriate for a toddler exploring cause and effect.',
      b: 'Cooperative rule-based games suit school-age children (6–12 years).',
      d: 'Solitary screen time is not developmentally therapeutic for a 4-year-old.',
    },
  },
  {
    id: 'q6',
    subjectId: 'mentalhealth',
    subjectName: 'Mental Health',
    topic: 'Anxiety Disorders',
    prompt:
      'A patient with generalized anxiety disorder is learning diaphragmatic breathing. Which statement indicates the technique is understood?',
    options: [
      { id: 'a', label: '"I will take shallow breaths in through my mouth."' },
      { id: 'b', label: '"I will inhale slowly through my nose and feel my belly rise."' },
      { id: 'c', label: '"I will exhale faster than I inhale."' },
      { id: 'd', label: '"I will hold my breath for 10 seconds between each breath."' },
    ],
    correctOptionId: 'b',
    rationale:
      'Diaphragmatic breathing uses slow inhalation through the nose, allowing the abdomen to rise, followed by a longer exhalation. This activates the parasympathetic nervous system and reduces anxiety.',
    keyTakeaway:
      'Belly rise on inhale through the nose, slow exhale — parasympathetic activation.',
    nclexTip:
      'Exhalation longer than inhalation is the calming phase of the breath cycle.',
    otherOptions: {
      a: 'Shallow mouth breathing is associated with hyperventilation.',
      c: 'Exhalation should be slower, not faster.',
      d: 'Breath-holding can increase anxiety and is not part of the technique.',
    },
  },
  {
    id: 'q7',
    subjectId: 'ob',
    subjectName: 'Maternal & Newborn',
    topic: 'Labor & Delivery',
    prompt:
      'A laboring patient at 38 weeks gestation has a sudden onset of sharp, continuous abdominal pain and fetal tachycardia. What is the priority action?',
    options: [
      { id: 'a', label: 'Administer prescribed IV analgesic' },
      { id: 'b', label: 'Place the patient in a lateral position and notify the provider' },
      { id: 'c', label: 'Encourage pant-breathing through the contraction' },
      { id: 'd', label: 'Increase oral fluid intake' },
    ],
    correctOptionId: 'b',
    rationale:
      'Sudden continuous abdominal pain with fetal tachycardia suggests placental abruption. The priority is to position the patient to optimize placental perfusion (left lateral) and immediately notify the provider for emergency management.',
    keyTakeaway:
      'Continuous pain + fetal tachycardia = possible abruption — position and call.',
    nclexTip:
      'In obstetric emergencies, position the patient first (left lateral optimizes perfusion), then escalate.',
    otherOptions: {
      a: 'Analgesics do not address the underlying emergency and may mask symptoms.',
      c: 'Breathing techniques are for normal labor, not an emergency.',
      d: 'Oral intake is contraindicated given likely imminent surgical intervention.',
    },
  },
  {
    id: 'q8',
    subjectId: 'fundamentals',
    subjectName: 'Fundamentals',
    topic: 'Infection Control',
    prompt:
      'A patient is on contact precautions for Clostridioides difficile. Which action by the nurse is correct?',
    options: [
      { id: 'a', label: 'Use an alcohol-based hand rub after removing gloves' },
      { id: 'b', label: 'Wash hands with soap and water after providing care' },
      { id: 'c', label: 'Wear a surgical mask when within 3 feet of the patient' },
      { id: 'd', label: 'Dedicate a stethoscope only if it touches the patient' },
    ],
    correctOptionId: 'b',
    rationale:
      'C. difficile spores are resistant to alcohol-based hand rubs. Soap and water mechanically remove spores and are required after caring for these patients. Contact precautions require gown and gloves, and dedicated equipment.',
    keyTakeaway:
      'For C. difficile, always use soap and water — alcohol rubs do not kill spores.',
    nclexTip:
      'Alcohol-based rubs are ineffective against C. difficile spores — soap and water is the exception.',
    otherOptions: {
      a: 'Alcohol-based rubs do not kill C. difficile spores.',
      c: 'A mask is not required for contact precautions alone.',
      d: 'Dedicated equipment should be used for all contact precaution patients.',
    },
  },
];

export const scoreHistory = [
  { week: 'W1', score: 62 },
  { week: 'W2', score: 68 },
  { week: 'W3', score: 71 },
  { week: 'W4', score: 75 },
  { week: 'W5', score: 78 },
  { week: 'W6', score: 82 },
  { week: 'W7', score: 85 },
  { week: 'W8', score: 89 },
];

export const weeklyActivity = [
  { day: 'Mon', questions: 42, correct: 36 },
  { day: 'Tue', questions: 28, correct: 22 },
  { day: 'Wed', questions: 55, correct: 47 },
  { day: 'Thu', questions: 38, correct: 30 },
  { day: 'Fri', questions: 50, correct: 44 },
  { day: 'Sat', questions: 62, correct: 56 },
  { day: 'Sun', questions: 35, correct: 31 },
];
