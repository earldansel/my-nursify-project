/*
# Lock server-owned learning progress fields

1. Access
- Browsers can read their own progress through RLS.
- XP totals, XP events, achievements, activity, and daily challenge completion are written only by controlled database functions.

2. Security
- Removes direct authenticated INSERT, UPDATE, and DELETE grants from server-owned tables.
- Existing owner policies remain as defense in depth.
*/

REVOKE INSERT, UPDATE, DELETE ON public.daily_challenges FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.learning_activity FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.user_xp FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.xp_events FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.user_achievements FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.bookmarks FROM anon;
REVOKE SELECT ON public.daily_challenges, public.learning_activity, public.user_xp, public.xp_events, public.user_achievements FROM anon;