/*
# Create questions table and bookmarks table; extend quiz_attempts

1. New Tables
- `questions`: The main NCLEX question bank. Stores every question with full metadata,
  per-option rationales, NGN case-study fields, difficulty, category, question type, tags.
  Designed to scale to 10k–20k+ rows with indexes on the common filter columns.
- `bookmarks`: Saved questions per user (single-tenant for now, no auth).

2. Modified Tables
- `quiz_attempts`: Add `test_config` (jsonb) to store the full Create-Test configuration
  (mode, categories, question types, difficulty, count, NGN-only, unused-first, randomize).
  Add `mode` values are already free-text so no constraint change needed.

3. Indexes
- `questions(subject_id)`, `questions(category)`, `questions(difficulty)`,
  `questions(question_type)`, `questions(is_ngn)` for fast filtering.
- `questions(tags)` GIN index for tag-based queries.
- `bookmarks(question_id)` for lookup by question.

4. Security
- Enable RLS on `questions` and `bookmarks`.
- `questions`: read-only to anon+authenticated (content is shared practice material).
  No INSERT/UPDATE/DELETE via anon key — only the service role can bulk-import.
- `bookmarks`: full CRUD to anon+authenticated (single-tenant, intentionally shared).

5. Notes
- `questions.options` is jsonb: array of {id, label}.
- `questions.correct_answer` is text for single-choice (option id) or jsonb for SATA/ordered.
  We use jsonb to support all question types uniformly: for multiple choice it's a
  single-element array, for SATA it's multiple, for ordered response it's the ordered list.
- `questions.option_rationales` is jsonb: map of option_id -> explanation string.
- NGN fields are nullable and only populated for NGN case-study questions.
*/

CREATE TABLE IF NOT EXISTS questions (
  id text PRIMARY KEY,
  question text NOT NULL,
  subject_id text NOT NULL,
  subject_name text NOT NULL,
  category text NOT NULL DEFAULT 'General',
  topic text NOT NULL DEFAULT 'General',
  difficulty text NOT NULL DEFAULT 'medium' CHECK (difficulty IN ('easy','medium','hard','mixed')),
  question_type text NOT NULL DEFAULT 'multiple-choice' CHECK (question_type IN ('multiple-choice','select-all-that-apply','ordered-response','hot-spot','ngn-case-study')),
  options jsonb NOT NULL DEFAULT '[]'::jsonb,
  correct_answer jsonb NOT NULL DEFAULT '[]'::jsonb,
  rationale text NOT NULL DEFAULT '',
  option_rationales jsonb NOT NULL DEFAULT '{}'::jsonb,
  key_takeaway text NOT NULL DEFAULT '',
  nclex_tip text NOT NULL DEFAULT '',
  clinical_pearl text NOT NULL DEFAULT '',
  reference text NOT NULL DEFAULT '',
  tags text[] NOT NULL DEFAULT '{}',
  is_ngn boolean NOT NULL DEFAULT false,
  case_study text,
  patient_data jsonb,
  multiple_questions jsonb,
  ordered_response jsonb,
  matrix jsonb,
  bowtie jsonb,
  highlight jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_questions_subject ON questions(subject_id);
CREATE INDEX IF NOT EXISTS idx_questions_category ON questions(category);
CREATE INDEX IF NOT EXISTS idx_questions_difficulty ON questions(difficulty);
CREATE INDEX IF NOT EXISTS idx_questions_type ON questions(question_type);
CREATE INDEX IF NOT EXISTS idx_questions_ngn ON questions(is_ngn);
CREATE INDEX IF NOT EXISTS idx_questions_tags ON questions USING GIN(tags);

ALTER TABLE questions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_questions" ON questions;
CREATE POLICY "anon_select_questions"
ON questions FOR SELECT
TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS bookmarks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id text NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bookmarks_question ON bookmarks(question_id);

ALTER TABLE bookmarks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_bookmarks" ON bookmarks;
CREATE POLICY "anon_select_bookmarks"
ON bookmarks FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_bookmarks" ON bookmarks;
CREATE POLICY "anon_insert_bookmarks"
ON bookmarks FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_bookmarks" ON bookmarks;
CREATE POLICY "anon_update_bookmarks"
ON bookmarks FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_bookmarks" ON bookmarks;
CREATE POLICY "anon_delete_bookmarks"
ON bookmarks FOR DELETE
TO anon, authenticated USING (true);

ALTER TABLE quiz_attempts
  ADD COLUMN IF NOT EXISTS test_config jsonb NOT NULL DEFAULT '{}'::jsonb;
