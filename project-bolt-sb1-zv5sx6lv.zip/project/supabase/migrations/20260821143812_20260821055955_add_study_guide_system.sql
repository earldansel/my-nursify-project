-- Study Guide System
CREATE TABLE IF NOT EXISTS public.study_guide_subjects (
  id text PRIMARY KEY,
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text NOT NULL DEFAULT '',
  accent_color text NOT NULL DEFAULT '#3b82f6',
  icon text NOT NULL DEFAULT 'book-open',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE public.study_guide_subjects ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "sg_subjects_select_all" ON public.study_guide_subjects;
CREATE POLICY "sg_subjects_select_all" ON public.study_guide_subjects FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS public.study_guide_topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id text NOT NULL REFERENCES public.study_guide_subjects(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  key_concepts text[] NOT NULL DEFAULT '{}',
  nursing_considerations text[] NOT NULL DEFAULT '{}',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE public.study_guide_topics ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "sg_topics_select_all" ON public.study_guide_topics;
CREATE POLICY "sg_topics_select_all" ON public.study_guide_topics FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_sg_topics_subject ON public.study_guide_topics(subject_id);

CREATE TABLE IF NOT EXISTS public.study_guide_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  topic_id uuid NOT NULL REFERENCES public.study_guide_topics(id) ON DELETE CASCADE,
  studied boolean NOT NULL DEFAULT false,
  studied_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, topic_id)
);
ALTER TABLE public.study_guide_progress ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "sg_progress_select_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_select_own" ON public.study_guide_progress FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "sg_progress_insert_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_insert_own" ON public.study_guide_progress FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "sg_progress_update_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_update_own" ON public.study_guide_progress FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "sg_progress_delete_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_delete_own" ON public.study_guide_progress FOR DELETE TO authenticated USING (auth.uid() = user_id);