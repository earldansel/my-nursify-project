-- Add Premium Expiration System
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS premium_expires_at timestamptz;

DROP FUNCTION IF EXISTS public.admin_list_users();
DROP FUNCTION IF EXISTS public.admin_set_user_role(uuid, text);

CREATE OR REPLACE FUNCTION public.admin_list_users()
RETURNS TABLE(id uuid, full_name text, email text, role text, subscription_status text, created_at timestamptz, premium_expires_at timestamptz)
LANGUAGE sql SECURITY DEFINER SET search_path = public
AS $$ SELECT p.id, p.full_name, u.email, p.role, p.subscription_status, p.created_at, p.premium_expires_at FROM public.profiles p JOIN auth.users u ON u.id = p.id WHERE EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin') ORDER BY p.created_at DESC; $$;
GRANT EXECUTE ON FUNCTION public.admin_list_users() TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_set_user_role(p_user_id uuid, p_role text, p_premium_expires_at timestamptz DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE target_email text; new_expires timestamptz;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin') THEN RAISE EXCEPTION 'Admin access required'; END IF;
  IF p_role NOT IN ('free', 'premium', 'admin') THEN RAISE EXCEPTION 'Invalid role'; END IF;
  SELECT u.email INTO target_email FROM auth.users u WHERE u.id = p_user_id;
  IF target_email = 'nursify@gmail.com' AND p_role != 'admin' THEN RAISE EXCEPTION 'Cannot downgrade the main admin account'; END IF;
  IF p_role = 'admin' THEN new_expires := NULL;
  ELSIF p_role = 'premium' THEN new_expires := COALESCE(p_premium_expires_at, now() + interval '3 months');
  ELSE new_expires := NULL; END IF;
  UPDATE public.profiles SET role = p_role, subscription_status = CASE WHEN p_role IN ('premium','admin') THEN 'premium' ELSE 'free' END, premium_expires_at = new_expires, updated_at = now() WHERE id = p_user_id;
END; $$;
GRANT EXECUTE ON FUNCTION public.admin_set_user_role(uuid, text, timestamptz) TO authenticated;

CREATE OR REPLACE FUNCTION public.expire_premium_users()
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$ DECLARE expired_count integer; BEGIN
  UPDATE public.profiles SET role = 'free', subscription_status = 'free', premium_expires_at = NULL, updated_at = now() WHERE role = 'premium' AND premium_expires_at IS NOT NULL AND premium_expires_at <= now();
  GET DIAGNOSTICS expired_count = ROW_COUNT; RETURN expired_count;
END; $$;
GRANT EXECUTE ON FUNCTION public.expire_premium_users() TO authenticated;

-- Backfill premium expiration
UPDATE public.profiles SET premium_expires_at = now() + interval '3 months', updated_at = now() WHERE role = 'premium' AND premium_expires_at IS NULL;