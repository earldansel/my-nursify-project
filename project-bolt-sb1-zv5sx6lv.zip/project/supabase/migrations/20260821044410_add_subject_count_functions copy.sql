/*
# Add subject count functions for accurate question counts

## Problem
The frontend fetches all question rows to count them client-side, but Supabase's
default row limit is 1000. With 1394+ questions, some subjects get incorrect counts
or disappear entirely. This migration adds server-side functions that return accurate
counts regardless of row count.

## Changes
1. New function `get_subject_question_counts()` — returns one row per subject_id
   with the total question count. SECURITY DEFINER so it bypasses RLS safely
   (questions are already publicly readable via anon_select_questions policy).
2. New function `get_category_question_counts()` — returns one row per category
   with the total question count, for the Practice/Create Test modal.

## Security
- Both functions are SECURITY DEFINER, owned by the postgres role.
- They only SELECT from the questions table, which already has a public SELECT policy.
- EXECUTE is granted to anon and authenticated so the frontend can call them.
*/

CREATE OR REPLACE FUNCTION public.get_subject_question_counts()
RETURNS TABLE (subject_id text, total bigint)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT subject_id, COUNT(*)::bigint AS total
  FROM public.questions
  WHERE subject_id IS NOT NULL
  GROUP BY subject_id;
$$;

GRANT EXECUTE ON FUNCTION public.get_subject_question_counts() TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.get_category_question_counts()
RETURNS TABLE (category text, total bigint)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT category, COUNT(*)::bigint AS total
  FROM public.questions
  WHERE category IS NOT NULL
  GROUP BY category;
$$;

GRANT EXECUTE ON FUNCTION public.get_category_question_counts() TO anon, authenticated;
