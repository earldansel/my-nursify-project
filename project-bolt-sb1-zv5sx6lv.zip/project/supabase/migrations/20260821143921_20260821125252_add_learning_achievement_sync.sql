-- Achievement sync function
CREATE OR REPLACE FUNCTION public.sync_learning_achievements()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid(); v_answered integer; v_pharma_answered integer; v_pharma_correct integer;
  v_streak integer := 0; v_day date; v_previous date; v_started boolean := false;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  IF EXISTS (SELECT 1 FROM public.quiz_attempts WHERE user_id = v_user AND completed = true) THEN
    INSERT INTO public.user_achievements (user_id, achievement_key) VALUES (v_user, 'first_steps') ON CONFLICT DO NOTHING;
  END IF;
  IF EXISTS (SELECT 1 FROM public.quiz_attempts WHERE user_id = v_user AND completed = true AND score >= 90) THEN
    INSERT INTO public.user_achievements (user_id, achievement_key) VALUES (v_user, 'sharp_shooter') ON CONFLICT DO NOTHING;
  END IF;
  SELECT COUNT(*) INTO v_answered FROM public.question_answers WHERE user_id = v_user;
  IF v_answered >= 100 THEN
    INSERT INTO public.user_achievements (user_id, achievement_key) VALUES (v_user, 'century') ON CONFLICT DO NOTHING;
  END IF;
  SELECT COUNT(*), COUNT(*) FILTER (WHERE is_correct) INTO v_pharma_answered, v_pharma_correct
  FROM public.question_answers WHERE user_id = v_user AND subject_id = 'pharmacology';
  IF v_pharma_answered >= 10 AND v_pharma_correct::numeric / v_pharma_answered >= 0.85 THEN
    INSERT INTO public.user_achievements (user_id, achievement_key) VALUES (v_user, 'pharma_master') ON CONFLICT DO NOTHING;
  END IF;
  FOR v_day IN SELECT activity_date FROM public.learning_activity WHERE user_id = v_user ORDER BY activity_date DESC LOOP
    IF NOT v_started THEN v_streak := 1; v_previous := v_day; v_started := true;
    ELSIF v_previous - v_day = 1 THEN v_streak := v_streak + 1; v_previous := v_day;
    ELSE EXIT; END IF;
  END LOOP;
  IF v_streak >= 7 THEN
    INSERT INTO public.user_achievements (user_id, achievement_key) VALUES (v_user, 'on_fire') ON CONFLICT DO NOTHING;
    PERFORM public.award_learning_event('streak:' || v_previous::text, 'streak_7');
  END IF;
END; $$;
REVOKE ALL ON FUNCTION public.sync_learning_achievements() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.sync_learning_achievements() TO authenticated;

-- Grant read access to learning tables
GRANT SELECT ON public.daily_challenges TO authenticated;
GRANT SELECT ON public.learning_activity TO authenticated;
GRANT SELECT ON public.user_xp TO authenticated;
GRANT SELECT ON public.xp_events TO authenticated;
GRANT SELECT ON public.user_achievements TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bookmarks TO authenticated;

-- Lock server-owned learning progress fields
REVOKE INSERT, UPDATE, DELETE ON public.daily_challenges FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.learning_activity FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.user_xp FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.xp_events FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.user_achievements FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.bookmarks FROM anon;
REVOKE SELECT ON public.daily_challenges, public.learning_activity, public.user_xp, public.xp_events, public.user_achievements FROM anon;