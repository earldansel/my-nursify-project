-- Bulk insert questions (session-based admin check)
CREATE OR REPLACE FUNCTION public.admin_bulk_insert_questions(p_questions jsonb)
RETURNS TABLE (inserted_count integer, error_message text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  q jsonb;
  v_count integer := 0;
  v_id text;
  v_question text;
  v_subject_id text;
  v_subject_name text;
  v_category text;
  v_topic text;
  v_difficulty text;
  v_question_type text;
  v_options jsonb;
  v_correct_answer jsonb;
  v_rationale text;
  v_option_rationales jsonb;
  v_key_takeaway text;
  v_nclex_tip text;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin') THEN
    RETURN QUERY SELECT 0, 'Admin access required';
    RETURN;
  END IF;

  FOR q IN SELECT * FROM jsonb_array_elements(p_questions)
  LOOP
    v_id := q->>'id';
    v_question := q->>'question';
    v_subject_id := q->>'subject_id';
    v_subject_name := q->>'subject_name';
    v_category := COALESCE(q->>'category', 'General');
    v_topic := COALESCE(q->>'topic', 'General');
    v_difficulty := COALESCE(q->>'difficulty', 'medium');
    v_question_type := COALESCE(q->>'question_type', 'multiple-choice');
    v_options := COALESCE(q->'options', '[]'::jsonb);
    v_correct_answer := COALESCE(q->'correct_answer', '[]'::jsonb);
    v_rationale := COALESCE(q->>'rationale', '');
    v_option_rationales := COALESCE(q->'option_rationales', '{}'::jsonb);
    v_key_takeaway := COALESCE(q->>'key_takeaway', '');
    v_nclex_tip := COALESCE(q->>'nclex_tip', '');

    IF EXISTS (SELECT 1 FROM public.questions WHERE question = v_question) THEN CONTINUE; END IF;
    IF v_id IS NULL OR v_id = '' THEN v_id := 'csv_' || md5(v_question || v_subject_id); END IF;
    IF EXISTS (SELECT 1 FROM public.questions WHERE id = v_id) THEN CONTINUE; END IF;

    INSERT INTO public.questions (id, question, subject_id, subject_name, category, topic, difficulty, question_type, options, correct_answer, rationale, option_rationales, key_takeaway, nclex_tip)
    VALUES (v_id, v_question, v_subject_id, v_subject_name, v_category, v_topic, v_difficulty, v_question_type, v_options, v_correct_answer, v_rationale, v_option_rationales, v_key_takeaway, v_nclex_tip);
    v_count := v_count + 1;
  END LOOP;

  RETURN QUERY SELECT v_count, NULL::text;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_bulk_insert_questions(jsonb) TO authenticated;