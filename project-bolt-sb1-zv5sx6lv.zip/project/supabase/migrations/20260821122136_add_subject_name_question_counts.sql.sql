CREATE OR REPLACE FUNCTION public.get_subject_name_question_counts()
RETURNS TABLE(subject_name text, total bigint)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT subject_name, COUNT(*)::bigint AS total
  FROM public.questions
  WHERE subject_name IS NOT NULL
  GROUP BY subject_name;
$$;