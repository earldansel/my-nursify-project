/*
# Backfill Premium Expiration for Existing Users

1. Data Fix
- For all profiles where role = 'premium' AND premium_expires_at IS NULL:
  set premium_expires_at = now() + interval '3 months'.
- This fixes existing premium users who were showing "No expiration" on
  their profile by giving them a valid 3-month expiration from today.
- Admin accounts (role = 'admin') are left alone — they have no expiration
  by design.

2. No schema changes
- The premium_expires_at column already exists from a prior migration.

3. Important Notes
- This is a one-time data backfill.
- After this runs, every premium user will have a concrete expiration date.
- The expire_premium_users() function will automatically downgrade them
  to free when that date is reached.
*/

UPDATE public.profiles
SET premium_expires_at = now() + interval '3 months',
    updated_at = now()
WHERE role = 'premium'
  AND premium_expires_at IS NULL;
