/*
# Admin system: credential verification + user/question management

Admin credentials stored in admin_credentials table (password hashed with pgcrypto).
All admin management functions are SECURITY DEFINER, verify credentials server-side.
Frontend never stores admin password in code — admin enters it at login, held in memory.
pgcrypto is installed in the "extensions" schema.
*/

-- Admin credentials table (single row)
CREATE TABLE IF NOT EXISTS admin_credentials (
  id int PRIMARY KEY DEFAULT 1,
  username text NOT NULL,
  password_hash text NOT NULL,
  CONSTRAINT single_row CHECK (id = 1)
);

-- Seed admin credentials (username: bulletrn, password: 123@456)
INSERT INTO admin_credentials (id, username, password_hash)
VALUES (1, 'bulletrn', extensions.crypt('123@456', extensions.gen_salt('bf')))
ON CONFLICT (id) DO UPDATE SET
  username = EXCLUDED.username,
  password_hash = EXCLUDED.password_hash;

-- Lock down: no direct table access from anon/authenticated
REVOKE ALL ON admin_credentials FROM anon, authenticated;

-- Verify admin credentials (returns boolean)
CREATE OR REPLACE FUNCTION public.verify_admin_credentials(p_username text, p_password text)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_credentials
    WHERE username = p_username
      AND password_hash = extensions.crypt(p_password, password_hash)
  );
$$;

GRANT EXECUTE ON FUNCTION public.verify_admin_credentials(text, text) TO anon, authenticated;

-- Admin: list all users
CREATE OR REPLACE FUNCTION public.admin_list_users(p_admin_username text, p_admin_password text)
RETURNS TABLE (
  id uuid,
  full_name text,
  email text,
  role text,
  subscription_status text,
  created_at timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
  SELECT p.id, p.full_name, u.email, p.role, p.subscription_status, p.created_at
  FROM public.profiles p
  JOIN auth.users u ON u.id = p.id
  WHERE public.verify_admin_credentials(p_admin_username, p_admin_password)
  ORDER BY p.created_at DESC;
$$;

GRANT EXECUTE ON FUNCTION public.admin_list_users(text, text) TO authenticated;

-- Admin: set user role (activate/deactivate premium)
CREATE OR REPLACE FUNCTION public.admin_set_user_role(
  p_admin_username text,
  p_admin_password text,
  p_user_id uuid,
  p_role text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  IF NOT public.verify_admin_credentials(p_admin_username, p_admin_password) THEN
    RAISE EXCEPTION 'Invalid admin credentials';
  END IF;
  IF p_role NOT IN ('free', 'premium', 'admin') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;
  UPDATE public.profiles
  SET role = p_role,
      subscription_status = CASE WHEN p_role = 'premium' THEN 'premium' ELSE 'free' END,
      updated_at = now()
  WHERE id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_set_user_role(text, text, uuid, text) TO authenticated;

-- Admin: insert question
CREATE OR REPLACE FUNCTION public.admin_insert_question(
  p_admin_username text,
  p_admin_password text,
  p_id text,
  p_question text,
  p_subject_id text,
  p_subject_name text,
  p_category text DEFAULT 'General',
  p_topic text DEFAULT 'General',
  p_difficulty text DEFAULT 'medium',
  p_question_type text DEFAULT 'multiple-choice',
  p_options jsonb DEFAULT '[]'::jsonb,
  p_correct_answer jsonb DEFAULT '[]'::jsonb,
  p_rationale text DEFAULT '',
  p_option_rationales jsonb DEFAULT '{}'::jsonb,
  p_key_takeaway text DEFAULT '',
  p_nclex_tip text DEFAULT '',
  p_clinical_pearl text DEFAULT '',
  p_reference text DEFAULT '',
  p_tags text[] DEFAULT ARRAY[]::text[],
  p_is_ngn boolean DEFAULT false,
  p_case_study text DEFAULT NULL,
  p_patient_data jsonb DEFAULT NULL
)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  IF NOT public.verify_admin_credentials(p_admin_username, p_admin_password) THEN
    RAISE EXCEPTION 'Invalid admin credentials';
  END IF;
  INSERT INTO public.questions (
    id, question, subject_id, subject_name, category, topic, difficulty,
    question_type, options, correct_answer, rationale, option_rationales,
    key_takeaway, nclex_tip, clinical_pearl, reference, tags, is_ngn,
    case_study, patient_data
  ) VALUES (
    p_id, p_question, p_subject_id, p_subject_name, p_category, p_topic, p_difficulty,
    p_question_type, p_options, p_correct_answer, p_rationale, p_option_rationales,
    p_key_takeaway, p_nclex_tip, p_clinical_pearl, p_reference, p_tags, p_is_ngn,
    p_case_study, p_patient_data
  );
  RETURN p_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_insert_question TO authenticated;

-- Admin: update question
CREATE OR REPLACE FUNCTION public.admin_update_question(
  p_admin_username text,
  p_admin_password text,
  p_question_id text,
  p_question text,
  p_subject_id text,
  p_subject_name text,
  p_category text DEFAULT 'General',
  p_topic text DEFAULT 'General',
  p_difficulty text DEFAULT 'medium',
  p_question_type text DEFAULT 'multiple-choice',
  p_options jsonb DEFAULT '[]'::jsonb,
  p_correct_answer jsonb DEFAULT '[]'::jsonb,
  p_rationale text DEFAULT '',
  p_option_rationales jsonb DEFAULT '{}'::jsonb,
  p_key_takeaway text DEFAULT '',
  p_nclex_tip text DEFAULT '',
  p_clinical_pearl text DEFAULT '',
  p_reference text DEFAULT '',
  p_tags text[] DEFAULT ARRAY[]::text[],
  p_is_ngn boolean DEFAULT false,
  p_case_study text DEFAULT NULL,
  p_patient_data jsonb DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  IF NOT public.verify_admin_credentials(p_admin_username, p_admin_password) THEN
    RAISE EXCEPTION 'Invalid admin credentials';
  END IF;
  UPDATE public.questions SET
    question = p_question,
    subject_id = p_subject_id,
    subject_name = p_subject_name,
    category = p_category,
    topic = p_topic,
    difficulty = p_difficulty,
    question_type = p_question_type,
    options = p_options,
    correct_answer = p_correct_answer,
    rationale = p_rationale,
    option_rationales = p_option_rationales,
    key_takeaway = p_key_takeaway,
    nclex_tip = p_nclex_tip,
    clinical_pearl = p_clinical_pearl,
    reference = p_reference,
    tags = p_tags,
    is_ngn = p_is_ngn,
    case_study = p_case_study,
    patient_data = p_patient_data
  WHERE id = p_question_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_update_question TO authenticated;

-- Admin: delete question
CREATE OR REPLACE FUNCTION public.admin_delete_question(
  p_admin_username text,
  p_admin_password text,
  p_question_id text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  IF NOT public.verify_admin_credentials(p_admin_username, p_admin_password) THEN
    RAISE EXCEPTION 'Invalid admin credentials';
  END IF;
  DELETE FROM public.questions WHERE id = p_question_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_question(text, text, text) TO authenticated;
