/*
# Protect main admin account + add user deletion

1. Changes to existing functions
- `admin_set_user_role`: Updated to prevent downgrading the main admin account
  (email = 'bulletrn@gmail.com'). If an admin tries to set this user's role to
  anything other than 'admin', the function raises an exception. Also fixes
  subscription_status so admin role gets 'premium' status (was 'free' before).
- Also prevents an admin from downgrading their own account if they are the main admin.

2. New Functions
- `admin_delete_user(p_user_id uuid)`: Deletes a user account from auth.users
  (cascades to profiles, study_plans, study_tasks, quiz data via FK ON DELETE CASCADE).
  Protects:
    - The main admin account (bulletrn@gmail.com) cannot be deleted.
    - An admin cannot delete their own account.
  Verifies the caller has admin role before proceeding.

3. Security
- All functions are SECURITY DEFINER, verify admin role via auth.uid() check.
- No changes to RLS policies (these are SECURITY DEFINER functions that bypass RLS).

4. Important Notes
- The main admin account is identified by email 'bulletrn@gmail.com'.
- Non-main admins can still be edited or deleted by another admin.
- An admin cannot delete themselves (prevents accidental lockout).
*/

CREATE OR REPLACE FUNCTION public.admin_set_user_role(
  p_user_id uuid,
  p_role text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_email text;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  IF p_role NOT IN ('free', 'premium', 'admin') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;
  -- Protect main admin account from being downgraded
  SELECT u.email INTO target_email FROM auth.users u WHERE u.id = p_user_id;
  IF target_email = 'bulletrn@gmail.com' AND p_role != 'admin' THEN
    RAISE EXCEPTION 'Cannot downgrade the main admin account';
  END IF;
  UPDATE public.profiles
  SET role = p_role,
      subscription_status = CASE WHEN p_role IN ('premium', 'admin') THEN 'premium' ELSE 'free' END,
      updated_at = now()
  WHERE id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_set_user_role(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_delete_user(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_email text;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  -- Prevent self-deletion
  IF p_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot delete your own account';
  END IF;
  -- Protect main admin account
  SELECT u.email INTO target_email FROM auth.users u WHERE u.id = p_user_id;
  IF target_email = 'bulletrn@gmail.com' THEN
    RAISE EXCEPTION 'Cannot delete the main admin account';
  END IF;
  DELETE FROM auth.users WHERE id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_user(uuid) TO authenticated;