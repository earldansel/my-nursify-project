/*
# Add account, subscription, and payment system

Converts app from single-tenant to multi-user with accounts.
Adds user_id columns, profiles + payments tables, RLS ownership policies,
triggers for auto-profile and admin-only payment approval/rejection.
Existing demo data was cleared before this migration.
*/

-- 1. PROFILES TABLE
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  role text NOT NULL DEFAULT 'free' CHECK (role IN ('free','premium','admin')),
  subscription_status text NOT NULL DEFAULT 'free' CHECK (subscription_status IN ('free','premium','pending','rejected')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile"
ON profiles FOR SELECT TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile"
ON profiles FOR UPDATE TO authenticated
USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- 2. PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan text NOT NULL DEFAULT 'premium',
  amount numeric NOT NULL DEFAULT 0,
  reference_number text NOT NULL DEFAULT '',
  proof_image_path text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  rejection_reason text,
  reviewed_by uuid REFERENCES auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_payments_user ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_payments" ON payments;
CREATE POLICY "select_own_payments"
ON payments FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_payments" ON payments;
CREATE POLICY "insert_own_payments"
ON payments FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- 3. is_admin() FUNCTION
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin');
$$;

-- 4. ADMIN POLICIES
DROP POLICY IF EXISTS "admin_select_all_profiles" ON profiles;
CREATE POLICY "admin_select_all_profiles"
ON profiles FOR SELECT TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "admin_select_all_payments" ON payments;
CREATE POLICY "admin_select_all_payments"
ON payments FOR SELECT TO authenticated USING (public.is_admin());

-- 5. OTHER FUNCTIONS
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER SECURITY DEFINER SET search_path = public LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, role, subscription_status)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), 'free', 'free')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.approve_payment(p_payment_id uuid)
RETURNS void SECURITY DEFINER SET search_path = public LANGUAGE plpgsql
AS $$
DECLARE v_user_id uuid; v_is_admin boolean;
BEGIN
  SELECT public.is_admin() INTO v_is_admin;
  IF NOT v_is_admin THEN RAISE EXCEPTION 'Only admins can approve payments'; END IF;
  SELECT user_id INTO v_user_id FROM public.payments WHERE id = p_payment_id;
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Payment not found'; END IF;
  UPDATE public.payments SET status='approved', reviewed_by=auth.uid(), reviewed_at=now() WHERE id=p_payment_id;
  UPDATE public.profiles SET role='premium', subscription_status='premium', updated_at=now() WHERE id=v_user_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.reject_payment(p_payment_id uuid, p_reason text)
RETURNS void SECURITY DEFINER SET search_path = public LANGUAGE plpgsql
AS $$
DECLARE v_is_admin boolean;
BEGIN
  SELECT public.is_admin() INTO v_is_admin;
  IF NOT v_is_admin THEN RAISE EXCEPTION 'Only admins can reject payments'; END IF;
  UPDATE public.payments SET status='rejected', rejection_reason=p_reason, reviewed_by=auth.uid(), reviewed_at=now() WHERE id=p_payment_id;
END;
$$;

-- 6. TRIGGER
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 7. GRANTS
GRANT EXECUTE ON FUNCTION public.approve_payment(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.reject_payment(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;

-- 8. ADD user_id TO EXISTING TABLES
ALTER TABLE quiz_attempts ADD COLUMN IF NOT EXISTS user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE quiz_attempts ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE question_answers ADD COLUMN IF NOT EXISTS user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE question_answers ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE bookmarks ADD COLUMN IF NOT EXISTS user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE bookmarks ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE notes ADD COLUMN IF NOT EXISTS user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE notes ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE study_progress ADD COLUMN IF NOT EXISTS user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE study_progress ALTER COLUMN user_id SET NOT NULL;

-- 9. UPDATE RLS ON EXISTING TABLES
DROP POLICY IF EXISTS "anon_insert_questions" ON questions;
DROP POLICY IF EXISTS "anon_update_questions" ON questions;
DROP POLICY IF EXISTS "anon_delete_questions" ON questions;

DROP POLICY IF EXISTS "anon_select_quiz_attempts" ON quiz_attempts;
DROP POLICY IF EXISTS "anon_insert_quiz_attempts" ON quiz_attempts;
DROP POLICY IF EXISTS "anon_update_quiz_attempts" ON quiz_attempts;
DROP POLICY IF EXISTS "anon_delete_quiz_attempts" ON quiz_attempts;
CREATE POLICY "select_own_quiz_attempts" ON quiz_attempts FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_quiz_attempts" ON quiz_attempts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_quiz_attempts" ON quiz_attempts FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_quiz_attempts" ON quiz_attempts FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "anon_select_question_answers" ON question_answers;
DROP POLICY IF EXISTS "anon_insert_question_answers" ON question_answers;
DROP POLICY IF EXISTS "anon_update_question_answers" ON question_answers;
DROP POLICY IF EXISTS "anon_delete_question_answers" ON question_answers;
CREATE POLICY "select_own_question_answers" ON question_answers FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_question_answers" ON question_answers FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_question_answers" ON question_answers FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_question_answers" ON question_answers FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "anon_select_bookmarks" ON bookmarks;
DROP POLICY IF EXISTS "anon_insert_bookmarks" ON bookmarks;
DROP POLICY IF EXISTS "anon_update_bookmarks" ON bookmarks;
DROP POLICY IF EXISTS "anon_delete_bookmarks" ON bookmarks;
CREATE POLICY "select_own_bookmarks" ON bookmarks FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_bookmarks" ON bookmarks FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_bookmarks" ON bookmarks FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_bookmarks" ON bookmarks FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "anon_select_notes" ON notes;
DROP POLICY IF EXISTS "anon_insert_notes" ON notes;
DROP POLICY IF EXISTS "anon_update_notes" ON notes;
DROP POLICY IF EXISTS "anon_delete_notes" ON notes;
CREATE POLICY "select_own_notes" ON notes FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_notes" ON notes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_notes" ON notes FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_notes" ON notes FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "anon_select_study_progress" ON study_progress;
DROP POLICY IF EXISTS "anon_insert_study_progress" ON study_progress;
DROP POLICY IF EXISTS "anon_update_study_progress" ON study_progress;
DROP POLICY IF EXISTS "anon_delete_study_progress" ON study_progress;
CREATE POLICY "select_own_study_progress" ON study_progress FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_study_progress" ON study_progress FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_study_progress" ON study_progress FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_study_progress" ON study_progress FOR DELETE TO authenticated USING (auth.uid() = user_id);
