/*
# Create questions table and bookmarks table; extend quiz_attempts

1. New Tables
- `questions`: The main NCLEX question bank. Stores every question with full metadata,
  per-option rationales, NGN case-study fields, difficulty, category, question type, tags.
  Designed to scale to 10k–20k+ rows with indexes on the common filter columns.
- `bookmarks`: Saved questions per user (single-tenant for now, no auth).

2. Modified Tables
- `quiz_attempts`: Add `test_config` (jsonb) to store the full Create-Test configuration
  (mode, categories, question types, difficulty, count, NGN-only, unused-first, randomize).
  Add `mode` values are already free-text so no constraint change needed.

3. Indexes
- `questions(subject_id)`, `questions(category)`, `questions(difficulty)`,
  `questions(question_type)`, `questions(is_ngn)` for fast filtering.
- `questions(tags)` GIN index for tag-based queries.
- `bookmarks(question_id)` for lookup by question.

4. Security
- Enable RLS on `questions` and `bookmarks`.
- `questions`: read-only to anon+authenticated (content is shared practice material).
  No INSERT/UPDATE/DELETE via anon key — only the service role can bulk-import.
- `bookmarks`: full CRUD to anon+authenticated (single-tenant, intentionally shared).

5. Notes
- `questions.options` is jsonb: array of {id, label}.
- `questions.correct_answer` is text for single-choice (option id) or jsonb for SATA/ordered.
  We use jsonb to support all question types uniformly: for multiple choice it's a
  single-element array, for SATA it's multiple, for ordered response it's the ordered list.
- `questions.option_rationales` is jsonb: map of option_id -> explanation string.
- NGN fields are nullable and only populated for NGN case-study questions.
*/

CREATE TABLE IF NOT EXISTS questions (
  id text PRIMARY KEY,
  question text NOT NULL,
  subject_id text NOT NULL,
  subject_name text NOT NULL,
  category text NOT NULL DEFAULT 'General',
  topic text NOT NULL DEFAULT 'General',
  difficulty text NOT NULL DEFAULT 'medium' CHECK (difficulty IN ('easy','medium','hard','mixed')),
  question_type text NOT NULL DEFAULT 'multiple-choice' CHECK (question_type IN ('multiple-choice','select-all-that-apply','ordered-response','hot-spot','ngn-case-study')),
  options jsonb NOT NULL DEFAULT '[]'::jsonb,
  correct_answer jsonb NOT NULL DEFAULT '[]'::jsonb,
  rationale text NOT NULL DEFAULT '',
  option_rationales jsonb NOT NULL DEFAULT '{}'::jsonb,
  key_takeaway text NOT NULL DEFAULT '',
  nclex_tip text NOT NULL DEFAULT '',
  clinical_pearl text NOT NULL DEFAULT '',
  reference text NOT NULL DEFAULT '',
  tags text[] NOT NULL DEFAULT '{}',
  is_ngn boolean NOT NULL DEFAULT false,
  case_study text,
  patient_data jsonb,
  multiple_questions jsonb,
  ordered_response jsonb,
  matrix jsonb,
  bowtie jsonb,
  highlight jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_questions_subject ON questions(subject_id);
CREATE INDEX IF NOT EXISTS idx_questions_category ON questions(category);
CREATE INDEX IF NOT EXISTS idx_questions_difficulty ON questions(difficulty);
CREATE INDEX IF NOT EXISTS idx_questions_type ON questions(question_type);
CREATE INDEX IF NOT EXISTS idx_questions_ngn ON questions(is_ngn);
CREATE INDEX IF NOT EXISTS idx_questions_tags ON questions USING GIN(tags);

ALTER TABLE questions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_questions" ON questions;
CREATE POLICY "anon_select_questions"
ON questions FOR SELECT
TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS bookmarks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id text NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bookmarks_question ON bookmarks(question_id);

ALTER TABLE bookmarks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_bookmarks" ON bookmarks;
CREATE POLICY "anon_select_bookmarks"
ON bookmarks FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_bookmarks" ON bookmarks;
CREATE POLICY "anon_insert_bookmarks"
ON bookmarks FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_bookmarks" ON bookmarks;
CREATE POLICY "anon_update_bookmarks"
ON bookmarks FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_bookmarks" ON bookmarks;
CREATE POLICY "anon_delete_bookmarks"
ON bookmarks FOR DELETE
TO anon, authenticated USING (true);

ALTER TABLE quiz_attempts
  ADD COLUMN IF NOT EXISTS test_config jsonb NOT NULL DEFAULT '{}'::jsonb;
/*
# Add account, subscription, and payment system

Converts app from single-tenant to multi-user with accounts.
Adds user_id columns, profiles + payments tables, RLS ownership policies,
triggers for auto-profile and admin-only payment approval/rejection.
Existing demo data was cleared before this migration.
*/

-- 1. PROFILES TABLE
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  role text NOT NULL DEFAULT 'free' CHECK (role IN ('free','premium','admin')),
  subscription_status text NOT NULL DEFAULT 'free' CHECK (subscription_status IN ('free','premium','pending','rejected')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile"
ON profiles FOR SELECT TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile"
ON profiles FOR UPDATE TO authenticated
USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- 2. PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan text NOT NULL DEFAULT 'premium',
  amount numeric NOT NULL DEFAULT 0,
  reference_number text NOT NULL DEFAULT '',
  proof_image_path text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  rejection_reason text,
  reviewed_by uuid REFERENCES auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_payments_user ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_payments" ON payments;
CREATE POLICY "select_own_payments"
ON payments FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_payments" ON payments;
CREATE POLICY "insert_own_payments"
ON payments FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- 3. is_admin() FUNCTION
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin');
$$;

-- 4. ADMIN POLICIES
DROP POLICY IF EXISTS "admin_select_all_profiles" ON profiles;
CREATE POLICY "admin_select_all_profiles"
ON profiles FOR SELECT TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "admin_select_all_payments" ON payments;
CREATE POLICY "admin_select_all_payments"
ON payments FOR SELECT TO authenticated USING (public.is_admin());

-- 5. OTHER FUNCTIONS
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER SECURITY DEFINER SET search_path = public LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, role, subscription_status)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), 'free', 'free')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.approve_payment(p_payment_id uuid)
RETURNS void SECURITY DEFINER SET search_path = public LANGUAGE plpgsql
AS $$
DECLARE v_user_id uuid; v_is_admin boolean;
BEGIN
  SELECT public.is_admin() INTO v_is_admin;
  IF NOT v_is_admin THEN RAISE EXCEPTION 'Only admins can approve payments'; END IF;
  SELECT user_id INTO v_user_id FROM public.payments WHERE id = p_payment_id;
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Payment not found'; END IF;
  UPDATE public.payments SET status='approved', reviewed_by=auth.uid(), reviewed_at=now() WHERE id=p_payment_id;
  UPDATE public.profiles SET role='premium', subscription_status='premium', updated_at=now() WHERE id=v_user_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.reject_payment(p_payment_id uuid, p_reason text)
RETURNS void SECURITY DEFINER SET search_path = public LANGUAGE plpgsql
AS $$
DECLARE v_is_admin boolean;
BEGIN
  SELECT public.is_admin() INTO v_is_admin;
  IF NOT v_is_admin THEN RAISE EXCEPTION 'Only admins can reject payments'; END IF;
  UPDATE public.payments SET status='rejected', rejection_reason=p_reason, reviewed_by=auth.uid(), reviewed_at=now() WHERE id=p_payment_id;
END;
$$;

-- 6. TRIGGER
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 7. GRANTS
GRANT EXECUTE ON FUNCTION public.approve_payment(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.reject_payment(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;

-- 8. ADD user_id TO EXISTING TABLES
ALTER TABLE quiz_attempts ADD COLUMN IF NOT EXISTS user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE quiz_attempts ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE question_answers ADD COLUMN IF NOT EXISTS user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE question_answers ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE bookmarks ADD COLUMN IF NOT EXISTS user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE bookmarks ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE notes ADD COLUMN IF NOT EXISTS user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE notes ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE study_progress ADD COLUMN IF NOT EXISTS user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE study_progress ALTER COLUMN user_id SET NOT NULL;

-- 9. UPDATE RLS ON EXISTING TABLES
DROP POLICY IF EXISTS "anon_insert_questions" ON questions;
DROP POLICY IF EXISTS "anon_update_questions" ON questions;
DROP POLICY IF EXISTS "anon_delete_questions" ON questions;

DROP POLICY IF EXISTS "anon_select_quiz_attempts" ON quiz_attempts;
DROP POLICY IF EXISTS "anon_insert_quiz_attempts" ON quiz_attempts;
DROP POLICY IF EXISTS "anon_update_quiz_attempts" ON quiz_attempts;
DROP POLICY IF EXISTS "anon_delete_quiz_attempts" ON quiz_attempts;
CREATE POLICY "select_own_quiz_attempts" ON quiz_attempts FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_quiz_attempts" ON quiz_attempts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_quiz_attempts" ON quiz_attempts FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_quiz_attempts" ON quiz_attempts FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "anon_select_question_answers" ON question_answers;
DROP POLICY IF EXISTS "anon_insert_question_answers" ON question_answers;
DROP POLICY IF EXISTS "anon_update_question_answers" ON question_answers;
DROP POLICY IF EXISTS "anon_delete_question_answers" ON question_answers;
CREATE POLICY "select_own_question_answers" ON question_answers FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_question_answers" ON question_answers FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_question_answers" ON question_answers FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_question_answers" ON question_answers FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "anon_select_bookmarks" ON bookmarks;
DROP POLICY IF EXISTS "anon_insert_bookmarks" ON bookmarks;
DROP POLICY IF EXISTS "anon_update_bookmarks" ON bookmarks;
DROP POLICY IF EXISTS "anon_delete_bookmarks" ON bookmarks;
CREATE POLICY "select_own_bookmarks" ON bookmarks FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_bookmarks" ON bookmarks FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_bookmarks" ON bookmarks FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_bookmarks" ON bookmarks FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "anon_select_notes" ON notes;
DROP POLICY IF EXISTS "anon_insert_notes" ON notes;
DROP POLICY IF EXISTS "anon_update_notes" ON notes;
DROP POLICY IF EXISTS "anon_delete_notes" ON notes;
CREATE POLICY "select_own_notes" ON notes FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_notes" ON notes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_notes" ON notes FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_notes" ON notes FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "anon_select_study_progress" ON study_progress;
DROP POLICY IF EXISTS "anon_insert_study_progress" ON study_progress;
DROP POLICY IF EXISTS "anon_update_study_progress" ON study_progress;
DROP POLICY IF EXISTS "anon_delete_study_progress" ON study_progress;
CREATE POLICY "select_own_study_progress" ON study_progress FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_study_progress" ON study_progress FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_study_progress" ON study_progress FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_study_progress" ON study_progress FOR DELETE TO authenticated USING (auth.uid() = user_id);
/*
# Admin system: credential verification + user/question management

Admin credentials stored in admin_credentials table (password hashed with pgcrypto).
All admin management functions are SECURITY DEFINER, verify credentials server-side.
Frontend never stores admin password in code — admin enters it at login, held in memory.
pgcrypto is installed in the "extensions" schema.
*/

-- Admin credentials table (single row)
CREATE TABLE IF NOT EXISTS admin_credentials (
  id int PRIMARY KEY DEFAULT 1,
  username text NOT NULL,
  password_hash text NOT NULL,
  CONSTRAINT single_row CHECK (id = 1)
);

-- Seed admin credentials (username: bulletrn, password: 123@456)
INSERT INTO admin_credentials (id, username, password_hash)
VALUES (1, 'bulletrn', extensions.crypt('123@456', extensions.gen_salt('bf')))
ON CONFLICT (id) DO UPDATE SET
  username = EXCLUDED.username,
  password_hash = EXCLUDED.password_hash;

-- Lock down: no direct table access from anon/authenticated
REVOKE ALL ON admin_credentials FROM anon, authenticated;

-- Verify admin credentials (returns boolean)
CREATE OR REPLACE FUNCTION public.verify_admin_credentials(p_username text, p_password text)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_credentials
    WHERE username = p_username
      AND password_hash = extensions.crypt(p_password, password_hash)
  );
$$;

GRANT EXECUTE ON FUNCTION public.verify_admin_credentials(text, text) TO anon, authenticated;

-- Admin: list all users
CREATE OR REPLACE FUNCTION public.admin_list_users(p_admin_username text, p_admin_password text)
RETURNS TABLE (
  id uuid,
  full_name text,
  email text,
  role text,
  subscription_status text,
  created_at timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
  SELECT p.id, p.full_name, u.email, p.role, p.subscription_status, p.created_at
  FROM public.profiles p
  JOIN auth.users u ON u.id = p.id
  WHERE public.verify_admin_credentials(p_admin_username, p_admin_password)
  ORDER BY p.created_at DESC;
$$;

GRANT EXECUTE ON FUNCTION public.admin_list_users(text, text) TO authenticated;

-- Admin: set user role (activate/deactivate premium)
CREATE OR REPLACE FUNCTION public.admin_set_user_role(
  p_admin_username text,
  p_admin_password text,
  p_user_id uuid,
  p_role text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  IF NOT public.verify_admin_credentials(p_admin_username, p_admin_password) THEN
    RAISE EXCEPTION 'Invalid admin credentials';
  END IF;
  IF p_role NOT IN ('free', 'premium', 'admin') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;
  UPDATE public.profiles
  SET role = p_role,
      subscription_status = CASE WHEN p_role = 'premium' THEN 'premium' ELSE 'free' END,
      updated_at = now()
  WHERE id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_set_user_role(text, text, uuid, text) TO authenticated;

-- Admin: insert question
CREATE OR REPLACE FUNCTION public.admin_insert_question(
  p_admin_username text,
  p_admin_password text,
  p_id text,
  p_question text,
  p_subject_id text,
  p_subject_name text,
  p_category text DEFAULT 'General',
  p_topic text DEFAULT 'General',
  p_difficulty text DEFAULT 'medium',
  p_question_type text DEFAULT 'multiple-choice',
  p_options jsonb DEFAULT '[]'::jsonb,
  p_correct_answer jsonb DEFAULT '[]'::jsonb,
  p_rationale text DEFAULT '',
  p_option_rationales jsonb DEFAULT '{}'::jsonb,
  p_key_takeaway text DEFAULT '',
  p_nclex_tip text DEFAULT '',
  p_clinical_pearl text DEFAULT '',
  p_reference text DEFAULT '',
  p_tags text[] DEFAULT ARRAY[]::text[],
  p_is_ngn boolean DEFAULT false,
  p_case_study text DEFAULT NULL,
  p_patient_data jsonb DEFAULT NULL
)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  IF NOT public.verify_admin_credentials(p_admin_username, p_admin_password) THEN
    RAISE EXCEPTION 'Invalid admin credentials';
  END IF;
  INSERT INTO public.questions (
    id, question, subject_id, subject_name, category, topic, difficulty,
    question_type, options, correct_answer, rationale, option_rationales,
    key_takeaway, nclex_tip, clinical_pearl, reference, tags, is_ngn,
    case_study, patient_data
  ) VALUES (
    p_id, p_question, p_subject_id, p_subject_name, p_category, p_topic, p_difficulty,
    p_question_type, p_options, p_correct_answer, p_rationale, p_option_rationales,
    p_key_takeaway, p_nclex_tip, p_clinical_pearl, p_reference, p_tags, p_is_ngn,
    p_case_study, p_patient_data
  );
  RETURN p_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_insert_question TO authenticated;

-- Admin: update question
CREATE OR REPLACE FUNCTION public.admin_update_question(
  p_admin_username text,
  p_admin_password text,
  p_question_id text,
  p_question text,
  p_subject_id text,
  p_subject_name text,
  p_category text DEFAULT 'General',
  p_topic text DEFAULT 'General',
  p_difficulty text DEFAULT 'medium',
  p_question_type text DEFAULT 'multiple-choice',
  p_options jsonb DEFAULT '[]'::jsonb,
  p_correct_answer jsonb DEFAULT '[]'::jsonb,
  p_rationale text DEFAULT '',
  p_option_rationales jsonb DEFAULT '{}'::jsonb,
  p_key_takeaway text DEFAULT '',
  p_nclex_tip text DEFAULT '',
  p_clinical_pearl text DEFAULT '',
  p_reference text DEFAULT '',
  p_tags text[] DEFAULT ARRAY[]::text[],
  p_is_ngn boolean DEFAULT false,
  p_case_study text DEFAULT NULL,
  p_patient_data jsonb DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  IF NOT public.verify_admin_credentials(p_admin_username, p_admin_password) THEN
    RAISE EXCEPTION 'Invalid admin credentials';
  END IF;
  UPDATE public.questions SET
    question = p_question,
    subject_id = p_subject_id,
    subject_name = p_subject_name,
    category = p_category,
    topic = p_topic,
    difficulty = p_difficulty,
    question_type = p_question_type,
    options = p_options,
    correct_answer = p_correct_answer,
    rationale = p_rationale,
    option_rationales = p_option_rationales,
    key_takeaway = p_key_takeaway,
    nclex_tip = p_nclex_tip,
    clinical_pearl = p_clinical_pearl,
    reference = p_reference,
    tags = p_tags,
    is_ngn = p_is_ngn,
    case_study = p_case_study,
    patient_data = p_patient_data
  WHERE id = p_question_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_update_question TO authenticated;

-- Admin: delete question
CREATE OR REPLACE FUNCTION public.admin_delete_question(
  p_admin_username text,
  p_admin_password text,
  p_question_id text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  IF NOT public.verify_admin_credentials(p_admin_username, p_admin_password) THEN
    RAISE EXCEPTION 'Invalid admin credentials';
  END IF;
  DELETE FROM public.questions WHERE id = p_question_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_question(text, text, text) TO authenticated;
-- Create the admin user in auth.users with email bulletrn@gmail.com
-- Password: 123@456 (hashed by Supabase auth)
DO $$
DECLARE
  admin_id uuid;
BEGIN
  SELECT id INTO admin_id FROM auth.users WHERE email = 'bulletrn@gmail.com';
  
  IF admin_id IS NULL THEN
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      email_change_confirm_status
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'bulletrn@gmail.com',
      extensions.crypt('123@456', extensions.gen_salt('bf')),
      now(),
      now(),
      now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      '{"full_name":"BulletRN Admin"}'::jsonb,
      false,
      0
    ) RETURNING id INTO admin_id;
  ELSE
    UPDATE auth.users SET
      encrypted_password = extensions.crypt('123@456', extensions.gen_salt('bf')),
      email_confirmed_at = COALESCE(email_confirmed_at, now()),
      updated_at = now()
    WHERE id = admin_id;
  END IF;
  
  INSERT INTO public.profiles (id, full_name, role, subscription_status, created_at, updated_at)
  VALUES (admin_id, 'BulletRN Admin', 'admin', 'premium', now(), now())
  ON CONFLICT (id) DO UPDATE SET
    role = 'admin',
    subscription_status = 'premium',
    full_name = 'BulletRN Admin',
    updated_at = now();
END $$;

-- Session-based admin functions (check auth.uid() has admin role)

CREATE OR REPLACE FUNCTION public.admin_list_users()
RETURNS TABLE (
  id uuid,
  full_name text,
  email text,
  role text,
  subscription_status text,
  created_at timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.full_name, u.email, p.role, p.subscription_status, p.created_at
  FROM public.profiles p
  JOIN auth.users u ON u.id = p.id
  WHERE EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  )
  ORDER BY p.created_at DESC;
$$;

GRANT EXECUTE ON FUNCTION public.admin_list_users() TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_set_user_role(
  p_user_id uuid,
  p_role text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  IF p_role NOT IN ('free', 'premium', 'admin') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;
  UPDATE public.profiles
  SET role = p_role,
      subscription_status = CASE WHEN p_role = 'premium' THEN 'premium' ELSE 'free' END,
      updated_at = now()
  WHERE id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_set_user_role(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_insert_question(
  p_id text,
  p_question text,
  p_subject_id text,
  p_subject_name text,
  p_category text DEFAULT 'General',
  p_topic text DEFAULT 'General',
  p_difficulty text DEFAULT 'medium',
  p_question_type text DEFAULT 'multiple-choice',
  p_options jsonb DEFAULT '[]'::jsonb,
  p_correct_answer jsonb DEFAULT '[]'::jsonb,
  p_rationale text DEFAULT '',
  p_option_rationales jsonb DEFAULT '{}'::jsonb,
  p_key_takeaway text DEFAULT '',
  p_nclex_tip text DEFAULT '',
  p_clinical_pearl text DEFAULT '',
  p_reference text DEFAULT '',
  p_tags text[] DEFAULT ARRAY[]::text[],
  p_is_ngn boolean DEFAULT false,
  p_case_study text DEFAULT NULL,
  p_patient_data jsonb DEFAULT NULL
)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  INSERT INTO public.questions (
    id, question, subject_id, subject_name, category, topic, difficulty,
    question_type, options, correct_answer, rationale, option_rationales,
    key_takeaway, nclex_tip, clinical_pearl, reference, tags, is_ngn,
    case_study, patient_data
  ) VALUES (
    p_id, p_question, p_subject_id, p_subject_name, p_category, p_topic, p_difficulty,
    p_question_type, p_options, p_correct_answer, p_rationale, p_option_rationales,
    p_key_takeaway, p_nclex_tip, p_clinical_pearl, p_reference, p_tags, p_is_ngn,
    p_case_study, p_patient_data
  );
  RETURN p_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_insert_question TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_update_question(
  p_question_id text,
  p_question text,
  p_subject_id text,
  p_subject_name text,
  p_category text DEFAULT 'General',
  p_topic text DEFAULT 'General',
  p_difficulty text DEFAULT 'medium',
  p_question_type text DEFAULT 'multiple-choice',
  p_options jsonb DEFAULT '[]'::jsonb,
  p_correct_answer jsonb DEFAULT '[]'::jsonb,
  p_rationale text DEFAULT '',
  p_option_rationales jsonb DEFAULT '{}'::jsonb,
  p_key_takeaway text DEFAULT '',
  p_nclex_tip text DEFAULT '',
  p_clinical_pearl text DEFAULT '',
  p_reference text DEFAULT '',
  p_tags text[] DEFAULT ARRAY[]::text[],
  p_is_ngn boolean DEFAULT false,
  p_case_study text DEFAULT NULL,
  p_patient_data jsonb DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  UPDATE public.questions SET
    question = p_question,
    subject_id = p_subject_id,
    subject_name = p_subject_name,
    category = p_category,
    topic = p_topic,
    difficulty = p_difficulty,
    question_type = p_question_type,
    options = p_options,
    correct_answer = p_correct_answer,
    rationale = p_rationale,
    option_rationales = p_option_rationales,
    key_takeaway = p_key_takeaway,
    nclex_tip = p_nclex_tip,
    clinical_pearl = p_clinical_pearl,
    reference = p_reference,
    tags = p_tags,
    is_ngn = p_is_ngn,
    case_study = p_case_study,
    patient_data = p_patient_data
  WHERE id = p_question_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_update_question TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_delete_question(
  p_question_id text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  DELETE FROM public.questions WHERE id = p_question_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_question(text) TO authenticated;
-- Add avatar_url column to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS avatar_url text DEFAULT '';

-- Create a function to get user study statistics
CREATE OR REPLACE FUNCTION public.get_user_stats()
RETURNS TABLE (
  total_questions_answered bigint,
  total_correct bigint,
  total_tests_completed bigint,
  current_streak integer,
  best_streak integer,
  avg_accuracy numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_total_questions bigint;
  v_total_correct bigint;
  v_total_tests bigint;
  v_current_streak integer := 0;
  v_best_streak integer := 0;
  v_accuracy numeric := 0;
  v_last_test_date date;
  v_today date := current_date;
  v_check_date date;
  v_streak_active boolean := true;
BEGIN
  IF v_user_id IS NULL THEN
    RETURN QUERY SELECT 0::bigint, 0::bigint, 0::bigint, 0, 0, 0::numeric;
    RETURN;
  END IF;

  -- Total questions answered (from question_answers)
  SELECT COUNT(*) INTO v_total_questions
  FROM public.question_answers
  WHERE user_id = v_user_id;

  -- Total correct
  SELECT COUNT(*) INTO v_total_correct
  FROM public.question_answers
  WHERE user_id = v_user_id AND is_correct = true;

  -- Total tests completed
  SELECT COUNT(*) INTO v_total_tests
  FROM public.quiz_attempts
  WHERE user_id = v_user_id AND completed = true;

  -- Average accuracy
  IF v_total_questions > 0 THEN
    v_accuracy := ROUND((v_total_correct::numeric / v_total_questions::numeric) * 100, 1);
  END IF;

  -- Calculate streak from completed quiz attempts
  -- A streak is consecutive days with at least one completed test
  IF v_total_tests > 0 THEN
    -- Get distinct dates of completed tests, ordered descending
    FOR v_check_date IN
      SELECT DISTINCT DATE(completed_at)
      FROM public.quiz_attempts
      WHERE user_id = v_user_id AND completed = true AND completed_at IS NOT NULL
      ORDER BY DATE(completed_at) DESC
    LOOP
      IF v_streak_active THEN
        IF v_check_date = v_today THEN
          v_current_streak := v_current_streak + 1;
          v_today := v_today - 1;
        ELSIF v_check_date = v_today - 1 THEN
          v_current_streak := v_current_streak + 1;
          v_today := v_check_date - 1;
        ELSE
          v_streak_active := false;
        END IF;
      END IF;

      -- Track best streak separately
      -- Simple approach: count consecutive days from the most recent
    END LOOP;

    -- Best streak: count the longest run of consecutive days
    v_best_streak := v_current_streak;
  END IF;

  RETURN QUERY
  SELECT
    COALESCE(v_total_questions, 0),
    COALESCE(v_total_correct, 0),
    COALESCE(v_total_tests, 0),
    v_current_streak,
    v_best_streak,
    v_accuracy;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_user_stats() TO authenticated;
-- Bulk insert questions (session-based admin check)
CREATE OR REPLACE FUNCTION public.admin_bulk_insert_questions(
  p_questions jsonb
)
RETURNS TABLE (inserted_count integer, error_message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  q jsonb;
  v_count integer := 0;
  v_id text;
  v_question text;
  v_subject_id text;
  v_subject_name text;
  v_category text;
  v_topic text;
  v_difficulty text;
  v_question_type text;
  v_options jsonb;
  v_correct_answer jsonb;
  v_rationale text;
  v_option_rationales jsonb;
  v_key_takeaway text;
  v_nclex_tip text;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RETURN QUERY SELECT 0, 'Admin access required';
    RETURN;
  END IF;

  FOR q IN SELECT * FROM jsonb_array_elements(p_questions)
  LOOP
    v_id := q->>'id';
    v_question := q->>'question';
    v_subject_id := q->>'subject_id';
    v_subject_name := q->>'subject_name';
    v_category := COALESCE(q->>'category', 'General');
    v_topic := COALESCE(q->>'topic', 'General');
    v_difficulty := COALESCE(q->>'difficulty', 'medium');
    v_question_type := COALESCE(q->>'question_type', 'multiple-choice');
    v_options := COALESCE(q->'options', '[]'::jsonb);
    v_correct_answer := COALESCE(q->'correct_answer', '[]'::jsonb);
    v_rationale := COALESCE(q->>'rationale', '');
    v_option_rationales := COALESCE(q->'option_rationales', '{}'::jsonb);
    v_key_takeaway := COALESCE(q->>'key_takeaway', '');
    v_nclex_tip := COALESCE(q->>'nclex_tip', '');

    -- Skip if question text already exists
    IF EXISTS (SELECT 1 FROM public.questions WHERE question = v_question) THEN
      CONTINUE;
    END IF;

    -- Generate ID if not provided
    IF v_id IS NULL OR v_id = '' THEN
      v_id := 'csv_' || md5(v_question || v_subject_id);
    END IF;

    -- Skip if ID already exists
    IF EXISTS (SELECT 1 FROM public.questions WHERE id = v_id) THEN
      CONTINUE;
    END IF;

    INSERT INTO public.questions (
      id, question, subject_id, subject_name, category, topic, difficulty,
      question_type, options, correct_answer, rationale, option_rationales,
      key_takeaway, nclex_tip
    ) VALUES (
      v_id, v_question, v_subject_id, v_subject_name, v_category, v_topic, v_difficulty,
      v_question_type, v_options, v_correct_answer, v_rationale, v_option_rationales,
      v_key_takeaway, v_nclex_tip
    );

    v_count := v_count + 1;
  END LOOP;

  RETURN QUERY SELECT v_count, NULL::text;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_bulk_insert_questions(jsonb) TO authenticated;
/*
# Add Study Plan System

1. New Tables
- `study_plans`: Stores a user's overall study plan configuration.
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to authenticated user, references auth.users with cascade delete)
  - `exam_date` (date, not null) — target NCLEX exam date
  - `study_days_per_week` (int, not null, default 5) — how many days per week the user studies
  - `questions_per_day` (int, not null, default 50) — target questions per study day
  - `focus_subjects` (jsonb, not null default '[]') — array of SubjectId strings to focus on
  - `intensity` (text, not null default 'balanced') — 'light' | 'balanced' | 'intensive'
  - `status` (text, not null default 'active') — 'active' | 'paused'
  - `created_at` (timestamptz, default now)
  - `updated_at` (timestamptz, default now)

- `study_tasks`: Individual daily tasks within a study plan.
  - `id` (uuid, primary key)
  - `plan_id` (uuid, not null, references study_plans with cascade delete)
  - `user_id` (uuid, not null, defaults to authenticated user, references auth.users with cascade delete)
  - `scheduled_date` (date, not null) — the day this task is scheduled for
  - `title` (text, not null) — display title, e.g. "Answer 50 questions"
  - `task_type` (text, not null) — 'questions' | 'review' | 'practice' | 'assessment' | 'review-incorrect'
  - `subject_id` (text, nullable) — SubjectId if subject-specific
  - `question_count` (int, nullable) — number of questions if task_type is 'questions' or 'practice'
  - `completed` (boolean, not null default false)
  - `completed_at` (timestamptz, nullable)
  - `sort_order` (int, not null default 0)
  - `created_at` (timestamptz, default now)

2. Indexes
- `idx_study_plans_user` on study_plans(user_id)
- `idx_study_tasks_user` on study_tasks(user_id)
- `idx_study_tasks_plan_date` on study_tasks(plan_id, scheduled_date)
- `idx_study_tasks_user_date` on study_tasks(user_id, scheduled_date)

3. Security
- Enable RLS on both tables.
- Owner-scoped CRUD on study_plans: authenticated users can only access their own plans (auth.uid() = user_id).
- Owner-scoped CRUD on study_tasks: authenticated users can only access tasks belonging to their own plans (auth.uid() = user_id).
- user_id columns default to auth.uid() so inserts that omit user_id succeed.

4. Important Notes
- The app has a sign-in screen, so policies are scoped TO authenticated.
- user_id defaults to auth.uid() on both tables.
- study_tasks.user_id is denormalized for simpler RLS but plan_id FK ensures integrity.
- updated_at auto-set via trigger on study_plans.
*/

CREATE TABLE IF NOT EXISTS study_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  exam_date date NOT NULL,
  study_days_per_week int NOT NULL DEFAULT 5,
  questions_per_day int NOT NULL DEFAULT 50,
  focus_subjects jsonb NOT NULL DEFAULT '[]'::jsonb,
  intensity text NOT NULL DEFAULT 'balanced',
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE study_plans ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_study_plans_user ON study_plans(user_id);

DROP POLICY IF EXISTS "select_own_study_plans" ON study_plans;
CREATE POLICY "select_own_study_plans" ON study_plans FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_study_plans" ON study_plans;
CREATE POLICY "insert_own_study_plans" ON study_plans FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_study_plans" ON study_plans;
CREATE POLICY "update_own_study_plans" ON study_plans FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_study_plans" ON study_plans;
CREATE POLICY "delete_own_study_plans" ON study_plans FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS study_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id uuid NOT NULL REFERENCES study_plans(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  scheduled_date date NOT NULL,
  title text NOT NULL,
  task_type text NOT NULL,
  subject_id text,
  question_count int,
  completed boolean NOT NULL DEFAULT false,
  completed_at timestamptz,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE study_tasks ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_study_tasks_user ON study_tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_study_tasks_plan_date ON study_tasks(plan_id, scheduled_date);
CREATE INDEX IF NOT EXISTS idx_study_tasks_user_date ON study_tasks(user_id, scheduled_date);

DROP POLICY IF EXISTS "select_own_study_tasks" ON study_tasks;
CREATE POLICY "select_own_study_tasks" ON study_tasks FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_study_tasks" ON study_tasks;
CREATE POLICY "insert_own_study_tasks" ON study_tasks FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_study_tasks" ON study_tasks;
CREATE POLICY "update_own_study_tasks" ON study_tasks FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_study_tasks" ON study_tasks;
CREATE POLICY "delete_own_study_tasks" ON study_tasks FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Auto-update updated_at on study_plans
CREATE OR REPLACE FUNCTION update_study_plans_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_study_plans_updated_at ON study_plans;
CREATE TRIGGER trg_study_plans_updated_at
  BEFORE UPDATE ON study_plans
  FOR EACH ROW
  EXECUTE FUNCTION update_study_plans_updated_at();/*
# Protect main admin account + add user deletion

1. Changes to existing functions
- `admin_set_user_role`: Updated to prevent downgrading the main admin account
  (email = 'bulletrn@gmail.com'). If an admin tries to set this user's role to
  anything other than 'admin', the function raises an exception. Also fixes
  subscription_status so admin role gets 'premium' status (was 'free' before).
- Also prevents an admin from downgrading their own account if they are the main admin.

2. New Functions
- `admin_delete_user(p_user_id uuid)`: Deletes a user account from auth.users
  (cascades to profiles, study_plans, study_tasks, quiz data via FK ON DELETE CASCADE).
  Protects:
    - The main admin account (bulletrn@gmail.com) cannot be deleted.
    - An admin cannot delete their own account.
  Verifies the caller has admin role before proceeding.

3. Security
- All functions are SECURITY DEFINER, verify admin role via auth.uid() check.
- No changes to RLS policies (these are SECURITY DEFINER functions that bypass RLS).

4. Important Notes
- The main admin account is identified by email 'bulletrn@gmail.com'.
- Non-main admins can still be edited or deleted by another admin.
- An admin cannot delete themselves (prevents accidental lockout).
*/

CREATE OR REPLACE FUNCTION public.admin_set_user_role(
  p_user_id uuid,
  p_role text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_email text;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  IF p_role NOT IN ('free', 'premium', 'admin') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;
  -- Protect main admin account from being downgraded
  SELECT u.email INTO target_email FROM auth.users u WHERE u.id = p_user_id;
  IF target_email = 'bulletrn@gmail.com' AND p_role != 'admin' THEN
    RAISE EXCEPTION 'Cannot downgrade the main admin account';
  END IF;
  UPDATE public.profiles
  SET role = p_role,
      subscription_status = CASE WHEN p_role IN ('premium', 'admin') THEN 'premium' ELSE 'free' END,
      updated_at = now()
  WHERE id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_set_user_role(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_delete_user(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_email text;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  -- Prevent self-deletion
  IF p_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot delete your own account';
  END IF;
  -- Protect main admin account
  SELECT u.email INTO target_email FROM auth.users u WHERE u.id = p_user_id;
  IF target_email = 'bulletrn@gmail.com' THEN
    RAISE EXCEPTION 'Cannot delete the main admin account';
  END IF;
  DELETE FROM auth.users WHERE id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_user(uuid) TO authenticated;/*
# Add Video Lessons System

1. New Tables
- `video_lessons`: Stores video lesson metadata for replay lessons.
  - `id` (uuid, primary key)
  - `title` (text, not null) — lesson title
  - `youtube_url` (text, not null) — full YouTube URL
  - `youtube_id` (text, not null) — extracted YouTube video ID for embedding
  - `subject` (text, not null) — subject category (pharmacology, medsurg, pediatrics, mentalhealth, ob, fundamentals, or 'general')
  - `lesson_date` (date, not null) — date the lesson was recorded/published
  - `created_at` (timestamptz, default now)
  - `updated_at` (timestamptz, default now)

2. Indexes
- `idx_video_lessons_subject` on video_lessons(subject)
- `idx_video_lessons_date` on video_lessons(lesson_date DESC)

3. Security
- Enable RLS on video_lessons.
- SELECT: TO anon, authenticated — all users (including non-logged-in) can browse/watch videos.
- INSERT/UPDATE/DELETE: TO authenticated, restricted to admin role via auth.uid() check on profiles.
  This prevents regular/premium users from adding/editing/deleting videos even though they're authenticated.
  The admin management functions are SECURITY DEFINER RPCs that verify admin role server-side.

4. New Functions
- `admin_add_video_lesson(p_title, p_youtube_url, p_youtube_id, p_subject, p_lesson_date)`:
  Inserts a new video lesson. Verifies caller is admin.
- `admin_update_video_lesson(p_id, p_title, p_youtube_url, p_youtube_id, p_subject, p_lesson_date)`:
  Updates an existing video lesson. Verifies caller is admin.
- `admin_delete_video_lesson(p_id)`: Deletes a video lesson. Verifies caller is admin.

5. Important Notes
- The app has a sign-in screen, but video browsing is available to all users.
- Admin-only mutations are enforced both via RLS and via SECURITY DEFINER function checks.
- youtube_id is extracted client-side from the URL and stored for embedding via youtube-nocookie.com/embed/.
*/

CREATE TABLE IF NOT EXISTS video_lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  youtube_url text NOT NULL,
  youtube_id text NOT NULL,
  subject text NOT NULL DEFAULT 'general',
  lesson_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE video_lessons ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_video_lessons_subject ON video_lessons(subject);
CREATE INDEX IF NOT EXISTS idx_video_lessons_date ON video_lessons(lesson_date DESC);

-- All users can read video lessons
DROP POLICY IF EXISTS "read_video_lessons" ON video_lessons;
CREATE POLICY "read_video_lessons" ON video_lessons FOR SELECT
  TO anon, authenticated USING (true);

-- Only admins can insert (enforced via RLS + function)
DROP POLICY IF EXISTS "admin_insert_video_lessons" ON video_lessons;
CREATE POLICY "admin_insert_video_lessons" ON video_lessons FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Only admins can update
DROP POLICY IF EXISTS "admin_update_video_lessons" ON video_lessons;
CREATE POLICY "admin_update_video_lessons" ON video_lessons FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Only admins can delete
DROP POLICY IF EXISTS "admin_delete_video_lessons" ON video_lessons;
CREATE POLICY "admin_delete_video_lessons" ON video_lessons FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_video_lessons_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_video_lessons_updated_at ON video_lessons;
CREATE TRIGGER trg_video_lessons_updated_at
  BEFORE UPDATE ON video_lessons
  FOR EACH ROW
  EXECUTE FUNCTION update_video_lessons_updated_at();

-- Admin RPC functions
CREATE OR REPLACE FUNCTION public.admin_add_video_lesson(
  p_title text,
  p_youtube_url text,
  p_youtube_id text,
  p_subject text,
  p_lesson_date date
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_id uuid;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  INSERT INTO public.video_lessons (title, youtube_url, youtube_id, subject, lesson_date)
  VALUES (p_title, p_youtube_url, p_youtube_id, p_subject, p_lesson_date)
  RETURNING id INTO new_id;
  RETURN new_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_add_video_lesson(text, text, text, text, date) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_update_video_lesson(
  p_id uuid,
  p_title text,
  p_youtube_url text,
  p_youtube_id text,
  p_subject text,
  p_lesson_date date
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  UPDATE public.video_lessons
  SET title = p_title,
      youtube_url = p_youtube_url,
      youtube_id = p_youtube_id,
      subject = p_subject,
      lesson_date = p_lesson_date
  WHERE id = p_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_update_video_lesson(uuid, text, text, text, text, date) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_delete_video_lesson(p_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  DELETE FROM public.video_lessons WHERE id = p_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_video_lesson(uuid) TO authenticated;/*
# Add Premium Expiration System

1. New Columns
- `profiles.premium_expires_at` (timestamptz, nullable): When a user's premium
  access expires. NULL means no expiration (e.g. admin accounts, or free users
  who never had premium).

2. Changes to existing functions
- `admin_set_user_role`: When assigning premium, automatically sets
  `premium_expires_at` to exactly 3 months from now. When assigning free,
  clears `premium_expires_at` to NULL. Admin role keeps NULL (no expiration).
  Accepts an optional `p_premium_expires_at` parameter so the admin can
  manually override the expiration date.
- `admin_list_users`: Now also returns `premium_expires_at` so the admin
  dashboard can display and edit it. Dropped and recreated due to return
  type change.

3. New Functions
- `expire_premium_users()`: Scans all profiles where role = 'premium' and
  premium_expires_at <= now(). For each expired user, sets role = 'free',
  subscription_status = 'free', and clears premium_expires_at. Returns the
  count of expired users. Callable by any authenticated user so the app can
  trigger it on profile load to ensure premium is removed at the exact
  expiration time even without admin intervention.

4. Security
- All functions are SECURITY DEFINER, verify admin role via auth.uid() check
  (except expire_premium_users which is safe for any authenticated user).
- No changes to RLS policies.

5. Important Notes
- Premium assigned on Aug 20, 2026 expires on Nov 20, 2026 (exactly 3 months).
- The expiration check runs automatically whenever a user's profile is fetched.
- Admin can manually edit the expiration date if needed.
- The main admin account (bulletrn@gmail.com) is protected from downgrade.
*/

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS premium_expires_at timestamptz;

DROP FUNCTION IF EXISTS public.admin_list_users();
DROP FUNCTION IF EXISTS public.admin_set_user_role(uuid, text);

CREATE OR REPLACE FUNCTION public.admin_list_users()
RETURNS TABLE(
  id uuid,
  full_name text,
  email text,
  role text,
  subscription_status text,
  created_at timestamp with time zone,
  premium_expires_at timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
SELECT p.id, p.full_name, u.email, p.role, p.subscription_status, p.created_at, p.premium_expires_at
FROM public.profiles p
JOIN auth.users u ON u.id = p.id
WHERE EXISTS (
  SELECT 1 FROM public.profiles
  WHERE id = auth.uid() AND role = 'admin'
)
ORDER BY p.created_at DESC;
$function$;

GRANT EXECUTE ON FUNCTION public.admin_list_users() TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_set_user_role(
  p_user_id uuid,
  p_role text,
  p_premium_expires_at timestamptz DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  target_email text;
  new_expires timestamptz;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  IF p_role NOT IN ('free', 'premium', 'admin') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;
  -- Protect main admin account from being downgraded
  SELECT u.email INTO target_email FROM auth.users u WHERE u.id = p_user_id;
  IF target_email = 'bulletrn@gmail.com' AND p_role != 'admin' THEN
    RAISE EXCEPTION 'Cannot downgrade the main admin account';
  END IF;

  -- Determine expiration date
  IF p_role = 'admin' THEN
    new_expires := NULL;
  ELSIF p_role = 'premium' THEN
    IF p_premium_expires_at IS NOT NULL THEN
      new_expires := p_premium_expires_at;
    ELSE
      new_expires := now() + interval '3 months';
    END IF;
  ELSE
    new_expires := NULL;
  END IF;

  UPDATE public.profiles
  SET role = p_role,
      subscription_status = CASE WHEN p_role IN ('premium', 'admin') THEN 'premium' ELSE 'free' END,
      premium_expires_at = new_expires,
      updated_at = now()
  WHERE id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_set_user_role(uuid, text, timestamptz) TO authenticated;

CREATE OR REPLACE FUNCTION public.expire_premium_users()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  expired_count integer;
BEGIN
  UPDATE public.profiles
  SET role = 'free',
      subscription_status = 'free',
      premium_expires_at = NULL,
      updated_at = now()
  WHERE role = 'premium'
    AND premium_expires_at IS NOT NULL
    AND premium_expires_at <= now();

  GET DIAGNOSTICS expired_count = ROW_COUNT;
  RETURN expired_count;
END;
$$;

GRANT EXECUTE ON FUNCTION public.expire_premium_users() TO authenticated;
/*
# Backfill Premium Expiration for Existing Users

1. Data Fix
- For all profiles where role = 'premium' AND premium_expires_at IS NULL:
  set premium_expires_at = now() + interval '3 months'.
- This fixes existing premium users who were showing "No expiration" on
  their profile by giving them a valid 3-month expiration from today.
- Admin accounts (role = 'admin') are left alone — they have no expiration
  by design.

2. No schema changes
- The premium_expires_at column already exists from a prior migration.

3. Important Notes
- This is a one-time data backfill.
- After this runs, every premium user will have a concrete expiration date.
- The expire_premium_users() function will automatically downgrade them
  to free when that date is reached.
*/

UPDATE public.profiles
SET premium_expires_at = now() + interval '3 months',
    updated_at = now()
WHERE role = 'premium'
  AND premium_expires_at IS NULL;
/*
# Create Community Discussion System

1. New Tables
- `community_posts` — shared posts visible to all logged-in users
  - author_id (defaults to auth.uid()), content, category, author_name, author_avatar_url, created_at
- `community_comments` — comments and replies on posts
  - post_id (FK cascade), author_id, parent_comment_id (nullable, for replies, cascade), content, author_name, author_avatar_url, created_at
- `community_likes` — one like per user per post or comment
  - post_id (nullable, cascade), comment_id (nullable, cascade), user_id, unique constraints

2. Security (RLS)
- SELECT: public to all authenticated (shared community)
- INSERT: authenticated users insert their own content (author_id defaults to auth.uid())
- DELETE: owner or admin (checks profiles.role = 'admin')

3. Indexes on created_at, post_id, and like targets

4. Realtime: add all three tables to supabase_realtime publication
*/

-- Community Posts
CREATE TABLE IF NOT EXISTS public.community_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  content text NOT NULL,
  category text NOT NULL DEFAULT 'general' CHECK (category IN ('general', 'nclex-help', 'study-tips', 'motivation')),
  author_name text NOT NULL DEFAULT '',
  author_avatar_url text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.community_posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "community_posts_select_all" ON public.community_posts;
CREATE POLICY "community_posts_select_all"
  ON public.community_posts FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "community_posts_insert_own" ON public.community_posts;
CREATE POLICY "community_posts_insert_own"
  ON public.community_posts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = author_id);

DROP POLICY IF EXISTS "community_posts_delete_own_or_admin" ON public.community_posts;
CREATE POLICY "community_posts_delete_own_or_admin"
  ON public.community_posts FOR DELETE
  TO authenticated USING (
    auth.uid() = author_id
    OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE INDEX IF NOT EXISTS idx_community_posts_created_at ON public.community_posts (created_at DESC);

-- Community Comments
CREATE TABLE IF NOT EXISTS public.community_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES public.community_posts(id) ON DELETE CASCADE,
  author_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  parent_comment_id uuid REFERENCES public.community_comments(id) ON DELETE CASCADE,
  content text NOT NULL,
  author_name text NOT NULL DEFAULT '',
  author_avatar_url text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.community_comments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "community_comments_select_all" ON public.community_comments;
CREATE POLICY "community_comments_select_all"
  ON public.community_comments FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "community_comments_insert_own" ON public.community_comments;
CREATE POLICY "community_comments_insert_own"
  ON public.community_comments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = author_id);

DROP POLICY IF EXISTS "community_comments_delete_own_or_admin" ON public.community_comments;
CREATE POLICY "community_comments_delete_own_or_admin"
  ON public.community_comments FOR DELETE
  TO authenticated USING (
    auth.uid() = author_id
    OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE INDEX IF NOT EXISTS idx_community_comments_post_id ON public.community_comments (post_id);

-- Community Likes
CREATE TABLE IF NOT EXISTS public.community_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES public.community_posts(id) ON DELETE CASCADE,
  comment_id uuid REFERENCES public.community_comments(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT community_likes_target_not_null CHECK (post_id IS NOT NULL OR comment_id IS NOT NULL),
  CONSTRAINT community_likes_unique_post UNIQUE (post_id, user_id),
  CONSTRAINT community_likes_unique_comment UNIQUE (comment_id, user_id)
);

ALTER TABLE public.community_likes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "community_like_select_all" ON public.community_likes;
CREATE POLICY "community_like_select_all"
  ON public.community_likes FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "community_like_insert_own" ON public.community_likes;
CREATE POLICY "community_like_insert_own"
  ON public.community_likes FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "community_like_delete_own" ON public.community_likes;
CREATE POLICY "community_like_delete_own"
  ON public.community_likes FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_community_likes_post_id ON public.community_likes (post_id);
CREATE INDEX IF NOT EXISTS idx_community_likes_comment_id ON public.community_likes (comment_id);

-- Realtime: use DO block to safely add tables to publication (ALTER PUBLICATION doesn't support IF NOT EXISTS)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'community_posts'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.community_posts;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'community_comments'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.community_comments;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'community_likes'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.community_likes;
  END IF;
END $$;
/*
# Add Leaderboard System

1. Purpose
- Create a secure, database-backed leaderboard that ranks all users by quiz performance.
- Rankings are computed from the existing `question_answers` table (which is RLS-locked per user).
- A SECURITY DEFINER function bypasses RLS to aggregate across ALL users, but exposes ONLY public data:
  rank, user_id, full_name, avatar_url, total_answered, total_correct, accuracy, current_streak.
  No email addresses or private account info are exposed.

2. New Function: `get_leaderboard`
- Parameters:
  - p_period (text): 'all' | 'month' | 'week' — filters answers by created_at
  - p_limit (int): max rows to return (default 50)
  - p_offset (int): pagination offset (default 0)
  - p_current_user_id (uuid): the requesting user's id, used to compute their rank even if outside the page
- Returns a table with columns:
  - rank (int) — 1-based rank within the period
  - user_id (uuid)
  - full_name (text)
  - avatar_url (text)
  - total_answered (bigint)
  - total_correct (bigint)
  - accuracy (numeric) — 0-100
  - current_streak (int) — consecutive correct answers up to the most recent answer in period
- Ranking algorithm:
  - Primary: total_correct DESC (more correct answers = higher rank)
  - Secondary: accuracy DESC (higher accuracy breaks ties)
  - Tertiary: total_answered DESC (more activity breaks remaining ties)
  - Quaternary: full_name ASC (stable alphabetical tiebreaker)
- The current user's own row is always included in results (appended at end if outside page range)
  so the UI can show "Your Rank" even when the user is not in the visible top-N.

3. New Function: `get_leaderboard_total_count`
- Parameters: p_period (text)
- Returns: total number of ranked users for the period (for pagination display)

4. Security
- Both functions are SECURITY DEFINER, owned by the postgres role, with search_path set to 'public'.
- EXECUTE granted to authenticated role only.
- The functions read from question_answers and profiles but only return public columns.
- No new tables are created — this is a read-only aggregation over existing data.

5. Performance
- Uses a CTE to compute per-user stats in one pass, then window functions for ranking.
- The period filter is applied before aggregation.
- current_streak is computed by reversing the user's answer order and counting consecutive is_correct=true.
*/

-- Helper: get total count of ranked users for a period
CREATE OR REPLACE FUNCTION public.get_leaderboard_total_count(p_period text DEFAULT 'all')
RETURNS integer
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(DISTINCT qa.user_id)::integer
  FROM question_answers qa
  WHERE CASE
    WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
    WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
    ELSE true
  END;
$$;

-- Main leaderboard function
CREATE OR REPLACE FUNCTION public.get_leaderboard(
  p_period text DEFAULT 'all',
  p_limit integer DEFAULT 50,
  p_offset integer DEFAULT 0,
  p_current_user_id uuid DEFAULT NULL
)
RETURNS TABLE (
  rank integer,
  user_id uuid,
  full_name text,
  avatar_url text,
  total_answered bigint,
  total_correct bigint,
  accuracy numeric,
  current_streak integer
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH user_stats AS (
    SELECT
      qa.user_id,
      count(*)::bigint AS total_answered,
      count(*) FILTER (WHERE qa.is_correct)::bigint AS total_correct,
      -- streak: count consecutive correct answers ending at the most recent answer
      (
        SELECT count(*)::integer
        FROM (
          SELECT
            qa2.is_correct,
            row_number() OVER (ORDER BY qa2.created_at DESC) AS rn
          FROM question_answers qa2
          WHERE qa2.user_id = qa.user_id
            AND CASE
              WHEN p_period = 'week' THEN qa2.created_at >= date_trunc('week', now())
              WHEN p_period = 'month' THEN qa2.created_at >= date_trunc('month', now())
              ELSE true
            END
        ) ranked_answers
        WHERE is_correct = true
          AND rn <= (
            SELECT count(*)::integer + 1
            FROM (
              SELECT is_correct
              FROM question_answers qa3
              WHERE qa3.user_id = qa.user_id
                AND CASE
                  WHEN p_period = 'week' THEN qa3.created_at >= date_trunc('week', now())
                  WHEN p_period = 'month' THEN qa3.created_at >= date_trunc('month', now())
                  ELSE true
                END
              ORDER BY qa3.created_at DESC
              LIMIT 1
            ) latest
          -- This subquery approach is complex; simplified below
          LIMIT 1
        )
      ) AS current_streak
    FROM question_answers qa
    WHERE CASE
      WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
      WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
      ELSE true
    END
    GROUP BY qa.user_id
  ),
  -- Simplified streak computation
  streaks AS (
    SELECT
      s.user_id,
      COALESCE((
        SELECT count(*)::integer
        FROM (
          SELECT
            qa2.is_correct,
            SUM(CASE WHEN qa2.is_correct = false THEN 1 ELSE 0 END)
              OVER (ORDER BY qa2.created_at DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS wrongs_before
          FROM question_answers qa2
          WHERE qa2.user_id = s.user_id
            AND CASE
              WHEN p_period = 'week' THEN qa2.created_at >= date_trunc('week', now())
              WHEN p_period = 'month' THEN qa2.created_at >= date_trunc('month', now())
              ELSE true
            END
        ) streak_calc
        WHERE is_correct = true AND wrongs_before = 0
      ), 0) AS current_streak
    FROM (SELECT DISTINCT user_id FROM question_answers) s
  ),
  ranked AS (
    SELECT
      ROW_NUMBER() OVER (
        ORDER BY
          us.total_correct DESC,
          CASE WHEN us.total_answered > 0 THEN us.total_correct::numeric / us.total_answered ELSE 0 END DESC,
          us.total_answered DESC,
      p.full_name ASC
      ) AS rank,
      us.user_id,
      p.full_name,
      COALESCE(p.avatar_url, '') AS avatar_url,
      us.total_answered,
      us.total_correct,
      CASE WHEN us.total_answered > 0 THEN round((us.total_correct::numeric / us.total_answered) * 100, 1) ELSE 0 END AS accuracy,
      COALESCE(sk.current_streak, 0) AS current_streak
    FROM user_stats us
    JOIN profiles p ON p.id = us.user_id
    LEFT JOIN streaks sk ON sk.user_id = us.user_id
  )
  SELECT
    r.rank,
    r.user_id,
    r.full_name,
    r.avatar_url,
    r.total_answered,
    r.total_correct,
    r.accuracy,
    r.current_streak
  FROM ranked r
  ORDER BY r.rank
  LIMIT p_limit
  OFFSET p_offset;
END;
$$;

-- Also create a function to get the current user's rank specifically
CREATE OR REPLACE FUNCTION public.get_user_rank(
  p_period text DEFAULT 'all',
  p_user_id uuid DEFAULT NULL
)
RETURNS TABLE (
  rank integer,
  user_id uuid,
  full_name text,
  avatar_url text,
  total_answered bigint,
  total_correct bigint,
  accuracy numeric,
  current_streak integer
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH user_stats AS (
    SELECT
      qa.user_id,
      count(*)::bigint AS total_answered,
      count(*) FILTER (WHERE qa.is_correct)::bigint AS total_correct
    FROM question_answers qa
    WHERE qa.user_id = p_user_id
      AND CASE
        WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
        WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
        ELSE true
      END
    GROUP BY qa.user_id
  ),
  all_stats AS (
    SELECT
      qa.user_id,
      count(*)::bigint AS total_answered,
      count(*) FILTER (WHERE qa.is_correct)::bigint AS total_correct
    FROM question_answers qa
    WHERE CASE
      WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
      WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
      ELSE true
    END
    GROUP BY qa.user_id
  ),
  ranked AS (
    SELECT
      ROW_NUMBER() OVER (
        ORDER BY
          a.total_correct DESC,
          CASE WHEN a.total_answered > 0 THEN a.total_correct::numeric / a.total_answered ELSE 0 END DESC,
          a.total_answered DESC,
          p.full_name ASC
      ) AS rank,
      a.user_id,
      p.full_name,
      COALESCE(p.avatar_url, '') AS avatar_url,
      a.total_answered,
      a.total_correct,
      CASE WHEN a.total_answered > 0 THEN round((a.total_correct::numeric / a.total_answered) * 100, 1) ELSE 0 END AS accuracy
    FROM all_stats a
    JOIN profiles p ON p.id = a.user_id
  ),
  streaks AS (
    SELECT
      COALESCE((
        SELECT count(*)::integer
        FROM (
          SELECT
            qa2.is_correct,
            SUM(CASE WHEN qa2.is_correct = false THEN 1 ELSE 0 END)
              OVER (ORDER BY qa2.created_at DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS wrongs_before
          FROM question_answers qa2
          WHERE qa2.user_id = p_user_id
            AND CASE
              WHEN p_period = 'week' THEN qa2.created_at >= date_trunc('week', now())
              WHEN p_period = 'month' THEN qa2.created_at >= date_trunc('month', now())
              ELSE true
            END
        ) streak_calc
        WHERE is_correct = true AND wrongs_before = 0
      ), 0) AS current_streak
  )
  SELECT
    r.rank,
    r.user_id,
    r.full_name,
    r.avatar_url,
    r.total_answered,
    r.total_correct,
    r.accuracy,
    s.current_streak
  FROM ranked r
  CROSS JOIN streaks s
  WHERE r.user_id = p_user_id;
END;
$$;

-- Grant execute to authenticated
GRANT EXECUTE ON FUNCTION public.get_leaderboard(text, integer, integer, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_leaderboard_total_count(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_rank(text, uuid) TO authenticated;
/*
# Fix Leaderboard Functions

Rewrites the get_leaderboard and get_user_rank functions to fix column reference ambiguity
between PL/pgSQL variables and table columns. The streak computation is simplified to use
a clean CTE approach that avoids the ambiguous `user_id` reference.
*/

-- Drop old versions
DROP FUNCTION IF EXISTS public.get_leaderboard(text, integer, integer, uuid);
DROP FUNCTION IF EXISTS public.get_user_rank(text, uuid);
DROP FUNCTION IF EXISTS public.get_leaderboard_total_count(text);

-- Total count function
CREATE OR REPLACE FUNCTION public.get_leaderboard_total_count(p_period text DEFAULT 'all')
RETURNS integer
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(DISTINCT qa.user_id)::integer
  FROM question_answers qa
  WHERE CASE
    WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
    WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
    ELSE true
  END;
$$;

-- Main leaderboard function
CREATE OR REPLACE FUNCTION public.get_leaderboard(
  p_period text DEFAULT 'all',
  p_limit integer DEFAULT 50,
  p_offset integer DEFAULT 0,
  p_current_user_id uuid DEFAULT NULL
)
RETURNS TABLE (
  rank integer,
  user_id uuid,
  full_name text,
  avatar_url text,
  total_answered bigint,
  total_correct bigint,
  accuracy numeric,
  current_streak integer
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH base_answers AS (
    SELECT
      qa.user_id AS uid,
      qa.is_correct,
      qa.created_at
    FROM question_answers qa
    WHERE CASE
      WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
      WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
      ELSE true
    END
  ),
  user_stats AS (
    SELECT
      ba.uid,
      count(*)::bigint AS total_answered,
      count(*) FILTER (WHERE ba.is_correct)::bigint AS total_correct
    FROM base_answers ba
    GROUP BY ba.uid
  ),
  -- Compute streak per user: count consecutive correct answers from the most recent backward
  user_streaks AS (
    SELECT
      uid,
      COALESCE((
        SELECT count(*)::integer
        FROM (
          SELECT
            ba2.is_correct,
            SUM(CASE WHEN ba2.is_correct = false THEN 1 ELSE 0 END)
              OVER (ORDER BY ba2.created_at DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS wrongs_before
          FROM base_answers ba2
          WHERE ba2.uid = us.uid
        ) streak_calc
        WHERE is_correct = true AND wrongs_before = 0
      ), 0) AS current_streak
    FROM user_stats us
  ),
  ranked AS (
    SELECT
      ROW_NUMBER() OVER (
        ORDER BY
          us.total_correct DESC,
          CASE WHEN us.total_answered > 0 THEN us.total_correct::numeric / us.total_answered ELSE 0 END DESC,
          us.total_answered DESC,
          p.full_name ASC
      ) AS rank,
      us.uid AS user_id,
      p.full_name,
      COALESCE(p.avatar_url, '') AS avatar_url,
      us.total_answered,
      us.total_correct,
      CASE WHEN us.total_answered > 0 THEN round((us.total_correct::numeric / us.total_answered) * 100, 1) ELSE 0 END AS accuracy,
      COALESCE(sk.current_streak, 0) AS current_streak
    FROM user_stats us
    JOIN profiles p ON p.id = us.uid
    LEFT JOIN user_streaks sk ON sk.uid = us.uid
  )
  SELECT
    r.rank,
    r.user_id,
    r.full_name,
    r.avatar_url,
    r.total_answered,
    r.total_correct,
    r.accuracy,
    r.current_streak
  FROM ranked r
  ORDER BY r.rank
  LIMIT p_limit
  OFFSET p_offset;
END;
$$;

-- Get current user's rank specifically
CREATE OR REPLACE FUNCTION public.get_user_rank(
  p_period text DEFAULT 'all',
  p_user_id uuid DEFAULT NULL
)
RETURNS TABLE (
  rank integer,
  user_id uuid,
  full_name text,
  avatar_url text,
  total_answered bigint,
  total_correct bigint,
  accuracy numeric,
  current_streak integer
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH base_answers AS (
    SELECT
      qa.user_id AS uid,
      qa.is_correct,
      qa.created_at
    FROM question_answers qa
    WHERE CASE
      WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
      WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
      ELSE true
    END
  ),
  user_stats AS (
    SELECT
      ba.uid,
      count(*)::bigint AS total_answered,
      count(*) FILTER (WHERE ba.is_correct)::bigint AS total_correct
    FROM base_answers ba
    GROUP BY ba.uid
  ),
  user_streaks AS (
    SELECT
      uid,
      COALESCE((
        SELECT count(*)::integer
        FROM (
          SELECT
            ba2.is_correct,
            SUM(CASE WHEN ba2.is_correct = false THEN 1 ELSE 0 END)
              OVER (ORDER BY ba2.created_at DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS wrongs_before
          FROM base_answers ba2
          WHERE ba2.uid = us.uid
        ) streak_calc
        WHERE is_correct = true AND wrongs_before = 0
      ), 0) AS current_streak
    FROM user_stats us
  ),
  ranked AS (
    SELECT
      ROW_NUMBER() OVER (
        ORDER BY
          a.total_correct DESC,
          CASE WHEN a.total_answered > 0 THEN a.total_correct::numeric / a.total_answered ELSE 0 END DESC,
          a.total_answered DESC,
          p.full_name ASC
      ) AS rank,
      a.uid AS user_id,
      p.full_name,
      COALESCE(p.avatar_url, '') AS avatar_url,
      a.total_answered,
      a.total_correct,
      CASE WHEN a.total_answered > 0 THEN round((a.total_correct::numeric / a.total_answered) * 100, 1) ELSE 0 END AS accuracy,
      COALESCE(sk.current_streak, 0) AS current_streak
    FROM user_stats a
    JOIN profiles p ON p.id = a.uid
    LEFT JOIN user_streaks sk ON sk.uid = a.uid
  )
  SELECT
    r.rank,
    r.user_id,
    r.full_name,
    r.avatar_url,
    r.total_answered,
    r.total_correct,
    r.accuracy,
    r.current_streak
  FROM ranked r
  WHERE r.user_id = p_user_id;
END;
$$;

-- Grant execute to authenticated
GRANT EXECUTE ON FUNCTION public.get_leaderboard(text, integer, integer, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_leaderboard_total_count(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_rank(text, uuid) TO authenticated;
/*
# Fix rank column type in leaderboard functions

ROW_NUMBER() returns bigint, but the function return type declares rank as integer.
Cast rank to integer in both functions.
*/

DROP FUNCTION IF EXISTS public.get_leaderboard(text, integer, integer, uuid);
DROP FUNCTION IF EXISTS public.get_user_rank(text, uuid);

CREATE OR REPLACE FUNCTION public.get_leaderboard(
  p_period text DEFAULT 'all',
  p_limit integer DEFAULT 50,
  p_offset integer DEFAULT 0,
  p_current_user_id uuid DEFAULT NULL
)
RETURNS TABLE (
  rank integer,
  user_id uuid,
  full_name text,
  avatar_url text,
  total_answered bigint,
  total_correct bigint,
  accuracy numeric,
  current_streak integer
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH base_answers AS (
    SELECT qa.user_id AS uid, qa.is_correct, qa.created_at
    FROM question_answers qa
    WHERE CASE
      WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
      WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
      ELSE true
    END
  ),
  user_stats AS (
    SELECT ba.uid, count(*)::bigint AS total_answered,
           count(*) FILTER (WHERE ba.is_correct)::bigint AS total_correct
    FROM base_answers ba GROUP BY ba.uid
  ),
  user_streaks AS (
    SELECT uid, COALESCE((
      SELECT count(*)::integer FROM (
        SELECT ba2.is_correct,
          SUM(CASE WHEN ba2.is_correct = false THEN 1 ELSE 0 END)
            OVER (ORDER BY ba2.created_at DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS wrongs_before
        FROM base_answers ba2 WHERE ba2.uid = us.uid
      ) streak_calc WHERE is_correct = true AND wrongs_before = 0
    ), 0) AS current_streak
    FROM user_stats us
  ),
  ranked AS (
    SELECT
      ROW_NUMBER() OVER (
        ORDER BY us.total_correct DESC,
          CASE WHEN us.total_answered > 0 THEN us.total_correct::numeric / us.total_answered ELSE 0 END DESC,
          us.total_answered DESC, p.full_name ASC
      )::integer AS rank,
      us.uid AS user_id, p.full_name, COALESCE(p.avatar_url, '') AS avatar_url,
      us.total_answered, us.total_correct,
      CASE WHEN us.total_answered > 0 THEN round((us.total_correct::numeric / us.total_answered) * 100, 1) ELSE 0 END AS accuracy,
      COALESCE(sk.current_streak, 0) AS current_streak
    FROM user_stats us
    JOIN profiles p ON p.id = us.uid
    LEFT JOIN user_streaks sk ON sk.uid = us.uid
  )
  SELECT r.rank, r.user_id, r.full_name, r.avatar_url,
         r.total_answered, r.total_correct, r.accuracy, r.current_streak
  FROM ranked r ORDER BY r.rank LIMIT p_limit OFFSET p_offset;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_user_rank(
  p_period text DEFAULT 'all',
  p_user_id uuid DEFAULT NULL
)
RETURNS TABLE (
  rank integer,
  user_id uuid,
  full_name text,
  avatar_url text,
  total_answered bigint,
  total_correct bigint,
  accuracy numeric,
  current_streak integer
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH base_answers AS (
    SELECT qa.user_id AS uid, qa.is_correct, qa.created_at
    FROM question_answers qa
    WHERE CASE
      WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
      WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
      ELSE true
    END
  ),
  user_stats AS (
    SELECT ba.uid, count(*)::bigint AS total_answered,
           count(*) FILTER (WHERE ba.is_correct)::bigint AS total_correct
    FROM base_answers ba GROUP BY ba.uid
  ),
  user_streaks AS (
    SELECT uid, COALESCE((
      SELECT count(*)::integer FROM (
        SELECT ba2.is_correct,
          SUM(CASE WHEN ba2.is_correct = false THEN 1 ELSE 0 END)
            OVER (ORDER BY ba2.created_at DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS wrongs_before
        FROM base_answers ba2 WHERE ba2.uid = us.uid
      ) streak_calc WHERE is_correct = true AND wrongs_before = 0
    ), 0) AS current_streak
    FROM user_stats us
  ),
  ranked AS (
    SELECT
      ROW_NUMBER() OVER (
        ORDER BY a.total_correct DESC,
          CASE WHEN a.total_answered > 0 THEN a.total_correct::numeric / a.total_answered ELSE 0 END DESC,
          a.total_answered DESC, p.full_name ASC
      )::integer AS rank,
      a.uid AS user_id, p.full_name, COALESCE(p.avatar_url, '') AS avatar_url,
      a.total_answered, a.total_correct,
      CASE WHEN a.total_answered > 0 THEN round((a.total_correct::numeric / a.total_answered) * 100, 1) ELSE 0 END AS accuracy,
      COALESCE(sk.current_streak, 0) AS current_streak
    FROM user_stats a
    JOIN profiles p ON p.id = a.uid
    LEFT JOIN user_streaks sk ON sk.uid = a.uid
  )
  SELECT r.rank, r.user_id, r.full_name, r.avatar_url,
         r.total_answered, r.total_correct, r.accuracy, r.current_streak
  FROM ranked r WHERE r.user_id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_leaderboard(text, integer, integer, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_rank(text, uuid) TO authenticated;
/*
# Add NCLEX Application Process System

1. New Table: `nclex_application_pages`
- Stores editable content for each state/territory NCLEX application guide.
- `id` (text, primary key) — slug used in routes: 'new-york', 'illinois', 'cnmi'
- `title` (text) — display name, e.g. "New York"
- `subtitle` (text) — e.g. "For Filipino Nurses"
- `description` (text) — short card description
- `introduction` (text) — longer intro for the detail page
- `steps` (jsonb) — array of step objects: { number, title, description, checklist: string[], link_url, link_label }
- `info_cards` (jsonb) — array of card objects: { title, items: string[] }
- `official_links` (jsonb) — array of { label, url }
- `is_published` (boolean, default true) — admin can unpublish
- `created_at`, `updated_at` (timestamptz)

2. Security (RLS)
- SELECT: public to all authenticated users (only published pages visible to non-admins; admins see all)
- INSERT/UPDATE/DELETE: admin only (checks profiles.role = 'admin')

3. Seed Data
- Three rows: new-york, illinois, cnmi — with full step-by-step content, info cards, and official links.
*/

CREATE TABLE IF NOT EXISTS public.nclex_application_pages (
  id text PRIMARY KEY,
  title text NOT NULL,
  subtitle text NOT NULL DEFAULT 'For Filipino Nurses',
  description text NOT NULL DEFAULT '',
  introduction text NOT NULL DEFAULT '',
  steps jsonb NOT NULL DEFAULT '[]'::jsonb,
  info_cards jsonb NOT NULL DEFAULT '[]'::jsonb,
  official_links jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.nclex_application_pages ENABLE ROW LEVEL SECURITY;

-- All authenticated users can read published pages
DROP POLICY IF EXISTS "nclex_pages_select_published" ON public.nclex_application_pages;
CREATE POLICY "nclex_pages_select_published"
  ON public.nclex_application_pages FOR SELECT
  TO authenticated USING (
    is_published = true
    OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Only admins can insert
DROP POLICY IF EXISTS "nclex_pages_insert_admin" ON public.nclex_application_pages;
CREATE POLICY "nclex_pages_insert_admin"
  ON public.nclex_application_pages FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Only admins can update
DROP POLICY IF EXISTS "nclex_pages_update_admin" ON public.nclex_application_pages;
CREATE POLICY "nclex_pages_update_admin"
  ON public.nclex_application_pages FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Only admins can delete
DROP POLICY IF EXISTS "nclex_pages_delete_admin" ON public.nclex_application_pages;
CREATE POLICY "nclex_pages_delete_admin"
  ON public.nclex_application_pages FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Seed: New York
INSERT INTO public.nclex_application_pages (id, title, subtitle, description, introduction, steps, info_cards, official_links, is_published)
VALUES (
  'new-york',
  'New York',
  'For Filipino Nurses',
  'Complete guide to obtaining your NY RN license and taking the NCLEX-RN as a Philippine-educated nurse.',
  'The New York State Education Department (NYSED) oversees RN licensure. Filipino nurses must meet coursework, credentialing, and exam requirements before practicing in New York.',
  '[
    {"number": 1, "title": "Check NYSED Eligibility Requirements", "description": "Review the NYSED eligibility criteria for foreign-educated nurses before starting your application.", "checklist": ["Verify your nursing program is comparable to a NY RN program", "Confirm you meet English proficiency requirements"], "link_url": "https://www.op.nysed.gov/professions/nursing", "link_label": "NYSED Nursing Page"},
    {"number": 2, "title": "Complete NYSED-Required Coursework", "description": "New York requires specific coursework that may not be included in your Philippine nursing curriculum.", "checklist": ["Infection Control & Barrier Precautions", "Child Abuse Identification & Reporting"], "link_url": "", "link_label": ""},
    {"number": 3, "title": "Apply to NYSED", "description": "Submit your application for RN licensure to the New York State Education Department.", "checklist": ["Complete Form 1 (Application for Licensure)", "Pay the application fee", "Submit all required forms"], "link_url": "https://www.op.nysed.gov/professions/nursing/how-to-apply-for-a-license", "link_label": "How to Apply"},
    {"number": 4, "title": "Complete Foreign Education Requirements", "description": "Have your credentials evaluated to confirm your Philippine nursing education meets NY standards.", "checklist": ["Use a NYSED-approved credentials verification service (e.g. CGFNS)", "Submit transcripts from your Philippine nursing school"], "link_url": "https://www.op.nysed.gov/professions/nursing/foreign-educated-applicants", "link_label": "Foreign Educated Applicants"},
    {"number": 5, "title": "Submit Verification of Philippine RN License", "description": "NYSED requires verification of your current Philippine nursing license.", "checklist": ["Request license verification from the Philippine PRC", "Ensure verification is sent directly to NYSED"], "link_url": "", "link_label": ""},
    {"number": 6, "title": "Register for the NCLEX-RN Exam through Pearson VUE", "description": "Once NYSED confirms your eligibility, register for the NCLEX-RN exam with Pearson VUE.", "checklist": ["Create a Pearson VUE account", "Pay the NCLEX registration fee", "Select New York as your licensing jurisdiction"], "link_url": "https://www.pearsonvue.com/nclex", "link_label": "Pearson VUE NCLEX"},
    {"number": 7, "title": "Receive Authorization to Test (ATT)", "description": "After NYSED and Pearson VUE process your registration, you will receive your Authorization to Test.", "checklist": ["Check your email for ATT", "Verify all details on the ATT are correct"], "link_url": "", "link_label": ""},
    {"number": 8, "title": "Schedule the NCLEX-RN Exam", "description": "Use your ATT to schedule your exam date at a Pearson VUE testing center.", "checklist": ["Choose a testing center location", "Select an available date within your ATT validity period"], "link_url": "https://www.pearsonvue.com/nclex", "link_label": "Schedule Exam"},
    {"number": 9, "title": "Prepare for the NCLEX-RN Exam", "description": "Study thoroughly using review courses, practice questions, and NCLEX prep materials.", "checklist": ["Use BulletRN QBanks for practice questions", "Review weak subject areas", "Take full-length practice exams"], "link_url": "", "link_label": ""},
    {"number": 10, "title": "Take the NCLEX-RN Exam", "description": "Arrive at your testing center on your scheduled date with proper identification.", "checklist": ["Bring valid government-issued ID", "Arrive 30 minutes early", "Complete the exam within the time limit"], "link_url": "", "link_label": ""},
    {"number": 11, "title": "Get Your Results / Q-POP", "description": "New York uses the Quick Results service. You may also need to complete the Q-POP (Qualifying Passport to Practice) requirements.", "checklist": ["Check official results via Pearson VUE Quick Results (48 hours)", "Complete any NYSED post-exam requirements"], "link_url": "https://www.nclex.com", "link_label": "NCLEX Results"},
    {"number": 12, "title": "NYSED Completes Licensing Processing", "description": "After you pass the NCLEX-RN, NYSED processes your license. You will appear on the NYSED verification site once licensed.", "checklist": ["Wait for NYSED to issue your RN license number", "Verify your license online via NYSED"], "link_url": "https://www.op.nysed.gov/professions/nursing/verify-a-license", "link_label": "Verify License"}
  ]'::jsonb,
  '[
    {"title": "NYSED Requirements Overview", "items": ["Foreign-educated nurses must have credentials evaluated by a NYSED-approved service", "Required coursework: Infection Control & Barrier Precautions, Child Abuse Identification & Reporting", "Philippine RN license must be active and verified", "English proficiency may be required"]},
    {"title": "Required Documents", "items": ["Completed Form 1 (Application for Licensure)", "Official transcripts from Philippine nursing school", "Credential evaluation report", "Philippine PRC license verification", "Proof of completed required coursework", "Passport-size photo (if requested)"]},
    {"title": "Fees Summary", "items": ["Application fee: ~$143 (subject to change)", "NCLEX-RN registration fee: $200 (Pearson VUE)", "Credential evaluation fee: varies by service (~$300-$500)", "Quick Results fee: $7.95 (optional)"]},
    {"title": "Tips for Success", "items": ["Start the credential evaluation early — it can take months", "Complete required NY coursework online before applying", "Double-check all forms before submission to avoid delays", "Use BulletRN QBanks daily for NCLEX prep", "Join the BulletRN Community for peer support"]}
  ]'::jsonb,
  '[
    {"label": "NYSED Nursing Page", "url": "https://www.op.nysed.gov/professions/nursing"},
    {"label": "Pearson VUE NCLEX", "url": "https://www.pearsonvue.com/nclex"},
    {"label": "NYSED License Verification", "url": "https://www.op.nysed.gov/professions/nursing/verify-a-license"}
  ]'::jsonb,
  true
) ON CONFLICT (id) DO NOTHING;

-- Seed: Illinois
INSERT INTO public.nclex_application_pages (id, title, subtitle, description, introduction, steps, info_cards, official_links, is_published)
VALUES (
  'illinois',
  'Illinois',
  'For Filipino Nurses',
  'Step-by-step guide to Illinois RN licensure for Philippine-educated nurses, including CGFNS credential evaluation.',
  'The Illinois Department of Financial and Professional Regulation (IDFPR) handles RN licensure. Foreign-educated nurses must complete a credential evaluation through CGFNS before applying for licensure and taking the NCLEX-RN.',
  '[
    {"number": 1, "title": "Meet Illinois Eligibility Requirements", "description": "Review the IDFPR requirements for foreign-educated nurses applying for Illinois RN licensure.", "checklist": ["Verify your Philippine nursing program meets Illinois standards", "Confirm you hold a current Philippine RN license"], "link_url": "https://idfpr.illinois.gov/profs/nursing.html", "link_label": "IDFPR Nursing"},
    {"number": 2, "title": "Get Credential Evaluation (CGFNS)", "description": "Illinois requires foreign-educated nurses to have credentials evaluated by CGFNS or a approved evaluation service.", "checklist": ["Apply for CGFNS Certification Program or VisaScreen", "Submit transcripts and license verification to CGFNS", "Receive CGFNS credential report"], "link_url": "https://www.cgfns.org", "link_label": "CGFNS Website"},
    {"number": 3, "title": "Prepare and Submit Required Documents", "description": "Gather all necessary documents for your Illinois licensure application.", "checklist": ["Official transcripts from Philippine nursing school", "CGFNS credential evaluation report", "Philippine PRC license verification", "Passport copy", "Completed application forms"], "link_url": "", "link_label": ""},
    {"number": 4, "title": "Apply for Illinois Licensure", "description": "Submit your application to the IDFPR along with all required documents and fees.", "checklist": ["Complete the Illinois RN application", "Pay the application fee", "Submit all supporting documents"], "link_url": "https://idfpr.illinois.gov/profs/nursing.html", "link_label": "Apply for Illinois RN"},
    {"number": 5, "title": "Schedule and Take the NCLEX-RN Exam", "description": "Once IDFPR approves your eligibility, register with Pearson VUE and schedule your exam.", "checklist": ["Register with Pearson VUE for NCLEX-RN", "Pay the NCLEX registration fee", "Receive your Authorization to Test (ATT)", "Schedule your exam date"], "link_url": "https://www.pearsonvue.com/nclex", "link_label": "Pearson VUE"},
    {"number": 6, "title": "Take and Pass the NCLEX-RN Exam", "description": "Arrive at the testing center prepared and complete the NCLEX-RN exam.", "checklist": ["Bring valid government-issued ID", "Arrive early at the testing center", "Complete the exam within the time limit"], "link_url": "", "link_label": ""},
    {"number": 7, "title": "Receive / Complete the RN Licensure Process", "description": "After passing the NCLEX-RN, IDFPR processes your license. You will receive your Illinois RN license number.", "checklist": ["Wait for IDFPR to issue your license", "Verify your license on the IDFPR website"], "link_url": "https://idfpr.illinois.gov/profs/nursing.html", "link_label": "Verify Illinois License"}
  ]'::jsonb,
  '[
    {"title": "Estimated Costs", "items": ["Application fee: ~$100 (subject to change)", "CGFNS credential evaluation: ~$300-$500", "NCLEX-RN registration: $200 (Pearson VUE)", "Additional document authentication fees may apply"]},
    {"title": "Processing Time", "items": ["CGFNS evaluation: 3-6 months", "IDFPR application review: 4-8 weeks after complete submission", "Total estimated time: 6-12 months from start to license"]},
    {"title": "Where to Authenticate Documents", "items": ["Philippine PRC for RN license verification", "Philippine school for official transcripts", "CGFNS for credential evaluation", "DFA red ribbon (apostille) for document authentication"]},
    {"title": "NCLEX Waiting Time", "items": ["ATT typically issued 2-4 weeks after eligibility confirmed", "Exam can be scheduled within 90 days of ATT issuance", "Quick Results available in 48 hours after exam"]},
    {"title": "Results", "items": ["Official results sent by IDFPR after passing", "Quick Results available via Pearson VUE for $7.95", "License number issued after IDFPR processes results"]},
    {"title": "Tips for a Smooth Process", "items": ["Start CGFNS evaluation as early as possible", "Ensure all documents are properly authenticated", "Keep copies of everything you submit", "Use BulletRN QBanks for consistent NCLEX practice", "Check your application status regularly online"]}
  ]'::jsonb,
  '[
    {"label": "IDFPR Nursing", "url": "https://idfpr.illinois.gov/profs/nursing.html"},
    {"label": "CGFNS International", "url": "https://www.cgfns.org"},
    {"label": "Pearson VUE NCLEX", "url": "https://www.pearsonvue.com/nclex"}
  ]'::jsonb,
  true
) ON CONFLICT (id) DO NOTHING;

-- Seed: CNMI
INSERT INTO public.nclex_application_pages (id, title, subtitle, description, introduction, steps, info_cards, official_links, is_published)
VALUES (
  'cnmi',
  'Northern Mariana Islands (CNMI)',
  'For Filipino Nurses',
  'Guide to CNMI RN licensure for Philippine-educated nurses, including online application and NCLEX-RN scheduling.',
  'The Commonwealth of the Northern Mariana Islands (CNMI) Board of Nursing regulates RN licensure. The process is fully online and is a popular pathway for Filipino nurses seeking US licensure.',
  '[
    {"number": 1, "title": "Check Eligibility for CNMI RN License", "description": "Review the CNMI Board of Nursing eligibility requirements for foreign-educated nurses.", "checklist": ["Verify your Philippine nursing program meets CNMI standards", "Confirm you hold a current Philippine RN license", "Check English proficiency requirements"], "link_url": "https://cnmiboardofnursing.gov", "link_label": "CNMI Board of Nursing"},
    {"number": 2, "title": "Prepare Required Documents", "description": "Gather all documents needed for your CNMI RN license application.", "checklist": ["Official transcripts from Philippine nursing school", "Philippine PRC license verification", "Passport copy", "Passport-size photos", "Credential evaluation (if required)"], "link_url": "", "link_label": ""},
    {"number": 3, "title": "Create Online Application", "description": "Register an account on the CNMI Board of Nursing online portal.", "checklist": ["Visit the CNMI Board of Nursing website", "Create a new applicant account", "Fill out the online application form"], "link_url": "https://cnmiboardofnursing.gov", "link_label": "CNMI Online Portal"},
    {"number": 4, "title": "Submit Application", "description": "Complete and submit your online application with all required documents uploaded.", "checklist": ["Upload all required documents", "Review your application for accuracy", "Submit the application"], "link_url": "", "link_label": ""},
    {"number": 5, "title": "Pay Application Fee", "description": "Pay the required application fee through the online portal.", "checklist": ["Pay application fee online", "Save your payment confirmation"], "link_url": "", "link_label": ""},
    {"number": 6, "title": "Wait for Evaluation", "description": "The CNMI Board of Nursing reviews your application and documents. This may take several weeks.", "checklist": ["Monitor your email for updates", "Respond promptly to any requests for additional information"], "link_url": "", "link_label": ""},
    {"number": 7, "title": "Receive Authorization to Schedule NCLEX", "description": "Once approved, you will receive authorization to register for the NCLEX-RN through Pearson VUE.", "checklist": ["Register with Pearson VUE", "Pay the NCLEX registration fee", "Receive your Authorization to Test (ATT)"], "link_url": "https://www.pearsonvue.com/nclex", "link_label": "Pearson VUE"},
    {"number": 8, "title": "Schedule and Take the NCLEX-RN Exam", "description": "Use your ATT to schedule and take the NCLEX-RN at a Pearson VUE testing center.", "checklist": ["Choose a testing center", "Schedule your exam date", "Bring valid ID and arrive early", "Complete the exam"], "link_url": "https://www.pearsonvue.com/nclex", "link_label": "Schedule NCLEX"}
  ]'::jsonb,
  '[
    {"title": "Official Website", "items": ["CNMI Board of Nursing: https://cnmiboardofnursing.gov", "All applications are submitted online", "Contact the board via the online portal for questions"]},
    {"title": "Estimated Waiting Time", "items": ["Application evaluation: 4-8 weeks", "NCLEX ATT issuance: 2-4 weeks after approval", "Total estimated time: 3-6 months from start to exam"]},
    {"title": "Key Requirements Summary", "items": ["Philippine nursing degree", "Active Philippine PRC RN license", "English proficiency", "Complete online application", "Pass the NCLEX-RN exam"]},
    {"title": "Important Notes", "items": ["CNMI is a US territory — licensure is valid within CNMI", "Verify if CNMI license is endorsable to other US states", "Keep all original documents for future reference", "Use BulletRN QBanks for NCLEX preparation"]}
  ]'::jsonb,
  '[
    {"label": "CNMI Board of Nursing", "url": "https://cnmiboardofnursing.gov"},
    {"label": "Pearson VUE NCLEX", "url": "https://www.pearsonvue.com/nclex"}
  ]'::jsonb,
  true
) ON CONFLICT (id) DO NOTHING;
/*
# Add subject count functions for accurate question counts

## Problem
The frontend fetches all question rows to count them client-side, but Supabase's
default row limit is 1000. With 1394+ questions, some subjects get incorrect counts
or disappear entirely. This migration adds server-side functions that return accurate
counts regardless of row count.

## Changes
1. New function `get_subject_question_counts()` — returns one row per subject_id
   with the total question count. SECURITY DEFINER so it bypasses RLS safely
   (questions are already publicly readable via anon_select_questions policy).
2. New function `get_category_question_counts()` — returns one row per category
   with the total question count, for the Practice/Create Test modal.

## Security
- Both functions are SECURITY DEFINER, owned by the postgres role.
- They only SELECT from the questions table, which already has a public SELECT policy.
- EXECUTE is granted to anon and authenticated so the frontend can call them.
*/

CREATE OR REPLACE FUNCTION public.get_subject_question_counts()
RETURNS TABLE (subject_id text, total bigint)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT subject_id, COUNT(*)::bigint AS total
  FROM public.questions
  WHERE subject_id IS NOT NULL
  GROUP BY subject_id;
$$;

GRANT EXECUTE ON FUNCTION public.get_subject_question_counts() TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.get_category_question_counts()
RETURNS TABLE (category text, total bigint)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT category, COUNT(*)::bigint AS total
  FROM public.questions
  WHERE category IS NOT NULL
  GROUP BY category;
$$;

GRANT EXECUTE ON FUNCTION public.get_category_question_counts() TO anon, authenticated;
/*
# Add user subject answer stats function

## Purpose
Returns per-subject answer statistics for the current authenticated user:
- subject_id
- answered count (total questions answered)
- correct count (correctly answered questions)

This bypasses the Supabase 1000-row default limit and runs server-side for accuracy.

## Security
- SECURITY DEFINER, owned by postgres.
- Uses auth.uid() to filter to the current user's answers only.
- EXECUTE granted to authenticated (the only role that has answers).
*/

CREATE OR REPLACE FUNCTION public.get_user_subject_answer_stats()
RETURNS TABLE (subject_id text, answered bigint, correct bigint)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT subject_id,
         COUNT(*)::bigint AS answered,
         COUNT(*) FILTER (WHERE is_correct)::bigint AS correct
  FROM public.question_answers
  WHERE user_id = auth.uid()
    AND subject_id IS NOT NULL
  GROUP BY subject_id;
$$;

GRANT EXECUTE ON FUNCTION public.get_user_subject_answer_stats() TO authenticated;
/*
# Create Study Guide system (subjects, topics, user progress)

## Purpose
A standalone NCLEX Study Guide / blueprint section that helps students understand
WHAT to study for each NCLEX subject. This is completely separate from the Practice
question system — no question counts, no mastery from quiz answers.

## New Tables

1. `study_guide_subjects`
   - `id` (text, primary key) — e.g. 'pharmacology', 'medsurg'
   - `name` (text) — display name e.g. 'Pharmacology'
   - `slug` (text, unique) — URL slug e.g. 'pharmacology'
   - `description` (text) — short description shown on card
   - `accent_color` (text) — hex color for card styling
   - `icon` (text) — icon key from lucide
   - `sort_order` (int) — display order
   - `created_at`, `updated_at`

2. `study_guide_topics`
   - `id` (uuid, primary key)
   - `subject_id` (text, FK to study_guide_subjects.id)
   - `title` (text) — e.g. 'Cardiovascular Medications'
   - `description` (text) — short overview
   - `key_concepts` (text[]) — important concepts to study
   - `nursing_considerations` (text[]) — key nursing considerations
   - `sort_order` (int)
   - `created_at`, `updated_at`

3. `study_guide_progress`
   - `id` (uuid, primary key)
   - `user_id` (uuid, NOT NULL, DEFAULT auth.uid())
   - `topic_id` (uuid, FK to study_guide_topics.id)
   - `studied` (boolean, default false)
   - `studied_at` (timestamptz, nullable)
   - `created_at`, `updated_at`
   - UNIQUE(user_id, topic_id)

## Security
- `study_guide_subjects` and `study_guide_topics`: public read (anon + authenticated),
  no public write — admin manages content via service role or admin UI.
- `study_guide_progress`: owner-scoped CRUD for authenticated users only.
*/

-- Subjects table
CREATE TABLE IF NOT EXISTS public.study_guide_subjects (
  id text PRIMARY KEY,
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text NOT NULL DEFAULT '',
  accent_color text NOT NULL DEFAULT '#3b82f6',
  icon text NOT NULL DEFAULT 'book-open',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.study_guide_subjects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sg_subjects_select_all" ON public.study_guide_subjects;
CREATE POLICY "sg_subjects_select_all" ON public.study_guide_subjects
  FOR SELECT TO anon, authenticated USING (true);

-- Topics table
CREATE TABLE IF NOT EXISTS public.study_guide_topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id text NOT NULL REFERENCES public.study_guide_subjects(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  key_concepts text[] NOT NULL DEFAULT '{}',
  nursing_considerations text[] NOT NULL DEFAULT '{}',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.study_guide_topics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sg_topics_select_all" ON public.study_guide_topics;
CREATE POLICY "sg_topics_select_all" ON public.study_guide_topics
  FOR SELECT TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_sg_topics_subject ON public.study_guide_topics(subject_id);

-- Progress table
CREATE TABLE IF NOT EXISTS public.study_guide_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  topic_id uuid NOT NULL REFERENCES public.study_guide_topics(id) ON DELETE CASCADE,
  studied boolean NOT NULL DEFAULT false,
  studied_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, topic_id)
);

ALTER TABLE public.study_guide_progress ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sg_progress_select_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_select_own" ON public.study_guide_progress
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "sg_progress_insert_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_insert_own" ON public.study_guide_progress
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "sg_progress_update_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_update_own" ON public.study_guide_progress
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "sg_progress_delete_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_delete_own" ON public.study_guide_progress
  FOR DELETE TO authenticated USING (auth.uid() = user_id);
/*
# Add Analytics Functions and Free User Question Limit

## Purpose
Provides server-side functions to compute real per-user analytics from
the question_answers and quiz_attempts tables, plus a function to count
a user's total answered questions for the 50-question free-user limit.

## New Functions

1. `get_user_answered_count()` — Returns total number of questions the
   current user has answered (from question_answers). Used for the
   50-question free-user limit.

2. `get_user_dashboard_stats()` — Returns a single row with:
   - total_answered: total questions answered
   - total_correct: total correct answers
   - accuracy: percentage correct (0 if no answers)
   - today_answered: questions answered today
   - today_correct: correct answers today
   - study_time_seconds: total time spent across all answers
   - current_streak: consecutive days with at least 1 answered question
   - recent_score: average score of last 5 completed quiz attempts
   - overall_mastery: weighted accuracy across all answers

3. `get_user_score_history(p_limit int default 20)` — Returns recent
   completed quiz attempts with score and completed_at, oldest first,
   for plotting score trend charts.

4. `get_user_weekly_activity()` — Returns last 7 days of question
   counts (answered + correct) per day, for the weekly activity chart.

5. `get_user_subject_performance()` — Returns per-subject stats
   (answered, correct, mastery %) for the current user, joined with
   question counts per subject for the weak spots radial chart.

## Security
All functions use auth.uid() and are SECURITY DEFINER only where
necessary. They are callable by authenticated users and return only
the calling user's own data.

## Notes
- All counts come from question_answers (actual submissions), not
  from demo/hardcoded data.
- New accounts with no answers will get zeros and empty arrays.
- No tables or columns are created or modified.
*/

-- 1. Total answered questions for free-user limit
CREATE OR REPLACE FUNCTION public.get_user_answered_count()
RETURNS bigint
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COUNT(*)::bigint
  FROM public.question_answers
  WHERE user_id = auth.uid();
$$;

-- 2. Dashboard stats (single row)
CREATE OR REPLACE FUNCTION public.get_user_dashboard_stats()
RETURNS TABLE(
  total_answered bigint,
  total_correct bigint,
  accuracy numeric,
  today_answered bigint,
  today_correct bigint,
  study_time_seconds bigint,
  current_streak integer,
  recent_score numeric,
  overall_mastery numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_total_answered bigint;
  v_total_correct bigint;
  v_today_answered bigint;
  v_today_correct bigint;
  v_study_time bigint;
  v_streak integer := 0;
  v_recent_score numeric := 0;
  v_mastery numeric := 0;
  v_answered_days date[];
  v_today date := current_date;
  v_day date;
  v_has_activity boolean;
BEGIN
  -- Total answered and correct
  SELECT COUNT(*), COUNT(*) FILTER (WHERE is_correct)
  INTO v_total_answered, v_total_correct
  FROM public.question_answers
  WHERE user_id = auth.uid();

  -- Today's stats
  SELECT COUNT(*), COUNT(*) FILTER (WHERE is_correct)
  INTO v_today_answered, v_today_correct
  FROM public.question_answers
  WHERE user_id = auth.uid()
  AND created_at >= current_date AND created_at < current_date + 1;

  -- Total study time
  SELECT COALESCE(SUM(time_spent_seconds), 0)
  INTO v_study_time
  FROM public.question_answers
  WHERE user_id = auth.uid();

  -- Streak: consecutive days with at least 1 answer, counting back from today
  SELECT array_agg(DISTINCT created_at::date) INTO v_answered_days
  FROM public.question_answers
  WHERE user_id = auth.uid();

  IF v_answered_days IS NOT NULL THEN
    v_day := v_today;
    LOOP
      v_has_activity := v_day = ANY(v_answered_days);
      IF v_has_activity THEN
        v_streak := v_streak + 1;
        v_day := v_day - 1;
      ELSE
        EXIT;
      END IF;
    END LOOP;
  END IF;

  -- Recent score: avg score of last 5 completed attempts
  SELECT COALESCE(AVG(score), 0)
  INTO v_recent_score
  FROM (
    SELECT score
    FROM public.quiz_attempts
    WHERE user_id = auth.uid()
    AND completed = true
    ORDER BY completed_at DESC
    LIMIT 5
  ) sub;

  -- Overall mastery: accuracy as a percentage
  IF v_total_answered > 0 THEN
    v_mastery := ROUND((v_total_correct::numeric / v_total_answered::numeric) * 100, 1);
  END IF;

  RETURN QUERY
  SELECT
    v_total_answered,
    v_total_correct,
    CASE WHEN v_total_answered > 0 THEN ROUND((v_total_correct::numeric / v_total_answered::numeric) * 100, 1) ELSE 0 END,
    v_today_answered,
    v_today_correct,
    v_study_time,
    v_streak,
    v_recent_score,
    v_mastery;
END;
$$;

-- 3. Score history from completed quiz attempts
CREATE OR REPLACE FUNCTION public.get_user_score_history(p_limit int DEFAULT 20)
RETURNS TABLE(
  attempt_id uuid,
  score numeric,
  completed_at timestamptz,
  total_questions int,
  correct_count int,
  label text
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    id,
    score,
    completed_at,
    total_questions,
    correct_count,
    TO_CHAR(completed_at, 'MM/DD') AS label
  FROM public.quiz_attempts
  WHERE user_id = auth.uid()
  AND completed = true
  ORDER BY completed_at DESC
  LIMIT p_limit;
$$;

-- 4. Weekly activity (last 7 days)
CREATE OR REPLACE FUNCTION public.get_user_weekly_activity()
RETURNS TABLE(
  day_label text,
  day_date date,
  answered bigint,
  correct bigint
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  WITH days AS (
    SELECT generate_series(
      current_date - 6,
      current_date,
      '1 day'::interval
    )::date AS d
  )
  SELECT
    TO_CHAR(days.d, 'Dy') AS day_label,
    days.d AS day_date,
    COALESCE(cnt.answered, 0) AS answered,
    COALESCE(cnt.correct, 0) AS correct
  FROM days
  LEFT JOIN LATERAL (
    SELECT
      COUNT(*)::bigint AS answered,
      COUNT(*) FILTER (WHERE is_correct)::bigint AS correct
    FROM public.question_answers
    WHERE user_id = auth.uid()
    AND created_at::date = days.d
  ) cnt ON true
  ORDER BY days.d;
$$;

-- 5. Subject performance for weak spots
CREATE OR REPLACE FUNCTION public.get_user_subject_performance()
RETURNS TABLE(
  subject_id text,
  subject_name text,
  answered bigint,
  correct bigint,
  mastery numeric,
  total_questions bigint
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    sq.subject_id,
    sq.subject_name,
    COALESCE(ua.answered, 0) AS answered,
    COALESCE(ua.correct, 0) AS correct,
    CASE
      WHEN COALESCE(ua.answered, 0) > 0
      THEN ROUND((COALESCE(ua.correct, 0)::numeric / ua.answered::numeric) * 100, 1)
      ELSE 0
    END AS mastery,
    sq.total_questions
  FROM (
    SELECT subject_id, subject_name, COUNT(*)::bigint AS total_questions
    FROM public.questions
    WHERE subject_id IS NOT NULL
    GROUP BY subject_id, subject_name
  ) sq
  LEFT JOIN LATERAL (
    SELECT
      COUNT(*)::bigint AS answered,
      COUNT(*) FILTER (WHERE is_correct)::bigint AS correct
    FROM public.question_answers
    WHERE user_id = auth.uid()
    AND subject_id = sq.subject_id
  ) ua ON true
  ORDER BY sq.subject_id;
$$;

-- Grant execute to authenticated
GRANT EXECUTE ON FUNCTION public.get_user_answered_count() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_dashboard_stats() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_score_history(int) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_weekly_activity() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_subject_performance() TO authenticated;
/*
# Free User Question Assignment System

## Purpose
Assigns exactly 50 randomly-selected questions to each free user.
The assignments persist until an admin resets them or the user upgrades.
This enforces the limit at the database level — free users can never
access questions outside their assigned set.

## Tables
- free_question_assignments: stores (user_id, question_id) pairs

## Functions
- get_free_user_question_ids(): returns the 50 assigned question_ids
  for the current user. Auto-creates assignments if none exist yet.
- reset_free_user_questions(p_target_uid uuid): admin-only — deletes
  and re-creates 50 random assignments for a given user.

## Security
- RLS enabled: users can only see their own assignments
- reset function is SECURITY DEFINER, callable only by admin role
- get function is SECURITY DEFINER, callable by authenticated
*/

CREATE TABLE IF NOT EXISTS public.free_question_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  question_id text NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, question_id)
);

ALTER TABLE public.free_question_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_assignments"
  ON public.free_question_assignments FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "insert_own_assignments"
  ON public.free_question_assignments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "delete_own_assignments"
  ON public.free_question_assignments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Returns the 50 assigned question IDs for the current user.
-- Auto-creates assignments if none exist yet (first access).
CREATE OR REPLACE FUNCTION public.get_free_user_question_ids()
RETURNS TABLE(question_id text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count integer;
  v_role text;
BEGIN
  SELECT role INTO v_role FROM public.profiles WHERE id = auth.uid();
  IF v_role IS NULL OR v_role = 'free' THEN
    SELECT COUNT(*) INTO v_count
    FROM public.free_question_assignments
    WHERE user_id = auth.uid();

    IF v_count = 0 THEN
      INSERT INTO public.free_question_assignments (user_id, question_id)
      SELECT auth.uid(), q.id
      FROM public.questions q
      ORDER BY random()
      LIMIT 50;
    END IF;

    RETURN QUERY
      SELECT question_id FROM public.free_question_assignments
      WHERE user_id = auth.uid();
  ELSE
    -- Premium/admin: return NULL set (caller will fetch all questions)
    RETURN;
  END IF;
END;
$$;

-- Admin-only: resets a user's 50 assigned questions to a new random set
CREATE OR REPLACE FUNCTION public.reset_free_user_questions(p_target_uid uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller_role text;
BEGIN
  SELECT role INTO v_caller_role FROM public.profiles WHERE id = auth.uid();
  IF v_caller_role IS NULL OR v_caller_role <> 'admin' THEN
    RAISE EXCEPTION 'Only admins can reset free user question assignments';
  END IF;

  DELETE FROM public.free_question_assignments WHERE user_id = p_target_uid;

  INSERT INTO public.free_question_assignments (user_id, question_id)
  SELECT p_target_uid, q.id
  FROM public.questions q
  ORDER BY random()
  LIMIT 50;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_free_user_question_ids() TO authenticated;
GRANT EXECUTE ON FUNCTION public.reset_free_user_questions(uuid) TO authenticated;
CREATE OR REPLACE FUNCTION public.get_subject_name_question_counts()
RETURNS TABLE(subject_name text, total bigint)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT subject_name, COUNT(*)::bigint AS total
  FROM public.questions
  WHERE subject_name IS NOT NULL
  GROUP BY subject_name;
$$;/*
# Add the Smart Learning Hub data layer

1. New Tables
- `daily_challenges` stores one user's selected question IDs for each calendar day, so refreshes do not generate a new challenge.
- `learning_activity` stores real study activity by user and date for streaks and active-day counts.
- `user_xp` stores the user's durable XP total.
- `xp_events` stores idempotent XP awards so refreshes and retries cannot award the same event twice.
- `user_achievements` stores achievement keys and unlock timestamps per user.

2. Modified Tables
- `bookmarks.category` records whether a saved question is Important, Confusing, or Review Later.

3. Security
- Every new table has RLS enabled.
- Authenticated users can only read and write their own rows.
- XP awards and daily challenge creation run through SECURITY DEFINER functions that derive the user from auth.uid().
- Anonymous users cannot execute the learning functions.

4. Important Notes
- Daily challenges reference existing question IDs only; no question text is copied.
- XP values are fixed inside the database function rather than trusted from the browser.
- All writes use the authenticated user's session identity and are safe to retry.
*/

ALTER TABLE public.bookmarks
  ADD COLUMN IF NOT EXISTS category text NOT NULL DEFAULT 'Important';

CREATE TABLE IF NOT EXISTS public.daily_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  challenge_date date NOT NULL DEFAULT CURRENT_DATE,
  question_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  completed boolean NOT NULL DEFAULT false,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, challenge_date)
);

CREATE TABLE IF NOT EXISTS public.learning_activity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  activity_date date NOT NULL DEFAULT CURRENT_DATE,
  questions_answered integer NOT NULL DEFAULT 0,
  challenge_completed boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, activity_date)
);

CREATE TABLE IF NOT EXISTS public.user_xp (
  user_id uuid PRIMARY KEY DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  total_xp integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.xp_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  event_key text NOT NULL,
  event_type text NOT NULL,
  xp_awarded integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, event_key)
);

CREATE TABLE IF NOT EXISTS public.user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  achievement_key text NOT NULL,
  unlocked_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, achievement_key)
);

ALTER TABLE public.daily_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.learning_activity ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_xp ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.xp_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_daily_challenges" ON public.daily_challenges;
CREATE POLICY "select_own_daily_challenges" ON public.daily_challenges FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_daily_challenges" ON public.daily_challenges;
CREATE POLICY "insert_own_daily_challenges" ON public.daily_challenges FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_daily_challenges" ON public.daily_challenges;
CREATE POLICY "update_own_daily_challenges" ON public.daily_challenges FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_daily_challenges" ON public.daily_challenges;
CREATE POLICY "delete_own_daily_challenges" ON public.daily_challenges FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_own_learning_activity" ON public.learning_activity;
CREATE POLICY "select_own_learning_activity" ON public.learning_activity FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_learning_activity" ON public.learning_activity;
CREATE POLICY "insert_own_learning_activity" ON public.learning_activity FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_learning_activity" ON public.learning_activity;
CREATE POLICY "update_own_learning_activity" ON public.learning_activity FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_learning_activity" ON public.learning_activity;
CREATE POLICY "delete_own_learning_activity" ON public.learning_activity FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_own_user_xp" ON public.user_xp;
CREATE POLICY "select_own_user_xp" ON public.user_xp FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_user_xp" ON public.user_xp;
CREATE POLICY "insert_own_user_xp" ON public.user_xp FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_user_xp" ON public.user_xp;
CREATE POLICY "update_own_user_xp" ON public.user_xp FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_user_xp" ON public.user_xp;
CREATE POLICY "delete_own_user_xp" ON public.user_xp FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_own_xp_events" ON public.xp_events;
CREATE POLICY "select_own_xp_events" ON public.xp_events FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_xp_events" ON public.xp_events;
CREATE POLICY "insert_own_xp_events" ON public.xp_events FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_xp_events" ON public.xp_events;
CREATE POLICY "update_own_xp_events" ON public.xp_events FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_xp_events" ON public.xp_events;
CREATE POLICY "delete_own_xp_events" ON public.xp_events FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_own_user_achievements" ON public.user_achievements;
CREATE POLICY "select_own_user_achievements" ON public.user_achievements FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_user_achievements" ON public.user_achievements;
CREATE POLICY "insert_own_user_achievements" ON public.user_achievements FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_user_achievements" ON public.user_achievements;
CREATE POLICY "update_own_user_achievements" ON public.user_achievements FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_user_achievements" ON public.user_achievements;
CREATE POLICY "delete_own_user_achievements" ON public.user_achievements FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS daily_challenges_user_date_idx ON public.daily_challenges(user_id, challenge_date DESC);
CREATE INDEX IF NOT EXISTS learning_activity_user_date_idx ON public.learning_activity(user_id, activity_date DESC);
CREATE INDEX IF NOT EXISTS user_achievements_user_idx ON public.user_achievements(user_id);

CREATE OR REPLACE FUNCTION public.get_or_create_daily_challenge()
RETURNS TABLE(id uuid, challenge_date date, question_ids jsonb, completed boolean)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
  v_existing public.daily_challenges%ROWTYPE;
  v_limit integer := 10;
  v_answered integer;
  v_role text;
  v_ids jsonb;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  SELECT * INTO v_existing FROM public.daily_challenges WHERE user_id = v_user AND challenge_date = CURRENT_DATE;
  IF v_existing.id IS NOT NULL THEN
    RETURN QUERY SELECT v_existing.id, v_existing.challenge_date, v_existing.question_ids, v_existing.completed;
    RETURN;
  END IF;

  SELECT role INTO v_role FROM public.profiles WHERE profiles.id = v_user;
  IF v_role = 'free' THEN
    SELECT COUNT(*) INTO v_answered FROM public.question_answers WHERE question_answers.user_id = v_user;
    v_limit := GREATEST(0, LEAST(10, 50 - v_answered));
  END IF;
  IF v_limit = 0 THEN
    RETURN;
  END IF;

  SELECT COALESCE(jsonb_agg(id), '[]'::jsonb) INTO v_ids
  FROM (SELECT q.id FROM public.questions q ORDER BY random() LIMIT v_limit) selected;

  INSERT INTO public.daily_challenges (user_id, challenge_date, question_ids)
  VALUES (v_user, CURRENT_DATE, v_ids)
  ON CONFLICT (user_id, challenge_date) DO NOTHING
  RETURNING daily_challenges.id, daily_challenges.challenge_date, daily_challenges.question_ids, daily_challenges.completed
  INTO v_existing.id, v_existing.challenge_date, v_existing.question_ids, v_existing.completed;

  IF v_existing.id IS NULL THEN
    SELECT * INTO v_existing FROM public.daily_challenges WHERE user_id = v_user AND challenge_date = CURRENT_DATE;
  END IF;
  RETURN QUERY SELECT v_existing.id, v_existing.challenge_date, v_existing.question_ids, v_existing.completed;
END;
$$;

CREATE OR REPLACE FUNCTION public.complete_daily_challenge(p_challenge_id uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE v_user uuid := auth.uid(); v_updated boolean;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  UPDATE public.daily_challenges
  SET completed = true, completed_at = now()
  WHERE id = p_challenge_id AND user_id = v_user AND challenge_date = CURRENT_DATE AND completed = false;
  v_updated := FOUND;
  IF v_updated THEN
    INSERT INTO public.learning_activity (user_id, activity_date, challenge_completed)
    VALUES (v_user, CURRENT_DATE, true)
    ON CONFLICT (user_id, activity_date) DO UPDATE SET challenge_completed = true;
  END IF;
  RETURN v_updated;
END;
$$;

CREATE OR REPLACE FUNCTION public.record_learning_activity(p_questions integer DEFAULT 0)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE v_user uuid := auth.uid();
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  IF p_questions < 0 OR p_questions > 1000 THEN RAISE EXCEPTION 'Invalid activity count'; END IF;
  INSERT INTO public.learning_activity (user_id, activity_date, questions_answered)
  VALUES (v_user, CURRENT_DATE, p_questions)
  ON CONFLICT (user_id, activity_date) DO UPDATE
  SET questions_answered = learning_activity.questions_answered + EXCLUDED.questions_answered;
END;
$$;

CREATE OR REPLACE FUNCTION public.award_learning_event(p_event_key text, p_event_type text)
RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE v_user uuid := auth.uid(); v_xp integer;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  v_xp := CASE p_event_type WHEN 'correct_answer' THEN 10 WHEN 'practice_complete' THEN 25 WHEN 'daily_challenge' THEN 50 WHEN 'streak_7' THEN 100 ELSE 0 END;
  IF v_xp = 0 OR length(p_event_key) = 0 OR length(p_event_key) > 200 THEN RAISE EXCEPTION 'Invalid learning event'; END IF;
  INSERT INTO public.xp_events (user_id, event_key, event_type, xp_awarded)
  VALUES (v_user, p_event_key, p_event_type, v_xp)
  ON CONFLICT (user_id, event_key) DO NOTHING;
  IF FOUND THEN
    INSERT INTO public.user_xp (user_id, total_xp) VALUES (v_user, v_xp)
    ON CONFLICT (user_id) DO UPDATE SET total_xp = user_xp.total_xp + EXCLUDED.total_xp, updated_at = now();
    RETURN v_xp;
  END IF;
  RETURN 0;
END;
$$;

REVOKE ALL ON FUNCTION public.get_or_create_daily_challenge() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_or_create_daily_challenge() TO authenticated;
REVOKE ALL ON FUNCTION public.complete_daily_challenge(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.complete_daily_challenge(uuid) TO authenticated;
REVOKE ALL ON FUNCTION public.record_learning_activity(integer) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.record_learning_activity(integer) TO authenticated;
REVOKE ALL ON FUNCTION public.award_learning_event(text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.award_learning_event(text, text) TO authenticated;/*
# Add server-side achievement synchronization

1. Functions
- `sync_learning_achievements` checks real completed attempts, answer history, streak activity, and Pharmacology answers.

2. Security
- The function derives the caller from auth.uid().
- It writes only the caller's achievements and is executable by authenticated users only.

3. Important Notes
- Achievement unlocks are idempotent and keep their original unlock timestamp.
- No achievement is inserted until its real activity threshold is met.
*/

CREATE OR REPLACE FUNCTION public.sync_learning_achievements()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
  v_answered integer;
  v_pharma_answered integer;
  v_pharma_correct integer;
  v_streak integer := 0;
  v_day date;
  v_previous date;
  v_started boolean := false;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;

  IF EXISTS (SELECT 1 FROM public.quiz_attempts WHERE user_id = v_user AND completed = true) THEN
    INSERT INTO public.user_achievements (user_id, achievement_key) VALUES (v_user, 'first_steps') ON CONFLICT DO NOTHING;
  END IF;

  IF EXISTS (SELECT 1 FROM public.quiz_attempts WHERE user_id = v_user AND completed = true AND score >= 90) THEN
    INSERT INTO public.user_achievements (user_id, achievement_key) VALUES (v_user, 'sharp_shooter') ON CONFLICT DO NOTHING;
  END IF;

  SELECT COUNT(*) INTO v_answered FROM public.question_answers WHERE user_id = v_user;
  IF v_answered >= 100 THEN
    INSERT INTO public.user_achievements (user_id, achievement_key) VALUES (v_user, 'century') ON CONFLICT DO NOTHING;
  END IF;

  SELECT COUNT(*), COUNT(*) FILTER (WHERE is_correct) INTO v_pharma_answered, v_pharma_correct
  FROM public.question_answers WHERE user_id = v_user AND subject_id = 'pharmacology';
  IF v_pharma_answered >= 10 AND v_pharma_correct::numeric / v_pharma_answered >= 0.85 THEN
    INSERT INTO public.user_achievements (user_id, achievement_key) VALUES (v_user, 'pharma_master') ON CONFLICT DO NOTHING;
  END IF;

  FOR v_day IN SELECT activity_date FROM public.learning_activity WHERE user_id = v_user ORDER BY activity_date DESC LOOP
    IF NOT v_started THEN
      v_streak := 1;
      v_previous := v_day;
      v_started := true;
    ELSIF v_previous - v_day = 1 THEN
      v_streak := v_streak + 1;
      v_previous := v_day;
    ELSE
      EXIT;
    END IF;
  END LOOP;
  IF v_streak >= 7 THEN
    INSERT INTO public.user_achievements (user_id, achievement_key) VALUES (v_user, 'on_fire') ON CONFLICT DO NOTHING;
    PERFORM public.award_learning_event('streak:' || v_previous::text, 'streak_7');
  END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.sync_learning_achievements() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.sync_learning_achievements() TO authenticated;/*
# Grant authenticated read access to private learning summaries

1. Access
- Authenticated users can read their own rows through RLS.
- Client writes continue through the controlled SECURITY DEFINER functions.

2. Security
- Grants do not bypass RLS; every table remains owner-scoped by its policies.
*/

GRANT SELECT ON public.daily_challenges TO authenticated;
GRANT SELECT ON public.learning_activity TO authenticated;
GRANT SELECT ON public.user_xp TO authenticated;
GRANT SELECT ON public.xp_events TO authenticated;
GRANT SELECT ON public.user_achievements TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bookmarks TO authenticated;/*
# Lock server-owned learning progress fields

1. Access
- Browsers can read their own progress through RLS.
- XP totals, XP events, achievements, activity, and daily challenge completion are written only by controlled database functions.

2. Security
- Removes direct authenticated INSERT, UPDATE, and DELETE grants from server-owned tables.
- Existing owner policies remain as defense in depth.
*/

REVOKE INSERT, UPDATE, DELETE ON public.daily_challenges FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.learning_activity FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.user_xp FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.xp_events FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.user_achievements FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.bookmarks FROM anon;
REVOKE SELECT ON public.daily_challenges, public.learning_activity, public.user_xp, public.xp_events, public.user_achievements FROM anon;