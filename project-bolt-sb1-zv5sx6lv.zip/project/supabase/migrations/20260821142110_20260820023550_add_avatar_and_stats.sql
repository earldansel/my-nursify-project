-- Add avatar_url column to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS avatar_url text DEFAULT '';

-- Create a function to get user study statistics
CREATE OR REPLACE FUNCTION public.get_user_stats()
RETURNS TABLE (
  total_questions_answered bigint,
  total_correct bigint,
  total_tests_completed bigint,
  current_streak integer,
  best_streak integer,
  avg_accuracy numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_total_questions bigint;
  v_total_correct bigint;
  v_total_tests bigint;
  v_current_streak integer := 0;
  v_best_streak integer := 0;
  v_accuracy numeric := 0;
  v_last_test_date date;
  v_today date := current_date;
  v_check_date date;
  v_streak_active boolean := true;
BEGIN
  IF v_user_id IS NULL THEN
    RETURN QUERY SELECT 0::bigint, 0::bigint, 0::bigint, 0, 0, 0::numeric;
    RETURN;
  END IF;

  SELECT COUNT(*) INTO v_total_questions
  FROM public.question_answers WHERE user_id = v_user_id;

  SELECT COUNT(*) INTO v_total_correct
  FROM public.question_answers WHERE user_id = v_user_id AND is_correct = true;

  SELECT COUNT(*) INTO v_total_tests
  FROM public.quiz_attempts WHERE user_id = v_user_id AND completed = true;

  IF v_total_questions > 0 THEN
    v_accuracy := ROUND((v_total_correct::numeric / v_total_questions::numeric) * 100, 1);
  END IF;

  IF v_total_tests > 0 THEN
    FOR v_check_date IN
      SELECT DISTINCT DATE(completed_at)
      FROM public.quiz_attempts
      WHERE user_id = v_user_id AND completed = true AND completed_at IS NOT NULL
      ORDER BY DATE(completed_at) DESC
    LOOP
      IF v_streak_active THEN
        IF v_check_date = v_today THEN
          v_current_streak := v_current_streak + 1;
          v_today := v_today - 1;
        ELSIF v_check_date = v_today - 1 THEN
          v_current_streak := v_current_streak + 1;
          v_today := v_check_date - 1;
        ELSE
          v_streak_active := false;
        END IF;
      END IF;
    END LOOP;
    v_best_streak := v_current_streak;
  END IF;

  RETURN QUERY SELECT COALESCE(v_total_questions, 0), COALESCE(v_total_correct, 0), COALESCE(v_total_tests, 0), v_current_streak, v_best_streak, v_accuracy;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_user_stats() TO authenticated;