-- Smart Learning Hub data layer
ALTER TABLE public.bookmarks ADD COLUMN IF NOT EXISTS category text NOT NULL DEFAULT 'Important';

CREATE TABLE IF NOT EXISTS public.daily_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  challenge_date date NOT NULL DEFAULT CURRENT_DATE,
  question_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  completed boolean NOT NULL DEFAULT false,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, challenge_date)
);
CREATE TABLE IF NOT EXISTS public.learning_activity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  activity_date date NOT NULL DEFAULT CURRENT_DATE,
  questions_answered integer NOT NULL DEFAULT 0,
  challenge_completed boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, activity_date)
);
CREATE TABLE IF NOT EXISTS public.user_xp (
  user_id uuid PRIMARY KEY DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  total_xp integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.xp_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  event_key text NOT NULL,
  event_type text NOT NULL,
  xp_awarded integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, event_key)
);
CREATE TABLE IF NOT EXISTS public.user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  achievement_key text NOT NULL,
  unlocked_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, achievement_key)
);

ALTER TABLE public.daily_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.learning_activity ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_xp ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.xp_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_daily_challenges" ON public.daily_challenges;
CREATE POLICY "select_own_daily_challenges" ON public.daily_challenges FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_daily_challenges" ON public.daily_challenges;
CREATE POLICY "insert_own_daily_challenges" ON public.daily_challenges FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_daily_challenges" ON public.daily_challenges;
CREATE POLICY "update_own_daily_challenges" ON public.daily_challenges FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_daily_challenges" ON public.daily_challenges;
CREATE POLICY "delete_own_daily_challenges" ON public.daily_challenges FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_own_learning_activity" ON public.learning_activity;
CREATE POLICY "select_own_learning_activity" ON public.learning_activity FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_learning_activity" ON public.learning_activity;
CREATE POLICY "insert_own_learning_activity" ON public.learning_activity FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_learning_activity" ON public.learning_activity;
CREATE POLICY "update_own_learning_activity" ON public.learning_activity FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_learning_activity" ON public.learning_activity;
CREATE POLICY "delete_own_learning_activity" ON public.learning_activity FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_own_user_xp" ON public.user_xp;
CREATE POLICY "select_own_user_xp" ON public.user_xp FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_user_xp" ON public.user_xp;
CREATE POLICY "insert_own_user_xp" ON public.user_xp FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_user_xp" ON public.user_xp;
CREATE POLICY "update_own_user_xp" ON public.user_xp FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_user_xp" ON public.user_xp;
CREATE POLICY "delete_own_user_xp" ON public.user_xp FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_own_xp_events" ON public.xp_events;
CREATE POLICY "select_own_xp_events" ON public.xp_events FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_xp_events" ON public.xp_events;
CREATE POLICY "insert_own_xp_events" ON public.xp_events FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_xp_events" ON public.xp_events;
CREATE POLICY "update_own_xp_events" ON public.xp_events FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_xp_events" ON public.xp_events;
CREATE POLICY "delete_own_xp_events" ON public.xp_events FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_own_user_achievements" ON public.user_achievements;
CREATE POLICY "select_own_user_achievements" ON public.user_achievements FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_user_achievements" ON public.user_achievements;
CREATE POLICY "insert_own_user_achievements" ON public.user_achievements FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_user_achievements" ON public.user_achievements;
CREATE POLICY "update_own_user_achievements" ON public.user_achievements FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_user_achievements" ON public.user_achievements;
CREATE POLICY "delete_own_user_achievements" ON public.user_achievements FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS daily_challenges_user_date_idx ON public.daily_challenges(user_id, challenge_date DESC);
CREATE INDEX IF NOT EXISTS learning_activity_user_date_idx ON public.learning_activity(user_id, activity_date DESC);
CREATE INDEX IF NOT EXISTS user_achievements_user_idx ON public.user_achievements(user_id);

CREATE OR REPLACE FUNCTION public.get_or_create_daily_challenge()
RETURNS TABLE(id uuid, challenge_date date, question_ids jsonb, completed boolean)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE v_user uuid := auth.uid(); v_existing public.daily_challenges%ROWTYPE; v_limit integer := 10; v_answered integer; v_role text; v_ids jsonb;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  SELECT * INTO v_existing FROM public.daily_challenges WHERE user_id = v_user AND challenge_date = CURRENT_DATE;
  IF v_existing.id IS NOT NULL THEN RETURN QUERY SELECT v_existing.id, v_existing.challenge_date, v_existing.question_ids, v_existing.completed; RETURN; END IF;
  SELECT role INTO v_role FROM public.profiles WHERE profiles.id = v_user;
  IF v_role = 'free' THEN
    SELECT COUNT(*) INTO v_answered FROM public.question_answers WHERE question_answers.user_id = v_user;
    v_limit := GREATEST(0, LEAST(10, 50 - v_answered));
  END IF;
  IF v_limit = 0 THEN RETURN; END IF;
  SELECT COALESCE(jsonb_agg(id), '[]'::jsonb) INTO v_ids FROM (SELECT q.id FROM public.questions q ORDER BY random() LIMIT v_limit) selected;
  INSERT INTO public.daily_challenges (user_id, challenge_date, question_ids) VALUES (v_user, CURRENT_DATE, v_ids)
  ON CONFLICT (user_id, challenge_date) DO NOTHING
  RETURNING daily_challenges.id, daily_challenges.challenge_date, daily_challenges.question_ids, daily_challenges.completed INTO v_existing.id, v_existing.challenge_date, v_existing.question_ids, v_existing.completed;
  IF v_existing.id IS NULL THEN SELECT * INTO v_existing FROM public.daily_challenges WHERE user_id = v_user AND challenge_date = CURRENT_DATE; END IF;
  RETURN QUERY SELECT v_existing.id, v_existing.challenge_date, v_existing.question_ids, v_existing.completed;
END; $$;

CREATE OR REPLACE FUNCTION public.complete_daily_challenge(p_challenge_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE v_user uuid := auth.uid(); v_updated boolean;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  UPDATE public.daily_challenges SET completed = true, completed_at = now() WHERE id = p_challenge_id AND user_id = v_user AND challenge_date = CURRENT_DATE AND completed = false;
  v_updated := FOUND;
  IF v_updated THEN
    INSERT INTO public.learning_activity (user_id, activity_date, challenge_completed) VALUES (v_user, CURRENT_DATE, true)
    ON CONFLICT (user_id, activity_date) DO UPDATE SET challenge_completed = true;
  END IF;
  RETURN v_updated;
END; $$;

CREATE OR REPLACE FUNCTION public.record_learning_activity(p_questions integer DEFAULT 0)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE v_user uuid := auth.uid();
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  IF p_questions < 0 OR p_questions > 1000 THEN RAISE EXCEPTION 'Invalid activity count'; END IF;
  INSERT INTO public.learning_activity (user_id, activity_date, questions_answered) VALUES (v_user, CURRENT_DATE, p_questions)
  ON CONFLICT (user_id, activity_date) DO UPDATE SET questions_answered = learning_activity.questions_answered + EXCLUDED.questions_answered;
END; $$;

CREATE OR REPLACE FUNCTION public.award_learning_event(p_event_key text, p_event_type text)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE v_user uuid := auth.uid(); v_xp integer;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  v_xp := CASE p_event_type WHEN 'correct_answer' THEN 10 WHEN 'practice_complete' THEN 25 WHEN 'daily_challenge' THEN 50 WHEN 'streak_7' THEN 100 ELSE 0 END;
  IF v_xp = 0 OR length(p_event_key) = 0 OR length(p_event_key) > 200 THEN RAISE EXCEPTION 'Invalid learning event'; END IF;
  INSERT INTO public.xp_events (user_id, event_key, event_type, xp_awarded) VALUES (v_user, p_event_key, p_event_type, v_xp) ON CONFLICT (user_id, event_key) DO NOTHING;
  IF FOUND THEN
    INSERT INTO public.user_xp (user_id, total_xp) VALUES (v_user, v_xp) ON CONFLICT (user_id) DO UPDATE SET total_xp = user_xp.total_xp + EXCLUDED.total_xp, updated_at = now();
    RETURN v_xp;
  END IF;
  RETURN 0;
END; $$;

REVOKE ALL ON FUNCTION public.get_or_create_daily_challenge() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_or_create_daily_challenge() TO authenticated;
REVOKE ALL ON FUNCTION public.complete_daily_challenge(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.complete_daily_challenge(uuid) TO authenticated;
REVOKE ALL ON FUNCTION public.record_learning_activity(integer) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.record_learning_activity(integer) TO authenticated;
REVOKE ALL ON FUNCTION public.award_learning_event(text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.award_learning_event(text, text) TO authenticated;