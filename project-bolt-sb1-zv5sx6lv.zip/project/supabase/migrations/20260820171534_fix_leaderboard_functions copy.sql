/*
# Fix Leaderboard Functions

Rewrites the get_leaderboard and get_user_rank functions to fix column reference ambiguity
between PL/pgSQL variables and table columns. The streak computation is simplified to use
a clean CTE approach that avoids the ambiguous `user_id` reference.
*/

-- Drop old versions
DROP FUNCTION IF EXISTS public.get_leaderboard(text, integer, integer, uuid);
DROP FUNCTION IF EXISTS public.get_user_rank(text, uuid);
DROP FUNCTION IF EXISTS public.get_leaderboard_total_count(text);

-- Total count function
CREATE OR REPLACE FUNCTION public.get_leaderboard_total_count(p_period text DEFAULT 'all')
RETURNS integer
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(DISTINCT qa.user_id)::integer
  FROM question_answers qa
  WHERE CASE
    WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
    WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
    ELSE true
  END;
$$;

-- Main leaderboard function
CREATE OR REPLACE FUNCTION public.get_leaderboard(
  p_period text DEFAULT 'all',
  p_limit integer DEFAULT 50,
  p_offset integer DEFAULT 0,
  p_current_user_id uuid DEFAULT NULL
)
RETURNS TABLE (
  rank integer,
  user_id uuid,
  full_name text,
  avatar_url text,
  total_answered bigint,
  total_correct bigint,
  accuracy numeric,
  current_streak integer
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH base_answers AS (
    SELECT
      qa.user_id AS uid,
      qa.is_correct,
      qa.created_at
    FROM question_answers qa
    WHERE CASE
      WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
      WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
      ELSE true
    END
  ),
  user_stats AS (
    SELECT
      ba.uid,
      count(*)::bigint AS total_answered,
      count(*) FILTER (WHERE ba.is_correct)::bigint AS total_correct
    FROM base_answers ba
    GROUP BY ba.uid
  ),
  -- Compute streak per user: count consecutive correct answers from the most recent backward
  user_streaks AS (
    SELECT
      uid,
      COALESCE((
        SELECT count(*)::integer
        FROM (
          SELECT
            ba2.is_correct,
            SUM(CASE WHEN ba2.is_correct = false THEN 1 ELSE 0 END)
              OVER (ORDER BY ba2.created_at DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS wrongs_before
          FROM base_answers ba2
          WHERE ba2.uid = us.uid
        ) streak_calc
        WHERE is_correct = true AND wrongs_before = 0
      ), 0) AS current_streak
    FROM user_stats us
  ),
  ranked AS (
    SELECT
      ROW_NUMBER() OVER (
        ORDER BY
          us.total_correct DESC,
          CASE WHEN us.total_answered > 0 THEN us.total_correct::numeric / us.total_answered ELSE 0 END DESC,
          us.total_answered DESC,
          p.full_name ASC
      ) AS rank,
      us.uid AS user_id,
      p.full_name,
      COALESCE(p.avatar_url, '') AS avatar_url,
      us.total_answered,
      us.total_correct,
      CASE WHEN us.total_answered > 0 THEN round((us.total_correct::numeric / us.total_answered) * 100, 1) ELSE 0 END AS accuracy,
      COALESCE(sk.current_streak, 0) AS current_streak
    FROM user_stats us
    JOIN profiles p ON p.id = us.uid
    LEFT JOIN user_streaks sk ON sk.uid = us.uid
  )
  SELECT
    r.rank,
    r.user_id,
    r.full_name,
    r.avatar_url,
    r.total_answered,
    r.total_correct,
    r.accuracy,
    r.current_streak
  FROM ranked r
  ORDER BY r.rank
  LIMIT p_limit
  OFFSET p_offset;
END;
$$;

-- Get current user's rank specifically
CREATE OR REPLACE FUNCTION public.get_user_rank(
  p_period text DEFAULT 'all',
  p_user_id uuid DEFAULT NULL
)
RETURNS TABLE (
  rank integer,
  user_id uuid,
  full_name text,
  avatar_url text,
  total_answered bigint,
  total_correct bigint,
  accuracy numeric,
  current_streak integer
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH base_answers AS (
    SELECT
      qa.user_id AS uid,
      qa.is_correct,
      qa.created_at
    FROM question_answers qa
    WHERE CASE
      WHEN p_period = 'week' THEN qa.created_at >= date_trunc('week', now())
      WHEN p_period = 'month' THEN qa.created_at >= date_trunc('month', now())
      ELSE true
    END
  ),
  user_stats AS (
    SELECT
      ba.uid,
      count(*)::bigint AS total_answered,
      count(*) FILTER (WHERE ba.is_correct)::bigint AS total_correct
    FROM base_answers ba
    GROUP BY ba.uid
  ),
  user_streaks AS (
    SELECT
      uid,
      COALESCE((
        SELECT count(*)::integer
        FROM (
          SELECT
            ba2.is_correct,
            SUM(CASE WHEN ba2.is_correct = false THEN 1 ELSE 0 END)
              OVER (ORDER BY ba2.created_at DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS wrongs_before
          FROM base_answers ba2
          WHERE ba2.uid = us.uid
        ) streak_calc
        WHERE is_correct = true AND wrongs_before = 0
      ), 0) AS current_streak
    FROM user_stats us
  ),
  ranked AS (
    SELECT
      ROW_NUMBER() OVER (
        ORDER BY
          a.total_correct DESC,
          CASE WHEN a.total_answered > 0 THEN a.total_correct::numeric / a.total_answered ELSE 0 END DESC,
          a.total_answered DESC,
          p.full_name ASC
      ) AS rank,
      a.uid AS user_id,
      p.full_name,
      COALESCE(p.avatar_url, '') AS avatar_url,
      a.total_answered,
      a.total_correct,
      CASE WHEN a.total_answered > 0 THEN round((a.total_correct::numeric / a.total_answered) * 100, 1) ELSE 0 END AS accuracy,
      COALESCE(sk.current_streak, 0) AS current_streak
    FROM user_stats a
    JOIN profiles p ON p.id = a.uid
    LEFT JOIN user_streaks sk ON sk.uid = a.uid
  )
  SELECT
    r.rank,
    r.user_id,
    r.full_name,
    r.avatar_url,
    r.total_answered,
    r.total_correct,
    r.accuracy,
    r.current_streak
  FROM ranked r
  WHERE r.user_id = p_user_id;
END;
$$;

-- Grant execute to authenticated
GRANT EXECUTE ON FUNCTION public.get_leaderboard(text, integer, integer, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_leaderboard_total_count(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_rank(text, uuid) TO authenticated;
