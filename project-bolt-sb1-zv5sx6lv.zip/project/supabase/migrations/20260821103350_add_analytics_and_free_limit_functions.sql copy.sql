/*
# Add Analytics Functions and Free User Question Limit

## Purpose
Provides server-side functions to compute real per-user analytics from
the question_answers and quiz_attempts tables, plus a function to count
a user's total answered questions for the 50-question free-user limit.

## New Functions

1. `get_user_answered_count()` — Returns total number of questions the
   current user has answered (from question_answers). Used for the
   50-question free-user limit.

2. `get_user_dashboard_stats()` — Returns a single row with:
   - total_answered: total questions answered
   - total_correct: total correct answers
   - accuracy: percentage correct (0 if no answers)
   - today_answered: questions answered today
   - today_correct: correct answers today
   - study_time_seconds: total time spent across all answers
   - current_streak: consecutive days with at least 1 answered question
   - recent_score: average score of last 5 completed quiz attempts
   - overall_mastery: weighted accuracy across all answers

3. `get_user_score_history(p_limit int default 20)` — Returns recent
   completed quiz attempts with score and completed_at, oldest first,
   for plotting score trend charts.

4. `get_user_weekly_activity()` — Returns last 7 days of question
   counts (answered + correct) per day, for the weekly activity chart.

5. `get_user_subject_performance()` — Returns per-subject stats
   (answered, correct, mastery %) for the current user, joined with
   question counts per subject for the weak spots radial chart.

## Security
All functions use auth.uid() and are SECURITY DEFINER only where
necessary. They are callable by authenticated users and return only
the calling user's own data.

## Notes
- All counts come from question_answers (actual submissions), not
  from demo/hardcoded data.
- New accounts with no answers will get zeros and empty arrays.
- No tables or columns are created or modified.
*/

-- 1. Total answered questions for free-user limit
CREATE OR REPLACE FUNCTION public.get_user_answered_count()
RETURNS bigint
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COUNT(*)::bigint
  FROM public.question_answers
  WHERE user_id = auth.uid();
$$;

-- 2. Dashboard stats (single row)
CREATE OR REPLACE FUNCTION public.get_user_dashboard_stats()
RETURNS TABLE(
  total_answered bigint,
  total_correct bigint,
  accuracy numeric,
  today_answered bigint,
  today_correct bigint,
  study_time_seconds bigint,
  current_streak integer,
  recent_score numeric,
  overall_mastery numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_total_answered bigint;
  v_total_correct bigint;
  v_today_answered bigint;
  v_today_correct bigint;
  v_study_time bigint;
  v_streak integer := 0;
  v_recent_score numeric := 0;
  v_mastery numeric := 0;
  v_answered_days date[];
  v_today date := current_date;
  v_day date;
  v_has_activity boolean;
BEGIN
  -- Total answered and correct
  SELECT COUNT(*), COUNT(*) FILTER (WHERE is_correct)
  INTO v_total_answered, v_total_correct
  FROM public.question_answers
  WHERE user_id = auth.uid();

  -- Today's stats
  SELECT COUNT(*), COUNT(*) FILTER (WHERE is_correct)
  INTO v_today_answered, v_today_correct
  FROM public.question_answers
  WHERE user_id = auth.uid()
  AND created_at >= current_date AND created_at < current_date + 1;

  -- Total study time
  SELECT COALESCE(SUM(time_spent_seconds), 0)
  INTO v_study_time
  FROM public.question_answers
  WHERE user_id = auth.uid();

  -- Streak: consecutive days with at least 1 answer, counting back from today
  SELECT array_agg(DISTINCT created_at::date) INTO v_answered_days
  FROM public.question_answers
  WHERE user_id = auth.uid();

  IF v_answered_days IS NOT NULL THEN
    v_day := v_today;
    LOOP
      v_has_activity := v_day = ANY(v_answered_days);
      IF v_has_activity THEN
        v_streak := v_streak + 1;
        v_day := v_day - 1;
      ELSE
        EXIT;
      END IF;
    END LOOP;
  END IF;

  -- Recent score: avg score of last 5 completed attempts
  SELECT COALESCE(AVG(score), 0)
  INTO v_recent_score
  FROM (
    SELECT score
    FROM public.quiz_attempts
    WHERE user_id = auth.uid()
    AND completed = true
    ORDER BY completed_at DESC
    LIMIT 5
  ) sub;

  -- Overall mastery: accuracy as a percentage
  IF v_total_answered > 0 THEN
    v_mastery := ROUND((v_total_correct::numeric / v_total_answered::numeric) * 100, 1);
  END IF;

  RETURN QUERY
  SELECT
    v_total_answered,
    v_total_correct,
    CASE WHEN v_total_answered > 0 THEN ROUND((v_total_correct::numeric / v_total_answered::numeric) * 100, 1) ELSE 0 END,
    v_today_answered,
    v_today_correct,
    v_study_time,
    v_streak,
    v_recent_score,
    v_mastery;
END;
$$;

-- 3. Score history from completed quiz attempts
CREATE OR REPLACE FUNCTION public.get_user_score_history(p_limit int DEFAULT 20)
RETURNS TABLE(
  attempt_id uuid,
  score numeric,
  completed_at timestamptz,
  total_questions int,
  correct_count int,
  label text
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    id,
    score,
    completed_at,
    total_questions,
    correct_count,
    TO_CHAR(completed_at, 'MM/DD') AS label
  FROM public.quiz_attempts
  WHERE user_id = auth.uid()
  AND completed = true
  ORDER BY completed_at DESC
  LIMIT p_limit;
$$;

-- 4. Weekly activity (last 7 days)
CREATE OR REPLACE FUNCTION public.get_user_weekly_activity()
RETURNS TABLE(
  day_label text,
  day_date date,
  answered bigint,
  correct bigint
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  WITH days AS (
    SELECT generate_series(
      current_date - 6,
      current_date,
      '1 day'::interval
    )::date AS d
  )
  SELECT
    TO_CHAR(days.d, 'Dy') AS day_label,
    days.d AS day_date,
    COALESCE(cnt.answered, 0) AS answered,
    COALESCE(cnt.correct, 0) AS correct
  FROM days
  LEFT JOIN LATERAL (
    SELECT
      COUNT(*)::bigint AS answered,
      COUNT(*) FILTER (WHERE is_correct)::bigint AS correct
    FROM public.question_answers
    WHERE user_id = auth.uid()
    AND created_at::date = days.d
  ) cnt ON true
  ORDER BY days.d;
$$;

-- 5. Subject performance for weak spots
CREATE OR REPLACE FUNCTION public.get_user_subject_performance()
RETURNS TABLE(
  subject_id text,
  subject_name text,
  answered bigint,
  correct bigint,
  mastery numeric,
  total_questions bigint
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    sq.subject_id,
    sq.subject_name,
    COALESCE(ua.answered, 0) AS answered,
    COALESCE(ua.correct, 0) AS correct,
    CASE
      WHEN COALESCE(ua.answered, 0) > 0
      THEN ROUND((COALESCE(ua.correct, 0)::numeric / ua.answered::numeric) * 100, 1)
      ELSE 0
    END AS mastery,
    sq.total_questions
  FROM (
    SELECT subject_id, subject_name, COUNT(*)::bigint AS total_questions
    FROM public.questions
    WHERE subject_id IS NOT NULL
    GROUP BY subject_id, subject_name
  ) sq
  LEFT JOIN LATERAL (
    SELECT
      COUNT(*)::bigint AS answered,
      COUNT(*) FILTER (WHERE is_correct)::bigint AS correct
    FROM public.question_answers
    WHERE user_id = auth.uid()
    AND subject_id = sq.subject_id
  ) ua ON true
  ORDER BY sq.subject_id;
$$;

-- Grant execute to authenticated
GRANT EXECUTE ON FUNCTION public.get_user_answered_count() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_dashboard_stats() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_score_history(int) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_weekly_activity() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_subject_performance() TO authenticated;
