/*
# Seed PNLE Study Guide — 5 Nursing Practice Areas

1. Purpose
Creates the PNLE study guide content with 5 Nursing Practice areas (NP I-V),
each with multiple study topics covering the Philippine Nurse Licensure Examination scope.

2. Data
- study_guide_subjects: 5 NP areas (NP I through NP V)
- study_guide_topics: Multiple topics per NP area with key concepts and nursing considerations

3. Important Notes
- All subjects and topics are tagged with exam_track = 'pnle'
- This data is separate from any NCLEX study guide content
- Topics include key_concepts and nursing_considerations arrays for rich study content
*/

-- NP I — Community Health Nursing
INSERT INTO public.study_guide_subjects (id, name, slug, description, accent_color, icon, sort_order, exam_track)
VALUES ('np1-community-health', 'NP I — Community Health Nursing', 'np1-community-health',
'Community health, primary health care, epidemiology, family and community assessment, health programs, environmental health, and disaster nursing.',
'#0891b2', 'heart-pulse', 1, 'pnle')
ON CONFLICT (id) DO NOTHING;

-- NP II — Maternal and Child Nursing
INSERT INTO public.study_guide_subjects (id, name, slug, description, accent_color, icon, sort_order, exam_track)
VALUES ('np2-maternal-child', 'NP II — Maternal and Child Nursing', 'np2-maternal-child',
'Maternal nursing, pregnancy, labor and delivery, postpartum care, newborn care, pediatric nursing, and growth and development.',
'#db2777', 'baby', 2, 'pnle')
ON CONFLICT (id) DO NOTHING;

-- NP III — Medical-Surgical Nursing
INSERT INTO public.study_guide_subjects (id, name, slug, description, accent_color, icon, sort_order, exam_track)
VALUES ('np3-medsurg', 'NP III — Medical-Surgical Nursing', 'np3-medsurg',
'Perioperative care, respiratory, cardiovascular, fluids and electrolytes, acid-base balance, infectious, immunologic, and oncologic conditions.',
'#7c3aed', 'stethoscope', 3, 'pnle')
ON CONFLICT (id) DO NOTHING;

-- NP IV — Medical-Surgical and Specialized Nursing
INSERT INTO public.study_guide_subjects (id, name, slug, description, accent_color, icon, sort_order, exam_track)
VALUES ('np4-specialized', 'NP IV — Medical-Surgical and Specialized Nursing', 'np4-specialized',
'Nutrition, gastrointestinal, endocrine, metabolic, renal, neurologic, sensory, mobility, and related nursing concepts.',
'#ea580c', 'activity', 4, 'pnle')
ON CONFLICT (id) DO NOTHING;

-- NP V — Mental Health, Critical Care and Emergency Nursing
INSERT INTO public.study_guide_subjects (id, name, slug, description, accent_color, icon, sort_order, exam_track)
VALUES ('np5-mental-critical', 'NP V — Mental Health, Critical Care and Emergency Nursing', 'np5-mental-critical',
'Psychiatric nursing, crisis intervention, critical care, emergency nursing, shock, and high-acuity nursing care.',
'#dc2626', 'brain', 5, 'pnle')
ON CONFLICT (id) DO NOTHING;

-- NP I Topics
INSERT INTO public.study_guide_topics (subject_id, title, description, key_concepts, nursing_considerations, sort_order) VALUES
('np1-community-health', 'Primary Health Care', 'Principles and strategies of primary health care in the Philippines.', ARRAY['Definition and principles of PHC', 'Levels of health care: primary, secondary, tertiary', 'Barangay Health Worker roles', 'Essential health services package'], ARRAY['Community participation is essential', 'Use of appropriate technology', 'Self-reliance and sustainability', 'Intersectoral collaboration'], 1),
('np1-community-health', 'Epidemiology', 'Study of disease distribution and determinants in populations.', ARRAY['Epidemiological triad: agent, host, environment', 'Modes of transmission', 'Incidence vs prevalence', 'Endemic, epidemic, pandemic, sporadic'], ARRAY['Surveillance and reporting systems', 'Outbreak investigation steps', 'Prevention levels: primary, secondary, tertiary', 'Immunization as primary prevention'], 2),
('np1-community-health', 'Family Health', 'Family assessment and health care delivery.', ARRAY['Family structures and functions', 'Family assessment tools (FHSIS)', 'Family nursing process', 'Home visit techniques'], ARRAY['Family as unit of care', 'Family life cycle stages', 'Role of BHW in family health', 'Maternal and child health services'], 3),
('np1-community-health', 'Environmental Health', 'Environmental sanitation and health promotion.', ARRAY['Water sanitation and safety', 'Food sanitation', 'Waste management', 'Air and noise pollution'], ARRAY['DOH sanitation standards', 'Vector control programs', 'Healthy settings initiative', 'Climate change and health'], 4),
('np1-community-health', 'Disaster Nursing', 'Disaster preparedness, response, and recovery.', ARRAY['Disaster phases: pre-impact, impact, post-impact', 'Triage in disasters', 'Disaster risk reduction framework', 'Community preparedness'], ARRAY['Nurses role in disaster response', 'Psychological first aid', 'Epidemic management post-disaster', 'Rehabilitation and reconstruction'], 5);

-- NP II Topics
INSERT INTO public.study_guide_topics (subject_id, title, description, key_concepts, nursing_considerations, sort_order) VALUES
('np2-maternal-child', 'Prenatal Care', 'Comprehensive care during pregnancy.', ARRAY['Physiologic changes in pregnancy', 'Prenatal visits schedule', 'Danger signs in pregnancy', 'Nutritional requirements'], ARRAY['Regular prenatal checkups', 'Fetal monitoring', ' tetanus immunization', 'Iron and folate supplementation'], 1),
('np2-maternal-child', 'Labor and Delivery', 'Management of the stages of labor.', ARRAY['Four stages of labor', 'Cardinal movements of labor', 'Fetal heart rate monitoring', 'Pain management options'], ARRAY['Partograph use', 'Episiotomy considerations', 'Immediate newborn assessment', 'Active management of third stage'], 2),
('np2-maternal-child', 'Postpartum Care', 'Care of the mother after delivery.', ARRAY['Postpartum physiological changes', 'Involution process', 'Lochia assessment', 'Postpartum complications'], ARRAY['Breastfeeding support', 'Perineal care', 'Postpartum warning signs', 'Family planning counseling'], 3),
('np2-maternal-child', 'Newborn Care', 'Essential newborn care and assessment.', ARRAY['Newborn assessment (APGAR)', 'Essential Newborn Care protocol', 'Newborn screening', 'Thermoregulation'], ARRAY['Immediate drying and warming', 'Skin-to-skin contact', 'Early breastfeeding initiation', 'Cord care practices'], 4),
('np2-maternal-child', 'Pediatric Nursing', 'Growth, development, and care of children.', ARRAY['Growth and development milestones', 'Immunization schedule (EPI)', 'Common childhood illnesses', 'Nutrition across childhood'], ARRAY['IMCI guidelines', 'Developmental assessment', 'Pediatric medication dosing', 'Child safety and injury prevention'], 5);

-- NP III Topics
INSERT INTO public.study_guide_topics (subject_id, title, description, key_concepts, nursing_considerations, sort_order) VALUES
('np3-medsurg', 'Perioperative Nursing', 'Care before, during, and after surgery.', ARRAY['Pre-operative assessment', 'Intra-operative care', 'Post-operative recovery', 'Surgical asepsis'], ARRAY['Informed consent', 'NPO guidelines', 'Wound care and healing', 'Post-op complications'], 1),
('np3-medsurg', 'Cardiovascular Nursing', 'Assessment and management of cardiac conditions.', ARRAY['Cardiac assessment', 'Hypertension management', 'Heart failure', 'Coronary artery disease'], ARRAY['Hemodynamic monitoring', 'Cardiac medication administration', 'Lifestyle modifications', 'Cardiac rehabilitation'], 2),
('np3-medsurg', 'Respiratory Nursing', 'Respiratory assessment and care.', ARRAY['Respiratory assessment', 'Pneumonia and TB management', 'COPD and asthma', 'Oxygen therapy'], ARRAY['Airway management techniques', 'Breathing exercises', 'Infection control for TB', 'Pulmonary hygiene'], 3),
('np3-medsurg', 'Fluid and Electrolyte Balance', 'Maintenance of fluid and electrolyte homeostasis.', ARRAY['Fluid compartments', 'Electrolyte functions', 'Acid-base balance', 'IV therapy'], ARRAY['Fluid replacement protocols', 'Electrolyte monitoring', 'Acid-base imbalance correction', 'IV site care'], 4),
('np3-medsurg', 'Oncologic Nursing', 'Care of patients with cancer.', ARRAY['Cancer pathophysiology', 'Treatment modalities', 'Side effect management', 'Terminal care'], ARRAY['Chemotherapy safety', 'Radiation precautions', 'Pain management', 'Psychosocial support'], 5);

-- NP IV Topics
INSERT INTO public.study_guide_topics (subject_id, title, description, key_concepts, nursing_considerations, sort_order) VALUES
('np4-specialized', 'Nutrition', 'Nutritional assessment and support.', ARRAY['Nutritional assessment tools', 'Macronutrient and micronutrient needs', 'Enteral and parenteral nutrition', 'Therapeutic diets'], ARRAY['Malnutrition screening', 'Feeding tube management', 'TPN administration', 'Dietary counseling'], 1),
('np4-specialized', 'Gastrointestinal Nursing', 'GI assessment and common disorders.', ARRAY['GI assessment', 'Peptic ulcer disease', 'Inflammatory bowel disease', 'Liver disorders'], ARRAY['Bowel management', 'Ostomy care', 'GI bleeding precautions', 'Hepatic encephalopathy monitoring'], 2),
('np4-specialized', 'Endocrine Nursing', 'Endocrine system disorders and management.', ARRAY['Diabetes mellitus', 'Thyroid disorders', 'Adrenal disorders', 'Pituitary disorders'], ARRAY['Insulin administration', 'Blood glucose monitoring', 'Diabetic foot care', 'Thyroid precautions'], 3),
('np4-specialized', 'Renal Nursing', 'Kidney function and renal disorders.', ARRAY['Acute kidney injury', 'Chronic kidney disease', 'Dialysis', 'Urinary tract infections'], ARRAY['Fluid restriction', 'Dialysis access care', 'Renal diet education', 'Electrolyte monitoring'], 4),
('np4-specialized', 'Neurologic Nursing', 'Nervous system assessment and disorders.', ARRAY['Neuro assessment', 'Stroke management', 'Seizure disorders', 'Spinal cord injuries'], ARRAY['Glasgow Coma Scale', 'Stroke precautions', 'Seizure safety', 'ICP monitoring'], 5);

-- NP V Topics
INSERT INTO public.study_guide_topics (subject_id, title, description, key_concepts, nursing_considerations, sort_order) VALUES
('np5-mental-critical', 'Psychiatric Nursing', 'Mental health assessment and care.', ARRAY['Mental health assessment', 'Anxiety disorders', 'Mood disorders', 'Schizophrenia'], ARRAY['Therapeutic communication', 'Psychiatric medications', 'Suicide precautions', 'Milieu management'], 1),
('np5-mental-critical', 'Crisis Intervention', 'Acute crisis management and support.', ARRAY['Crisis types and phases', 'Crisis intervention models', 'Post-traumatic stress', 'Grief and loss'], ARRAY['De-escalation techniques', 'Safety assessment', 'Supportive counseling', 'Referral systems'], 2),
('np5-mental-critical', 'Critical Care Nursing', 'Care of critically ill patients.', ARRAY['ICU monitoring', 'Mechanical ventilation', 'Hemodynamic monitoring', 'Vasoactive medications'], ARRAY['Ventilator care', 'Central line management', 'Sedation protocols', 'Family support in ICU'], 3),
('np5-mental-critical', 'Emergency Nursing', 'Emergency assessment and triage.', ARRAY['Triage systems', 'Emergency assessment', 'Trauma care', 'Toxicology'], ARRAY['ABCDE assessment', 'Trauma protocols', 'Poison management', 'Mass casualty response'], 4),
('np5-mental-critical', 'Shock and High-Acuity Care', 'Management of shock states.', ARRAY['Types of shock', 'Stages of shock', 'Multiple organ dysfunction', 'Sepsis management'], ARRAY['Fluid resuscitation', 'Vasopressor administration', 'Lactate monitoring', 'Surviving sepsis guidelines'], 5);