/*
# Grant authenticated read access to private learning summaries

1. Access
- Authenticated users can read their own rows through RLS.
- Client writes continue through the controlled SECURITY DEFINER functions.

2. Security
- Grants do not bypass RLS; every table remains owner-scoped by its policies.
*/

GRANT SELECT ON public.daily_challenges TO authenticated;
GRANT SELECT ON public.learning_activity TO authenticated;
GRANT SELECT ON public.user_xp TO authenticated;
GRANT SELECT ON public.xp_events TO authenticated;
GRANT SELECT ON public.user_achievements TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bookmarks TO authenticated;