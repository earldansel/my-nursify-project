-- Create the admin user in auth.users with email bulletrn@gmail.com
-- Password: 123@456 (hashed by Supabase auth)
DO $$
DECLARE
  admin_id uuid;
BEGIN
  SELECT id INTO admin_id FROM auth.users WHERE email = 'bulletrn@gmail.com';
  
  IF admin_id IS NULL THEN
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      email_change_confirm_status
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'bulletrn@gmail.com',
      extensions.crypt('123@456', extensions.gen_salt('bf')),
      now(),
      now(),
      now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      '{"full_name":"BulletRN Admin"}'::jsonb,
      false,
      0
    ) RETURNING id INTO admin_id;
  ELSE
    UPDATE auth.users SET
      encrypted_password = extensions.crypt('123@456', extensions.gen_salt('bf')),
      email_confirmed_at = COALESCE(email_confirmed_at, now()),
      updated_at = now()
    WHERE id = admin_id;
  END IF;
  
  INSERT INTO public.profiles (id, full_name, role, subscription_status, created_at, updated_at)
  VALUES (admin_id, 'BulletRN Admin', 'admin', 'premium', now(), now())
  ON CONFLICT (id) DO UPDATE SET
    role = 'admin',
    subscription_status = 'premium',
    full_name = 'BulletRN Admin',
    updated_at = now();
END $$;

-- Session-based admin functions (check auth.uid() has admin role)

CREATE OR REPLACE FUNCTION public.admin_list_users()
RETURNS TABLE (
  id uuid,
  full_name text,
  email text,
  role text,
  subscription_status text,
  created_at timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.full_name, u.email, p.role, p.subscription_status, p.created_at
  FROM public.profiles p
  JOIN auth.users u ON u.id = p.id
  WHERE EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  )
  ORDER BY p.created_at DESC;
$$;

GRANT EXECUTE ON FUNCTION public.admin_list_users() TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_set_user_role(
  p_user_id uuid,
  p_role text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  IF p_role NOT IN ('free', 'premium', 'admin') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;
  UPDATE public.profiles
  SET role = p_role,
      subscription_status = CASE WHEN p_role = 'premium' THEN 'premium' ELSE 'free' END,
      updated_at = now()
  WHERE id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_set_user_role(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_insert_question(
  p_id text,
  p_question text,
  p_subject_id text,
  p_subject_name text,
  p_category text DEFAULT 'General',
  p_topic text DEFAULT 'General',
  p_difficulty text DEFAULT 'medium',
  p_question_type text DEFAULT 'multiple-choice',
  p_options jsonb DEFAULT '[]'::jsonb,
  p_correct_answer jsonb DEFAULT '[]'::jsonb,
  p_rationale text DEFAULT '',
  p_option_rationales jsonb DEFAULT '{}'::jsonb,
  p_key_takeaway text DEFAULT '',
  p_nclex_tip text DEFAULT '',
  p_clinical_pearl text DEFAULT '',
  p_reference text DEFAULT '',
  p_tags text[] DEFAULT ARRAY[]::text[],
  p_is_ngn boolean DEFAULT false,
  p_case_study text DEFAULT NULL,
  p_patient_data jsonb DEFAULT NULL
)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  INSERT INTO public.questions (
    id, question, subject_id, subject_name, category, topic, difficulty,
    question_type, options, correct_answer, rationale, option_rationales,
    key_takeaway, nclex_tip, clinical_pearl, reference, tags, is_ngn,
    case_study, patient_data
  ) VALUES (
    p_id, p_question, p_subject_id, p_subject_name, p_category, p_topic, p_difficulty,
    p_question_type, p_options, p_correct_answer, p_rationale, p_option_rationales,
    p_key_takeaway, p_nclex_tip, p_clinical_pearl, p_reference, p_tags, p_is_ngn,
    p_case_study, p_patient_data
  );
  RETURN p_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_insert_question TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_update_question(
  p_question_id text,
  p_question text,
  p_subject_id text,
  p_subject_name text,
  p_category text DEFAULT 'General',
  p_topic text DEFAULT 'General',
  p_difficulty text DEFAULT 'medium',
  p_question_type text DEFAULT 'multiple-choice',
  p_options jsonb DEFAULT '[]'::jsonb,
  p_correct_answer jsonb DEFAULT '[]'::jsonb,
  p_rationale text DEFAULT '',
  p_option_rationales jsonb DEFAULT '{}'::jsonb,
  p_key_takeaway text DEFAULT '',
  p_nclex_tip text DEFAULT '',
  p_clinical_pearl text DEFAULT '',
  p_reference text DEFAULT '',
  p_tags text[] DEFAULT ARRAY[]::text[],
  p_is_ngn boolean DEFAULT false,
  p_case_study text DEFAULT NULL,
  p_patient_data jsonb DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  UPDATE public.questions SET
    question = p_question,
    subject_id = p_subject_id,
    subject_name = p_subject_name,
    category = p_category,
    topic = p_topic,
    difficulty = p_difficulty,
    question_type = p_question_type,
    options = p_options,
    correct_answer = p_correct_answer,
    rationale = p_rationale,
    option_rationales = p_option_rationales,
    key_takeaway = p_key_takeaway,
    nclex_tip = p_nclex_tip,
    clinical_pearl = p_clinical_pearl,
    reference = p_reference,
    tags = p_tags,
    is_ngn = p_is_ngn,
    case_study = p_case_study,
    patient_data = p_patient_data
  WHERE id = p_question_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_update_question TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_delete_question(
  p_question_id text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  DELETE FROM public.questions WHERE id = p_question_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_question(text) TO authenticated;
