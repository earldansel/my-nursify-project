/*
# Add Study Plan System

1. New Tables
- `study_plans`: Stores a user's overall study plan configuration.
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to authenticated user, references auth.users with cascade delete)
  - `exam_date` (date, not null) — target NCLEX exam date
  - `study_days_per_week` (int, not null, default 5) — how many days per week the user studies
  - `questions_per_day` (int, not null, default 50) — target questions per study day
  - `focus_subjects` (jsonb, not null default '[]') — array of SubjectId strings to focus on
  - `intensity` (text, not null default 'balanced') — 'light' | 'balanced' | 'intensive'
  - `status` (text, not null default 'active') — 'active' | 'paused'
  - `created_at` (timestamptz, default now)
  - `updated_at` (timestamptz, default now)

- `study_tasks`: Individual daily tasks within a study plan.
  - `id` (uuid, primary key)
  - `plan_id` (uuid, not null, references study_plans with cascade delete)
  - `user_id` (uuid, not null, defaults to authenticated user, references auth.users with cascade delete)
  - `scheduled_date` (date, not null) — the day this task is scheduled for
  - `title` (text, not null) — display title, e.g. "Answer 50 questions"
  - `task_type` (text, not null) — 'questions' | 'review' | 'practice' | 'assessment' | 'review-incorrect'
  - `subject_id` (text, nullable) — SubjectId if subject-specific
  - `question_count` (int, nullable) — number of questions if task_type is 'questions' or 'practice'
  - `completed` (boolean, not null default false)
  - `completed_at` (timestamptz, nullable)
  - `sort_order` (int, not null default 0)
  - `created_at` (timestamptz, default now)

2. Indexes
- `idx_study_plans_user` on study_plans(user_id)
- `idx_study_tasks_user` on study_tasks(user_id)
- `idx_study_tasks_plan_date` on study_tasks(plan_id, scheduled_date)
- `idx_study_tasks_user_date` on study_tasks(user_id, scheduled_date)

3. Security
- Enable RLS on both tables.
- Owner-scoped CRUD on study_plans: authenticated users can only access their own plans (auth.uid() = user_id).
- Owner-scoped CRUD on study_tasks: authenticated users can only access tasks belonging to their own plans (auth.uid() = user_id).
- user_id columns default to auth.uid() so inserts that omit user_id succeed.

4. Important Notes
- The app has a sign-in screen, so policies are scoped TO authenticated.
- user_id defaults to auth.uid() on both tables.
- study_tasks.user_id is denormalized for simpler RLS but plan_id FK ensures integrity.
- updated_at auto-set via trigger on study_plans.
*/

CREATE TABLE IF NOT EXISTS study_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  exam_date date NOT NULL,
  study_days_per_week int NOT NULL DEFAULT 5,
  questions_per_day int NOT NULL DEFAULT 50,
  focus_subjects jsonb NOT NULL DEFAULT '[]'::jsonb,
  intensity text NOT NULL DEFAULT 'balanced',
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE study_plans ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_study_plans_user ON study_plans(user_id);

DROP POLICY IF EXISTS "select_own_study_plans" ON study_plans;
CREATE POLICY "select_own_study_plans" ON study_plans FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_study_plans" ON study_plans;
CREATE POLICY "insert_own_study_plans" ON study_plans FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_study_plans" ON study_plans;
CREATE POLICY "update_own_study_plans" ON study_plans FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_study_plans" ON study_plans;
CREATE POLICY "delete_own_study_plans" ON study_plans FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS study_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id uuid NOT NULL REFERENCES study_plans(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  scheduled_date date NOT NULL,
  title text NOT NULL,
  task_type text NOT NULL,
  subject_id text,
  question_count int,
  completed boolean NOT NULL DEFAULT false,
  completed_at timestamptz,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE study_tasks ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_study_tasks_user ON study_tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_study_tasks_plan_date ON study_tasks(plan_id, scheduled_date);
CREATE INDEX IF NOT EXISTS idx_study_tasks_user_date ON study_tasks(user_id, scheduled_date);

DROP POLICY IF EXISTS "select_own_study_tasks" ON study_tasks;
CREATE POLICY "select_own_study_tasks" ON study_tasks FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_study_tasks" ON study_tasks;
CREATE POLICY "insert_own_study_tasks" ON study_tasks FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_study_tasks" ON study_tasks;
CREATE POLICY "update_own_study_tasks" ON study_tasks FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_study_tasks" ON study_tasks;
CREATE POLICY "delete_own_study_tasks" ON study_tasks FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Auto-update updated_at on study_plans
CREATE OR REPLACE FUNCTION update_study_plans_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_study_plans_updated_at ON study_plans;
CREATE TRIGGER trg_study_plans_updated_at
  BEFORE UPDATE ON study_plans
  FOR EACH ROW
  EXECUTE FUNCTION update_study_plans_updated_at();