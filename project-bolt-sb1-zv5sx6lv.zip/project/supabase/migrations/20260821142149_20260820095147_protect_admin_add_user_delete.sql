-- Protect main admin account + add user deletion
CREATE OR REPLACE FUNCTION public.admin_set_user_role(p_user_id uuid, p_role text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE target_email text;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin') THEN RAISE EXCEPTION 'Admin access required'; END IF;
  IF p_role NOT IN ('free', 'premium', 'admin') THEN RAISE EXCEPTION 'Invalid role'; END IF;
  SELECT u.email INTO target_email FROM auth.users u WHERE u.id = p_user_id;
  IF target_email = 'nursify@gmail.com' AND p_role != 'admin' THEN RAISE EXCEPTION 'Cannot downgrade the main admin account'; END IF;
  UPDATE public.profiles SET role = p_role, subscription_status = CASE WHEN p_role IN ('premium', 'admin') THEN 'premium' ELSE 'free' END, updated_at = now() WHERE id = p_user_id;
END;
$$;
GRANT EXECUTE ON FUNCTION public.admin_set_user_role(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_delete_user(p_user_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE target_email text;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin') THEN RAISE EXCEPTION 'Admin access required'; END IF;
  IF p_user_id = auth.uid() THEN RAISE EXCEPTION 'Cannot delete your own account'; END IF;
  SELECT u.email INTO target_email FROM auth.users u WHERE u.id = p_user_id;
  IF target_email = 'nursify@gmail.com' THEN RAISE EXCEPTION 'Cannot delete the main admin account'; END IF;
  DELETE FROM auth.users WHERE id = p_user_id;
END;
$$;
GRANT EXECUTE ON FUNCTION public.admin_delete_user(uuid) TO authenticated;