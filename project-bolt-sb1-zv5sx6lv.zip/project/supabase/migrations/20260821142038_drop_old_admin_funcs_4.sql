DO $$ BEGIN
  EXECUTE 'DROP FUNCTION IF EXISTS pg_catalog.pg_proc_renamed_' || 17654;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

DO $$ BEGIN
  EXECUTE 'DROP FUNCTION IF EXISTS public.admin_insert_question' || '(' || (
    SELECT string_agg(format('%s', t), ', ')
    FROM unnest(string_to_array(
      (SELECT pg_get_function_identity_arguments(17654)), ','
    )) AS t
  ) || ') CASCADE';
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Try direct approach
DO $$ 
DECLARE fn_oid bigint;
BEGIN
  -- Drop admin_insert_question by OID
  FOR fn_oid IN SELECT oid FROM pg_proc WHERE pronamespace = 'public'::regnamespace AND proname = 'admin_insert_question' AND oid = 17654
  LOOP
    EXECUTE format('DROP FUNCTION IF EXISTS %s CASCADE', fn_oid::regprocedure);
  END LOOP;
  FOR fn_oid IN SELECT oid FROM pg_proc WHERE pronamespace = 'public'::regnamespace AND proname = 'admin_update_question' AND oid = 17655
  LOOP
    EXECUTE format('DROP FUNCTION IF EXISTS %s CASCADE', fn_oid::regprocedure);
  END LOOP;
END $$;