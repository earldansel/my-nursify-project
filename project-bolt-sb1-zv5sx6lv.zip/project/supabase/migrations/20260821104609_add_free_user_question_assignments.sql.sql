/*
# Free User Question Assignment System

## Purpose
Assigns exactly 50 randomly-selected questions to each free user.
The assignments persist until an admin resets them or the user upgrades.
This enforces the limit at the database level — free users can never
access questions outside their assigned set.

## Tables
- free_question_assignments: stores (user_id, question_id) pairs

## Functions
- get_free_user_question_ids(): returns the 50 assigned question_ids
  for the current user. Auto-creates assignments if none exist yet.
- reset_free_user_questions(p_target_uid uuid): admin-only — deletes
  and re-creates 50 random assignments for a given user.

## Security
- RLS enabled: users can only see their own assignments
- reset function is SECURITY DEFINER, callable only by admin role
- get function is SECURITY DEFINER, callable by authenticated
*/

CREATE TABLE IF NOT EXISTS public.free_question_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  question_id text NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, question_id)
);

ALTER TABLE public.free_question_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_assignments"
  ON public.free_question_assignments FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "insert_own_assignments"
  ON public.free_question_assignments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "delete_own_assignments"
  ON public.free_question_assignments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Returns the 50 assigned question IDs for the current user.
-- Auto-creates assignments if none exist yet (first access).
CREATE OR REPLACE FUNCTION public.get_free_user_question_ids()
RETURNS TABLE(question_id text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count integer;
  v_role text;
BEGIN
  SELECT role INTO v_role FROM public.profiles WHERE id = auth.uid();
  IF v_role IS NULL OR v_role = 'free' THEN
    SELECT COUNT(*) INTO v_count
    FROM public.free_question_assignments
    WHERE user_id = auth.uid();

    IF v_count = 0 THEN
      INSERT INTO public.free_question_assignments (user_id, question_id)
      SELECT auth.uid(), q.id
      FROM public.questions q
      ORDER BY random()
      LIMIT 50;
    END IF;

    RETURN QUERY
      SELECT question_id FROM public.free_question_assignments
      WHERE user_id = auth.uid();
  ELSE
    -- Premium/admin: return NULL set (caller will fetch all questions)
    RETURN;
  END IF;
END;
$$;

-- Admin-only: resets a user's 50 assigned questions to a new random set
CREATE OR REPLACE FUNCTION public.reset_free_user_questions(p_target_uid uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller_role text;
BEGIN
  SELECT role INTO v_caller_role FROM public.profiles WHERE id = auth.uid();
  IF v_caller_role IS NULL OR v_caller_role <> 'admin' THEN
    RAISE EXCEPTION 'Only admins can reset free user question assignments';
  END IF;

  DELETE FROM public.free_question_assignments WHERE user_id = p_target_uid;

  INSERT INTO public.free_question_assignments (user_id, question_id)
  SELECT p_target_uid, q.id
  FROM public.questions q
  ORDER BY random()
  LIMIT 50;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_free_user_question_ids() TO authenticated;
GRANT EXECUTE ON FUNCTION public.reset_free_user_questions(uuid) TO authenticated;
