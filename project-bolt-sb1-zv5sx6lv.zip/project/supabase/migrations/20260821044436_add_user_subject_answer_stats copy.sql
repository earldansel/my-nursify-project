/*
# Add user subject answer stats function

## Purpose
Returns per-subject answer statistics for the current authenticated user:
- subject_id
- answered count (total questions answered)
- correct count (correctly answered questions)

This bypasses the Supabase 1000-row default limit and runs server-side for accuracy.

## Security
- SECURITY DEFINER, owned by postgres.
- Uses auth.uid() to filter to the current user's answers only.
- EXECUTE granted to authenticated (the only role that has answers).
*/

CREATE OR REPLACE FUNCTION public.get_user_subject_answer_stats()
RETURNS TABLE (subject_id text, answered bigint, correct bigint)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT subject_id,
         COUNT(*)::bigint AS answered,
         COUNT(*) FILTER (WHERE is_correct)::bigint AS correct
  FROM public.question_answers
  WHERE user_id = auth.uid()
    AND subject_id IS NOT NULL
  GROUP BY subject_id;
$$;

GRANT EXECUTE ON FUNCTION public.get_user_subject_answer_stats() TO authenticated;
