-- Subject count functions
CREATE OR REPLACE FUNCTION public.get_subject_question_counts()
RETURNS TABLE (subject_id text, total bigint)
LANGUAGE sql SECURITY DEFINER SET search_path = public
AS $$ SELECT subject_id, COUNT(*)::bigint AS total FROM public.questions WHERE subject_id IS NOT NULL GROUP BY subject_id; $$;
GRANT EXECUTE ON FUNCTION public.get_subject_question_counts() TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.get_category_question_counts()
RETURNS TABLE (category text, total bigint)
LANGUAGE sql SECURITY DEFINER SET search_path = public
AS $$ SELECT category, COUNT(*)::bigint AS total FROM public.questions WHERE category IS NOT NULL GROUP BY category; $$;
GRANT EXECUTE ON FUNCTION public.get_category_question_counts() TO anon, authenticated;

-- User subject answer stats
CREATE OR REPLACE FUNCTION public.get_user_subject_answer_stats()
RETURNS TABLE (subject_id text, answered bigint, correct bigint)
LANGUAGE sql SECURITY DEFINER SET search_path = public
AS $$ SELECT subject_id, COUNT(*)::bigint AS answered, COUNT(*) FILTER (WHERE is_correct)::bigint AS correct FROM public.question_answers WHERE user_id = auth.uid() AND subject_id IS NOT NULL GROUP BY subject_id; $$;
GRANT EXECUTE ON FUNCTION public.get_user_subject_answer_stats() TO authenticated;

-- Subject name question counts
CREATE OR REPLACE FUNCTION public.get_subject_name_question_counts()
RETURNS TABLE (subject_name text, total bigint)
LANGUAGE sql SECURITY DEFINER SET search_path = public
AS $$ SELECT subject_name, COUNT(*)::bigint AS total FROM public.questions WHERE subject_name IS NOT NULL GROUP BY subject_name; $$;
GRANT EXECUTE ON FUNCTION public.get_subject_name_question_counts() TO anon, authenticated;