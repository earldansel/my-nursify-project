/*
# Add Video Lessons System

1. New Tables
- `video_lessons`: Stores video lesson metadata for replay lessons.
  - `id` (uuid, primary key)
  - `title` (text, not null) — lesson title
  - `youtube_url` (text, not null) — full YouTube URL
  - `youtube_id` (text, not null) — extracted YouTube video ID for embedding
  - `subject` (text, not null) — subject category (pharmacology, medsurg, pediatrics, mentalhealth, ob, fundamentals, or 'general')
  - `lesson_date` (date, not null) — date the lesson was recorded/published
  - `created_at` (timestamptz, default now)
  - `updated_at` (timestamptz, default now)

2. Indexes
- `idx_video_lessons_subject` on video_lessons(subject)
- `idx_video_lessons_date` on video_lessons(lesson_date DESC)

3. Security
- Enable RLS on video_lessons.
- SELECT: TO anon, authenticated — all users (including non-logged-in) can browse/watch videos.
- INSERT/UPDATE/DELETE: TO authenticated, restricted to admin role via auth.uid() check on profiles.
  This prevents regular/premium users from adding/editing/deleting videos even though they're authenticated.
  The admin management functions are SECURITY DEFINER RPCs that verify admin role server-side.

4. New Functions
- `admin_add_video_lesson(p_title, p_youtube_url, p_youtube_id, p_subject, p_lesson_date)`:
  Inserts a new video lesson. Verifies caller is admin.
- `admin_update_video_lesson(p_id, p_title, p_youtube_url, p_youtube_id, p_subject, p_lesson_date)`:
  Updates an existing video lesson. Verifies caller is admin.
- `admin_delete_video_lesson(p_id)`: Deletes a video lesson. Verifies caller is admin.

5. Important Notes
- The app has a sign-in screen, but video browsing is available to all users.
- Admin-only mutations are enforced both via RLS and via SECURITY DEFINER function checks.
- youtube_id is extracted client-side from the URL and stored for embedding via youtube-nocookie.com/embed/.
*/

CREATE TABLE IF NOT EXISTS video_lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  youtube_url text NOT NULL,
  youtube_id text NOT NULL,
  subject text NOT NULL DEFAULT 'general',
  lesson_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE video_lessons ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_video_lessons_subject ON video_lessons(subject);
CREATE INDEX IF NOT EXISTS idx_video_lessons_date ON video_lessons(lesson_date DESC);

-- All users can read video lessons
DROP POLICY IF EXISTS "read_video_lessons" ON video_lessons;
CREATE POLICY "read_video_lessons" ON video_lessons FOR SELECT
  TO anon, authenticated USING (true);

-- Only admins can insert (enforced via RLS + function)
DROP POLICY IF EXISTS "admin_insert_video_lessons" ON video_lessons;
CREATE POLICY "admin_insert_video_lessons" ON video_lessons FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Only admins can update
DROP POLICY IF EXISTS "admin_update_video_lessons" ON video_lessons;
CREATE POLICY "admin_update_video_lessons" ON video_lessons FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Only admins can delete
DROP POLICY IF EXISTS "admin_delete_video_lessons" ON video_lessons;
CREATE POLICY "admin_delete_video_lessons" ON video_lessons FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_video_lessons_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_video_lessons_updated_at ON video_lessons;
CREATE TRIGGER trg_video_lessons_updated_at
  BEFORE UPDATE ON video_lessons
  FOR EACH ROW
  EXECUTE FUNCTION update_video_lessons_updated_at();

-- Admin RPC functions
CREATE OR REPLACE FUNCTION public.admin_add_video_lesson(
  p_title text,
  p_youtube_url text,
  p_youtube_id text,
  p_subject text,
  p_lesson_date date
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_id uuid;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  INSERT INTO public.video_lessons (title, youtube_url, youtube_id, subject, lesson_date)
  VALUES (p_title, p_youtube_url, p_youtube_id, p_subject, p_lesson_date)
  RETURNING id INTO new_id;
  RETURN new_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_add_video_lesson(text, text, text, text, date) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_update_video_lesson(
  p_id uuid,
  p_title text,
  p_youtube_url text,
  p_youtube_id text,
  p_subject text,
  p_lesson_date date
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  UPDATE public.video_lessons
  SET title = p_title,
      youtube_url = p_youtube_url,
      youtube_id = p_youtube_id,
      subject = p_subject,
      lesson_date = p_lesson_date
  WHERE id = p_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_update_video_lesson(uuid, text, text, text, text, date) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_delete_video_lesson(p_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;
  DELETE FROM public.video_lessons WHERE id = p_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_video_lesson(uuid) TO authenticated;