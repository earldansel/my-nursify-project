/*
# Add exam_track column for PNLE/NCLEX separation

1. New Columns
- questions.exam_track (text, default 'nclex'): 'pnle' or 'nclex'
- quiz_attempts.exam_track (text, default 'nclex'): which track the quiz belongs to
- question_answers.exam_track (text, default 'nclex'): which track the answer belongs to
- study_progress.exam_track (text, default 'nclex'): per-track study progress
- study_guide_subjects.exam_track (text, default 'nclex'): which track the subject belongs to
- study_guide_progress.exam_track (text, default 'nclex'): per-track study guide progress

2. Indexes
- Added index on questions.exam_track for filtered queries
- Added index on quiz_attempts.exam_track for per-track history
- Added index on question_answers.exam_track for per-track analytics

3. Security
- No policy changes needed; existing RLS policies already scope by user_id
- The exam_track column is set by the client when creating records

4. Important Notes
- All existing questions default to 'nclex' track
- Users who select both tracks will have separate data per track
- PNLE data never affects NCLEX analytics and vice versa
*/

ALTER TABLE public.questions ADD COLUMN IF NOT EXISTS exam_track text NOT NULL DEFAULT 'nclex' CHECK (exam_track IN ('pnle', 'nclex'));
ALTER TABLE public.quiz_attempts ADD COLUMN IF NOT EXISTS exam_track text NOT NULL DEFAULT 'nclex' CHECK (exam_track IN ('pnle', 'nclex'));
ALTER TABLE public.question_answers ADD COLUMN IF NOT EXISTS exam_track text NOT NULL DEFAULT 'nclex' CHECK (exam_track IN ('pnle', 'nclex'));
ALTER TABLE public.study_progress ADD COLUMN IF NOT EXISTS exam_track text NOT NULL DEFAULT 'nclex' CHECK (exam_track IN ('pnle', 'nclex'));
ALTER TABLE public.study_guide_subjects ADD COLUMN IF NOT EXISTS exam_track text NOT NULL DEFAULT 'nclex' CHECK (exam_track IN ('pnle', 'nclex'));
ALTER TABLE public.study_guide_progress ADD COLUMN IF NOT EXISTS exam_track text NOT NULL DEFAULT 'nclex' CHECK (exam_track IN ('pnle', 'nclex'));

CREATE INDEX IF NOT EXISTS idx_questions_exam_track ON public.questions(exam_track);
CREATE INDEX IF NOT EXISTS idx_quiz_attempts_exam_track ON public.quiz_attempts(exam_track);
CREATE INDEX IF NOT EXISTS idx_question_answers_exam_track ON public.question_answers(exam_track);

-- Add unique constraint for study_guide_progress per track
-- (user can study the same topic in both tracks independently)
ALTER TABLE public.study_guide_progress DROP CONSTRAINT IF EXISTS study_guide_progress_user_id_topic_id_key;
ALTER TABLE public.study_guide_progress ADD CONSTRAINT study_guide_progress_user_topic_track_unique UNIQUE (user_id, topic_id, exam_track);