/*
# Add NCLEX Application Process System

1. New Table: `nclex_application_pages`
- Stores editable content for each state/territory NCLEX application guide.
- `id` (text, primary key) — slug used in routes: 'new-york', 'illinois', 'cnmi'
- `title` (text) — display name, e.g. "New York"
- `subtitle` (text) — e.g. "For Filipino Nurses"
- `description` (text) — short card description
- `introduction` (text) — longer intro for the detail page
- `steps` (jsonb) — array of step objects: { number, title, description, checklist: string[], link_url, link_label }
- `info_cards` (jsonb) — array of card objects: { title, items: string[] }
- `official_links` (jsonb) — array of { label, url }
- `is_published` (boolean, default true) — admin can unpublish
- `created_at`, `updated_at` (timestamptz)

2. Security (RLS)
- SELECT: public to all authenticated users (only published pages visible to non-admins; admins see all)
- INSERT/UPDATE/DELETE: admin only (checks profiles.role = 'admin')

3. Seed Data
- Three rows: new-york, illinois, cnmi — with full step-by-step content, info cards, and official links.
*/

CREATE TABLE IF NOT EXISTS public.nclex_application_pages (
  id text PRIMARY KEY,
  title text NOT NULL,
  subtitle text NOT NULL DEFAULT 'For Filipino Nurses',
  description text NOT NULL DEFAULT '',
  introduction text NOT NULL DEFAULT '',
  steps jsonb NOT NULL DEFAULT '[]'::jsonb,
  info_cards jsonb NOT NULL DEFAULT '[]'::jsonb,
  official_links jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.nclex_application_pages ENABLE ROW LEVEL SECURITY;

-- All authenticated users can read published pages
DROP POLICY IF EXISTS "nclex_pages_select_published" ON public.nclex_application_pages;
CREATE POLICY "nclex_pages_select_published"
  ON public.nclex_application_pages FOR SELECT
  TO authenticated USING (
    is_published = true
    OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Only admins can insert
DROP POLICY IF EXISTS "nclex_pages_insert_admin" ON public.nclex_application_pages;
CREATE POLICY "nclex_pages_insert_admin"
  ON public.nclex_application_pages FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Only admins can update
DROP POLICY IF EXISTS "nclex_pages_update_admin" ON public.nclex_application_pages;
CREATE POLICY "nclex_pages_update_admin"
  ON public.nclex_application_pages FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Only admins can delete
DROP POLICY IF EXISTS "nclex_pages_delete_admin" ON public.nclex_application_pages;
CREATE POLICY "nclex_pages_delete_admin"
  ON public.nclex_application_pages FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Seed: New York
INSERT INTO public.nclex_application_pages (id, title, subtitle, description, introduction, steps, info_cards, official_links, is_published)
VALUES (
  'new-york',
  'New York',
  'For Filipino Nurses',
  'Complete guide to obtaining your NY RN license and taking the NCLEX-RN as a Philippine-educated nurse.',
  'The New York State Education Department (NYSED) oversees RN licensure. Filipino nurses must meet coursework, credentialing, and exam requirements before practicing in New York.',
  '[
    {"number": 1, "title": "Check NYSED Eligibility Requirements", "description": "Review the NYSED eligibility criteria for foreign-educated nurses before starting your application.", "checklist": ["Verify your nursing program is comparable to a NY RN program", "Confirm you meet English proficiency requirements"], "link_url": "https://www.op.nysed.gov/professions/nursing", "link_label": "NYSED Nursing Page"},
    {"number": 2, "title": "Complete NYSED-Required Coursework", "description": "New York requires specific coursework that may not be included in your Philippine nursing curriculum.", "checklist": ["Infection Control & Barrier Precautions", "Child Abuse Identification & Reporting"], "link_url": "", "link_label": ""},
    {"number": 3, "title": "Apply to NYSED", "description": "Submit your application for RN licensure to the New York State Education Department.", "checklist": ["Complete Form 1 (Application for Licensure)", "Pay the application fee", "Submit all required forms"], "link_url": "https://www.op.nysed.gov/professions/nursing/how-to-apply-for-a-license", "link_label": "How to Apply"},
    {"number": 4, "title": "Complete Foreign Education Requirements", "description": "Have your credentials evaluated to confirm your Philippine nursing education meets NY standards.", "checklist": ["Use a NYSED-approved credentials verification service (e.g. CGFNS)", "Submit transcripts from your Philippine nursing school"], "link_url": "https://www.op.nysed.gov/professions/nursing/foreign-educated-applicants", "link_label": "Foreign Educated Applicants"},
    {"number": 5, "title": "Submit Verification of Philippine RN License", "description": "NYSED requires verification of your current Philippine nursing license.", "checklist": ["Request license verification from the Philippine PRC", "Ensure verification is sent directly to NYSED"], "link_url": "", "link_label": ""},
    {"number": 6, "title": "Register for the NCLEX-RN Exam through Pearson VUE", "description": "Once NYSED confirms your eligibility, register for the NCLEX-RN exam with Pearson VUE.", "checklist": ["Create a Pearson VUE account", "Pay the NCLEX registration fee", "Select New York as your licensing jurisdiction"], "link_url": "https://www.pearsonvue.com/nclex", "link_label": "Pearson VUE NCLEX"},
    {"number": 7, "title": "Receive Authorization to Test (ATT)", "description": "After NYSED and Pearson VUE process your registration, you will receive your Authorization to Test.", "checklist": ["Check your email for ATT", "Verify all details on the ATT are correct"], "link_url": "", "link_label": ""},
    {"number": 8, "title": "Schedule the NCLEX-RN Exam", "description": "Use your ATT to schedule your exam date at a Pearson VUE testing center.", "checklist": ["Choose a testing center location", "Select an available date within your ATT validity period"], "link_url": "https://www.pearsonvue.com/nclex", "link_label": "Schedule Exam"},
    {"number": 9, "title": "Prepare for the NCLEX-RN Exam", "description": "Study thoroughly using review courses, practice questions, and NCLEX prep materials.", "checklist": ["Use BulletRN QBanks for practice questions", "Review weak subject areas", "Take full-length practice exams"], "link_url": "", "link_label": ""},
    {"number": 10, "title": "Take the NCLEX-RN Exam", "description": "Arrive at your testing center on your scheduled date with proper identification.", "checklist": ["Bring valid government-issued ID", "Arrive 30 minutes early", "Complete the exam within the time limit"], "link_url": "", "link_label": ""},
    {"number": 11, "title": "Get Your Results / Q-POP", "description": "New York uses the Quick Results service. You may also need to complete the Q-POP (Qualifying Passport to Practice) requirements.", "checklist": ["Check official results via Pearson VUE Quick Results (48 hours)", "Complete any NYSED post-exam requirements"], "link_url": "https://www.nclex.com", "link_label": "NCLEX Results"},
    {"number": 12, "title": "NYSED Completes Licensing Processing", "description": "After you pass the NCLEX-RN, NYSED processes your license. You will appear on the NYSED verification site once licensed.", "checklist": ["Wait for NYSED to issue your RN license number", "Verify your license online via NYSED"], "link_url": "https://www.op.nysed.gov/professions/nursing/verify-a-license", "link_label": "Verify License"}
  ]'::jsonb,
  '[
    {"title": "NYSED Requirements Overview", "items": ["Foreign-educated nurses must have credentials evaluated by a NYSED-approved service", "Required coursework: Infection Control & Barrier Precautions, Child Abuse Identification & Reporting", "Philippine RN license must be active and verified", "English proficiency may be required"]},
    {"title": "Required Documents", "items": ["Completed Form 1 (Application for Licensure)", "Official transcripts from Philippine nursing school", "Credential evaluation report", "Philippine PRC license verification", "Proof of completed required coursework", "Passport-size photo (if requested)"]},
    {"title": "Fees Summary", "items": ["Application fee: ~$143 (subject to change)", "NCLEX-RN registration fee: $200 (Pearson VUE)", "Credential evaluation fee: varies by service (~$300-$500)", "Quick Results fee: $7.95 (optional)"]},
    {"title": "Tips for Success", "items": ["Start the credential evaluation early — it can take months", "Complete required NY coursework online before applying", "Double-check all forms before submission to avoid delays", "Use BulletRN QBanks daily for NCLEX prep", "Join the BulletRN Community for peer support"]}
  ]'::jsonb,
  '[
    {"label": "NYSED Nursing Page", "url": "https://www.op.nysed.gov/professions/nursing"},
    {"label": "Pearson VUE NCLEX", "url": "https://www.pearsonvue.com/nclex"},
    {"label": "NYSED License Verification", "url": "https://www.op.nysed.gov/professions/nursing/verify-a-license"}
  ]'::jsonb,
  true
) ON CONFLICT (id) DO NOTHING;

-- Seed: Illinois
INSERT INTO public.nclex_application_pages (id, title, subtitle, description, introduction, steps, info_cards, official_links, is_published)
VALUES (
  'illinois',
  'Illinois',
  'For Filipino Nurses',
  'Step-by-step guide to Illinois RN licensure for Philippine-educated nurses, including CGFNS credential evaluation.',
  'The Illinois Department of Financial and Professional Regulation (IDFPR) handles RN licensure. Foreign-educated nurses must complete a credential evaluation through CGFNS before applying for licensure and taking the NCLEX-RN.',
  '[
    {"number": 1, "title": "Meet Illinois Eligibility Requirements", "description": "Review the IDFPR requirements for foreign-educated nurses applying for Illinois RN licensure.", "checklist": ["Verify your Philippine nursing program meets Illinois standards", "Confirm you hold a current Philippine RN license"], "link_url": "https://idfpr.illinois.gov/profs/nursing.html", "link_label": "IDFPR Nursing"},
    {"number": 2, "title": "Get Credential Evaluation (CGFNS)", "description": "Illinois requires foreign-educated nurses to have credentials evaluated by CGFNS or a approved evaluation service.", "checklist": ["Apply for CGFNS Certification Program or VisaScreen", "Submit transcripts and license verification to CGFNS", "Receive CGFNS credential report"], "link_url": "https://www.cgfns.org", "link_label": "CGFNS Website"},
    {"number": 3, "title": "Prepare and Submit Required Documents", "description": "Gather all necessary documents for your Illinois licensure application.", "checklist": ["Official transcripts from Philippine nursing school", "CGFNS credential evaluation report", "Philippine PRC license verification", "Passport copy", "Completed application forms"], "link_url": "", "link_label": ""},
    {"number": 4, "title": "Apply for Illinois Licensure", "description": "Submit your application to the IDFPR along with all required documents and fees.", "checklist": ["Complete the Illinois RN application", "Pay the application fee", "Submit all supporting documents"], "link_url": "https://idfpr.illinois.gov/profs/nursing.html", "link_label": "Apply for Illinois RN"},
    {"number": 5, "title": "Schedule and Take the NCLEX-RN Exam", "description": "Once IDFPR approves your eligibility, register with Pearson VUE and schedule your exam.", "checklist": ["Register with Pearson VUE for NCLEX-RN", "Pay the NCLEX registration fee", "Receive your Authorization to Test (ATT)", "Schedule your exam date"], "link_url": "https://www.pearsonvue.com/nclex", "link_label": "Pearson VUE"},
    {"number": 6, "title": "Take and Pass the NCLEX-RN Exam", "description": "Arrive at the testing center prepared and complete the NCLEX-RN exam.", "checklist": ["Bring valid government-issued ID", "Arrive early at the testing center", "Complete the exam within the time limit"], "link_url": "", "link_label": ""},
    {"number": 7, "title": "Receive / Complete the RN Licensure Process", "description": "After passing the NCLEX-RN, IDFPR processes your license. You will receive your Illinois RN license number.", "checklist": ["Wait for IDFPR to issue your license", "Verify your license on the IDFPR website"], "link_url": "https://idfpr.illinois.gov/profs/nursing.html", "link_label": "Verify Illinois License"}
  ]'::jsonb,
  '[
    {"title": "Estimated Costs", "items": ["Application fee: ~$100 (subject to change)", "CGFNS credential evaluation: ~$300-$500", "NCLEX-RN registration: $200 (Pearson VUE)", "Additional document authentication fees may apply"]},
    {"title": "Processing Time", "items": ["CGFNS evaluation: 3-6 months", "IDFPR application review: 4-8 weeks after complete submission", "Total estimated time: 6-12 months from start to license"]},
    {"title": "Where to Authenticate Documents", "items": ["Philippine PRC for RN license verification", "Philippine school for official transcripts", "CGFNS for credential evaluation", "DFA red ribbon (apostille) for document authentication"]},
    {"title": "NCLEX Waiting Time", "items": ["ATT typically issued 2-4 weeks after eligibility confirmed", "Exam can be scheduled within 90 days of ATT issuance", "Quick Results available in 48 hours after exam"]},
    {"title": "Results", "items": ["Official results sent by IDFPR after passing", "Quick Results available via Pearson VUE for $7.95", "License number issued after IDFPR processes results"]},
    {"title": "Tips for a Smooth Process", "items": ["Start CGFNS evaluation as early as possible", "Ensure all documents are properly authenticated", "Keep copies of everything you submit", "Use BulletRN QBanks for consistent NCLEX practice", "Check your application status regularly online"]}
  ]'::jsonb,
  '[
    {"label": "IDFPR Nursing", "url": "https://idfpr.illinois.gov/profs/nursing.html"},
    {"label": "CGFNS International", "url": "https://www.cgfns.org"},
    {"label": "Pearson VUE NCLEX", "url": "https://www.pearsonvue.com/nclex"}
  ]'::jsonb,
  true
) ON CONFLICT (id) DO NOTHING;

-- Seed: CNMI
INSERT INTO public.nclex_application_pages (id, title, subtitle, description, introduction, steps, info_cards, official_links, is_published)
VALUES (
  'cnmi',
  'Northern Mariana Islands (CNMI)',
  'For Filipino Nurses',
  'Guide to CNMI RN licensure for Philippine-educated nurses, including online application and NCLEX-RN scheduling.',
  'The Commonwealth of the Northern Mariana Islands (CNMI) Board of Nursing regulates RN licensure. The process is fully online and is a popular pathway for Filipino nurses seeking US licensure.',
  '[
    {"number": 1, "title": "Check Eligibility for CNMI RN License", "description": "Review the CNMI Board of Nursing eligibility requirements for foreign-educated nurses.", "checklist": ["Verify your Philippine nursing program meets CNMI standards", "Confirm you hold a current Philippine RN license", "Check English proficiency requirements"], "link_url": "https://cnmiboardofnursing.gov", "link_label": "CNMI Board of Nursing"},
    {"number": 2, "title": "Prepare Required Documents", "description": "Gather all documents needed for your CNMI RN license application.", "checklist": ["Official transcripts from Philippine nursing school", "Philippine PRC license verification", "Passport copy", "Passport-size photos", "Credential evaluation (if required)"], "link_url": "", "link_label": ""},
    {"number": 3, "title": "Create Online Application", "description": "Register an account on the CNMI Board of Nursing online portal.", "checklist": ["Visit the CNMI Board of Nursing website", "Create a new applicant account", "Fill out the online application form"], "link_url": "https://cnmiboardofnursing.gov", "link_label": "CNMI Online Portal"},
    {"number": 4, "title": "Submit Application", "description": "Complete and submit your online application with all required documents uploaded.", "checklist": ["Upload all required documents", "Review your application for accuracy", "Submit the application"], "link_url": "", "link_label": ""},
    {"number": 5, "title": "Pay Application Fee", "description": "Pay the required application fee through the online portal.", "checklist": ["Pay application fee online", "Save your payment confirmation"], "link_url": "", "link_label": ""},
    {"number": 6, "title": "Wait for Evaluation", "description": "The CNMI Board of Nursing reviews your application and documents. This may take several weeks.", "checklist": ["Monitor your email for updates", "Respond promptly to any requests for additional information"], "link_url": "", "link_label": ""},
    {"number": 7, "title": "Receive Authorization to Schedule NCLEX", "description": "Once approved, you will receive authorization to register for the NCLEX-RN through Pearson VUE.", "checklist": ["Register with Pearson VUE", "Pay the NCLEX registration fee", "Receive your Authorization to Test (ATT)"], "link_url": "https://www.pearsonvue.com/nclex", "link_label": "Pearson VUE"},
    {"number": 8, "title": "Schedule and Take the NCLEX-RN Exam", "description": "Use your ATT to schedule and take the NCLEX-RN at a Pearson VUE testing center.", "checklist": ["Choose a testing center", "Schedule your exam date", "Bring valid ID and arrive early", "Complete the exam"], "link_url": "https://www.pearsonvue.com/nclex", "link_label": "Schedule NCLEX"}
  ]'::jsonb,
  '[
    {"title": "Official Website", "items": ["CNMI Board of Nursing: https://cnmiboardofnursing.gov", "All applications are submitted online", "Contact the board via the online portal for questions"]},
    {"title": "Estimated Waiting Time", "items": ["Application evaluation: 4-8 weeks", "NCLEX ATT issuance: 2-4 weeks after approval", "Total estimated time: 3-6 months from start to exam"]},
    {"title": "Key Requirements Summary", "items": ["Philippine nursing degree", "Active Philippine PRC RN license", "English proficiency", "Complete online application", "Pass the NCLEX-RN exam"]},
    {"title": "Important Notes", "items": ["CNMI is a US territory — licensure is valid within CNMI", "Verify if CNMI license is endorsable to other US states", "Keep all original documents for future reference", "Use BulletRN QBanks for NCLEX preparation"]}
  ]'::jsonb,
  '[
    {"label": "CNMI Board of Nursing", "url": "https://cnmiboardofnursing.gov"},
    {"label": "Pearson VUE NCLEX", "url": "https://www.pearsonvue.com/nclex"}
  ]'::jsonb,
  true
) ON CONFLICT (id) DO NOTHING;
