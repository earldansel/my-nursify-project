/*
# Create Study Guide system (subjects, topics, user progress)

## Purpose
A standalone NCLEX Study Guide / blueprint section that helps students understand
WHAT to study for each NCLEX subject. This is completely separate from the Practice
question system — no question counts, no mastery from quiz answers.

## New Tables

1. `study_guide_subjects`
   - `id` (text, primary key) — e.g. 'pharmacology', 'medsurg'
   - `name` (text) — display name e.g. 'Pharmacology'
   - `slug` (text, unique) — URL slug e.g. 'pharmacology'
   - `description` (text) — short description shown on card
   - `accent_color` (text) — hex color for card styling
   - `icon` (text) — icon key from lucide
   - `sort_order` (int) — display order
   - `created_at`, `updated_at`

2. `study_guide_topics`
   - `id` (uuid, primary key)
   - `subject_id` (text, FK to study_guide_subjects.id)
   - `title` (text) — e.g. 'Cardiovascular Medications'
   - `description` (text) — short overview
   - `key_concepts` (text[]) — important concepts to study
   - `nursing_considerations` (text[]) — key nursing considerations
   - `sort_order` (int)
   - `created_at`, `updated_at`

3. `study_guide_progress`
   - `id` (uuid, primary key)
   - `user_id` (uuid, NOT NULL, DEFAULT auth.uid())
   - `topic_id` (uuid, FK to study_guide_topics.id)
   - `studied` (boolean, default false)
   - `studied_at` (timestamptz, nullable)
   - `created_at`, `updated_at`
   - UNIQUE(user_id, topic_id)

## Security
- `study_guide_subjects` and `study_guide_topics`: public read (anon + authenticated),
  no public write — admin manages content via service role or admin UI.
- `study_guide_progress`: owner-scoped CRUD for authenticated users only.
*/

-- Subjects table
CREATE TABLE IF NOT EXISTS public.study_guide_subjects (
  id text PRIMARY KEY,
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text NOT NULL DEFAULT '',
  accent_color text NOT NULL DEFAULT '#3b82f6',
  icon text NOT NULL DEFAULT 'book-open',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.study_guide_subjects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sg_subjects_select_all" ON public.study_guide_subjects;
CREATE POLICY "sg_subjects_select_all" ON public.study_guide_subjects
  FOR SELECT TO anon, authenticated USING (true);

-- Topics table
CREATE TABLE IF NOT EXISTS public.study_guide_topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id text NOT NULL REFERENCES public.study_guide_subjects(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  key_concepts text[] NOT NULL DEFAULT '{}',
  nursing_considerations text[] NOT NULL DEFAULT '{}',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.study_guide_topics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sg_topics_select_all" ON public.study_guide_topics;
CREATE POLICY "sg_topics_select_all" ON public.study_guide_topics
  FOR SELECT TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_sg_topics_subject ON public.study_guide_topics(subject_id);

-- Progress table
CREATE TABLE IF NOT EXISTS public.study_guide_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  topic_id uuid NOT NULL REFERENCES public.study_guide_topics(id) ON DELETE CASCADE,
  studied boolean NOT NULL DEFAULT false,
  studied_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, topic_id)
);

ALTER TABLE public.study_guide_progress ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sg_progress_select_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_select_own" ON public.study_guide_progress
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "sg_progress_insert_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_insert_own" ON public.study_guide_progress
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "sg_progress_update_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_update_own" ON public.study_guide_progress
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "sg_progress_delete_own" ON public.study_guide_progress;
CREATE POLICY "sg_progress_delete_own" ON public.study_guide_progress
  FOR DELETE TO authenticated USING (auth.uid() = user_id);
