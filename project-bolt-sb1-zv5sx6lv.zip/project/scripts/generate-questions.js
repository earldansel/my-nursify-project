#!/usr/bin/env node
// Generates 3,500 original NCLEX-RN practice questions and outputs SQL insert statements
// Usage: node generate-questions.js > questions.sql

// ============================================================
// QUESTION CONTENT LIBRARIES
// ============================================================

// Subject configurations
const SUBJECTS = {
  pharmacology: { id: 'pharmacology', name: 'Pharmacology', prefix: 'PHARM' },
  medsurg: { id: 'medsurg', name: 'Med-Surg', prefix: 'MS' },
  pediatrics: { id: 'pediatrics', name: 'Pediatrics', prefix: 'PEDS' },
  mentalhealth: { id: 'mentalhealth', name: 'Mental Health', prefix: 'MH' },
  ob: { id: 'ob', name: 'Maternal & Newborn', prefix: 'OB' },
  fundamentals: { id: 'fundamentals', name: 'Fundamentals', prefix: 'FUND' },
};

// Topic banks per subject - each topic has clinical scenarios
const TOPIC_BANKS = {
  pharmacology: [
    'Cardiovascular Medications', 'Anticoagulants', 'Antidiabetics', 'Antibiotics',
    'Psychiatric Medications', 'Pain Management', 'Anti-inflammatory Drugs',
    'Respiratory Medications', 'GI Medications', 'Neurological Medications',
    'Oncology Medications', 'Emergency Drugs', 'Vitamins & Supplements',
    'Herbal Supplements', 'IV Medications', 'Topical Medications',
    'Ophthalmic Medications', 'Ear Medications', 'Immunizations',
    'Antihypertensives', 'Diuretics', 'Antiarrhythmics', 'Cholesterol Medications',
    'Thyroid Medications', 'Corticosteroids', 'Antiepileptics',
  ],
  medsurg: [
    'Cardiac Disorders', 'Respiratory Disorders', 'GI Disorders', 'Renal Disorders',
    'Neurological Disorders', 'Endocrine Disorders', 'Hematologic Disorders',
    'Musculoskeletal Disorders', 'Integumentary Disorders', 'Immune Disorders',
    'Oncology Nursing', 'Perioperative Care', 'Emergency Nursing',
    'Shock', 'Fluid & Electrolyte Imbalances', 'Acid-Base Imbalances',
    'Nutrition Support', 'Wound Care', 'Infectious Diseases',
    'Sepsis Management', 'Trauma Nursing', 'Burns Management',
    'Organ Transplant', 'Bariatric Surgery',
  ],
  pediatrics: [
    'Growth & Development', 'Respiratory Disorders', 'Cardiac Disorders',
    'GI Disorders', 'Neurological Disorders', 'Renal Disorders',
    'Hematologic Disorders', 'Infectious Diseases', 'Endocrine Disorders',
    'Musculoskeletal Disorders', 'Skin Disorders', 'Child Abuse Recognition',
    'Immunizations', 'Newborn Care', 'Adolescent Health',
    'Psychosocial Development', 'Pain Management in Children',
    'Medication Administration for Children', 'Emergency Care for Children',
    'Chronic Illness in Children', 'Developmental Milestones',
    'Autism Spectrum', 'ADHD Management', 'Childhood Diabetes',
    'Asthma Management', 'Cystic Fibrosis', 'Sickle Cell Disease',
  ],
  mentalhealth: [
    'Anxiety Disorders', 'Mood Disorders', 'Psychotic Disorders',
    'Substance Use Disorders', 'Eating Disorders', 'Personality Disorders',
    'Cognitive Disorders', 'Childhood Mental Health', 'Crisis Intervention',
    'Suicide Prevention', 'Grief & Loss', 'Sleep Disorders',
    'Sexual Disorders', 'Anger Management', 'Group Therapy',
    'Milieu Therapy', 'Psychiatric Medications', 'Electroconvulsive Therapy',
    'Restraint & Seclusion', 'Therapeutic Communication',
    'Trauma & PTSD', 'Bipolar Disorder', 'Schizophrenia',
    'Depression', 'OCD & Related Disorders',
  ],
  ob: [
    'Prenatal Care', 'Labor & Delivery', 'Postpartum Care', 'Newborn Assessment',
    'Gestational Complications', 'Hypertensive Disorders of Pregnancy',
    'Hemorrhage in Pregnancy', 'Preterm Labor', 'Fetal Monitoring',
    'Pain Management in Labor', 'Cesarean Delivery', 'Newborn Nutrition',
    'Contraception', 'Infertility', 'STIs in Pregnancy',
    'Ectopic Pregnancy', 'Gestational Diabetes', 'Newborn Complications',
    'Postpartum Complications', 'Newborn Resuscitation', 'Fetal Demise',
    'High-Risk Pregnancy', 'Obstetric Emergencies', 'Newborn Screening',
  ],
  fundamentals: [
    'Infection Control', 'Safety & Security', 'Hygiene & Comfort',
    'Mobility & Immobility', 'Nutrition', 'Fluid Balance',
    'Sleep & Rest', 'Pain Management', 'Documentation',
    'Vital Signs', 'Assessment Techniques', 'Specimen Collection',
    'Medication Administration', 'IV Therapy', 'Wound Care',
    'Perioperative Care', 'Patient Education', 'Communication',
    'Ethics & Legal', 'Leadership & Management', 'Delegation',
    'Time Management', 'Quality Improvement', 'Cultural Competence',
    'End-of-Life Care', 'Disaster Planning', 'Fall Prevention',
  ],
};

// Mixed categories for the random set
const MIXED_TOPICS = [
  'Pharmacology', 'Medical-Surgical Nursing', 'Fundamentals', 'Pediatrics',
  'Maternal & Newborn', 'Mental Health', 'Safety and Infection Control',
  'Leadership and Management', 'Priority and Delegation', 'Emergency Nursing',
  'Ethical and Legal Nursing', 'Nutrition', 'Critical Care',
];

// ============================================================
// CLINICAL SCENARIO TEMPLATES
// ============================================================

// Each template generates a unique question with options and rationale

const SCENARIO_TEMPLATES = {
  pharmacology: [
    {
      build: (n) => ({
        q: `A nurse is preparing to administer ${pickMed(n)} ${n % 2 === 0 ? 'orally' : 'intravenously'} to a client. Which assessment finding should the nurse verify before administration?`,
        opts: [
          { id: 'a', label: `Blood pressure within the client's baseline range` },
          { id: 'b', label: `Recent intake of ${n % 2 === 0 ? 'grapefruit juice' : 'a high-fat meal'}` },
          { id: 'c', label: `Serum ${n % 3 === 0 ? 'potassium' : n % 3 === 1 ? 'sodium' : 'magnesium'} level of ${3.5 + (n % 10) / 10} mEq/L` },
          { id: 'd', label: `Heart rate of ${72 + (n % 20)} bpm` },
        ],
        correct: 'a',
        rationale: `Before administering medications with cardiovascular effects, the nurse must verify the blood pressure is within the client's baseline. This ensures the medication can be safely given and helps establish a baseline for monitoring effectiveness and adverse effects.`,
        optionRationales: {
          a: 'Correct. Verifying the blood pressure baseline is essential before administering medications that may affect hemodynamics.',
          b: 'While grapefruit juice and food interactions matter for certain drugs, the priority assessment is the vital sign baseline.',
          c: 'Electrolyte monitoring is important for specific medications but is not a universal pre-administration check.',
          d: 'Heart rate is part of vital signs but blood pressure is the most critical parameter for medications affecting the cardiovascular system.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A client receiving ${pickMed(n)} reports ${pickSymptom(n)} on day ${1 + (n % 5)} of therapy. What is the nurse's priority action?`,
        opts: [
          { id: 'a', label: 'Document the finding and continue monitoring' },
          { id: 'b', label: 'Withhold the medication and notify the healthcare provider' },
          { id: 'c', label: 'Administer a PRN medication for symptom relief' },
          { id: 'd', label: 'Reassure the client that this is an expected side effect' },
        ],
        correct: 'b',
        rationale: `When a client reports new or worsening symptoms during medication therapy, the nurse should withhold the medication and notify the provider. This prevents potential adverse drug reactions from progressing and allows the provider to evaluate whether the medication should be adjusted, discontinued, or switched.`,
        optionRationales: {
          a: 'Documenting alone is insufficient when the client is experiencing a potential adverse reaction.',
          b: 'Correct. Withholding the medication and notifying the provider is the priority to prevent further harm.',
          c: 'Administering another medication without provider input may compound the problem.',
          d: 'Reassuring the client without assessment dismisses a potentially serious adverse reaction.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A nurse is teaching a client about ${pickMed(n)}. Which statement by the client indicates understanding of the medication regimen?`,
        opts: [
          { id: 'a', label: `"I will take this medication only when I feel I need it."` },
          { id: 'b', label: `"I should take this medication at the same time each day as prescribed."` },
          { id: 'c', label: `"I can stop taking this medication once my symptoms improve."` },
          { id: 'd', label: `"It is safe to share this medication with family members who have similar conditions."` },
        ],
        correct: 'b',
        rationale: `Taking medication at the same time each day maintains therapeutic blood levels and demonstrates understanding of the prescribed regimen. Clients should never self-adjust dosing, stop medications prematurely, or share prescriptions with others, as these practices can lead to treatment failure, resistance, or adverse effects.`,
        optionRationales: {
          a: 'Self-adjusting medication based on perceived need leads to subtherapeutic dosing and treatment failure.',
          b: 'Correct. Consistent timing maintains therapeutic drug levels and shows understanding of the regimen.',
          c: 'Stopping medication prematurely can cause rebound effects, resistance, or relapse.',
          d: 'Sharing prescription medications is unsafe, illegal, and can cause harm to others.',
        },
      }),
    },
  ],
  medsurg: [
    {
      build: (n) => ({
        q: `A ${40 + (n % 40)}-year-old client is admitted with ${pickCondition(n)}. Which finding should the nurse report to the provider immediately?`,
        opts: [
          { id: 'a', label: `Temperature of ${99 + (n % 3)}.${n % 9}°F (${37.2 + (n % 3) * 0.1}°C)` },
          { id: 'b', label: `Respiratory rate of ${22 + (n % 8)} breaths per minute` },
          { id: 'c', label: 'Sudden onset of confusion and restlessness' },
          { id: 'd', label: `Heart rate of ${88 + (n % 15)} bpm` },
        ],
        correct: 'c',
        rationale: `Sudden onset of confusion and restlessness in a hospitalized client may indicate hypoxia, infection, or a neurological event. Acute changes in mental status are a red flag that requires immediate provider notification, as they can signal life-threatening deterioration such as sepsis, hypoxemia, or stroke.`,
        optionRationales: {
          a: 'A low-grade fever warrants monitoring but is not as urgent as an acute mental status change.',
          b: 'An elevated respiratory rate requires assessment but is less specific than acute confusion.',
          c: 'Correct. Sudden confusion and restlessness may indicate hypoxia or a neurological emergency and must be reported immediately.',
          d: 'A mildly elevated heart rate is not immediately concerning without other symptoms.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A client with ${pickCondition(n)} is being discharged. Which discharge instruction is most important for the nurse to include?`,
        opts: [
          { id: 'a', label: 'Follow up with the healthcare provider as scheduled' },
          { id: 'b', label: 'Monitor for warning signs and seek emergency care if they occur' },
          { id: 'c', label: 'Maintain a balanced diet and adequate hydration' },
          { id: 'd', label: 'Keep a daily journal of symptoms' },
        ],
        correct: 'b',
        rationale: `The most critical discharge instruction is teaching the client to recognize warning signs that require emergency care. While all instructions are important, the ability to identify and respond to deteriorating conditions can prevent readmission and save the client's life. This is the priority teaching point before discharge.`,
        optionRationales: {
          a: 'Follow-up appointments are important but not as urgent as knowing when to seek emergency care.',
          b: 'Correct. Recognizing and responding to warning signs is the most critical discharge instruction to prevent complications.',
          c: 'Diet and hydration are part of general health maintenance but are secondary to safety.',
          d: 'Symptom journaling is helpful for ongoing management but is not the priority discharge instruction.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A nurse is caring for a client with ${pickCondition(n)} who has an order for ${pickIntervention(n)}. Which action should the nurse take first?`,
        opts: [
          { id: 'a', label: 'Verify the order and confirm client identity using two identifiers' },
          { id: 'b', label: 'Gather the necessary supplies and equipment' },
          { id: 'c', label: 'Explain the procedure to the client and obtain consent' },
          { id: 'd', label: 'Assess the client\'s current status and vital signs' },
        ],
        correct: 'a',
        rationale: `Before performing any intervention, the nurse must first verify the order and confirm the client's identity using two identifiers. This is a National Patient Safety Goal and the foundation of safe nursing practice. All other steps follow after correct client identification.`,
        optionRationales: {
          a: 'Correct. Verifying the order and confirming client identity with two identifiers is the first step in safe nursing practice.',
          b: 'Gathering supplies is important but must follow client identification.',
          c: 'Explaining the procedure follows verification of the order and client identity.',
          d: 'Assessment is important but follows the safety check of verifying the order and client identity.',
        },
      }),
    },
  ],
  pediatrics: [
    {
      build: (n) => ({
        q: `A ${1 + (n % 12)}-year-old child is brought to the clinic by a parent who reports ${pickPedSymptom(n)}. What is the nurse's best initial response?`,
        opts: [
          { id: 'a', label: 'Immediately administer medication to address the symptom' },
          { id: 'b', label: 'Assess the child and gather a detailed history from the parent' },
          { id: 'c', label: 'Reassure the parent that the symptom is common and not concerning' },
          { id: 'd', label: 'Refer the family to the emergency department without assessment' },
        ],
        correct: 'b',
        rationale: `The nurse's best initial response is to assess the child and gather a detailed history. Assessment is always the first step in the nursing process and provides the data needed to determine the severity of the symptom, identify potential causes, and guide further interventions. Acting without assessment is unsafe.`,
        optionRationales: {
          a: 'Administering medication before assessment is unsafe and may mask serious symptoms.',
          b: 'Correct. Assessment and history gathering provide the foundation for safe clinical decision-making.',
          c: 'Reassuring without assessment dismisses the parent\'s concern and may miss a serious condition.',
          d: 'Referring without assessment is premature; the nurse must evaluate the child first.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `When communicating with a ${2 + (n % 10)}-year-old child, which approach by the nurse is most developmentally appropriate?`,
        opts: [
          { id: 'a', label: 'Use medical terminology to promote learning' },
          { id: 'b', label: 'Speak at the child\'s eye level using simple, concrete language' },
          { id: 'c', label: 'Direct all questions to the parent rather than the child' },
          { id: 'd', label: 'Use abstract explanations to encourage critical thinking' },
        ],
        correct: 'b',
        rationale: `Speaking at the child's eye level using simple, concrete language is the most developmentally appropriate approach. Young children think concretely and understand best when information is presented in a way that relates to their direct experience. This approach builds trust and reduces anxiety during healthcare encounters.`,
        optionRationales: {
          a: 'Medical terminology is too complex for young children and may increase fear.',
          b: 'Correct. Eye-level communication with simple, concrete language is developmentally appropriate and builds trust.',
          c: 'Excluding the child from communication reduces trust and increases anxiety.',
          d: 'Abstract thinking develops in adolescence; young children need concrete explanations.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A nurse is preparing to administer medication to a ${3 + (n % 14)}-year-old child. Which action by the nurse ensures safe medication administration?`,
        opts: [
          { id: 'a', label: 'Use the child\'s weight to calculate the dose and verify with a second nurse' },
          { id: 'b', label: 'Administer the same dose as an adult since the child is large for their age' },
          { id: 'c', label: 'Crush all medications and mix them in a large amount of food' },
          { id: 'd', label: 'Ask the parent to estimate the child\'s weight for dosing' },
        ],
        correct: 'a',
        rationale: `Pediatric medication dosing is weight-based, and the nurse must use the child's actual weight to calculate the dose. Verifying with a second nurse is a safety measure that reduces medication errors. Estimating weight or using adult dosing can lead to dangerous overdoses or underdoses in children.`,
        optionRationales: {
          a: 'Correct. Weight-based dosing with double verification is the standard for safe pediatric medication administration.',
          b: 'Adult dosing is never appropriate for children regardless of size.',
          c: 'Not all medications can be crushed, and mixing in large amounts of food may result in incomplete dosing.',
          d: 'Estimated weights lead to dosing errors; actual weight must be used.',
        },
      }),
    },
  ],
  mentalhealth: [
    {
      build: (n) => ({
        q: `A client with ${pickPsychCondition(n)} says to the nurse, "I don't think this treatment is helping me." What is the nurse's most therapeutic response?`,
        opts: [
          { id: 'a', label: '"You need to give the treatment more time to work."' },
          { id: 'b', label: '"Tell me more about what makes you feel that way."' },
          { id: 'c', label: '"Your doctor knows what\'s best for you."' },
          { id: 'd', label: '"Many patients feel that way at first."' },
        ],
        correct: 'b',
        rationale: `The therapeutic response explores the client's feelings and encourages them to elaborate. Using an open-ended, client-centered approach builds the therapeutic relationship and helps the nurse understand the client's perspective. Dismissing feelings, giving false reassurance, or minimizing concerns are non-therapeutic communication techniques.`,
        optionRationales: {
          a: 'Telling the client to wait is dismissive and does not explore their concerns.',
          b: 'Correct. An open-ended, exploratory response is therapeutic and client-centered.',
          c: 'Deferring to the doctor dismisses the client\'s feelings and is non-therapeutic.',
          d: 'Generalizing the client\'s feelings minimizes their individual experience.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A nurse is caring for a client admitted with ${pickPsychCondition(n)}. Which behavior should the nurse identify as a potential safety concern?`,
        opts: [
          { id: 'a', label: 'The client prefers to stay in their room during group activities' },
          { id: 'b', label: 'The client verbalizes feelings of hopelessness and being a burden to others' },
          { id: 'c', label: 'The client asks for a sleeping pill at bedtime' },
          { id: 'd', label: 'The client expresses disagreement with the treatment plan' },
        ],
        correct: 'b',
        rationale: `Verbalizing feelings of hopelessness and being a burden is a warning sign for suicide risk. The nurse must assess for suicidal ideation, implement safety precautions, and notify the treatment team. While the other behaviors may need addressing, safety concerns take priority.`,
        optionRationales: {
          a: 'Social withdrawal is common but is not an immediate safety concern.',
          b: 'Correct. Hopelessness and feeling like a burden are significant suicide risk indicators.',
          c: 'Requesting sleep medication is common and not a safety concern by itself.',
          d: 'Disagreeing with treatment is a normal part of the therapeutic process.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A client with ${pickPsychCondition(n)} is being discharged. Which statement indicates readiness for discharge?`,
        opts: [
          { id: 'a', label: '"I will stop my medication once I feel better."' },
          { id: 'b', label: '"I have a plan to attend my follow-up appointments and a support group."' },
          { id: 'c', label: '"I don\'t think I need to come back to the clinic anymore."' },
          { id: 'd', label: '"I will handle my symptoms on my own without bothering anyone."' },
        ],
        correct: 'b',
        rationale: `Having a concrete plan for follow-up appointments and support group attendance demonstrates readiness for discharge. It shows the client understands the importance of continued treatment, has a support system, and is engaged in their recovery. The other statements indicate poor insight or risk of relapse.`,
        optionRationales: {
          a: 'Stopping medication prematurely is a sign of poor understanding, not readiness.',
          b: 'Correct. A concrete follow-up plan demonstrates engagement in recovery and readiness for discharge.',
          c: 'Refusing follow-up indicates poor insight and is not readiness for discharge.',
          d: 'Isolating from support is a relapse risk factor, not readiness.',
        },
      }),
    },
  ],
  ob: [
    {
      build: (n) => ({
        q: `A pregnant client at ${28 + (n % 12)} weeks gestation reports ${pickObsSymptom(n)} during a prenatal visit. What is the nurse's priority action?`,
        opts: [
          { id: 'a', label: 'Document the finding as a normal pregnancy change' },
          { id: 'b', label: 'Assess the client further and notify the healthcare provider' },
          { id: 'c', label: 'Reassure the client that this is expected at this gestational age' },
          { id: 'd', label: 'Schedule the next routine prenatal appointment' },
        ],
        correct: 'b',
        rationale: `Any new symptom during pregnancy requires further assessment and provider notification. The nurse cannot assume symptoms are normal without evaluation, as they may indicate complications such as preeclampsia, preterm labor, or fetal distress. Assessment followed by escalation is the safest approach.`,
        optionRationales: {
          a: 'Documenting without assessment is unsafe; new symptoms may indicate complications.',
          b: 'Correct. Further assessment and provider notification ensure potential complications are identified promptly.',
          c: 'Reassuring without assessment dismisses a potentially serious symptom.',
          d: 'Scheduling a routine appointment delays evaluation of a potentially urgent symptom.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A nurse is caring for a client in labor at ${38 + (n % 3)} weeks gestation. The fetal heart rate monitor shows ${pickFHRPattern(n)}. What is the nurse's first action?`,
        opts: [
          { id: 'a', label: 'Reposition the client to a lateral position' },
          { id: 'b', label: 'Immediately prepare for an emergency cesarean delivery' },
          { id: 'c', label: 'Administer oxygen via face mask at 10 L/min' },
          { id: 'd', label: 'Document the finding and continue monitoring' },
        ],
        correct: 'a',
        rationale: `When an abnormal fetal heart rate pattern is noted, the nurse's first action is to reposition the client to a lateral position. This optimizes uteroplacental perfusion and may resolve the pattern. If the pattern persists, oxygen and provider notification follow. Repositioning is the least invasive and fastest intervention.`,
        optionRationales: {
          a: 'Correct. Repositioning to a lateral position is the first-line intervention to improve uteroplacental perfusion.',
          b: 'Preparing for cesarean is premature before trying conservative interventions.',
          c: 'Oxygen may be needed but follows repositioning as the first step.',
          d: 'Documenting without intervention is unsafe when the fetal heart rate is abnormal.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A postpartum client on day ${1 + (n % 5)} after delivery reports ${pickPPSymptom(n)}. Which action should the nurse take first?`,
        opts: [
          { id: 'a', label: 'Assess the client\'s vital signs and fundus' },
          { id: 'b', label: 'Administer prescribed pain medication' },
          { id: 'c', label: 'Encourage the client to rest and ambulate when ready' },
          { id: 'd', label: 'Document the finding in the medical record' },
        ],
        correct: 'a',
        rationale: `The nurse should first assess the postpartum client's vital signs and fundus when new symptoms are reported. This assessment helps determine whether the symptom is related to postpartum hemorrhage, infection, or another complication. Assessment guides all subsequent interventions and ensures patient safety.`,
        optionRationales: {
          a: 'Correct. Assessing vital signs and fundus is the priority to identify potential postpartum complications.',
          b: 'Pain medication may be needed but only after assessment determines the cause.',
          c: 'Encouraging rest is inappropriate without first assessing the symptom.',
          d: 'Documentation follows assessment and intervention, not before.',
        },
      }),
    },
  ],
  fundamentals: [
    {
      build: (n) => ({
        q: `A nurse is caring for a client on ${pickPrecaution(n)}. Which action by the nurse demonstrates proper infection control practices?`,
        opts: [
          { id: 'a', label: 'Wearing gloves when entering the room and removing them before exiting' },
          { id: 'b', label: 'Performing hand hygiene before donning and after removing personal protective equipment' },
          { id: 'c', label: 'Reusing the same gown for multiple clients on the same precautions' },
          { id: 'd', label: 'Using an alcohol-based hand rub in all situations regardless of the pathogen' },
        ],
        correct: 'b',
        rationale: `Performing hand hygiene before donning and after removing PPE is the cornerstone of infection control. This practice prevents the transmission of pathogens to and from the nurse and the client. Hand hygiene must be performed at the right moments, and the type of precaution determines the appropriate PPE.`,
        optionRationales: {
          a: 'Gloves alone are insufficient; hand hygiene and proper PPE use are required.',
          b: 'Correct. Hand hygiene before and after PPE use is the foundation of infection control.',
          c: 'Reusing gowns between clients is a violation of infection control standards.',
          d: 'Alcohol-based rubs are not effective against all pathogens (e.g., C. difficile spores).',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A nurse is delegating care tasks to a ${pickDelegatee(n)}. Which task is appropriate for the nurse to delegate?`,
        opts: [
          { id: 'a', label: 'Assessing a newly admitted client\'s vital signs and reporting abnormalities' },
          { id: 'b', label: 'Developing the plan of care for a client with complex needs' },
          { id: 'c', label: 'Administering IV push medications to a client with unstable vital signs' },
          { id: 'd', label: 'Providing discharge teaching to a client about new medications' },
        ],
        correct: 'a',
        rationale: `Delegating vital sign measurement and reporting abnormalities is appropriate for unlicensed assistive personnel, provided the client is stable. The nurse retains responsibility for assessment, care planning, medication administration, and teaching. Delegation must follow the five rights: right task, right circumstance, right person, right direction, and right supervision.`,
        optionRationales: {
          a: 'Correct. Measuring and reporting vital signs is within the scope of unlicensed personnel for stable clients.',
          b: 'Care planning is a nursing responsibility and cannot be delegated.',
          c: 'IV push medications require a licensed nurse and cannot be delegated to unlicensed staff.',
          d: 'Discharge teaching is a nursing responsibility that requires professional judgment.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A client is at risk for ${pickSafetyRisk(n)}. Which nursing intervention is most effective in preventing this complication?`,
        opts: [
          { id: 'a', label: 'Implementing hourly rounding and keeping the call light within reach' },
          { id: 'b', label: 'Restraining the client to prevent movement' },
          { id: 'c', label: 'Instructing the client to call for assistance only when absolutely necessary' },
          { id: 'd', label: 'Keeping the room dark to promote rest' },
        ],
        correct: 'a',
        rationale: `Hourly rounding and keeping the call light within reach are evidence-based interventions that prevent falls and other safety events. These proactive measures address toileting needs, pain, and positioning before the client attempts to get up alone. Restraints are a last resort, and restricting call light use or keeping rooms dark increases risk.`,
        optionRationales: {
          a: 'Correct. Hourly rounding and accessible call lights are evidence-based safety interventions.',
          b: 'Restraints are a last resort and can increase injury risk; they are not preventive.',
          c: 'Restricting call light use discourages help-seeking and increases fall risk.',
          d: 'A dark room increases fall risk; adequate lighting is a safety measure.',
        },
      }),
    },
  ],
};

// ============================================================
// HELPER FUNCTIONS
// ============================================================

const MEDS = ['metoprolol', 'lisinopril', 'furosemide', 'warfarin', 'insulin glargine', 'omeprazole', 'sertraline', 'levothyroxine', 'atorvastatin', 'amlodipine', 'metformin', 'albuterol', 'hydrochlorothiazide', 'gabapentin', 'tramadol', 'ciprofloxacin', 'vancomycin', 'heparin', 'digoxin', 'prednisone'];
const SYMPTOMS = ['nausea', 'dizziness', 'headache', 'fatigue', 'rash', 'shortness of breath', 'chest tightness', 'leg swelling', 'blurred vision', 'dry mouth', 'insomnia', 'muscle cramps'];
const CONDITIONS = ['heart failure', 'COPD', 'pneumonia', 'diabetes mellitus', 'hypertension', 'chronic kidney disease', 'cirrhosis', 'stroke', 'deep vein thrombosis', 'anemia', 'asthma', 'peptic ulcer disease'];
const INTERVENTIONS = ['continuous IV infusion', 'nasogastric tube insertion', 'urinary catheterization', 'wound dressing change', 'blood transfusion', 'chest tube management', 'IV antibiotic therapy', 'oxygen therapy'];
const PED_SYMPTOMS = ['persistent fever', 'decreased appetite', 'ear pulling and irritability', 'a limp when walking', 'frequent coughing at night', 'a rash on the trunk', 'vomiting after meals'];
const PSYCH_CONDITIONS = ['major depressive disorder', 'bipolar disorder', 'generalized anxiety disorder', 'schizophrenia', 'PTSD', 'panic disorder', 'OCD', 'substance use disorder'];
const OBS_SYMPTOMS = ['swelling in the hands and face', 'severe headache with visual changes', 'persistent nausea and vomiting', 'decreased fetal movement', 'abdominal pain', 'leg pain and swelling'];
const FHR_PATTERNS = ['late decelerations', 'variable decelerations', 'minimal variability', 'prolonged deceleration', 'absent variability', 'tachycardia'];
const PP_SYMPTOMS = ['heavy vaginal bleeding', 'fever and chills', 'severe perineal pain', 'breast engorgement', 'persistent headache', 'calf tenderness'];
const PRECAUTIONS = ['contact precautions', 'droplet precautions', 'airborne precautions', 'standard precautions', 'enteric precautions', 'neutropenic precautions'];
const DELEGATEES = ['nursing assistant', 'licensed practical nurse', 'student nurse', 'unlicensed assistive personnel'];
const SAFETY_RISKS = ['falls', 'pressure injuries', 'aspiration', 'infection', 'deep vein thrombosis', 'dehydration'];

function pickMed(n) { return MEDS[n % MEDS.length]; }
function pickSymptom(n) { return SYMPTOMS[n % SYMPTOMS.length]; }
function pickCondition(n) { return CONDITIONS[n % CONDITIONS.length]; }
function pickIntervention(n) { return INTERVENTIONS[n % INTERVENTIONS.length]; }
function pickPedSymptom(n) { return PED_SYMPTOMS[n % PED_SYMPTOMS.length]; }
function pickPsychCondition(n) { return PSYCH_CONDITIONS[n % PSYCH_CONDITIONS.length]; }
function pickObsSymptom(n) { return OBS_SYMPTOMS[n % OBS_SYMPTOMS.length]; }
function pickFHRPattern(n) { return FHR_PATTERNS[n % FHR_PATTERNS.length]; }
function pickPPSymptom(n) { return PP_SYMPTOMS[n % PP_SYMPTOMS.length]; }
function pickPrecaution(n) { return PRECAUTIONS[n % PRECAUTIONS.length]; }
function pickDelegatee(n) { return DELEGATEES[n % DELEGATEES.length]; }
function pickSafetyRisk(n) { return SAFETY_RISKS[n % SAFETY_RISKS.length]; }

// Additional clinical scenario templates for more variety
const ADDITIONAL_TEMPLATES = {
  pharmacology: [
    {
      build: (n) => ({
        q: `A client is prescribed ${pickMed(n)} and asks the nurse about potential ${n % 2 === 0 ? 'food interactions' : 'herbal supplement interactions'}. Which response by the nurse is most appropriate?`,
        opts: [
          { id: 'a', label: '"There are no interactions you need to worry about with this medication."' },
          { id: 'b', label: '"Let me check with your pharmacist about specific interactions, and I\'ll provide you with written information."' },
          { id: 'c', label: '"You should avoid all foods and supplements while on this medication."' },
          { id: 'd', label: '"Herbal supplements are always safe to take with prescription medications."' },
        ],
        correct: 'b',
        rationale: `The nurse should consult with the pharmacist for accurate interaction information and provide written materials. Many medications have significant interactions with foods (e.g., grapefruit with statins) and herbal supplements (e.g., St. John's Wort with antidepressants). Providing accurate, individualized information is essential for safe medication management.`,
        optionRationales: {
          a: 'Dismissing interaction concerns is dangerous; many medications have significant interactions.',
          b: 'Correct. Consulting the pharmacist and providing written information is the safest and most accurate approach.',
          c: 'Avoiding all foods and supplements is unnecessary and unrealistic; specific interactions should be discussed.',
          d: 'Herbal supplements can interact dangerously with prescription medications.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A nurse is calculating the dosage of ${pickMed(n)} for a client weighing ${50 + (n % 50)} kg. The order is for ${0.5 + (n % 5) * 0.5} mg/kg. What is the total dose to administer?`,
        opts: [
          { id: 'a', label: `${((50 + (n % 50)) * (0.5 + (n % 5) * 0.5)).toFixed(1)} mg` },
          { id: 'b', label: `${((50 + (n % 50)) * (0.5 + (n % 5) * 0.5) * 2).toFixed(1)} mg` },
          { id: 'c', label: `${((50 + (n % 50)) * (0.5 + (n % 5) * 0.5) / 2).toFixed(1)} mg` },
          { id: 'd', label: `${((50 + (n % 50)) + (0.5 + (n % 5) * 0.5)).toFixed(1)} mg` },
        ],
        correct: 'a',
        rationale: `Weight-based dosing requires multiplying the client's weight by the ordered dose per kilogram. The calculation is: weight (kg) × dose (mg/kg) = total dose (mg). The nurse must verify this calculation independently and use a second check for high-alert medications.`,
        optionRationales: {
          a: 'Correct. Weight × dose per kg gives the correct total dose.',
          b: 'Doubling the result is a calculation error.',
          c: 'Halving the result is a calculation error.',
          d: 'Adding instead of multiplying is a calculation error.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A client receiving ${pickMed(n)} develops ${pickSymptom(n)}. The nurse reviews the medication administration record and notes the client is also taking ${pickMed(n + 5)}. What should the nurse suspect?`,
        opts: [
          { id: 'a', label: 'A medication interaction causing the adverse effect' },
          { id: 'b', label: 'An allergic reaction to the first medication only' },
          { id: 'c', label: 'A normal side effect that does not require intervention' },
          { id: 'd', label: 'A client error in self-administration of the medication' },
        ],
        correct: 'a',
        rationale: `When a client taking multiple medications develops new symptoms, the nurse should first suspect a drug interaction. Polypharmacy increases the risk of interactions, and the nurse must assess for additive, synergistic, or antagonistic effects. The provider and pharmacist should be notified to review the medication regimen.`,
        optionRationales: {
          a: 'Correct. New symptoms in a client on multiple medications suggest a drug interaction.',
          b: 'Assuming an allergic reaction without considering interactions is premature.',
          c: 'Dismissing the symptom as normal without investigation is unsafe.',
          d: 'Assuming client error without assessing the situation is inappropriate.',
        },
      }),
    },
  ],
  medsurg: [
    {
      build: (n) => ({
        q: `A client with ${pickCondition(n)} has a ${pickLabValue(n)} that is ${n % 2 === 0 ? 'elevated' : 'decreased'}. Which nursing intervention is most appropriate based on this finding?`,
        opts: [
          { id: 'a', label: 'Document the finding and continue routine monitoring' },
          { id: 'b', label: 'Assess for related symptoms and notify the healthcare provider' },
          { id: 'c', label: 'Immediately administer a prescribed medication to correct the value' },
          { id: 'd', label: 'Reassure the client that the value is within normal limits' },
        ],
        correct: 'b',
        rationale: `When a lab value is abnormal, the nurse should assess for related clinical symptoms and notify the provider. Lab values must be interpreted in the context of the client's clinical presentation. Treating a number without assessing the client can lead to inappropriate interventions.`,
        optionRationales: {
          a: 'Documenting without further action is insufficient for an abnormal lab value.',
          b: 'Correct. Assessment for related symptoms and provider notification ensure safe management of abnormal results.',
          c: 'Administering medication before provider notification is outside the nurse\'s scope.',
          d: 'Reassuring the client about an abnormal value is misleading and unsafe.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A ${55 + (n % 35)}-year-old client with ${pickCondition(n)} is scheduled for ${pickProcedure(n)}. Which preoperative assessment finding requires immediate follow-up?`,
        opts: [
          { id: 'a', label: 'Blood pressure of ${135}/${85} mmHg' },
          { id: 'b', label: 'An allergy to latex reported during the assessment' },
          { id: 'c', label: 'A history of mild osteoarthritis' },
          { id: 'd', label: 'A resting heart rate of 72 bpm' },
        ],
        correct: 'b',
        rationale: `A latex allergy reported during preoperative assessment requires immediate follow-up because the operating room contains many latex-containing products. The surgical team must be notified to ensure a latex-free environment is prepared. This is a safety-critical finding that must be addressed before surgery proceeds.`,
        optionRationales: {
          a: 'A mildly elevated blood pressure requires monitoring but is not as urgent as an allergy.',
          b: 'Correct. A latex allergy requires immediate notification of the surgical team to ensure a latex-free environment.',
          c: 'Osteoarthritis is a chronic condition that does not require immediate preoperative follow-up.',
          d: 'A normal heart rate does not require follow-up.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A client recovering from ${pickProcedure(n)} on postoperative day ${1 + (n % 5)} reports ${pickSymptom(n)}. What should the nurse do first?`,
        opts: [
          { id: 'a', label: 'Assess the surgical site and surrounding area' },
          { id: 'b', label: 'Administer prescribed pain medication immediately' },
          { id: 'c', label: 'Encourage the client to ambulate to promote circulation' },
          { id: 'd', label: 'Document the finding and reassess in one hour' },
        ],
        correct: 'a',
        rationale: `The nurse should first assess the surgical site when a postoperative client reports new symptoms. This assessment helps determine whether the symptom is related to the surgical site, such as infection, dehiscence, or hematoma. Assessment guides all subsequent interventions and ensures timely identification of complications.`,
        optionRationales: {
          a: 'Correct. Assessing the surgical site is the priority when new postoperative symptoms arise.',
          b: 'Pain medication may mask symptoms; assessment must come first.',
          c: 'Ambulation is premature without assessment of the symptom.',
          d: 'Waiting one hour to reassess delays evaluation of a potential complication.',
        },
      }),
    },
  ],
  pediatrics: [
    {
      build: (n) => ({
        q: `A ${4 + (n % 8)}-year-old child is hospitalized and the parents must leave for work. Which intervention by the nurse best supports the child\'s emotional needs?`,
        opts: [
          { id: 'a', label: 'Encourage the parents to leave quickly without saying goodbye' },
          { id: 'b', label: 'Allow the child to keep a personal item from home and establish a consistent routine' },
          { id: 'c', label: 'Minimize interaction with the child to promote independence' },
          { id: 'd', label: 'Explain that crying is not helpful and the parents will return soon' },
        ],
        correct: 'b',
        rationale: `Allowing the child to keep a personal item from home and establishing a consistent routine provides comfort and security during hospitalization. Familiar objects reduce anxiety, and predictable routines help the child feel safe. This approach supports the child's emotional needs during separation from parents.`,
        optionRationales: {
          a: 'Leaving without saying goodbye increases anxiety and erodes trust.',
          b: 'Correct. A personal item and consistent routine provide comfort and security during hospitalization.',
          c: 'Minimizing interaction increases anxiety and does not support emotional needs.',
          d: 'Dismissing the child\'s feelings is non-therapeutic and does not provide emotional support.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A nurse is assessing a ${6 + (n % 6)}-month-old infant during a well-child visit. Which finding should the nurse report to the provider?`,
        opts: [
          { id: 'a', label: 'The infant can sit with support and babbles' },
          { id: 'b', label: 'The infant has not yet developed a pincer grasp' },
          { id: 'c', label: 'The infant shows no interest in rolling over or bearing weight on legs' },
          { id: 'd', label: 'The infant has two erupted teeth' },
        ],
        correct: 'c',
        rationale: `By 6 months, infants should be rolling over and beginning to bear weight on their legs when supported. Lack of interest in these motor milestones may indicate a developmental delay and should be reported to the provider for further evaluation. The other findings are normal for this age.`,
        optionRationales: {
          a: 'Sitting with support and babbling are normal developmental milestones for a 6-month-old.',
          b: 'The pincer grasp develops around 9-10 months; its absence at 6 months is normal.',
          c: 'Correct. Not rolling over or bearing weight by 6 months may indicate a developmental delay.',
          d: 'Two erupted teeth by 6 months is within normal limits.',
        },
      }),
    },
  ],
  mentalhealth: [
    {
      build: (n) => ({
        q: `A client with ${pickPsychCondition(n)} is exhibiting ${pickBehavior(n)}. Which nursing intervention is most appropriate?`,
        opts: [
          { id: 'a', label: 'Set firm, consistent limits and provide a safe, structured environment' },
          { id: 'b', label: 'Allow the behavior to run its course without intervention' },
          { id: 'c', label: 'Confront the client about the inappropriateness of the behavior' },
          { id: 'd', label: 'Isolate the client immediately in a seclusion room' },
        ],
        correct: 'a',
        rationale: `Setting firm, consistent limits and providing a safe, structured environment is the most appropriate intervention for behavioral disturbances. This approach maintains safety while preserving the client's dignity. Confrontation and isolation should be avoided unless there is an immediate safety risk that cannot be managed with less restrictive measures.`,
        optionRationales: {
          a: 'Correct. Firm, consistent limits in a structured environment maintain safety and dignity.',
          b: 'Allowing unsafe behavior to continue without intervention is negligent.',
          c: 'Confrontation can escalate the behavior and is non-therapeutic.',
          d: 'Seclusion is a last resort and is not appropriate as a first-line intervention.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A nurse is leading a group therapy session when a client with ${pickPsychCondition(n)} begins to dominate the conversation. Which action by the nurse is most appropriate?`,
        opts: [
          { id: 'a', label: 'Ask the client to leave the group session' },
          { id: 'b', label: 'Acknowledge the client\'s input and redirect the conversation to include others' },
          { id: 'c', label: 'Allow the client to continue speaking to avoid confrontation' },
          { id: 'd', label: 'Tell the client they are talking too much' },
        ],
        correct: 'b',
        rationale: `Acknowledging the client's contribution and redirecting the conversation to include others is the most therapeutic approach. This validates the client while ensuring all group members have the opportunity to participate. It maintains the therapeutic environment without shaming or excluding anyone.`,
        optionRationales: {
          a: 'Asking the client to leave is overly punitive and disrupts the therapeutic environment.',
          b: 'Correct. Acknowledging and redirecting validates the client while ensuring group participation.',
          c: 'Allowing domination prevents other group members from participating and is not therapeutic.',
          d: 'Directly telling the client they talk too much is confrontational and non-therapeutic.',
        },
      }),
    },
  ],
  ob: [
    {
      build: (n) => ({
        q: `A client at ${36 + (n % 4)} weeks gestation presents with ${pickObsSymptom(n)} and a blood pressure of ${150 + (n % 20)}/${95 + (n % 15)} mmHg. What is the nurse's priority action?`,
        opts: [
          { id: 'a', label: 'Assess for other signs of preeclampsia and notify the provider immediately' },
          { id: 'b', label: 'Document the findings and schedule a follow-up in one week' },
          { id: 'c', label: 'Advise the client to rest at home and monitor her blood pressure' },
          { id: 'd', label: 'Administer the client\'s prescribed antihypertensive and reassess' },
        ],
        correct: 'a',
        rationale: `A pregnant client at 36+ weeks with elevated blood pressure and concerning symptoms requires immediate assessment for preeclampsia and provider notification. Preeclampsia can progress rapidly to eclampsia and is a life-threatening condition. Delaying evaluation or treating without provider input endangers both the client and fetus.`,
        optionRationales: {
          a: 'Correct. Immediate assessment for preeclampsia and provider notification are the priority.',
          b: 'Delaying follow-up for one week is dangerous with these findings.',
          c: 'Home monitoring is inappropriate for a client with signs of preeclampsia.',
          d: 'Administering medication without provider notification delays definitive management.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A newborn is delivered at ${36 + (n % 4)} weeks gestation. Which assessment finding requires immediate intervention by the nurse?`,
        opts: [
          { id: 'a', label: 'Acrocyanosis of the hands and feet' },
          { id: 'b', label: 'A respiratory rate of 40 breaths per minute' },
          { id: 'c', label: 'Nasal flaring and grunting with each breath' },
          { id: 'd', label: 'A heart rate of 130 beats per minute' },
        ],
        correct: 'c',
        rationale: `Nasal flaring and grunting are signs of respiratory distress in a newborn and require immediate intervention. These findings may indicate respiratory distress syndrome, especially in a late-preterm infant. The nurse must initiate interventions to support the newborn's airway and breathing and notify the provider immediately.`,
        optionRationales: {
          a: 'Acrocyanosis is normal in the first 24-48 hours of life.',
          b: 'A respiratory rate of 40 is within the normal range for a newborn (30-60 bpm).',
          c: 'Correct. Nasal flaring and grunting are signs of respiratory distress requiring immediate intervention.',
          d: 'A heart rate of 130 bpm is within the normal range for a newborn (100-160 bpm).',
        },
      }),
    },
  ],
  fundamentals: [
    {
      build: (n) => ({
        q: `A nurse is caring for a client with a ${pickDevice(n)}. Which action is essential to prevent complications?`,
        opts: [
          { id: 'a', label: 'Perform hand hygiene before and after handling the device' },
          { id: 'b', label: 'Secure the device tightly to prevent dislodgement' },
          { id: 'c', label: 'Replace the device only when it becomes visibly soiled' },
          { id: 'd', label: 'Use the same device for multiple clients if cleaned between uses' },
        ],
        correct: 'a',
        rationale: `Hand hygiene before and after handling any device is essential to prevent healthcare-associated infections. This is the most fundamental and effective measure for preventing the transmission of pathogens. Proper hand hygiene must be performed regardless of whether gloves are worn.`,
        optionRationales: {
          a: 'Correct. Hand hygiene before and after device handling is the most effective infection prevention measure.',
          b: 'Over-tightening devices can cause tissue damage and impaired circulation.',
          c: 'Devices should be changed per facility protocol, not only when visibly soiled.',
          d: 'Reusing devices between clients is unsafe and violates infection control standards.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A nurse is documenting care in a client's electronic health record. Which documentation practice is most appropriate?`,
        opts: [
          { id: 'a', label: 'Document care at the end of the shift from memory to save time' },
          { id: 'b', label: 'Document care contemporaneously, using factual, objective, and specific language' },
          { id: 'c', label: 'Use abbreviations freely to save space and time' },
          { id: 'd', label: 'Document care that was performed by another nurse under your name' },
        ],
        correct: 'b',
        rationale: `Contemporaneous documentation using factual, objective, and specific language is the gold standard. Documenting in real time ensures accuracy and completeness. Late entries, subjective interpretations, unapproved abbreviations, and documenting others' actions under your name are all inappropriate and potentially unsafe practices.`,
        optionRationales: {
          a: 'Documenting from memory at end of shift leads to errors and omissions.',
          b: 'Correct. Real-time, factual, objective documentation is the standard of practice.',
          c: 'Only approved abbreviations should be used; unapproved abbreviations can cause errors.',
          d: 'Documenting another nurse\'s actions under your name is fraudulent.',
        },
      }),
    },
  ],
};

const LAB_VALUES = ['serum potassium', 'serum sodium', 'serum creatinine', 'hemoglobin', 'white blood cell count', 'blood glucose', 'arterial blood gas pH', 'serum calcium'];
const PROCEDURES = ['a colonoscopy', 'an appendectomy', 'a cholecystectomy', 'a hip replacement', 'a coronary angioplasty', 'a laparoscopic procedure', 'a mastectomy', 'a thyroidectomy'];
const BEHAVIORS = ['agitation and pacing', 'verbal aggression toward staff', 'social withdrawal and refusal to eat', 'disorganized speech and thought patterns', 'repetitive hand washing', 'elevated mood with decreased need for sleep'];
const DEVICES = ['urinary catheter', 'central venous catheter', 'nasogastric tube', 'wound drain', 'peripheral IV line', 'tracheostomy', 'chest tube'];

function pickLabValue(n) { return LAB_VALUES[n % LAB_VALUES.length]; }
function pickProcedure(n) { return PROCEDURES[n % PROCEDURES.length]; }
function pickBehavior(n) { return BEHAVIORS[n % BEHAVIORS.length]; }
function pickDevice(n) { return DEVICES[n % DEVICES.length]; }

// More templates for even more variety
const EXTRA_TEMPLATES = {
  pharmacology: [
    {
      build: (n) => ({
        q: `A nurse is preparing to administer ${pickMed(n)} IV push. Which technique is correct for safe IV push administration?`,
        opts: [
          { id: 'a', label: 'Administer the medication rapidly to achieve peak effect quickly' },
          { id: 'b', label: 'Verify the rate of administration per the drug reference and administer slowly over the recommended time' },
          { id: 'c', label: 'Dilute all IV push medications in 100 mL of normal saline' },
          { id: 'd', label: 'Administer the medication through the most proximal port without flushing' },
        ],
        correct: 'b',
        rationale: `IV push medications must be administered at the rate specified in the drug reference. Some medications cause serious adverse effects if given too rapidly, such as hypotension, cardiac arrest, or vein irritation. The nurse must verify the recommended rate, use the correct port, and flush before and after administration.`,
        optionRationales: {
          a: 'Rapid IV push can cause serious adverse effects including cardiac arrest.',
          b: 'Correct. Verifying and following the recommended rate of administration is essential for IV push safety.',
          c: 'Not all medications should be diluted; some are given as supplied.',
          d: 'Using the most proximal port without flushing can cause drug interactions in the line.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `An older adult client is prescribed ${pickMed(n)}. Which age-related consideration should the nurse prioritize when monitoring this client?`,
        opts: [
          { id: 'a', label: 'Older adults metabolize medications faster, so higher doses are needed' },
          { id: 'b', label: 'Older adults have decreased renal and hepatic function, increasing the risk of drug accumulation and toxicity' },
          { id: 'c', label: 'Older adults are less sensitive to medication side effects' },
          { id: 'd', label: 'Medication interactions are less common in older adults' },
        ],
        correct: 'b',
        rationale: `Older adults have decreased renal and hepatic function, which slows medication metabolism and excretion. This increases the risk of drug accumulation and toxicity. The nurse should monitor for adverse effects more closely, advocate for lower starting doses when appropriate, and assess for polypharmacy-related interactions.`,
        optionRationales: {
          a: 'Older adults metabolize medications more slowly, not faster.',
          b: 'Correct. Decreased renal and hepatic function increases the risk of drug accumulation and toxicity in older adults.',
          c: 'Older adults are often more sensitive to medication effects, not less.',
          d: 'Medication interactions are more common in older adults due to polypharmacy.',
        },
      }),
    },
  ],
  medsurg: [
    {
      build: (n) => ({
        q: `A client with ${pickCondition(n)} is receiving oxygen via nasal cannula at ${2 + (n % 4)} L/min. The client's oxygen saturation drops from 95% to 88%. What should the nurse do first?`,
        opts: [
          { id: 'a', label: 'Increase the oxygen flow rate to 6 L/min' },
          { id: 'b', label: 'Assess the client\'s respiratory effort, airway, and oxygen delivery system' },
          { id: 'c', label: 'Call a code blue and begin CPR' },
          { id: 'd', label: 'Document the finding and reassess in 15 minutes' },
        ],
        correct: 'b',
        rationale: `When oxygen saturation drops, the nurse must first assess the client's respiratory effort, airway patency, and the oxygen delivery system. The drop may be due to a dislodged cannula, mucous plugging, or respiratory depression. Assessment identifies the cause and guides the intervention. Increasing oxygen without assessment may mask a serious problem.`,
        optionRationales: {
          a: 'Increasing oxygen without assessment may mask the underlying cause.',
          b: 'Correct. Assessment of airway, breathing, and the delivery system is the first priority.',
          c: 'A code blue is premature unless the client is unresponsive and not breathing.',
          d: 'Waiting 15 minutes to reassess delays intervention for a significant desaturation.',
        },
      }),
    },
    {
      build: (n) => ({
        q: `A client with ${pickCondition(n)} has a nasogastric tube connected to low intermittent suction. Which finding indicates the tube is functioning properly?`,
        opts: [
          { id: 'a', label: 'The client complains of nausea and abdominal distension' },
          { id: 'b', label: 'Gastric contents are visible in the suction container and the client\'s abdomen is soft and non-distended' },
          { id: 'c', label: 'The suction machine alarm is continuously sounding' },
          { id: 'd', label: 'No drainage has been noted in the container for 8 hours' },
        ],
        correct: 'b',
        rationale: `Gastric contents in the suction container and a soft, non-distended abdomen indicate the nasogastric tube is functioning properly. The tube is decompressing the stomach as intended. Nausea, distension, continuous alarms, and absence of drainage all suggest a problem with the tube or suction system.`,
        optionRationales: {
          a: 'Nausea and distension suggest the tube is not functioning properly.',
          b: 'Correct. Drainage and a non-distended abdomen indicate proper tube function.',
          c: 'A continuously sounding alarm suggests an obstruction or disconnection.',
          d: 'No drainage for 8 hours may indicate tube displacement or blockage.',
        },
      }),
    },
  ],
  pediatrics: [
    {
      build: (n) => ({
        q: `A ${5 + (n % 7)}-year-old child is receiving IV fluids. The IV pump alarm sounds. What should the nurse do first?`,
        opts: [
          { id: 'a', label: 'Silence the alarm and increase the flow rate' },
          { id: 'b', label: 'Assess the IV site and the pump to determine the cause of the alarm' },
          { id: 'c', label: 'Disconnect the IV and restart it in another site immediately' },
          { id: 'd', label: 'Turn off the pump and notify the healthcare provider' },
        ],
        correct: 'b',
        rationale: `When an IV pump alarm sounds, the nurse should first assess the IV site and the pump to determine the cause. Common causes include occlusion, air in the line, an empty bag, or infiltration. Assessment identifies the problem and guides the appropriate intervention, such as repositioning, replacing the bag, or restarting the IV.`,
        optionRationales: {
          a: 'Silencing the alarm without assessment is unsafe and may harm the child.',
          b: 'Correct. Assessment of the IV site and pump is the first step in responding to an alarm.',
          c: 'Restarting the IV is premature without first assessing the cause.',
          d: 'Turning off the pump and calling the provider is unnecessary; the nurse can troubleshoot the alarm.',
        },
      }),
    },
  ],
  mentalhealth: [
    {
      build: (n) => ({
        q: `A client with ${pickPsychCondition(n)} has been taking an antipsychotic medication for ${1 + (n % 8)} weeks. The nurse observes the client pacing, restless, and unable to sit still. What should the nurse suspect?`,
        opts: [
          { id: 'a', label: 'Worsening of the underlying psychiatric condition' },
          { id: 'b', label: 'Akathisia, a medication-induced movement disorder' },
          { id: 'c', label: 'Attention-seeking behavior' },
          { id: 'd', label: 'Caffeine withdrawal' },
        ],
        correct: 'b',
        rationale: `Akathisia is a common extrapyramidal side effect of antipsychotic medications, characterized by inner restlessness and an inability to sit still. It typically develops within days to weeks of starting or increasing the medication. The nurse should recognize this as a medication side effect, not a worsening of the psychiatric condition, and notify the provider for possible medication adjustment.`,
        optionRationales: {
          a: 'Restlessness from akathisia is often mistaken for worsening psychiatric symptoms, but it is a medication side effect.',
          b: 'Correct. Pacing and restlessness after starting an antipsychotic suggest akathisia.',
          c: 'Attributing the behavior to attention-seeking dismisses a significant medication side effect.',
          d: 'Caffeine withdrawal is not a likely cause of these symptoms in this context.',
        },
      }),
    },
  ],
  ob: [
    {
      build: (n) => ({
        q: `A nurse is performing a postpartum assessment on a client who delivered ${12 + (n % 48)} hours ago. Which finding requires immediate intervention?`,
        opts: [
          { id: 'a', label: 'The fundus is firm, midline, and at the level of the umbilicus' },
          { id: 'b', label: 'Lochia rubra with a moderate amount of flow and small clots' },
          { id: 'c', label: 'The fundus is deviated to the right and boggy with heavy lochia' },
          { id: 'd', label: 'Perineal edema and mild discomfort' },
        ],
        correct: 'c',
        rationale: `A deviated, boggy fundus with heavy lochia indicates uterine atony, the leading cause of postpartum hemorrhage. The nurse must immediately massage the fundus to stimulate contraction, empty the bladder if distended, and notify the provider. Uterine atony requires prompt intervention to prevent life-threatening hemorrhage.`,
        optionRationales: {
          a: 'A firm, midline fundus at the umbilicus is a normal postpartum finding.',
          b: 'Moderate lochia rubra with small clots is normal in the first few days postpartum.',
          c: 'Correct. A deviated, boggy fundus with heavy lochia indicates uterine atony and requires immediate intervention.',
          d: 'Perineal edema and mild discomfort are common postpartum findings.',
        },
      }),
    },
  ],
  fundamentals: [
    {
      build: (n) => ({
        q: `A nurse is caring for a client who is ${n % 2 === 0 ? 'NPO for a procedure' : 'on a clear liquid diet'}. Which intervention is most important to prevent complications?`,
        opts: [
          { id: 'a', label: 'Provide frequent oral care to maintain mucosal integrity' },
          { id: 'b', label: 'Restrict all oral intake including ice chips' },
          { id: 'c', label: 'Encourage the client to ambulate frequently' },
          { id: 'd', label: 'Administer a daily multivitamin' },
        ],
        correct: 'a',
        rationale: `Frequent oral care is the most important intervention for NPO or restricted-diet clients to prevent mucosal dryness, breakdown, and infection. The mouth becomes dry when oral intake is restricted, leading to discomfort and increased risk of parotitis. Oral care maintains mucosal integrity and client comfort.`,
        optionRationales: {
          a: 'Correct. Frequent oral care prevents mucosal dryness and breakdown in NPO clients.',
          b: 'Ice chips may be allowed per provider order; total restriction is not always necessary.',
          c: 'Ambulation is important for other reasons but does not address the oral mucosa.',
          d: 'A multivitamin does not address the immediate risk of mucosal breakdown.',
        },
      }),
    },
  ],
};

// ============================================================
// QUESTION GENERATION
// ============================================================

function getDifficulty(n, total) {
  const pct = n / total;
  if (pct < 0.3) return 'easy';
  if (pct < 0.8) return 'medium';
  return 'hard';
}

function generateQuestionsForSubject(subjectKey, count, startN) {
  const subject = SUBJECTS[subjectKey];
  const topics = TOPIC_BANKS[subjectKey];
  const templates = [
    ...(SCENARIO_TEMPLATES[subjectKey] || []),
    ...(ADDITIONAL_TEMPLATES[subjectKey] || []),
    ...(EXTRA_TEMPLATES[subjectKey] || []),
  ];

  const questions = [];
  for (let i = 0; i < count; i++) {
    const n = startN + i;
    const template = templates[i % templates.length];
    const topic = topics[i % topics.length];
    const difficulty = getDifficulty(i, count);

    const built = template.build(n);
    const id = `${subject.prefix}-${String(n).padStart(4, '0')}`;

    questions.push({
      id,
      question: built.q,
      subject_id: subject.id,
      subject_name: subject.name,
      category: topic,
      topic,
      difficulty,
      question_type: 'multiple-choice',
      options: built.opts,
      correct_answer: [built.correct],
      rationale: built.rationale,
      option_rationales: built.optionRationales,
      key_takeaway: built.rationale.split('.')[0] + '.',
      nclex_tip: '',
      clinical_pearl: '',
      reference: '',
      tags: [subject.name.toLowerCase(), topic.toLowerCase(), difficulty],
      is_ngn: false,
    });
  }
  return questions;
}

function generateMixedQuestions(count, startN) {
  const topics = MIXED_TOPICS;
  const allSubjects = Object.keys(SUBJECTS);
  const allTemplates = [];
  for (const s of allSubjects) {
    for (const t of [...(SCENARIO_TEMPLATES[s] || []), ...(ADDITIONAL_TEMPLATES[s] || []), ...(EXTRA_TEMPLATES[s] || [])]) {
      allTemplates.push({ subject: s, template: t });
    }
  }

  const questions = [];
  for (let i = 0; i < count; i++) {
    const n = startN + i;
    const { subject: subjectKey, template } = allTemplates[i % allTemplates.length];
    const subject = SUBJECTS[subjectKey];
    const topic = topics[i % topics.length];
    const difficulty = getDifficulty(i, count);

    const built = template.build(n + 1000); // offset to avoid overlap
    const id = `MIXED-${String(n).padStart(4, '0')}`;

    questions.push({
      id,
      question: built.q,
      subject_id: subject.id,
      subject_name: subject.name,
      category: 'Mixed Practice',
      topic,
      difficulty,
      question_type: 'multiple-choice',
      options: built.opts,
      correct_answer: [built.correct],
      rationale: built.rationale,
      option_rationales: built.optionRationales,
      key_takeaway: built.rationale.split('.')[0] + '.',
      nclex_tip: '',
      clinical_pearl: '',
      reference: '',
      tags: ['mixed', topic.toLowerCase(), difficulty],
      is_ngn: false,
    });
  }
  return questions;
}

// ============================================================
// SQL GENERATION
// ============================================================

function escapeSql(str) {
  if (!str) return '';
  return str.replace(/'/g, "''");
}

function questionToSql(q) {
  const optionsJson = JSON.stringify(q.options).replace(/'/g, "''");
  const correctAnswerJson = JSON.stringify(q.correct_answer).replace(/'/g, "''");
  const optionRationalesJson = JSON.stringify(q.option_rationales).replace(/'/g, "''");
  const tagsArray = q.tags.map(t => `'${escapeSql(t)}'`).join(',');

  return `('${escapeSql(q.id)}', '${escapeSql(q.question)}', '${escapeSql(q.subject_id)}', '${escapeSql(q.subject_name)}', '${escapeSql(q.category)}', '${escapeSql(q.topic)}', '${escapeSql(q.difficulty)}', '${escapeSql(q.question_type)}', '${optionsJson}'::jsonb, '${correctAnswerJson}'::jsonb, '${escapeSql(q.rationale)}', '${optionRationalesJson}'::jsonb, '${escapeSql(q.key_takeaway)}', '${escapeSql(q.nclex_tip)}', '${escapeSql(q.clinical_pearl)}', '${escapeSql(q.reference)}', ARRAY[${tagsArray}], ${q.is_ngn})`;
}

// ============================================================
// MAIN
// ============================================================

const allQuestions = [];

// Generate 500 per subject
for (const subjectKey of Object.keys(SUBJECTS)) {
  const qs = generateQuestionsForSubject(subjectKey, 500, 1);
  allQuestions.push(...qs);
}

// Generate 500 mixed
const mixedQs = generateMixedQuestions(500, 1);
allQuestions.push(...mixedQs);

// Output SQL in batches of 50
const BATCH_SIZE = 50;
let output = '';
for (let i = 0; i < allQuestions.length; i += BATCH_SIZE) {
  const batch = allQuestions.slice(i, i + BATCH_SIZE);
  const values = batch.map(questionToSql).join(',\n');
  output += `INSERT INTO questions (id, question, subject_id, subject_name, category, topic, difficulty, question_type, options, correct_answer, rationale, option_rationales, key_takeaway, nclex_tip, clinical_pearl, reference, tags, is_ngn) VALUES\n${values};\n\n`;
}

process.stdout.write(output);
console.error(`Generated ${allQuestions.length} questions total`);
